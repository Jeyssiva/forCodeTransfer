// export const FieldPriorityHeader = {
//     saaHeader: {
//         isApplicable: true,
//         Header: {
//             isApplicable: true,
//             ChoiceType: {_text: 'Message'},
//             Message: {
//                 isApplicable: true,
//                 SenderReference: {
//                     isMandatory : true, isApplicable: true, isDisabled: false
//                 },
//                 MessageIdentifier : {
//                     isMandatory : true, isApplicable: true, isDisabled: false
//                 },
//                 Format : {
//                     isMandatory : true, isApplicable: true, isDisabled: false
//                 },
//                 SubFormat : {
//                     isMandatory : true, isApplicable: true, isDisabled: false
//                 },
//                 Sender : {
//                     isApplicable: true,
//                     ChoiceType: {_text: 'DN'},
//                     DN: {
//                         isMandatory : true, isApplicable: true, isDisabled: false
//                     },
//                     FullName: {
//                         X1: {
//                             isMandatory : true, isApplicable: true, isDisabled: false
//                         }
//                     }
//                 },
//                 Receiver: {
//                     isApplicable: true,
//                     ChoiceType: {_text: 'DN'},
//                     DN: {
//                         isMandatory : true, isApplicable: true, isDisabled: false
//                     },
//                     FullName: {
//                         X1: {
//                             isMandatory : true, isApplicable: true, isDisabled: false
//                         }
//                     }
//                 },
//                 SecurityInfo: {
//                     isApplicable : false
//                 },
//                 NetworkInfo: {
//                     isApplicable: true,
//                     FINNetworkInfo : {
//                         isApplicable: false
//                     },
//                     SWIFTNetNetworkInfo: {
//                         isApplicable: false
//                     },
//                     "xs:choice": {
//                         isApplicable: false
//                     },
//                     Service: {
//                         isMandatory : true,
//                         isApplicable: true,
//                         isDisabled: false
//                     }
//                 }
//             },
//             TransmissionReport: {
//                 isApplicable: false,
//                 NetworkInfo: {
//                     FINNetworkInfo : {
//                         isApplicable: false
//                     },
//                     SWIFTNetNetworkInfo: {
//                         isApplicable: false
//                     },
//                     "xs:choice": {
//                         isApplicable: false
//                     }
//                 },
//                 Message: {
//                     NetworkInfo: {
//                         FINNetworkInfo : {
//                             isApplicable: false
//                         },
//                         SWIFTNetNetworkInfo: {
//                             isApplicable: false
//                         },
//                         "xs:choice": {
//                             isApplicable: false
//                         }
//                     }
//                 }
//             },
//             DeliveryNotification: {
//                 isApplicable: false,
//                 SecurityInfo: {
//                     isApplicable : false
//                 },
//                 NetworkInfo: {
//                     FINNetworkInfo : {
//                         isApplicable: false
//                     },
//                     SWIFTNetNetworkInfo: {
//                         isApplicable: false
//                     },
//                     "xs:choice": {
//                         isApplicable: false
//                     }
//                 }
//             },
//             DeliveryReport: {
//                 isApplicable: false,
//                 SecurityInfo: {
//                     isApplicable : false
//                 },
//                 NetworkInfo: {
//                     FINNetworkInfo : {
//                         isApplicable: false
//                     },
//                     SWIFTNetNetworkInfo: {
//                         isApplicable: false
//                     },
//                     "xs:choice": {
//                         isApplicable: false
//                     }
//                 },
//                 Message: {
//                     SecurityInfo: {
//                         isApplicable : false
//                     },
//                     NetworkInfo: {
//                         FINNetworkInfo : {
//                             isApplicable: false
//                         },
//                         SWIFTNetNetworkInfo: {
//                             isApplicable: false
//                         },
//                         "xs:choice": {
//                             isApplicable: false
//                         }
//                     }
//                 }
//             },
//             HistoryReport: {
//                 isApplicable: false,
//                 Message: {
//                     SecurityInfo: {
//                         isApplicable : false
//                     },
//                     NetworkInfo: {
//                         FINNetworkInfo : {
//                             isApplicable: false
//                         },
//                         SWIFTNetNetworkInfo: {
//                             isApplicable: false
//                         },
//                         "xs:choice": {
//                             isApplicable: false
//                         }
//                     }
//                 }
//             }
//         }
//     }
// }