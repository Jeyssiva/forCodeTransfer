export const TRANS_TYPE = [
    {label: 'In', value: 'I'},
    {label: 'Out', value: 'O'}
]

export const TEMPLATE_SELECTION = [
    { label: 'PACS.008', value:'MT_XML_ISO_103', biz: 'STD', enqType: 'B2C', bodyMainSectionName: 'FIToFICstmrCdtTrf'},
    { label: 'PACS.009', value: 'MT_XML_ISO_202', biz: 'STD', enqType: 'B2B', bodyMainSectionName: 'FICdtTrf'},
    { label: 'PACS.009Cov', value: 'MT_XML_ISO_202_COV', biz: 'COV', enqType: 'B2B', bodyMainSectionName: 'FICdtTrf'}
]

export const GET_DEFAULT_VALUES = [
    { value:'MT_XML_ISO_103', queryName: 'GBR_O_103_STRUCT_STD' },
    { value: 'MT_XML_ISO_202', queryName: 'GBR_O_202_STRUCT_STD' },
    { value: 'MT_XML_ISO_202_COV', queryName: 'GBR_O_202_STRUCT_COV' }
]

export const GET_ELEMENT_ATTRIBUTES = [
    { value:'MT_XML_ISO_103', queryName: 'GBR_O_103_ELEM_STD' },
    { value: 'MT_XML_ISO_202', queryName: 'GBR_O_202_ELEM_STD' },
    { value: 'MT_XML_ISO_202_COV', queryName: 'GBR_O_202_ELEM_COV' }
]

export const GET_SCHEMA_NAMES = {
    'MT_XML_ISO_103' : 'pacs.008',
    'MT_XML_ISO_202' : 'pacs.009',
    'MT_XML_ISO_202_COV' :'pacs.009Cov',
    'MX_MT_ISO_103_PACS_008' : 'pacs.008',
    'MX_MT_ISO_202_PACS_009' : 'pacs.009',
    'MX_MT_ISO_202_COV_PACS_009' : 'pacs.009Cov'
}

export const GET_SUB_TYPE = {
    'MT_XML_ISO_103' : 'b2c',
    'MT_XML_ISO_202' : 'b2b',
    'MT_XML_ISO_202_COV' :'b2b'
}
export const GET_MESSAGE_TYPE = [
    {value: 'B2C', label: 'Bank To Customer'},
    {value: 'B2B', label: 'Bank To Bank'}
]

export const GET_BIZ_TYPE = [
    {value: 'STD', label: 'STD'},
    {value: 'COV', label: 'COV'}
]

export const GET_IDENTIFIER = [
    { label: 'MT_XML_ISO_103', value: 'MT_XML_ISO_103' },
    { label : 'MT_XML_ISO_202', value: 'MT_XML_ISO_202' },
    { label: 'MT_XML_ISO_202_COV', value: 'MT_XML_ISO_202_COV' }
]

export const PACS009COV = 'MT_XML_ISO_202_COV';
export const PACS009 = 'MT_XML_ISO_202';
export const PACS008 = 'MT_XML_ISO_103';

export const INCOMING_PACS009COV = 'MX_MT_ISO_202_COV_PACS_009';
export const INCOMING_PACS009 = 'MX_MT_ISO_202_PACS_009';
export const INCOMING_PACS008 = 'MX_MT_ISO_103_PACS_008';

export const TEMPLATE_REQACTION_SAVE = 'Save';
export const TEMPLATE_REQACTION_UPDATE = 'UpDate';
export const TEMPLATE_REQACTION_INACTIVE = 'InActive';

export const GET_PERSISTED_BODY_SCHEMA_NAMES = {
    'MT_XML_ISO_103' : 'bodySchemaB2CSTDPersist',
    'MT_XML_ISO_202' : 'bodySchemaB2BSTDPersist',
    'MT_XML_ISO_202_COV' :'bodySchemaB2BCoVPersist',
    'MX_MT_ISO_103_PACS_008' : 'bodySchemaB2CSTDPersist',
    'MX_MT_ISO_202_PACS_009' : 'bodySchemaB2BSTDPersist',
    'MX_MT_ISO_202_COV_PACS_009' : 'bodySchemaB2BCoVPersist'
}

export const GET_SECTION_DETAIL_SCHEMA_NAMES = {
    'MT_XML_ISO_103' : 'msgConfigB2CPersist',
    'MT_XML_ISO_202' : 'msgConfigB2BPersist',
    'MT_XML_ISO_202_COV' :'msgConfigB2BCovPersist',
    'MX_MT_ISO_103_PACS_008' : 'msgConfigB2CPersist',
    'MX_MT_ISO_202_PACS_009' : 'msgConfigB2BPersist',
    'MX_MT_ISO_202_COV_PACS_009' : 'msgConfigB2BCovPersist'
}

export const GET_DEFAULT_VALUES_SCHEMA_NAMES = {
    'MT_XML_ISO_103' : 'defaultValuesB2CSTDPersist',
    'MT_XML_ISO_202' : 'defaultValuesB2BSTDPersist',
    'MT_XML_ISO_202_COV' :'defaultValuesB2BCOVPersist'
}
export const INCLUDE_CUSTOMER_FIELDS_DEEP_COMPARE = ['custType','custBankAcNo', 'custNumber', 'shortName', 'custName', 'custId', 'bicCode', 'leiCode', 'gcifCode']
export const INCLUDE_ADDRESS_FIELDS = ['addressType','dept','subDept','streetName','buildingNo','buildingName','floor','postBox','room','postCode','townName','townLocName','districtName','countrySubDv','country','countryName']

export const INCLUDE_BENE_FIELDS_DEEP_COMPARE = ['benId','beneAcNo','beneAcName','beneBicCode','beneLeiCode','beneSortCode','beneIbanNumber'];

export const STATIC_LIST_PERSIST_NAMES = {
    'GBR_COUNTRY_LIST': 'countryListPersist',
    'GBR_CURRENCY_LIST' : 'currencyListPersist',
    'GBR_PURPOSE_ALL' : 'purposeCodesPersist'
}

export const SEARCH_SAVED_TEMPLATES_INITIAL_SEARCH = {
    templateName: '',
    startdateRange: '', enddateRange: '', messageDefID: '', createdBy: '', modifiedBy: '', status: []
  }
