export const CUSTOMER = 'customer';
export const CREDITOR = 'creditor';
export const CREATE_PAYMENT_TABS = [
    {label: 'Customer', value: CUSTOMER}, 
    {label: 'Beneficiaries', value: CREDITOR}
];

export const CUSTOMER_TYPE = [
  { label: 'INDIVIDUAL', value: 'I' },
  { label: 'CORPORATE', value: 'C' }
]

export const ADDRESS_TYPES = [
    {label: 'CORRESPONDENCE', value: 'COR', custType: 'BOTH'}, 
    {label: 'RESIDENTIAL', value: 'RES', custType: 'INDIVIDUAL'}, 
    {label: 'REGISTERED', value: 'REG', custType: 'CORPORATE'}, 
]

export const CREDITOR_TABLE_HEADERS = [
    // {
    //   id: 'creditorId',
    //   label: 'Creditor ID',
    //   numeric: false
    // },
    {
      id: 'creditAccNum',
      label: 'Beneficiary Account Number',
      numeric: false
    },
    {
      id: 'creditorName',
      label: 'Beneficiary Name',
      numeric: false
    },
    {
      id: 'creditorBIC',
      label: 'Beneficiary BIC',
      numeric: false
    },
    {
      id: 'creditorIBAN',
      label: 'IBAN',
      numeric: false
    },
    {
      id: 'creditorSort',
      label: 'Sort Code',
      numeric: false
    },
    {
      id: 'lastUpdatedDate',
      label: 'Last Updated Date (UTC)',
      numeric: false
    },
    {
      id: 'action',
      label: 'Actions',
      numeric: false
    }
  ];

  export const CUSTOMER_NAME_OPTIONS = {label: 'New Customer', value: 'newCustomer'}
  
  export const ACTION_CODES_DISPLAY = {
     'NA' : 'No Changes',
     'U' : 'Updated',
     'A' : "Added",
     'D' : 'Deleted'
  }

  export const PENDING_STATUS = 'pending'
  export const APPROVED_STATUS = 'approved';
  export const RETURNED_STATUS = 'returned';
  
  export const BENE_NAME = 'beneAcName';
  export const BENE_ACC_NUMBER = 'beneAcNo';
  export const BENE_IBAN = 'beneIbanNumber';

  export const BENE_SEARCH_CRITERIA = [{ value: '', label: 'Search All' }, { label: 'Beneficiary Name', value: BENE_NAME }, 
  { label: 'Beneficiary Account Number', value: BENE_ACC_NUMBER }, { label: 'Beneficiary IBAN', value: BENE_IBAN }]

  export const BENE_ACC_NUMBER_PATTERN = /^[a-zA-Z0-9-]+( [a-zA-Z0-9-]+)*$/;
  export const BENE_ACC_NAME_PATTERN = /^(?!^\s)(?!\s$)(?!.*\s{2,})[a-zA-Z0-9/:?().,+!#$&%*=^_'{|}~";@[\] \-\\]+(?<!\s)$/;
  export const BENE_IBAN_PATTERN = /^[A-Za-z]{2,2}[0-9]{2,2}[a-zA-Z0-9]{1,30}$/;
  export const CUST_NAME_PATTERN = /^(?!^\s)(?!\s$)(?!.*\s{2,})[a-zA-Z0-9/:?().,+!#$&%*=^_'{|}~";@[\] \-\\]+(?<!\s)$/;
  export const CUST_BANK_ACC_NUM_PATTERN = /^[a-zA-Z0-9]+( [a-zA-Z0-9]+)*$/;
  export const CUST_SHORT_NAME_PATTERN = /^(?!.* {2})[^ ](?:[a-zA-Z0-9,@\\/().& -]*[^ ])?$/;
  export const ADDRESS_PATTERN = /^(?!.* {2})(?![ ])[a-zA-Z0-9\-\/,()#&@.' ]*(?<![ ])$/;