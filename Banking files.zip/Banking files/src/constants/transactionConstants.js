import moment from "moment";
import { DATE_FORMAT_BACKEND } from "./constants";

export const TODAY_PAYMENT = 'today';
export const PREVIOUS_PAYMENT = 'previous';
export const CREATE_PAYMENT = 'createPayment';
export const SEARCH_PAYMENT = 'search';
export const ALL_PAYMENT = 'all';

// export const PAYMENT_TABS = [
//   { label: 'Today Payments', value: TODAY_PAYMENT },
//   { label: 'Previous Payments', value: PREVIOUS_PAYMENT },
//   { label: 'Search Payments', value: SEARCH_PAYMENT}
// ];

export const TRANSTYPE_PAYMENT_TABS = [
  { label: 'Today Payments', value: TODAY_PAYMENT },
  { label: 'Previous Payments', value: PREVIOUS_PAYMENT },
  { label: 'Search Payments', value: SEARCH_PAYMENT}
];

export const OUTGOING_STATEMENT_TABS = [
  { label: 'Today Statements', value: TODAY_PAYMENT },
  { label: 'Previous Statements', value: PREVIOUS_PAYMENT },
  { label: 'Search Statements', value: SEARCH_PAYMENT }
];

export const OUTGOING_TAB_DATE_CATEGORY = [
  { value: TODAY_PAYMENT, 
    startdateRange : `${moment().format(DATE_FORMAT_BACKEND)} 00:00:00.000`, 
    enddateRange : `${moment().format(DATE_FORMAT_BACKEND)} 23:59:59.000`,
    lookUpOn: 'current'
  },
  {
    value: PREVIOUS_PAYMENT,
    startdateRange: `${moment().subtract(60, "days").format(DATE_FORMAT_BACKEND)} 00:00:00.000`,
    enddateRange : `${moment().subtract(1, "days").format(DATE_FORMAT_BACKEND)} 23:59:59.000`,
    lookUpOn: 'current'
  },
  {
    value: SEARCH_PAYMENT,
    startdateRange:  `${moment().subtract(1, "year").format(DATE_FORMAT_BACKEND)} 00:00:00.000`,
    enddateRange : `${moment().subtract(61, "days").format(DATE_FORMAT_BACKEND)} 23:59:59.000`,
    lookUpOn: 'archive'
  }
]

export const MAKER_USERGROUPS = ['ISO_MAKER', 'ISO_MAKER_B2B', 'ISO_MAKER_B2C', 'ISO_MAKER_CHECKER',
  'ISO_MKR_CHKR_B2B', 'ISO_MKR_CHKR_B2C', 'ISO_OFFICER', 'ISO_COUNTRY_ADMIN']

export const CHECKER_USERGROUPS = ['ISO_CHECKER', 'ISO_CHECKER_B2B', 'ISO_CHECKER_B2C', 'ISO_MAKER_CHECKER',
  'ISO_MKR_CHKR_B2B', 'ISO_MKR_CHKR_B2C', 'ISO_OFFICER', 'ISO_COUNTRY_ADMIN']

export const ADMIN_USERGROUPS = ['ISO_USERADMIN', 'RTS_USERADMIN', 'ISO_COUNTRY_ADMIN']

export const COUNTRY_ADMIN_ROLE = 'ISO_COUNTRY_ADMIN'

export const MSG_STATUS = {
  'pendingApproval': 'Pending Approval',
  'draft': 'Draft',
  'draftReturn': 'Draft Returned'
}

export const OUTCOMING_TABLE_HEADERS = [
  {
    id: 'refNmber',
    label: 'Reference Number',
    numeric: false
  },
  {
    id: 'msgStatus',
    label: 'Message Status',
    numeric: false
  },
  {
    id: 'mode',
    label: 'Mode',
    numeric: false
  },
  {
    id: 'senderBIC',
    label: 'Sender BIC',
    numeric: false
  },
  {
    id: 'creationDate',
    label: 'Creation Date (UTC)',
    numeric: false
  },
  {
    id: 'lastActivityData',
    label: 'Last Activity Date (UTC)',
    numeric: false
  },
  {
    id: 'ackDate',
    label: 'Acknowledgement Date (UTC)',
    numeric: false
  },
  {
    id: 'mxTemplate',
    label: 'MX/MT *',
    numeric: false
  },
  {
    id: 'amt',
    label: 'Amount',
    numeric: true
  },
  {
    id: 'currency',
    label: 'Currency',
    numeric: false
  },
  // { id: 'requestor', 
  //   label: 'Requestor', 
  //   numeric: false,
  //   hidden: true}
];

export const INCOMING_TABLE_HEADERS = [
  {
    id: 'refNmber',
    label: 'Reference Number',
    numeric: false
  },
  {
    id: 'msgStatus',
    label: 'Message Status',
    numeric: false
  },
  {
    id: 'senderBIC',
    label: 'Sender BIC',
    numeric: false
  },
  {
    id: 'creationDate',
    label: 'Creation Date (UTC)',
    numeric: false
  },
  {
    id: 'lastActivityData',
    label: 'Last Activity Date (UTC)',
    numeric: false
  },
  {
    id: 'mxTemplate',
    label: 'MX/MT',
    numeric: false
  },
  {
    id: 'amt',
    label: 'Amount',
    numeric: true
  },
  {
    id: 'currency',
    label: 'Currency',
    numeric: false
  }
];

export const IN = 'in';
export const OUT = 'out'

export const REPAIR_APPROVE_FROM_TRANSACTIONS = 'repairApproveFromTransation';
export const REPAIR_APPROVE_FROM_EDITED_TEMPLATES = 'repairApproveFromEditedTemplates';

export const OUT_STATEMENTS = 'stmt';

export const STATEMENT_HEADERS = [
  {
    id: 'refNmber',
    label: 'Reference Number',
    numeric: false
  },
  {
    id: 'msgStatus',
    label: 'Message Status',
    numeric: false
  },
  {
    id: 'mode',
    label: 'Mode',
    numeric: false
  },
  {
    id: 'stmtDate',
    label: 'Statement Date',
    numeric: false
  },
  {
    id: 'ackDate',
    label: 'Acknowledgement Date (UTC)',
    numeric: false
  },
  {
    id: 'mxTemplate',
    label: 'MX/MT *',
    numeric: false
  },
  {
    id: 'openBalance',
    label: 'Opening Balance',
    numeric: true
  },
  {
    id: 'closeBalance',
    label: 'Closing Balance',
    numeric: true
  },
  {
    id: 'currency',
    label: 'Currency',
    numeric: false
  }
]

export const SEARCH_PAYMENTS_SEARCH_TYPES = [
  { value: '', label: 'Search All' },
  { value: 'refNumber', label: 'Reference Number' },
  { value: 'senderBIC', label: 'Sender BIC' },
  { value: 'uetrNo', label: 'UETR No' },
  { value: 'amt', label: 'Amount' },
  { value: 'currency', label: 'Currency' },
  { value: 'custAccNumber', label: 'Customer Account Number' },
  { value: 'beneName', label: 'Beneficiary Name' },
  { value: 'nostroAgentBIC', label: 'Nostro Agent BIC' }
]

export const SEARCH_STATEMENTS_SEARCH_TYPES = [
  { value: '', label: 'Search All'},
  { value: 'nostroAccNo', label: 'Nostro Acc No'},
  { value: 'bicCode', label: 'BIC Code'}
]

export const INITIAL_SEARCH_REQUEST = {
  searchType: '',
  searchText: '',
  startdateRange: '',
  enddateRange: '',
  status: [],
  lookUpOn: ''
}

export const ENQ_TYPE_BY_SELECTED_MENU = {
  ISO_VIEW_OUT_B2C : 'b2c',
  ISO_VIEW_IN_B2C : 'b2c',
  ISO_VIEW_OUT_B2B : 'b2b',
  ISO_VIEW_IN_B2B : 'b2b',
  ISO_OUT_STATEMENTS : 'stmt'
}
export const TRANS_TYPE_BY_SELECTED_MENU = {
  ISO_VIEW_OUT_B2C : 'out',
  ISO_VIEW_IN_B2C : 'in',
  ISO_VIEW_OUT_B2B : 'out',
  ISO_VIEW_IN_B2B : 'in',
  ISO_OUT_STATEMENTS : 'out'
}