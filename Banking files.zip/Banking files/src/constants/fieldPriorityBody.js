// export const FieldPriorityBody = {
//     FIToFICstmrCdtTrf : {
//         GrpHdr : {
//             MsgId : {isMandatory : true, isApplicable: true, isDisabled: false},
//             CreDtTm : {isMandatory : true, isApplicable: true, isDisabled: false},
//             NbOfTxs : {isMandatory : true, isApplicable: true, isDisabled: false},
//             SttlmInf : {
//                 SttlmMtd : {isMandatory : true, isApplicable: true, isDisabled: false}
//             }
//         },
//         CdtTrfTxInf: {
//             PmtId: {
//                 InstrId: {isMandatory : true, isApplicable: true, isDisabled: false},
//                 UETR: {isMandatory : true, isApplicable: true, isDisabled: false}
//             },
//             IntrBkSttlmAmt: {isMandatory : true, isApplicable: true, isDisabled: false},
//             IntrBkSttlmDt: {isMandatory : true, isApplicable: true, isDisabled: false},
//             ChrgBr: {isMandatory : true, isApplicable: true, isDisabled: false},
//             InstgAgt: {
//                 FinInstnId : {
//                     BICFI : {isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             },
//             InstdAgt: {
//                 FinInstnId : {
//                     BICFI : {isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             },
//             Dbtr: {
//                 Nm : {isMandatory : true, isApplicable: true, isDisabled: false},
//                 PstlAdr : {
//                     TwnNm: {isMandatory : true, isApplicable: true, isDisabled: false},
//                     Ctry: {isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             },
//             DbtrAcct: {
//                 Id: {
//                     ChoiceType: {_text: '', isOptionalChoiceType: true},
//                     isApplicable: true,
//                     Othr: {
//                         Id: {isMandatory : true, isApplicable: true, isDisabled: false, crossValidation: true}
//                     },
//                     IBAN : {isMandatory : true, isApplicable: true, isDisabled: false, crossValidation: true}
//                 }
//             },
//             Cdtr: {
//                 Nm : {isMandatory : true, isApplicable: true, isDisabled: false},
//                 PstlAdr : {
//                     TwnNm: {isMandatory : true, isApplicable: true, isDisabled: false},
//                     Ctry: {isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             },
//             CdtrAcct: {
//                 Id: {
//                     ChoiceType: {_text: '', isOptionalChoiceType: true},
//                     isApplicable: true,
//                     Othr: {
//                         Id: {isMandatory : true, isApplicable: true, isDisabled: false, crossValidation: true}
//                     },
//                     IBAN : {isMandatory : true, isApplicable: true, isDisabled: false, crossValidation: true}
//                 }
//             }
//         }
//     },
//     FICdtTrf : {
//         GrpHdr : {
//             MsgId : {isMandatory : true, isApplicable: true, isDisabled: false},
//             CreDtTm : {isMandatory : true, isApplicable: true, isDisabled: false},
//             NbOfTxs : {isMandatory : true, isApplicable: true, isDisabled: false},
//             SttlmInf : {
//                 SttlmMtd : {isMandatory : true, isApplicable: true, isDisabled: false}
//             }
//         },
//         CdtTrfTxInf: {
//             PmtId: {
//                 InstrId: {isMandatory : true, isApplicable: true, isDisabled: false},
//                 UETR: {isMandatory : true, isApplicable: true, isDisabled: false},
//                 EndToEndId : {isMandatory : true, isApplicable: true, isDisabled: false}
//             },
//             IntrBkSttlmAmt: {isMandatory : true, isApplicable: true, isDisabled: false},
//             IntrBkSttlmDt: {isMandatory : true, isApplicable: true, isDisabled: false},
//             InstgAgt: {
//                 FinInstnId : {
//                     BICFI : {isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             },
//             InstdAgt: {
//                 FinInstnId : {
//                     BICFI : {isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             },
//             Dbtr: {
//                 FinInstnId : {
//                     BICFI: {isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             },
//             UndrlygCstmrCdtTrf: {
//                 Dbtr: {
//                     Nm : {isMandatory : true, isApplicable: true, isDisabled: false},
//                     PstlAdr : {
//                         TwnNm: {isMandatory : true, isApplicable: true, isDisabled: false},
//                         Ctry: {isMandatory : true, isApplicable: true, isDisabled: false}
//                     }
//                 },
//                 DbtrAcct: {
//                     Id: {
//                         ChoiceType: {_text: '', isOptionalChoiceType: true},
//                         isApplicable: true,
//                         Othr: {
//                             Id: {isMandatory : true, isApplicable: true, isDisabled: false, crossValidation: true}
//                         },
//                         IBAN : {isMandatory : true, isApplicable: true, isDisabled: false, crossValidation: true}
//                     }
//                 },
//                 Cdtr: {
//                     Nm : {isMandatory : true, isApplicable: true, isDisabled: false},
//                     PstlAdr : {
//                         TwnNm: {isMandatory : true, isApplicable: true, isDisabled: false},
//                         Ctry: {isMandatory : true, isApplicable: true, isDisabled: false}
//                     }
//                 },
//                 CdtrAcct: {
//                     Id: {
//                         ChoiceType: {_text: '', isOptionalChoiceType: true},
//                         isApplicable: true,
//                         Othr: {
//                             Id: {isMandatory : true, isApplicable: true, isDisabled: false, crossValidation: true}
//                         },
//                         IBAN : {isMandatory : true, isApplicable: true, isDisabled: false, crossValidation: true}
//                     }
//                 },
//                 InstdAmt: {
//                     isMandatory: true, isApplicable: true, isDisabled: false
//                 }
//             }
//         }
//     }

// }