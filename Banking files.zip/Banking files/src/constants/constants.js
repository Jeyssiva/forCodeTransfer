import momentZone from 'moment-timezone';

export const ACTIONS_MODE = ['cust_add', 'cust_view', 'cust_edit', 'cust_delete', 'bene_add', 'bene_view', 'bene_edit', 'bene_delete', 'cust_view_actions', 'bene_view_actions', 'cust_editadd'];

export const STATUS = [{ value: 'PENDING', label: 'PENDING' }, { value: 'APPROVED', label: 'APPROVED' },
{ value: 'RETURNED', label: 'RETURNED' }];

export const MODULE_ID = 'RTS_ISO'

export const CURRENCY_FORMATS = [
    { id: 'SGD', name: 'Singapore' },
    { id: 'MYR', name: 'Malaysia' }
]

export const CUSTOM_REGEX_PATTERN = "^(\\d{4})-(\\d{2})-(\\d{2})$"

export const COUNTRY_CODES = [
    { label: 'Singapore', value: 'SGP', lKey: 'common.singapore' },
    { label: 'Malaysia', value: 'MYS', lKey: 'common.malaysia' }
]

export const SERVICE_PROVIDER_DETAILS = [
    { parentId: 'SGP', label: 'MBB', value: 'MBB' },
    { parentId: 'SGP', label: 'MEPS', value: 'MEPS' },
    // { parentId: 'SGP', label: 'FAST', value: 'FAST' },
    { parentId: 'MYS', label: 'DuitNow', value: 'RPP' },
    { parentId: 'MYS', label: 'RENTAS', value: 'RENTAS' },
    { parentId: 'MYS', label: 'BOTH', value: 'BOTH' },
    { parentId: 'MYS', label: 'MBB', value: 'MBB' }
]

export const MbbIndicator = [
    { label: 'Yes', value: 'Y', lKey: 'common.yes' },
    { label: 'No', value: 'N', lKey: 'common.no' }
]

export const trueFalseIndicator = [
    { label: 'True', value: 'true' },
    { label: 'False', value: 'false' }
]

export const yornIndicator = [
    { label: 'Y', value: 'Y' },
    { label: 'N', value: 'N' }
]

export const yornIndicaterWithTrueFalse = [
    { label: 'Y', value: 'true' },
    { label: 'N', value: 'false' }
]

export const ActiveIndicator = [
    { label: 'Active', value: 'A', lKey: 'bankList.active' },
    { label: 'In Active', value: 'I', lKey: 'bankList.inActive' }
]

export const TRANS_BANKLIST = 'BANLISINQ'
export const TRANS_SUBTYPE = 'BANLISMY'
export const TRANS_UPDATELIST = 'BANLISUPD'
export const TRANS_ISOCURRNQ = 'ISOCURRNQ'
export const TRANS_ISOCURRAL = 'ISOCURRAL'
export const TRANS_SECTION = 'SECTION';
export const TRANS_SECTION_SUBTYPE = 'SEARCH';
export const TRANS_VIEW_CUSTOMER_INFO = 'CUSTOMER';
export const TRANS_VIEW_STATUS = 'STATUS';
export const TRANS_VIEW_STATUS_SUBTYPE = 'CUSTOMERBENESTATUS';
export const TRANS_VIEW_CUSTOMER_SUBTYPE = 'VIEWCUSTOMER';
export const TRANS_INQ_TYPE = 'DROPDOWN';
export const TRANS_INQ_SUB_TYPE = 'DYNAMIC';
export const TRANS_VIEW_BENE_INFO_SUBTYPE = 'VIEWBENEFICARY';
export const TRANS_SAVE_ACCOUNT_SUBTYPE = 'CUSTORBENAPPROVAL';
export const TRANS_CUST_TRANSACTION = 'CUSTOMERNAVIGATION';
export const VIEW_TEMPLATE_TYPE = 'TEMPLATE';
export const VIEW_TEMPLATE_SUB_TYPE = 'SEARCH';

export const AlphaNumericPattern = /^[a-zA-Z0-9]+$/
export const AlphaNumbericHyphenPattern = /^[a-zA-Z0-9-]+$/

export const sessionItems = {
    Username: 'username',
    LoginStatus: 'loginStatus',
    CurrentLang: 'currentLanguage',
    UAMToken: 'uamtoken',
    CountryCode: 'isocountry',
    ISOToken: 'isotoken',
    pfNumber: 'pfNo',
    RoleId: 'roleId',
    InvalidSession: 'invalidSession'
}

export const SCREEN_NAMES = { noScreen: 'NoScreen', fromTransaction: 'FromTransaction' }

export const DATE_FORMAT = 'DD/MM/YYYY' // DD/MM/YYYY'
export const DATE_TIME_FORMAT = 'YYYY-MM-DD HH:mm:ss'; // YYYY-MM-DDTHH:mm:ss 'DD/MM/YYYY HH:mm:ss'
export const TIME_FORMAT = 'HH:mm:ss'
export const DATE_FORMAT_BACKEND = 'YYYY-MM-DD';
export const DATE_TIME_FORMAT_BACKEND = 'YYYY-MM-DDTHH:mm:ss';
export const DATE_TIME_FORMAT_LOG = 'YYYY-MM-DDTHH:mm:ss';
export const DATE_FORMAT_PICKER = 'YYYY-MM-DD';
export const DATE_TIME_FORMAT_PICKER = 'YYYY-MM-DDTHH:mm:ss';
export const DATE_TIME_FORMAT_LONG = 'DD MMM YYYY, h:mm a';
export const DATE_TIME_FORMAT_AUDIT_LOG = 'DD/MM/YYYY HH:mm:ss';

export const PATTERN_DESCRIPTION = {
    '[0-9]{1,15}': { desc: 'Matches a string consisting of 1 to 15 numerical digits.', example: '987654321012345' },
    '[A-Z]{2,2}[0-9]{2,2}[a-zA-Z0-9]{1,30}': {
        desc: 'Matches a string with exactly 2 uppercase letters, followed by 2 digits, and then 1 to 30 alphanumeric characters.',
        example: 'XY34abc123'
    },
    '[A-Z]{3,3}': { desc: 'Matches a string consisting of exactly 3 uppercase letters.', example: 'ABC' },
    '[A-Z0-9]{4,4}[A-Z]{2,2}[A-Z0-9]{2,2}([A-Z0-9]{3,3}){0,1}':
    {
        desc: 'Matches a string with 4 uppercase letters or digits, followed by 2 uppercase letters, then 2 uppercase letters or digits, and optionally followed by 3 uppercase letters or digits.',
        example: 'ABBESDXX'
    },
    '[A-Z0-9]{18,18}[0-9]{2,2}': { desc: 'Matches a string with exactly 18 uppercase letters or digits, followed by 2 digits.', example: 'ABCDEFGHIJKLMNOQRS23' },
    '[a-zA-Z0-9]{4}': { desc: 'Matches a string consisting of exactly 4 alphanumeric characters.', example: 'ABCD or a1b2 or 1234' },
    '[A-Z]{2,2}': { desc: 'Matches a string consisting of exactly 2 uppercase letters.', example: 'AB or XY' },
    '[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}': { desc: 'Matches a string in UUID format (UUIDv4).' },
    '[0-9]{2}': { desc: 'Matches a string consisting of exactly 2 numerical digits.', example: '12 or 56' },
    '\\+[0-9]{1,3}-[0-9()+\\-]{1,30}': {
        desc: 'Matches a string starting with a plus sign, followed by 1 to 3 numerical digits, a hyphen, and then 1 to 30 characters including digits, parentheses, plus sign, or hyphen.',
        example: '+123-456789'
    },
    // '^(?!.* {2})[a-zA-Z0-9,@\\/().& -]+$' : 'Matches a string consisting of alphanumeric characters and allows some special characters like comma (,), at symbol (@), forward slash (/),'/  
    //                                             'period (.), hyphen (-), parentheses (()), ampersand (&), and single space ( )',
    // '^(?!.* {2})[a-zA-Z0-9,@\\/().#& -]+$': 'Matches a string consisting of alphanumeric characters and allows some special characters like comma (,), at symbol (@), forward slash (/),'/  
    //                                             'period (.), hyphen (-), Number sign(#), parentheses (()), ampersand (&), and single space ( )',
}

export const PacsVersion = [
    { value: "pacs.002.001.12", label: "pacs.002.001.12" },
    { value: "pacs.003.001.09", label: "pacs.003.001.09" },
    { value: "pacs.004.001.11", label: "pacs.004.001.11" },
    { value: "pacs.007.001.11", label: "pacs.007.001.11" },
    { value: "pacs.008.001.10", label: "pacs.008.001.10" },
    { value: "pacs.009.001.10", label: "pacs.009.001.10" },
    { value: "pacs.010.001.05", label: "pacs.010.001.05" },
    { value: "pacs.028.001.05", label: "pacs.028.001.05" }
]

export const MXMessageTabs = [
    { label: 'MX', value: 'mx' },
    { label: 'MT', value: 'mt' }
]

export const RowsPerPageOptions = [
    { value: 10, label: '10' },
    { value: 25, label: '25' },
    { value: 50, label: '50' },
    { value: 100, label: '100' },
    { value: 200, label: '200' },
    // {value: -1, label: 'All'}
]

export const RowsPerPageOptionsAudit = [
    { value: 30, label: '30' },
    { value: 50, label: '50' },
    { value: 100, label: '100' },
    { value: 200, label: '200' },
    { value: 500, label: '500' },
    // {value: -1, label: 'All'}
]

export const RowsPerPageOptionsSavedTemplate = [
    { value: 10, label: '10' },
    { value: 25, label: '25' },
    { value: 50, label: '50' },
    { value: 100, label: '100' },
]

export const ACCESS_LEVELS = [
    { levelName: 'NO ACCESS', levelCode: 0 },
    { levelName: 'READ', levelCode: 8 },
    { levelName: 'WRITE', levelCode: 88 },
    { levelName: 'ALL', levelCode: 888 }
]

export const NO_ACCESS_LEVEL = 'NO ACCESS';
export const ACCESS_LEVEL_READ = 'READ';
export const ACCESS_LEVEL_WRITE = 'WRITE';
export const ACCESS_LEVEL_ALL = 'ALL'

export const PACSVERSION = {
    'b2c': 'pacs.008',
    'b2b': 'pacs.009'
}

export const TRANS_TYPE = {
    'in': 'I',
    'out': 'O'
}

export const DOMAINS = [
    { value: 'mbb', label: 'Maybank' },
    { value: 'mbbmy', label: 'Maybank-my' },
    { value: 'etiqamy', label: 'Etiqa-my' },
    { value: 'mbbgm', label: 'Maybank-GM' },
    { value: 'global', label: 'Global' }
]

export const DIALOGWIDTHS = [
    { value: 'xs', label: 'Extra Small' },
    { value: 'sm', label: 'Small' },
    { value: 'md', label: 'Medium' },
    { value: 'lg', label: 'Large' },
    { value: 'xl', label: 'Extra Large' }
]

export const FONT_FAMILY = ['Trebuchet MS']

export const ERROR_STATUS = [
    {
        errorCode: 503,
        errorMessage: 'Unexpected token  DOCTYPE  is not valid JSON', displayMessage: 'Service Unavailable'
    },
    {
        errorCode: 500,
        errorMessage: 'The user aborted a request', displayMessage: 'API Response failed due to timeout'
    },
    { errorCode: 500, errorMessage: "Failed to fetch", displayMessage: 'Service Unavailable' },
    { errorCode: 403, errorMessage: 'Unexpected end of JSON input', displayMessage: '403 Forbidden' },
    {
        errorCode: 405, errorMessage: 'Cannot destructure property executionStatus of resDataresponseHeader as it is undefined',
        displayMessage: 'Service Unavailable'
    },
    {
        errorCode: 500, errorMessage: 'Cannot destructure property executionStatus of responseDataresponseHeader as it is null',
        displayMessage: 'Response not available'
    }
]

export const MESSAGE_STATUS = ['Sent', 'Rejected', 'Returned', 'Draft', 'Pending Approval', 'Sent Error', 'Successful', 'Unsuccessful']

export const FONT_SIZE = '11.5px';
export const HEADER_FONT_SIZE = '13px';

export const CUSTOM_ERROR_CODES = [
    {
        code: 401, statusText: 'Unauthorized',
        subContent: 'You have probably signed in to more than one device,browser or session. Multiple login is not permitted.'
        , customCode: 401
    },
    {
        code: 502, statusText: 'Bad Gateway',
        subContent: 'You have probably signed in to more than one device,browser or session. Multiple login is not permitted.'
        , customCode: 502
    },
    {
        code: 400, statusText: 'Bad Request',
        subContent: 'You have probably signed in to more than one device,browser or session. Multiple login is not permitted.'
        , customCode: 400
    }
]

export const EXIT_PAGES = [
    { key: 'logout', title: 'Logout', content: 'You are now logged out' },
    { key: 'sessionExpired', title: 'Session Expired', content: 'Your session has expired due to inactivity' }
]

export const EXIT_KEY_LOGOUT = 'logout';
export const EXIT_KEY_SESSIONEXPIRED = 'sessionExpired';

export const ABORT_ERROR = 'AbortError'