export const AUDIT_DETAIL = 'vAuditDtl';
export const VIEW_CUST_INFO_DETAIL = 'vCustInfoDtl';
export const VIEW_BENE_INFO_DETAIL = 'vBeneInfoDtl';
export const VIEW_CUST_BENE_STATUS_INFO_DETAIL = 'vStatusInfoDtl';
export const ACTIONS_PENDING = 'vPendingApprovalDtl';
export const CUSTOMER_MAINTAINANCE = 'custMaintance';
export const CREATE_PAYMENT = 'CreatePmnt';
export const SAVE_TEMPLATE = 'sTemplate';
export const LOGOUT = 'logout';
export const INQUIRY = 'lnq';
export const AUTH = 'authenticate';
export const AUTHORISE = 'authorise';
export const VIEW_TRANSACTION_DETAILS = 'vTxnDtl';
export const VIEW_TRANSACTIONS = 'vTxn';
export const SECTION_DETAILS = 'secDtl';
export const SAVE_TRANSACTION_DETAILS = 'sTxnDtl';
export const TOKEN = 'token';
export const VIEW_TEMPLATES = 'vTemplate';
export const TEMPLATE_CONFIGURATION = 'msgConfig';

export const CUSTOM_TIMEOUT_ERRORS = {
    [AUTH]: 'Login Failed due to Timeout, Please Try again',
    [INQUIRY]: 'Sorry, Timeout Issue. Please Login again.',
    [AUTHORISE]: 'Authorisation failed due to timeout, Please Login again'
}