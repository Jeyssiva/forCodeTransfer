export const LOGIN = '/login';
export const MODULENAME = 'rts_iso';
export const DASHBOARD = `/${MODULENAME}/*`;
export const SUMMARY = 'summary';
export const BANK_LIST = 'banklist';
export const HOME_PAGE = `/${MODULENAME}/`;
export const CREATEPAYMENT = 'createpayment';
// export const REJECTEDTRANSACTIONS = 'nonstptransaction';
// export const SHOW_MXTEMPLATE = ':accesstype/:refNumber';
export const VIEWTRANSACTIONSROUTE = ':transtype/:enquiryType/*';
export const VIEWINTRANSACTIONROUTE = 'in/:enquiryType/*';
export const VIEWOUTTRANSACTIONROUTE = 'out/:enquiryType/*';
export const ACTIVITYLOG = 'activitylog';
export const ERROR_NAME = 'error';
export const INVALIDSESSION = `${ERROR_NAME}/:errorcode`;
export const EXIT = 'exit';
export const EXITPAGE = `${EXIT}/:key`;

export const CUSTOMERPAYMENTDATA = 'customerpaymentdata';
export const CUSTROUTE = 'createcustomerdata';
export const PENDINGACTIONS = 'pendingactions';
export const BENEROUTE = 'benepaymentdata';

export const SWIFT = 'swift';
export const SWIFT_PAGE = `/${SWIFT}/`;
export const SAVEDTEMPLATES = 'templatesdata/*';
export const EDIT_SAVED_TEMPLATE = 'edit/:templateId'
export const SAVEDTEMPLATES_CRUMBS = 'templatesdata';
