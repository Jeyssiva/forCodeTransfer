// export const FieldPriorityAppHdr = {
//     AppHdr: {
//         isApplicable: true,
//         Fr: {
//             ChoiceType: {_text:'FIId'},
//             isApplicable: true,
//             FIId: {
//                 FinInstnId: {
//                     BICFI :{ isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             }
//         },
//         To: {
//             ChoiceType: {_text:'FIId'},
//             isApplicable: true,
//             FIId: {
//                 FinInstnId: {
//                     BICFI :{ isMandatory : true, isApplicable: true, isDisabled: false}
//                 }
//             }
//         },
//         BizMsgIdr : { isMandatory : true, isApplicable: true, isDisabled: false },
//         MsgDefIdr : { isMandatory : true, isApplicable: true, isDisabled: false },
//         BizSvc : { isMandatory : true, isApplicable: true, isDisabled: false },
//         CreDt : { isMandatory : true, isApplicable: true, isDisabled: false }
//     }
// }