export const MSG_STATUS_DRAFT = 'draft';
export const MSG_STATUS_DRAFTRETURN = 'draft returned';
export const MSG_STATUS_PENDING_APPROVAL = 'pending approval'

export const ERRORCODES = {
    minLength: 3,
    totalDigits: 4,
    fractionDights: 5,
    minInclusive: 6,
    maxInclusive: 7,
    noErrors: 1,
    regexIssue: 0,
    regexCatch: 2,
    mandatory: 9,
    mandatory_min: 11,
    attriCurFormat: 12,
    attriInvalidCur: 13,
    accNameValid: 14,
    addressValid: 15,
    invalidCountry: 16,
    invalidDate: 17,
    mustBe: 18
}

export const AddressPatternFields = [
    'Dept', 'SubDept', 'StrtNm', 'BldgNb', 'BldgNm', 'Flr', 'PstBx', 'Room', 'PstCd', 'TwnNm', 'TwnLctnNm', 'DstrctNm', 'CtrySubDvsn', 'Ctry'
]

export const APPHEADER_TIMER = 2000;
export const BODY_TIMER = 5000;

export const MXTabs = [
    { label: 'SAA Header', value: 'saaHeader' },
    { label: 'Application Header', value: 'appHead' },
    { label: 'Body', value: 'body' }
];

export const SAAHEADER_TAB = 'saaHeader';
export const APPHEADER_TAB = 'appHead';
export const BODY_TAB = 'body';

export const XML_NAMESPACE = { _attributes: { version: '1.0', encoding: 'UTF-8', standalone: 'no' } }

export const ISODATETIME_TYPES = ['ISODate', 'ISOYear', 'ISOTime', 'ISODateTime'];

export const CASE_TYPES = {
    none : 'none',
    uppercase : 'uppercase'
}

// Source of Transaction
export const SRCOFTXN_CREATEPAYMENT = 'CREATE_PAYMENT';
export const SRCOFTXN_MIDAS = 'MIDAS'

export const NAMES_TO_REMOVE = ['Document', 'AppHdr', 'DataPDU'];