import React, { useState, useEffect } from 'react';

function ErrorBoundary(props) {
  const [error, setError] = useState(null);
  const [errorInfo, setErrorInfo] = useState(null);

  useEffect(() => {
    // This function will be called when an error occurs within its child components
    const handleError = (error, errorInfo) => {
      setError(error);
      setErrorInfo(errorInfo);
    };

    // Set up error boundary
    const componentDidCatch = window.ReactErrorBoundary?.createContextualHandler({
      onError: handleError,
    });

    return () => {
      // Clean up
      componentDidCatch?.dispose();
    };
  }, []);

  if (error) {
    // You can customize the error message or UI here
    return (
      <div>
        <h2>Something went wrong:</h2>
        <p>{error.toString()}</p>
        <details style={{ whiteSpace: 'pre-wrap' }}>
          {errorInfo && errorInfo.componentStack}
        </details>
      </div>
    );
  }

  // If there is no error, render the child components
  return props.children;
}

export default ErrorBoundary;
