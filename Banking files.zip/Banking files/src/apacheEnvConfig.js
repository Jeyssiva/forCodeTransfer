export const HEADERS = { uamService :  process.env.REACT_APP_ISO_UAM_SERVICE || "/api",
    idleTime : process.env.REACT_APP_IDLE_TIME_MS || 900000,
    autoLogoutAfterIdle : process.env.REACT_APP_AUTO_LOGOUT || 60000,
    logonIdleTime : process.env.REACT_APP_LOGON_IDLE_TIME_MS || 900000,
    isoService : process.env.REACT_APP_MBB_ISO_SERVICE || "/isoservices/isouiservice/api",
    apiTimeout : process.env.REACT_APP_API_TIMEOUT || 15000,
    authAPITimeout : process.env.REACT_APP_AUTH_API_TIMEOUT || 15000,
    transAPITimeout : process.env.REACT_APP_SAVE_TRANS_API_TIMEOUT || 15000,
    custBICCode : process.env.REACT_APP_CUSTOMER_BIC_CODE || 'MBBEGB2L'};

const ApacheEnvConfig = (() => {
    let headers = HEADERS;
    return {
        setApacheConfig: (newHeaders) => { headers = newHeaders; },
        getApacheConfig : () => headers
    }
})();

export default ApacheEnvConfig;

export const FETCH_ISO_SERVICE = () => {
    const apacheConfig = ApacheEnvConfig.getApacheConfig();
    return apacheConfig.isoService;
}

export const FETCH_UAM_SERVICE = () => {
    const apacheConfig = ApacheEnvConfig.getApacheConfig();
    return apacheConfig.uamService; 
}
export const FETCH_TRANS_API_TIMEOUT = () => {
    const apacheConfig = ApacheEnvConfig.getApacheConfig();
    return apacheConfig.transAPITimeout;
}