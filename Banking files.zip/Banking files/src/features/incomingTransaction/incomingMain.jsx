import * as React from 'react';
import { isEmpty } from 'lodash';
import { useSelector } from "react-redux";
import { getSelectedMenuInfo } from "../dashboard/dashboardSlice";
import { ENQ_TYPE_BY_SELECTED_MENU, IN } from '../../constants/transactionConstants';

const InPaymentMain = React.lazy(() => import("../viewTransactions/transTypePaymentMain"));

export default function IncomingMain() {
    const [enqType, setEnqType] = React.useState('b2c');
    const [refreshPage, setRefresh] = React.useState(false);
    const selectedMenuInfo = useSelector(getSelectedMenuInfo);
    const onHandleRefresh = () => {
        setRefresh(!refreshPage);
    }
    React.useEffect(() => {
        if (isEmpty(selectedMenuInfo)) return;
        const enType = ENQ_TYPE_BY_SELECTED_MENU[selectedMenuInfo.menuId];
        setEnqType(enType);
    }, [selectedMenuInfo]);
    
    if (enqType === "") return;

    return (
        <InPaymentMain enqType = {enqType} transType={IN} title={"inTitle"} subtitle={"inSubTitle"} 
        refreshPage = {refreshPage} onHandleRefresh = {onHandleRefresh} />
    )
}