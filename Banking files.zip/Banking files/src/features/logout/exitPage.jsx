import { makeStyles } from '@mui/styles';
import { useSelector } from 'react-redux';
import { FormattedMessage } from 'react-intl'
import { Grid, Typography } from '@mui/material'
import { useNavigate, useParams } from 'react-router-dom';

import { useEffect } from 'react';
import { defaultLocales } from '../i18n'
import MbButton from '../common/mbButton'
import { getTokens } from '../dashboard/helpers';
import { EXIT_PAGES } from '../../constants/constants';
import { LOGIN_SLICE } from '../../constants/sliceConstants';

export const useStyles = makeStyles(() => ({
    title: {
        position: 'relative',
        height: '85vh'
    },
    subtitle: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        maxWidth: '30%',
        width: '100%',
        textAlign: 'center'
    },
    header: {
        color: '#000',
        fontSize: '30px',
        fontWeight: '700',
        marginBottom: '10px',
        /* text-transform: uppercase; */
        marginTop: '0'
    },
    content: {
        color: '#000',
        marginBottom: '10px',
        /* text-transform: uppercase; */
        marginTop: '0'
    },
}))

export default function ExitPage() {
    const classes = useStyles();
    const navigate = useNavigate();
    const { key } = useParams();
    const loginStatus = useSelector(state => state[LOGIN_SLICE].loginStatus);
    const exitDetails = EXIT_PAGES.find(c => c.key === key) || {};

    useEffect(() => {
        const { uamToken, isoToken } = getTokens();
        if (loginStatus === undefined && !uamToken && !isoToken) {
            navigate('/login');
        }
    }, [navigate, loginStatus]);

    const onHomePage = () => {
        navigate('/login')
    }

    return (
        <Grid className={classes.title}>
            <Grid className={classes.subtitle}>
                <Typography className={classes.header}>
                    {exitDetails.title}
                </Typography>
                <Typography className={classes.content}>
                    {`${exitDetails.content}`}
                </Typography>
                <MbButton className={'button-maybank'}
                    buttonName={<FormattedMessage id="logout.gotohomepage" defaultMessage={defaultLocales["logout.gotoomepage"]} >
                    </FormattedMessage>}
                    onHandleAction={onHomePage}>
                </MbButton>
            </Grid>
        </Grid>
    )
}