import moment from "moment";
import { FormattedMessage } from "react-intl";
import React, { useEffect, useState } from "react";
import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Grid, Slide, Typography } from "@mui/material";
import MbButton from "../common/mbButton"; import { EXIT_KEY_LOGOUT, EXIT_KEY_SESSIONEXPIRED } from "../../constants/constants";
import { getApacheEnvs } from "../login/loginSlice";
import { useSelector } from "react-redux";

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

export default function SessionTimeoutModal({ openSesTO, onHandleSessionClose, onHandleStayedIn }) {
    let autoLogoutTimer = undefined;
    let autoLogoutCountdown = undefined;
    const apacheEnvConfig = useSelector(getApacheEnvs);
    const [countDown, setCountDown] = useState(new Date('2021-08-30T00:05:00.000').getTime())

    useEffect(() => {
        const { autoLogoutAfterIdle } = apacheEnvConfig;
        const autoTime = moment().add(autoLogoutAfterIdle, 'ms');
        autoLogoutTimer = setTimeout(() => {
            onHandleSessionClose({ key: EXIT_KEY_SESSIONEXPIRED });
        }, autoLogoutAfterIdle)
        autoLogoutCountdown = setInterval(() => {
            setCountDown(autoTime - new Date().getTime())
        }, 1000)
        return () => {
            clearInterval(autoLogoutCountdown);
            clearTimeout(autoLogoutTimer);
        }
    }, [apacheEnvConfig]);

    const handleLogout = () => {
        onHandleSessionClose({ key: EXIT_KEY_LOGOUT });
    }

    const handleStayedIn = () => {
        if (autoLogoutTimer) clearTimeout(autoLogoutTimer);
        if (autoLogoutCountdown) clearInterval(autoLogoutCountdown);
        onHandleStayedIn();
    }

    const getProperTimeFormat = () => {
        const hours = Math.floor(
            (countDown % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
        );
        const minutes = Math.floor((countDown % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((countDown % (1000 * 60)) / 1000);
        return { hours, minutes, seconds }
    }

    const { minutes = '00', seconds = '00' } = getProperTimeFormat();
    return (
        <Dialog open={openSesTO}
            TransitionComponent={Transition}
            keepMounted
            aria-labelledby="scroll-dialog-title"
            aria-describedby="scroll-dialog-description"
            sx={{ zIndex: 10000 }} // zIndex based on LoadingViewer
        >
            <DialogTitle>
                <Typography component={'span'} variant="h6" sx={{ display: 'flex', justifyContent: 'center' }}>
                    <FormattedMessage id='logout.sessionTimeout' />
                </Typography>
            </DialogTitle>
            <DialogContent dividers={true} sx={{ padding: '5px' }}>
                <DialogContentText>
                    <Grid sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                        <Typography component={'span'} variant="body">
                            <FormattedMessage id="logout.willExpire" />
                        </Typography>
                        <Typography component={'span'} variant="body" sx={{ fontWeight: 'bold', marginBottom: '10px' }}>{`${minutes} min ${seconds} secs`} </Typography>
                        <Typography component={'span'} variant="body">
                            <FormattedMessage id='logout.logoutBody1' />
                        </Typography >
                        <Typography component={'span'} variant="body">
                            <FormattedMessage id='logout.logoutBody2' />
                        </Typography >
                    </Grid>
                </DialogContentText>
                <DialogActions>
                    <MbButton buttonName={<FormattedMessage id="logout.stayloggedIn" />} onHandleAction={handleStayedIn} />
                    <MbButton buttonName={<FormattedMessage id="logout.logoutText" />} onHandleAction={handleLogout} />
                </DialogActions>
            </DialogContent>
        </Dialog>
    )
}