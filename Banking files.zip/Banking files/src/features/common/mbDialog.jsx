import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from "@mui/material";

export default function MbDialogBox({ openDialog, onHandleClose, onHandleYes, dialogTitle, dialogContent }) {

  return (
    <Dialog
      open={openDialog}
      onClose={onHandleClose}
      aria-labelledby="dialog-title"
    >
      <DialogTitle style={{ cursor: 'move' }} id="dialog-title">
        {dialogTitle}
      </DialogTitle>
      <DialogContent>
        <DialogContentText>
          {dialogContent}
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button autoFocus onClick={onHandleYes}>
          Yes
        </Button>
        <Button onClick={onHandleClose}>Cancel</Button>
      </DialogActions>
    </Dialog>
  )
}