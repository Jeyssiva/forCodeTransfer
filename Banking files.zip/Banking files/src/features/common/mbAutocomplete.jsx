import { Autocomplete, IconButton, InputAdornment, TextField, Box, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";
import React, { memo } from "react";

const useStyles = makeStyles((theme) => ({
  selectAdornment: {
      position: 'absolute', // for mobile view
      marginRight: '0px'
  },
  // Add spacing between selected content and the icon
  selectedContent: {
    marginLeft: '37px', // Adjust this value to your preference
  },
  setPlaceHolderPosition: {
    position: 'absolute', opacity: 0.2, left: 14, top: 16
  },
  setPlaceHolderPositionEAdorn: {
    position: 'absolute', opacity: 0.2, left: 50, top: 9
  }
}));

const MbAutocomplete = ({onAutocompleteSelectionChange, onAutoCompleteInputChange, 
    value = "", inputValue = "", labelText, optionLabel = 'label', optionValue = 'value', 
    fullWidth= false, enableAdornment = false, DynamicIcon,options = [], helperText = "", error = false,sxInputRootStyles = '',
    isLabelShrinkNotReq, newOption = null, inputStyle = {}, ...others}) => 
    {
      const classes = useStyles();
      const hint = React.useRef('');
      return (
          <Autocomplete onChange={onAutocompleteSelectionChange} 
            options={options}
            // value={value || null} 
            value={options.find(option => option[optionValue] === value) || null} //Warning:The value provided to Autocomplete is invalid. None of the options match with `{}`.
            inputValue={inputValue}
            // className = {sxRootStyles}
            // classes={{ inputRoot: sxInputRootStyles }}
            onInputChange={(e) => 
              {
                if(!e) return
                return onAutoCompleteInputChange(e.target.value)}
              }      
            getOptionLabel={(option) => option[optionLabel] || ""}
            isOptionEqualToValue={(option, value) => option[optionValue] === value[optionValue]}
            size= 'small' 
            fullWidth = {fullWidth}
            filterOptions={(options, state) => {
              let displayOptions = options.filter((option) =>
                  option[optionLabel]
                    .toLowerCase()
                    .trim()
                  );
              if(inputValue) {
                displayOptions = options.filter((option) =>
                  option[optionLabel]
                    .toLowerCase()
                    .trim()
                    .startsWith(inputValue?.toLowerCase().trim())
                  )
              }
              if(newOption) {
                const findNewOption = displayOptions.find(x => x.customerValue === newOption.customerValue);
                if(!findNewOption) displayOptions.push({...newOption})
              } 
              return displayOptions;
            }}
            renderInput={(params) => {
              return (
                <Box sx={{ position: 'relative' }}>
                    <Typography className= { enableAdornment ? classes.setPlaceHolderPositionEAdorn : classes.setPlaceHolderPosition}>
                      {hint.current}
                    </Typography>
                    <TextField {...params} 
                        InputLabelProps={{ className: inputStyle }}
                        label = {labelText}
                        InputProps={ enableAdornment ? {
                          ...params.InputProps,
                          startAdornment: (
                            <InputAdornment position="start" className={classes.selectAdornment}>
                              <IconButton>
                                {/* <Tooltip title={labelText}> */}
                                  <DynamicIcon/>
                                {/* </Tooltip> */}
                              </IconButton>
                            </InputAdornment>
                          ), 
                          classes : {
                            input: classes.selectedContent
                          }
                        } : {...params.InputProps, className : inputStyle}
                        } 
                        onChange={(e) => {
                          const newValue = e.target.value;
                          onAutoCompleteInputChange(newValue);
                          const matchingOption = options.find((option) =>
                            option[optionLabel].startsWith(newValue),
                          );

                          if (newValue && matchingOption) {
                            hint.current = matchingOption[optionLabel];
                          } else {
                            hint.current = '';
                          }
                        }}
                        helperText = {helperText}
                        error = {error}
                        className={sxInputRootStyles}
                    />
                </Box>
              )
            }}
            onKeyDown={(event) => {
              if (event.key === 'Tab') {
                if (hint.current) {
                  onAutoCompleteInputChange(hint.current);
                  event.preventDefault();
                }
              }
            }}
            onBlur={() => {
              hint.current = '';
            }}
            {...others}
        /> 
      )
    }
export default memo(MbAutocomplete)