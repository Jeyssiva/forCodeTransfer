import * as React from 'react';
import { Button } from '@mui/material';
import Select from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import ListItemText from '@mui/material/ListItemText';
import OutlinedInput from '@mui/material/OutlinedInput';

import { MESSAGE_STATUS } from '../../constants/constants';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 150,
    },
  },
};

export default function MbMultiSelection({ labelName, onHandleMultiSelection, selectionValue }) {
  const [multiSelection, setMultiSelection] = React.useState([]);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setMultiSelection(
      typeof value === 'string' ? value.split(',') : value,
    ); s
  };

  return (
    <FormControl sx={{ width: 200 }}>
      <InputLabel id="demo-multiple-checkbox-label" sx={{ marginTop: '4px' }}>
        {labelName}
      </InputLabel>
      <Select
        labelId="demo-multiple-checkbox-label"
        id="demo-multiple-checkbox"
        multiple
        value={multiSelection}
        onChange={onHandleMultiSelection}
        input={<OutlinedInput label={labelName} />}
        renderValue={(selected) => selected.join(', ')}
        MenuProps={MenuProps}
        size='small'
        sx={{ marginTop: '6px' }}
      >
        {MESSAGE_STATUS.map((name) => (
          <MenuItem key={name} value={name}>
            <Checkbox checked={multiSelection.indexOf(name) > -1} />
            <ListItemText primary={name} />
          </MenuItem>
        ))}
        <Button>OK</Button>
      </Select>
    </FormControl>
  );
}
