import { memo } from "react";
import { TextField } from "@mui/material"
import { convertDBDateToCustomDate } from "../inward/helpers"

const MbDateField = memo(function DateField({labelText, labelInfo, parentDetails, pattern, onDateItemChange}){
    return (
        <TextField id={`date_${labelText}`} defaultValue={convertDBDateToCustomDate(labelInfo, pattern)} 
          label={labelText} type='date' variant="outlined" size="small"
            InputLabelProps={{shrink: true}}  sx={{ width: '100%'}} onChange={onDateItemChange}/>
    )
})
export default MbDateField;