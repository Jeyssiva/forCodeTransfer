import { memo } from "react";
import { Button } from "@mui/material";

const MbButton = ({ variant = 'contained', fullWidth = false, className = '', buttonName, onHandleAction, onHandleMouseDown, sx = {}, size = "small", ...others }) => {
  return (
    <Button fullWidth={fullWidth} variant={variant} size={size} sx={sx} className={className}
      onClick={onHandleAction} onMouseDown={onHandleMouseDown} {...others}>{buttonName}</Button>
  )
}

export default memo(MbButton);