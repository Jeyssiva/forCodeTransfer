import { Checkbox, FormControlLabel } from "@mui/material";

export default function MbCheckbox({ id, labelName, checkboxValue, fStyle, defaultChecked, onCheckboxChange, disabled = false}) {
    return (
        <FormControlLabel
            id={id} 
            control={<Checkbox value={checkboxValue} color="primary" name={id} 
            defaultChecked = {defaultChecked} onChange={onCheckboxChange} />}
            sx={{padding: '0'}} label={labelName}
            disabled = {disabled}
      />  
    )
}