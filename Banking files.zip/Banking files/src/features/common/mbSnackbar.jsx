import React from "react";
import { Snackbar } from "@mui/material";
import MuiAlert from "@mui/material/Alert";

export default function MbSnackbar({ open = false, onClose, severity = 'error', message }) {
    const [snackBarProperties, setSnackBarProperties] = React.useState({ open: open, severity: severity, message: message });
    const AlertMessage = React.forwardRef(function Alert(props, ref) {
        return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
    });

    React.useEffect(() => {
        setSnackBarProperties((state) => ({ ...state, open: open, severity: severity, message: message }));
    }, [open, severity, message]);

    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackBarProperties((state) => ({ ...state, open: false, severity: '', message: '' }));
    }

    return (
        <Snackbar open={snackBarProperties.open} autoHideDuration={5000} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
            onClose={onClose ?? onSnackBarClose} sx={{ zIndex: 10000 }} >
            <AlertMessage onClose={onClose ?? onSnackBarClose} severity={snackBarProperties.severity || 'error'} style={{ width: '95vw' }}><h5 className="error-msg">{snackBarProperties.message}</h5></AlertMessage>
        </Snackbar>
    )
}