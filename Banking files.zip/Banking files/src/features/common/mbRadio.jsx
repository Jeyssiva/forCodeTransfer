import { memo } from "react"
import { FormattedMessage } from "react-intl"
import { FormControl, FormControlLabel, RadioGroup, Radio, FormLabel, css, Typography } from "@mui/material"

const MbRadio = ({ radioValue, onRadioChange, radioList, sxStyles = {},
    radioGrpStyles = {}, key, label, readOnly = false, size, inputStyle = {}, ...others }) => {
    const onHandleRadioChange = (event) => {
        onRadioChange(event)
    }

    return (
        <FormControl className={css(sxStyles)}>
            {
                label && <FormLabel id="demo-row-radio-buttons-group-label">{label}</FormLabel>
            }
            <RadioGroup row
                aria-labelledby="demo-row-radio-buttons-group-label"
                name="row-radio-buttons-group"
                value={radioValue}
                onChange={onHandleRadioChange}
                className={radioGrpStyles}
                {...others}>
                {
                    radioList.map(radio => {
                        return (
                            <FormControlLabel value={radio.value} key={`radiochild_${radio.label}`}
                                label={<Typography sx={{ fontWeight: 'bold' }} className={inputStyle}>
                                    {
                                        radio.lKey ? <FormattedMessage id={radio.lKey} /> : radio.label
                                    }
                                </Typography>}
                                control={<Radio disabled={readOnly} size={size} />}
                            />
                        )
                    })
                }
            </RadioGroup>
        </FormControl>
    )
}

export default memo(MbRadio)