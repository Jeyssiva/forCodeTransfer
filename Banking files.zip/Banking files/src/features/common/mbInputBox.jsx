import { Dialog, DialogTitle, FormControlLabel, DialogContent, DialogActions, Divider, Typography, Grid, IconButton } from "@mui/material"
import MbTextField from "./mbTextField"
import { useState } from "react"
import { useDispatch } from "react-redux"
import { snackBarActionsShowTemp } from "../showMxTemplateAsTreeView/showMxTempSlice"
import { FONT_SIZE } from "../../constants/constants"
import { Close, Done } from "@mui/icons-material"
import { makeStyles } from "@mui/styles"

const useStyles = makeStyles(() => ({
    // inputRoot : {
    //   '& .MuiInputBase-root': {
    //     height: '25px', // Adjust the height as needed
    //   },
    // },
    inputStyle : {
      fontSize : FONT_SIZE
    }
  }));
  
export default function MbInputBoxPopup ({title, openDialog, onHandleClose, onHandleConfirm, error = false, errorText = '',
    multiline = false, fieldName = 'Name', maxLength = 0, rows = null, size="medium", 
    dialogWidth = '400px', inputValue = '', specialRegPattern = null}) {
    const [comment, setComment] = useState(inputValue);
    const actDispatch = useDispatch();
    const classes = useStyles();

    const handleConfirm = () => {
        if(comment === "" || comment === null) {
            actDispatch(snackBarActionsShowTemp({open: true, snackBarMessage : "Please fill required fields"}))
            return
        }
        if(specialRegPattern) {
            const match = specialRegPattern.test(comment);
            if(!match){
                actDispatch(snackBarActionsShowTemp({open: true, snackBarMessage : "Slash(/) not allowed"}))
            return
            }
        }
        onHandleConfirm({comment})
    }
    
  return (
    <Dialog
        open={openDialog}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
    >
        <DialogTitle id="alert-dialog-title" sx={{display: 'flex', flexDirection: 'column'}}>
            <Typography variant="" sx={{display: 'flex', justifyContent: 'center'}}>
                {title}
            </Typography>
            <Divider sx={{width: '100%', marginTop: '5px'}} orientation="horizontal"/>
        </DialogTitle>
        <DialogContent sx={{width: dialogWidth}}>
           <FormControlLabel sx= {{width: '97%', marginLeft: '3px' }} labelPlacement="start" 
            label = {<Typography sx = {{ fontSize : FONT_SIZE }}> {fieldName}<span style={{color:"red"}} >*</span> : </Typography>}
            control={
                <Grid sx={{display: 'flex', width: '74%', flexDirection: 'column'}}>
                    <Typography variant='body' sx={{display: 'flex', fontSize: 8, fontWeight: 'bold', direction: 'rtl', marginTop: '4px'}}>
                        {`${comment ? comment.length : 0}/${maxLength}`}
                    </Typography>
                    <MbTextField onTextFieldChange={(e) => setComment(e.target.value)} value = {comment} maxLength={maxLength} size={size} 
                        multiline = {multiline} rows = {rows} sx={{width: '100%', marginLeft: '2px', marginTop: '3px'}} inputStyle={classes.inputStyle} 
                        error= {error} helperText = {errorText}/>
                </Grid>
            }/>
        </DialogContent>
        <DialogActions>
            <IconButton title="Ok" onClick={handleConfirm}>
                <Done />
            </IconButton>
            <IconButton title = "Cancel" onClick={onHandleClose}>
                <Close/>
            </IconButton>
        </DialogActions>
    </Dialog>
  )
};