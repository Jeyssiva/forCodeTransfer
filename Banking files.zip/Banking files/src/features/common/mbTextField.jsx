import React, { memo } from "react";
import { IconButton, InputAdornment, TextField } from "@mui/material"
import { AccountCircle, Visibility, VisibilityOff, Search } from "@mui/icons-material"

import { CASE_TYPES } from "../../constants/mxTempConstants"

const MbTextField = ({ id = "outlined-text", onTextFieldChange = null, onHandleValidation,
  onHandleMouseDown, maxLength = 120, DynamicIcon = AccountCircle, enableAdornment = false, enablePasswordAdornment = false,
  inputStyle = {}, multiline = false, isLabelShrinkNotReq = false, readOnly, label, caseType = CASE_TYPES.none,
  onTextFieldFocus, onTextBlur, helperText, disableUnderline = false, enableNumber = false, ...others }) => {

  const [showPassword, setShowPassword] = React.useState(false);

  const handleClickShowPassword = () => {
    setShowPassword((showPassword) => !showPassword);
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  }

  return (
    <TextField id={enablePasswordAdornment && !showPassword ? 'password' : id}
      variant='outlined'
      fullWidth
      helperText={(helperText ? <span className="helper-text">{helperText}</span> : <></>)}
      type={!enableNumber ? "text" : "number"}
      onChange={onTextFieldChange}
      onBlur={onHandleValidation}
      inputProps={{ maxLength: maxLength, readOnly, className: inputStyle, style: { textTransform: caseType } }}
      onMouseDown={onHandleMouseDown}
      multiline={multiline}
      InputProps={disableUnderline ?
        { disableUnderline: true } : enableAdornment ? {
          startAdornment: (
            <InputAdornment position="start">
              <Search fontSize="5" />
            </InputAdornment>
          )
        } : enablePasswordAdornment ? {
          endAdornment: (
            <InputAdornment position="end">
              <IconButton aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                onMouseDown={handleMouseDownPassword}
                edge="end"
              >
                {showPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>
          )
        } : {}
      }
      InputLabelProps={{ shrink: isLabelShrinkNotReq ? false : true }}
      label={isLabelShrinkNotReq ? '' : label}
      onFocus={onTextFieldFocus}
      onBlurCapture={onTextBlur}
      autoComplete="off"
      {...others}
    />
  )
}

export default memo(MbTextField);