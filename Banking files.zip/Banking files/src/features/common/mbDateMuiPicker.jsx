import dayjs from 'dayjs'
import { memo } from 'react'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers'

const MbDateMuiField = memo(function DateField ({
  labelText,
  labelInfo,
  onDateChange,
  views,
  format,
  readOnly = false,
  size,
  isLabelShrinkNotReq = false,
  clsDateStyles = '',
  inputStyle = null,
  error = false
}) {
  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DatePicker
        id={`date_${labelText}`}
        label={isLabelShrinkNotReq ? '' : labelText}
        variant='outlined'
        value={labelInfo ? dayjs(labelInfo) : null}
        onChange={onDateChange}
        views={views}
        format={format}
        readOnly={readOnly}
        //  slots={ {
        //     openPickerIcon : MoreTime,
        //     leftArrowIcon : ArrowBack,
        //     rightArrowIcon : ArrowForward,
        //     switchViewIcon : ChangeCircle
        //  }}
        slotProps={
          size === 'small'
            ? {
                openPickerIcon: { size },
                textField: {
                  error,
                  size,
                  InputProps: inputStyle
                    ? {
                        className: inputStyle
                      }
                    : {}
                }
              }
            : {
                textField: {
                  error
                }
              }
        }
        sx={{ width: '100%' }}
        className={clsDateStyles}
      />
    </LocalizationProvider>
  )
})
export default MbDateMuiField
