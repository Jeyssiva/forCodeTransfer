import { useIntl } from "react-intl";
import { useCallback, useMemo } from "react";
import { useNavigate } from "react-router-dom"
import { NavigateNext } from "@mui/icons-material"
import { Breadcrumbs, Typography, Link } from "@mui/material"

import { defaultLocales } from "../i18n";
import { FONT_SIZE } from "../../constants/constants";

export default function MbBreadCrumbs({ crumbsList = [] }) {

    const intl = useIntl();
    const navigate = useNavigate();

    const breadCrumbsList = useMemo(
        () => {
            return crumbsList.map((item) => {
                return { ...item, name: intl.formatMessage({ id: item.title, name: defaultLocales[item.title] }), 
                     url: item.url, icon: item.icon }
            })
        }, [crumbsList]);

    const onNavigateTo = useCallback((e, url) => {
        e.preventDefault();
        navigate(url);
    }, [])

    return (
        <Breadcrumbs key="breadcrumbs" sx={{ marginBottom: 1 }} separator={<NavigateNext fontSize="small" />}>
            {
                breadCrumbsList.map((item, i) => {
                    if (item.url) return <Link component={"button"} key={item.id} underline="hover" color="inherit" onClick={(e) => { onNavigateTo(e, item.url) }} sx={{ fontSize: FONT_SIZE }}><i><center>{item.icon}&nbsp;{item.name}</center></i></Link>
                    return <Typography key={`name_${i}`} sx={{ fontSize: FONT_SIZE }}><i>{item.icon ? <>{item.icon}&nbsp;</> : <></>}{item.name}</i></Typography>
                })
            }
        </Breadcrumbs>
    )
}