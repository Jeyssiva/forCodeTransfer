import { memo } from "react";
import { FormControl, InputAdornment, InputLabel, OutlinedInput } from "@mui/material";

const MbCurrencyField = memo(function CurrencyField({onCurrenyChange, label, value}) {
    return (
        <FormControl fullWidth >
            <InputLabel htmlFor="outlined-adornment-amount">{label}</InputLabel>
            <OutlinedInput
                id="outlined-adornment-amount"
                startAdornment={<InputAdornment position="start"></InputAdornment>}
                onChange={onCurrenyChange}
                label={label}
                value={value}
            />
        </FormControl>
    )
});

export default MbCurrencyField;