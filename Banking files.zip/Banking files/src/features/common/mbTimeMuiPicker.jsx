import dayjs from "dayjs";
import { memo } from "react";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider, TimePicker, renderTimeViewClock } from "@mui/x-date-pickers";


const MbTimePickerMuiField = memo(function TimeField({ labelText, labelInfo, format, onTimeChange,
    readOnly, size, isLabelShrinkNotReq = false, inputStyle = null, error = false }) {
    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <TimePicker id={`time_${labelText}`}
                label={isLabelShrinkNotReq ? '' : labelText} variant="outlined"
                sx={{ width: '100%' }} onChange={onTimeChange}
                value={(labelInfo && labelInfo !== null && labelInfo !== "")
                    ? dayjs(`0000-00-00T${labelInfo}`)
                    : null}
                views={['hours', 'minutes', 'seconds']}
                ampm={false}
                format={format}
                // defaultValue={dayjs('2022-04-17T00:00:00')}
                viewRenderers={{
                    hours: renderTimeViewClock,
                    minutes: renderTimeViewClock,
                    seconds: renderTimeViewClock,
                }}
                readOnly={readOnly}
                slotProps={
                    size === 'small' ?
                        {
                            textField: {
                                error,
                                size,
                                InputProps: inputStyle
                                    ? {
                                        className: inputStyle
                                    } : {}
                            }
                        }
                        : { textField: { error } }}
            />
        </LocalizationProvider>
    )
})
export default MbTimePickerMuiField;