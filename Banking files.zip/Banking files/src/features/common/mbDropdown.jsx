import { memo } from "react";
import { makeStyles } from "@mui/styles";
import { FormattedMessage } from "react-intl";
import ExpandMoreOutlinedIcon from '@mui/icons-material/ExpandMoreOutlined';
import { FormControl, FormHelperText, IconButton, InputAdornment, InputLabel, MenuItem, Select } from "@mui/material";

const useStyles = makeStyles((theme) => ({
    selectAdornment: {
        "& .MuiButtonBase-root": {
            position: "absolute",
            padding: 0,
            left: "12px",
        }
    },
    dropDownSelectStyles: {
        textAlign: 'left',
    }
}));

const MbDropdown = ({ labelName, labelValue, onDropdownChange, variant = "filled",
    dropdownList = [], sxFormStyles = '', size = "medium", onHandleValidation, fullWidth = false,
    error = false, helperText = null, enableAdornment, DynamicIcon, arrowIcon = false,
    sxSelectStyles = '', readOnly = false, margin = "none", isLabelShrinkNotReq, inputStyle = null, ...other }) => {
    const classes = useStyles();

    return (
        <FormControl className={sxFormStyles} margin={margin} variant={variant} size={size} fullWidth={fullWidth} error={error} id={`form_${labelName}`}>
            {
                !isLabelShrinkNotReq &&
                <InputLabel id={`input_${labelName}`}>{labelName}</InputLabel>
            }
            <Select labelId={`input_${labelName}`} id={`dropdown_${labelName}`}
                IconComponent={arrowIcon ? ExpandMoreOutlinedIcon : ExpandMoreOutlinedIcon}
                sx={{ width: '100%', textTransform: 'uppercase' }}
                value={labelValue}
                label={isLabelShrinkNotReq ? '' : labelName}
                onChange={onDropdownChange}
                className={sxSelectStyles || classes.dropDownSelectStyles || ''}
                onBlur={onHandleValidation}
                readOnly={readOnly}
                inputProps={enableAdornment
                    ? { sx: { marginLeft: '30px' } }
                    : inputStyle
                        ? { className: inputStyle }
                        : {}}
                startAdornment={enableAdornment && (
                    <InputAdornment className={classes.selectAdornment}>
                        <IconButton>
                            {/* <Tooltip title={labelName}> */}
                            <DynamicIcon />
                            {/* </Tooltip> */}
                        </IconButton>
                    </InputAdornment>
                )}
                {...other}
            >
                {
                    typeof dropdownList === 'object' && dropdownList.map(dropItem => {
                        return (
                            <MenuItem value={dropItem.value} key={`${labelName}menu_${dropItem.value}`}>
                                <h6 className="h6">{dropItem.lKey ? <FormattedMessage id={`${dropItem.lKey}`} /> : dropItem.label}</h6>
                            </MenuItem>
                        )
                    })
                }
            </Select>
            {helperText && <FormHelperText>{helperText}</FormHelperText>}
        </FormControl>
    )
}
export default memo(MbDropdown)