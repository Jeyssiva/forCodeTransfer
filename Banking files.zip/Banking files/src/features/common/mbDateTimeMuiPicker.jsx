import dayjs from "dayjs";
import { memo } from "react";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";

const MbDateTimeMuiField = ({ labelText, labelInfo, onDateChange, format, readOnly = false, size,
    isLabelShrinkNotReq = false, clsDateTimeStyle = '', inputStyle = null,
    view = ['year', 'month', 'day', 'hours', 'minutes', 'seconds'], error = false, helperText = "",
    maxDate = undefined, minDate = undefined}) => {
    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DateTimePicker
                id={`date_${labelText}`}
                label={isLabelShrinkNotReq ? '' : labelText}
                variant="outlined"
                value={labelInfo ? dayjs(labelInfo) : null}
                onChange={onDateChange}
                views={view}
                format={format}
                readOnly={readOnly}
                ampm={false}
                slotProps={
                    size === 'small' ?
                        {
                            textField:
                            {
                                error,
                                size,
                                helperText,
                                InputProps: inputStyle ? {
                                    className: inputStyle
                                } : {}
                            }
                        }
                        : { textField: { error } }}

                sx={{ width: '100%' }}
                className={clsDateTimeStyle}
                maxDate={maxDate && dayjs(maxDate)}
                minDate={minDate && dayjs(minDate)}
                // onAccept={onDateChange}            
                // defaultValue={dayjs('2022-04-17T15:30')}
            />
        </LocalizationProvider>
    )
}
export default memo(MbDateTimeMuiField);