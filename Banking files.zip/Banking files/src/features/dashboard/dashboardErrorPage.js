import { Typography } from "@mui/material"
import { useSelector } from "react-redux"
import { defaultLocales } from "../i18n";
import { FormattedMessage } from "react-intl";
import { DASHBOARD_SLICE } from "../../constants/sliceConstants"

export default function DashboardErrorPage() {
    const authorizedMenus = useSelector(state => state[DASHBOARD_SLICE].authorizedMenus);
    return (
        <>
            {      
                authorizedMenus && authorizedMenus.length === 0 && 
                (
                    <Typography variant="h6" sx={{display: 'flex', justifyContent: 'center', marginTop: '25px'}}>
                        <FormattedMessage id = "dashboard.nouserpermission" defaultMessage={defaultLocales["dashboard.nouserpermission"]}/>
                    </Typography>
                ) 
            }
        </>
    )
}