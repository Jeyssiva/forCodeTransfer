import { Outlet } from "react-router-dom"
import { Box, Container, Toolbar, Typography } from "@mui/material"

function SubNavigation() {
  return (
    <Box
      component="main"
      sx={{
        backgroundColor: (theme) =>
          theme.palette.mode === 'light'
            ? theme.palette.grey[100]
            : theme.palette.grey[900],
        flexGrow: 1,
        display: 'block',
        minHeight: '100vh',
        position: 'relative'
      }}
      id="subNavigation"
    >

      <Box className="sub-navigation">
        <Container maxWidth={false} disableGutters id='dashboardhub'>
          <Outlet />
        </Container>
      </Box>
    </Box>
  )
}

export default SubNavigation