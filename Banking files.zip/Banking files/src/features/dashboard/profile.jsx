import { useState } from "react";
import { FormattedMessage } from "react-intl";
import { useDispatch, useSelector } from "react-redux";
import { Typography, ListItemButton, ListItemText, Popover } from "@mui/material";

import { defaultLocales } from "../i18n";
import { logoutUser } from "./dashboardActions";
import ProfileMain from "../profile/profileMain";
import { getLocalAuth } from "../login/loginSlice";
import { EXIT_KEY_LOGOUT, MODULE_ID, sessionItems } from "../../constants/constants";

function Profile({ onCloseProfile, openProfile, locale }) {
  const [openProfileDialog, setOpenProfileDialog] = useState(null);
  const dispatch = useDispatch();
  const localAuth = useSelector(getLocalAuth);
  const open = Boolean(openProfile);
  const id = open ? 'simple-popover' : undefined;
  const handleClose = () => {
    onCloseProfile(null);
  }
  const onLogout = () => {
    onCloseProfile(null);
    const username = sessionStorage.getItem(sessionItems.Username);
    dispatch(logoutUser(username, MODULE_ID, localAuth, EXIT_KEY_LOGOUT));
  }

  const onHandleProfileOpen = () => {
    onCloseProfile(null);
    setOpenProfileDialog(true);
  }

  const onHandleProfileClose = () => {
    setOpenProfileDialog(false);
  }

  return (
    <>
      <Popover
        id={id}
        open={open}
        anchorEl={openProfile || null}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        sx={{ zIndex: 10000 }}
        disableScrollLock={true}
      >
        <ListItemButton>
          <ListItemText onClick={onHandleProfileOpen}
            primary={<Typography variant="h6" sx={{ fontWeight: 'bold', fontSize: '13px' }} ><FormattedMessage id='profilePage.profile' defaultMessage={defaultLocales["profilePage.profile"]} /></Typography>}
          />
        </ListItemButton>
        <ListItemButton>
          <ListItemText onClick={onLogout}
            primary={<Typography variant="h6" sx={{ fontWeight: 'bold', fontSize: '13px' }} ><FormattedMessage id='profilePage.signOut' defaultMessage={defaultLocales["profilePage.signOut"]} /></Typography>}
          />
        </ListItemButton>
      </Popover>
      {
        openProfileDialog && <ProfileMain openDialog={openProfileDialog} onClose={onHandleProfileClose} />
      }
    </>
  )

};
export default Profile;