import * as React from 'react';
import { cloneDeep } from 'lodash';
import { Link } from 'react-router-dom';
import { Collapse, Divider } from '@mui/material';
import ListItemText from '@mui/material/ListItemText';
import { useDispatch, useSelector } from 'react-redux';
import ListItemButton from '@mui/material/ListItemButton';
import { ExpandLess, ExpandMore } from '@mui/icons-material';

import LoadingViewer from '../loadingViewer';
import { collapseExpandAllSubMenus } from './helpers';
import { DASHBOARD_SLICE } from '../../constants/sliceConstants';
import { HOME_PAGE, SWIFT_PAGE } from "../../constants/routesURL";
import { resetPages } from '../viewTransactions/viewTransactionSlice';
import { expandCollapseAuthorizedMenus, getSelectedMenu, getAuthorizedMenus, getListItemLoading, } from './dashboardSlice';

const ListItems = () => {
  const actionDispatch = useDispatch();
  const getListLoading = useSelector(getListItemLoading);
  const authorizedMenus = useSelector(getAuthorizedMenus);
  const [pathname, setPathname] = React.useState(window.location.pathname);
  const toolbarOpenStatus = useSelector(state => state[DASHBOARD_SLICE].isOpenToolBar);

  const onExpandClick = (event, listItem) => {
    event.stopPropagation();
    if (listItem.subMenus) {
      actionDispatch(expandCollapseAuthorizedMenus({
        ...listItem, open: !listItem.open,
        subMenus: collapseExpandAllSubMenus(cloneDeep(listItem.subMenus), !listItem.open)
      }))
      actionDispatch(getSelectedMenu(listItem.subMenus[0]));
    } else
      actionDispatch(getSelectedMenu(listItem));
    actionDispatch(resetPages())
  }

  const generateMenuLabel = (menuLabel, open, isSubMenus) => {
    return <>{isSubMenus ? <>{menuLabel}</> : <>{!open ? <>&#9658;</> : <>&#9660;</>}&nbsp;{menuLabel}</>}</>;
  }

  const handleSelectedSideMenuBar = (mypath) => {
    return pathname.includes(String(mypath || 'swift'.toLowerCase()));
  };

  const renderSubItems = (subMenus, open, paddingLeft, isSubMenus = false) => {
    return (
      subMenus && subMenus.map(sub => {
        return (
          <React.Fragment key={`fragment_${sub.menuId}`}>
            <Collapse in={open} timeout="auto" unmountOnExit>
              <ListItemButton sx={{ pl: paddingLeft }}
                selected={handleSelectedSideMenuBar(sub.menuUrl)}
                component={Link}
                to={`${sub.menuUrl}`}
                key={`subItem_${sub.menuId}`}
                onClick={(e) => onExpandClick(e, sub)}
              >
                <ListItemText disableTypography>
                  <h6>{generateMenuLabel(sub.menuLabel, sub.open, isSubMenus)}</h6>
                </ListItemText>
              </ListItemButton>
            </Collapse>
            {sub.subMenus && renderSubItems(sub.subMenus, sub.open, paddingLeft + 2, true)}
          </React.Fragment>
        );
      })
    );
  };

  if (getListLoading)
    return (
      <LoadingViewer sxContainerStyle={{ height: '300px !important' }} sxSpinOverlay={{ backgroundColor: 'transparent !important' }}
        loadColor={'#FFFFFF'} loading={getListLoading} />
    )
  else
    return (
      authorizedMenus && authorizedMenus.map((item, key) => {
        return (
          <React.Fragment key={`parentItem_${key}`}>
            {key === 0 && (
              <>
                <ListItemButton selected={handleSelectedSideMenuBar(HOME_PAGE)} component={Link} to={HOME_PAGE} >
                  <ListItemText disableTypography sx={{
                    px: [1],
                    marginTop: [1.5],
                    marginBottom: [1.5]
                  }}>
                    <h6>DASHBOARD</h6>
                  </ListItemText>
                </ListItemButton>
                <Divider light className='divider-blue' />
              </>
            )}
            <>
              <ListItemButton selected={handleSelectedSideMenuBar(item.menuUrl)} component={Link} to={item.menuUrl}
                onClick={(e) => onExpandClick(e, item, [item.menuId])}>
                <ListItemText disableTypography
                  sx={{
                    px: [1],
                    marginTop: [1.5],
                    marginBottom: [1.5]
                  }}>
                  <h6>{item.menuLabel}</h6>
                </ListItemText>
                {item.subMenus
                  ? item.open ? <ExpandLess /> : <ExpandMore />
                  : null}
              </ListItemButton>
              {
                renderSubItems(item.subMenus, item.open, 3)
              }
              <Divider light className='divider-blue' />
            </>
          </React.Fragment>
        )
      })
    )
}
export default ListItems;
