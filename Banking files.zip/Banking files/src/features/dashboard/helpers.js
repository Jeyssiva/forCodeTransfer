import { has } from "lodash";
import { sessionItems } from "../../constants/constants";

export function updateMenuCollapsible(menuList, selectedMenu) {
    menuList.forEach((listItem, index, menuList) => {
        if(listItem.menuId === selectedMenu.menuId){
            menuList[index] = selectedMenu
        }
        if(listItem.subMenus){
            updateMenuCollapsible(listItem.subMenus, selectedMenu)
        }
    });

    return menuList;
}

export function collapseExpandAllSubMenus(subList, value) {
    subList.forEach((subItem, index, subList) => {
        if(has(subItem, 'open')) {
            subList[index] = {...subItem, open: value}
        }
        if(subItem.subMenus){
            collapseExpandAllSubMenus(subItem.subMenus, value)
        }
    })
    return subList
}

export function sessionClear() {
    sessionStorage.removeItem(sessionItems.UAMToken);
    sessionStorage.removeItem(sessionItems.Username);
    sessionStorage.setItem(sessionItems.LoginStatus, false);
    sessionStorage.removeItem(sessionItems.CountryCode);
    sessionStorage.removeItem(sessionItems.ISOToken);
    sessionStorage.removeItem(sessionItems.pfNumber);
    sessionStorage.removeItem(sessionItems.RoleId);
}

export function getTokens() {
    const uamToken = sessionStorage.getItem(sessionItems.UAMToken) === 'undefined' 
    ? undefined 
    : sessionStorage.getItem(sessionItems.UAMToken);
  const isoToken = sessionStorage.getItem(sessionItems.ISOToken);
  return {uamToken, isoToken};
}