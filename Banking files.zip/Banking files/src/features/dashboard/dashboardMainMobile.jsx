import * as React from 'react';
import { styled } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import MuiDrawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Badge from '@mui/material/Badge';
import Grid from '@mui/material/Grid';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import NotificationsIcon from '@mui/icons-material/Notifications';
import Avatar from '@mui/material/Avatar';
import ListItems from './listItems';
import { deepOrange } from '@mui/material/colors';
import Profile from './profile';
import SubNavigation from './subNavigation';
import m_logo from '../../images/m_logo_new.png'
import t_logo from '../../images/t_logo.png'
import { makeStyles } from '@mui/styles';
import { isMobile, isMobileOnly, isTablet, osVersion } from 'react-device-detect';
import MbDropdown from '../common/mbDropdown';
import { defaultLocales, locales } from '../i18n';
import { useDispatch, useSelector } from 'react-redux';
import { setGlobalLocale, setToolBarStatus } from './dashboardSlice';
import { sessionItems } from '../../constants/constants';
import { FormattedMessage } from 'react-intl';
import { Container } from '@mui/material';

const drawerWidth = 230;

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(['width', 'margin'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
  backgroundColor: '#fec70b'
}));

const Drawer = styled(MuiDrawer)(
  () => ({
    '& .MuiDrawer-paper': {
      width: drawerWidth,
      backgroundColor: "#231f20",
      color: "white"
    },
  }),
);

const useStyles = makeStyles(() => ({
  customIcon: {
    color: 'white'
  },
  selectFormStyles: {
    width: isMobileOnly ? '80%' : isTablet ? '30%' : '15%'
  }
}));
// const defaultTheme = createTheme();

export default function Dashboard() {
  const [openToolBar, setOpenToolBar] = React.useState(false);
  const [openProfile, setOpenProfile] = React.useState(null);
  const curLang = sessionStorage.getItem(sessionItems.CurrentLang);
  const [locale, setLocale] = React.useState( curLang || 'en-US');

  const actionDispatch = useDispatch();
  const globalLocale = useSelector(state => state.dashboard.locale);

  const classes = useStyles();
  // const toggleDrawer = () => {
  //   setOpenToolBar(!openToolBar);
  //   actionDispatch(setToolBarStatus(!openToolBar))
  // };

  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }

    setOpenToolBar(open);
    actionDispatch(setToolBarStatus(open))
  };

  const toggleProfile = (event) => {
    setOpenProfile(event.currentTarget)
  }

  const onCloseProfile = () => {
    setOpenProfile(null);
  }

  const onHandleLocale = e => {
    setLocale(e.target.value);
    actionDispatch(setGlobalLocale(e.target.value));
    sessionStorage.setItem(sessionItems.CurrentLang, e.target.value)
  }

  const localesList = locales.map(loc => {
    const { label, value, sLabel} = loc;
    if(openToolBar && isMobileOnly) {
      return {
        label: sLabel,
        value
      }
    }
    return { label , value}
  })

  const renderDrawerItems = () => {
    return (
      <>
         <Toolbar
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'flex-start',
              px: [1]
            }}
          >
            <IconButton onClick={toggleDrawer(false)}>
              <ChevronLeftIcon className={classes.customIcon} />
            </IconButton>
          </Toolbar>
          <Divider />
          <List sx={{ backgroundColor: '#231f20' }} component="nav">
            <ListItems/>
          </List>
      </>
    )
  }

  return (
    // <ThemeProvider theme={defaultTheme}>
    <React.Fragment>
      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <AppBar id='appbar' position="absolute" open={openToolBar}>
          <Toolbar
            sx={{
              display: 'flex',
              pr: '20px', // keep right padding when drawer closed
            }}
          >
            <IconButton
              edge="start"
              color="inherit"
              aria-label="open drawer"
              onClick={toggleDrawer(true)}
              sx={{
                marginRight: '36px',
                ...(openToolBar && { display: 'none' }),
              }}
            >
              <MenuIcon />
            </IconButton>
            {
              !isMobileOnly ?
                <Box
                  component="img"
                  sx={{ height: 50, maxWidth: '16%' }}
                  alt="Logo"
                  src={m_logo}
                />
                : <Box
                  component="img"
                  sx={{ height: 50, maxWidth: '16%' }}
                  alt="Logo"
                  src={t_logo}
                />
            }

            <Container maxWidth={false} disableGutters>
              <Typography
                component="h1"
                variant="h6"
                color="inherit"
                noWrap
                sx={{ flexGrow: 1 }}
              >

              </Typography>

              <Grid item
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                  px: [1]
                }}
              >
                <MbDropdown labelName={<FormattedMessage id = 'dashboard.selLanguage' 
                  defaultMessage={defaultLocales["dashboard.selLanguage"]}/>}
                  size='small' sxFormStyles= {classes.selectFormStyles} labelValue={locale} 
                  dropdownList={localesList} onDropdownChange={onHandleLocale}/>
                <IconButton color="inherit">
                  <Badge badgeContent={0} color="secondary">
                    <NotificationsIcon />
                  </Badge>
                </IconButton>
                <IconButton color="inherit">
                  <Avatar sx={{ bgcolor: deepOrange[500] }} onClick={toggleProfile}>J</Avatar>
                </IconButton>
              </Grid>
            </Container>

          </Toolbar>
        </AppBar>
        <Drawer id='drawer' anchor='left' open={openToolBar}>
          {
            renderDrawerItems()
          }          
        </Drawer>
        <SubNavigation />
        <Profile openProfile={openProfile} onCloseProfile={onCloseProfile} locale = {globalLocale}/>
      </Box>
    </React.Fragment>
    // </ThemeProvider>
  );
}