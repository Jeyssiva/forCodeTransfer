import { createSelector, createSlice } from '@reduxjs/toolkit';

import summaryJson from '../doc/summary.json'
import { updateMenuCollapsible } from './helpers';
import summaryResultJson from '../doc/summaryResult.json'
import { DASHBOARD_SLICE } from '../../constants/sliceConstants';
import { ACCESS_LEVELS, sessionItems } from '../../constants/constants';

export const dashInitialState = {
  summaryList : {},
  summaryResultList : {},
  update : "",
  locale: sessionStorage.getItem(sessionItems.CurrentLang) || 'en-US',
  isOpenToolBar: true,
  authorizedMenus: undefined,
  selectedMenu:{},
  snackBarPropertiesDashboard : {},
  countryList : [],
  ISOCurrencyList : [],
  appResolution: {},
  inValidSession: {},
  addressTypes : [],
  listItemLoading : false,
  screenPermissionByMenu : {}
};

const getSubMenus = (subMenus, parentIds) => {
    const subMenusList = [];
    subMenus.forEach(subMenuItem => {
        if (subMenuItem.selectedRank === 0) return;
        const { menuId, displayLevel, displayOrder, menuUrl, icon, menuLabel, menus, screens } = subMenuItem
        const subParents = [...parentIds, menuId]
        const addSubObject = {
            menuId,
            displayLevel,
            displayOrder,
            menuUrl,
            iconName: icon,
            menuLabel,
            // iconImage: GET_ICONS[icon],
            parentIds: subParents
        }
        if (menus && menus.length > 0) {
            addSubObject.open = false;
            addSubObject.subMenus = getSubMenus(menus, subParents)
        }
        if (screens) {
            addSubObject.screens = screens.map(screen => {
                const { levelName } = ACCESS_LEVELS.find(a => a.levelCode === screen.selectedRank);
                return { ...screen, levelName }
            });
        }
        subMenusList.push(addSubObject)
    })
    return subMenusList.sort((a, b) => a.displayOrder - b.displayOrder);
}

function screenAccess(menuInfo) {
    if (!menuInfo || !menuInfo.screens || menuInfo.screens.length === 0 ) return {}
    return { ...menuInfo.screens[0] } 
}

const dashboardSlice = createSlice({
    name : DASHBOARD_SLICE,
    initialState : dashInitialState,
    reducers: {
        loadSummary(state, action) {
            state.summaryList = summaryJson
        },
        updateSummaryFields(state, action) {
            // Create a deep copy of summaryResultList
            const updatedSummaryList = { ...state.summaryResultList };

            // Navigate through the parentDetails and update the field
            let currentObj = updatedSummaryList;
            action.payload.parentDetails.slice(0, -1).forEach(item => {
                if (item.type === 'array') {
                    currentObj = currentObj[item.name][0] || {}
                } else {
                    currentObj = currentObj[item.name] || {};
                }
            });

            currentObj[action.payload.fieldName] = action.payload.value;
            // Update the state with the new summaryResultList
            state.summaryResultList = updatedSummaryList;
        },
        loadSummaryResult(state, action) {
            state.summaryResultList = summaryResultJson
        },
        setGlobalLocale(state, action) {
            state.locale = action.payload || 'en-US'
        },
        setToolBarStatus(state, action) {
            state.isOpenToolBar = action.payload
        },
        authorizationSuccess(state, action) {
            const { userPermission } = action.payload.data;
            const { menus } = userPermission;
            const authorizedMenus = []
            menus.forEach(pMenuItem => {
                if (pMenuItem.selectedRank === 0) return;
                const { menuId, displayLevel, displayOrder, menuUrl, icon, menuLabel, menus } = pMenuItem
                const parentIds = [menuId]
                const addObject = {
                    menuId,
                    displayLevel,
                    displayOrder,
                    menuUrl,
                    iconName: icon,
                    menuLabel,
                    parentIds
                }
                if (menus && menus.length > 0) {
                    addObject.open = true;
                    addObject.subMenus = getSubMenus(menus, parentIds)
                }
                authorizedMenus.push(addObject);
            });
            state.authorizedMenus = authorizedMenus.sort((a,b) => a.displayOrder - b.displayOrder);
            state.listItemLoading = false;
        },
        expandCollapseAuthorizedMenus(state, action) {
            state.authorizedMenus = updateMenuCollapsible(state.authorizedMenus, action.payload)
        },
        getSelectedMenu(state, action) {
            state.selectedMenu = action.payload;
            state.screenPermissionByMenu = {...screenAccess(action.payload)};
        },
        snackBarActionDashboard(state, action) {
            state.snackBarPropertiesDashboard = { ...action.payload }
        },
        logoutDashboard() {
           return dashInitialState;
        },
        loadInq(state, action) {
            const { ddLists } = action.payload.resData.responseBody;

            // const ddLists = [
            //     {GBR_CURRENCY_LIST : null},
            //     {GBR_COUNTRY_LIST: null},
            //     {GBR_PURPOSE_ALL: null},
            //     {GBR_CUST_TYPE: null},
            //     {GBR_ADDRESS_TYPE: null}
            // ]
            state.ISOCurrencyList = ddLists[0]["GBR_CURRENCY_LIST"] ?
            [...ddLists[0]["GBR_CURRENCY_LIST"].map(cur => {
                return {
                    ...cur,
                    description : `${cur.description.trim()}`,
                    isoDisplayName : `${cur.code} - ${cur.description}`
                }
            })] : [];
            state.countryList = ddLists[1]["GBR_COUNTRY_LIST"] ? 
            [
                ...ddLists[1]["GBR_COUNTRY_LIST"].map(coun => {
                    return {
                        ...coun,
                        isoDisplayName : `${coun.code} - ${coun.description}`
                    }
                })
            ]: [];
            // state.purposeCodes = ddLists[2]["GBR_PURPOSE_ALL"];
            state.customerTypes = ddLists[3]["GBR_CUST_TYPE"] ? [...ddLists[3]["GBR_CUST_TYPE"].map(type => {
                return {
                    ...type,
                    label: type.description,
                    value: type.code
                }
            })] : [];
            state.addressTypes = ddLists[4]["GBR_ADDRESS_TYPE"] ? [
                ...ddLists[4]["GBR_ADDRESS_TYPE"].map(type => {
                    return {
                        ...type,
                        label: type.description,
                        value: type.code
                    }
                })
            ] : [];
        },
        setResolution(state, action) {
            state.appResolution = action.payload.data
        },
        setInvalidSession(state, action) {
            state.inValidSession = action.payload
        },
        setListItemLoading(state,action){
            state.listItemLoading = action.payload.status
        }
    }
})

// Selectors
const selectedMenu = state => state[DASHBOARD_SLICE].selectedMenu;
const scrAccess = state => state[DASHBOARD_SLICE].screenPermissionByMenu;
const resolution = state => state[DASHBOARD_SLICE].appResolution;
const invalid = state => state[DASHBOARD_SLICE].inValidSession;
const listLoad = state => state[DASHBOARD_SLICE].listItemLoading;
const menus = state => state[DASHBOARD_SLICE].authorizedMenus;

// Create Selectors
export const getSelectedMenuInfo = createSelector(selectedMenu, (menu) => menu);
export const getScreenAccess = createSelector(scrAccess, (scr) => scr);
export const getAppResolution = createSelector(resolution, re => re);
export const getInvlaidSession = createSelector(invalid, (inn) => inn);
export const getListItemLoading = createSelector(listLoad, (load) => load);
export const getAuthorizedMenus = createSelector(menus, (menu) => menu);

export const {
    loadSummary,
    updateSummaryFields,
    loadSummaryResult,
    setGlobalLocale,
    setToolBarStatus,
    authorizationSuccess,
    expandCollapseAuthorizedMenus,
    getSelectedMenu,
    snackBarActionDashboard,
    logoutDashboard,
    loadInq,
    setResolution,
    setInvalidSession,
    setListItemLoading
} = dashboardSlice.actions;

export default dashboardSlice.reducer;