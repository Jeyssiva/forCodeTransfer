import React from 'react';
import { Container } from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';
import MbBreadCrumbs from '../common/mbBreadcrumbs';

export default function DashboardMain() {
  return (
    <>
      <Container maxWidth={false} disableGutters className='container-form' sx={{ minHeight: 300, lineHeight: 'normal' }}>
        <MbBreadCrumbs crumbsList={[{ title: 'dashboard.title', icon: <HomeIcon fontSize="inherit"></HomeIcon> }]} />
        <h1>Welcome To Maybank Payments Operations Portal</h1>
        <h6>Coming soon.</h6>
      </Container>
    </>
  );
}