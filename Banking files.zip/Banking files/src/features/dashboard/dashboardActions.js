import { logout } from "../login/loginSlice"
import { networkISO } from "../../connections/networkISO"
import { INQUIRY, LOGOUT } from "../../constants/apiConstants"
import { CatchErrorDisplay } from "../errorPage/errorHelpers"
import { snackBarActionDashboard } from "./dashboardSlice"
import { loadCustomerPaymentStaticData } from "../showMxTemplateAsTreeView/persistedSlice"
import { TRANS_INQ_SUB_TYPE, TRANS_INQ_TYPE } from "../../constants/constants"
import { FETCH_ISO_SERVICE, FETCH_UAM_SERVICE } from "../../apacheEnvConfig"

export const logoutUser = (username, moduleId, lcAuth, key, forceLogout = false) => {
    return dispatch => {
        try {
            networkISO.loggedinUserProcess(`${FETCH_UAM_SERVICE()}/${LOGOUT}`, 
            {username, moduleId, lcAuth, forceLogout})
            .then((response) => {
                if(!response) throw new Error('Failed to fetch');
                if(!response.ok){
                    if(response.status)
                        throw new Error(`${response.status} - ${response.statusText}`)
                    else throw new Error('Failed to fetch')                
                }
                return response.json()
            })
            .then(resData => {
                dispatch(logout({resData, key}));
                // dispatch(logoutDashboard(resData));
                dispatch({type: 'auth/logout', payload : resData});
            })
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, LOGOUT, dispatch);
                if(findDisplayMessage)
                    dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: findDisplayMessage.displayMessage}));
                else
                    dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: error.message}));
            })
        }
        catch(error) {
            dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: error.message}));
        }
    }   
}

export const bindPaymentDataStaticList = (requestBody) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${INQUIRY}`, 
                    requestBody, TRANS_INQ_TYPE, TRANS_INQ_SUB_TYPE)
            .then((response) => {
                if(!response) throw new Error('Failed to fetch') 
                if(!response.ok){
                    if(response.status)
                        throw new Error(`${response.status} - ${response.statusText}`)
                    else throw new Error('Failed to fetch')                
                }
                return response.json()
            })
            .then(resData => {
                dispatch(loadCustomerPaymentStaticData({resData}));
            })
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, INQUIRY, dispatch);
                if(findDisplayMessage)
                    dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}`}));
                else
                    dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: `${error.message}`}));
            })
        }
        catch(error) {
            dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: `${error.message}`}));
        }
    }   
}
