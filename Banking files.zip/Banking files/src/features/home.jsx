import React, { useMemo } from 'react';
import moment from 'moment';
import { isEmpty } from 'lodash';
import Box from '@mui/material/Box';
import List from '@mui/material/List';
import Stack from '@mui/material/Stack';
import Avatar from '@mui/material/Avatar';
import Divider from '@mui/material/Divider';
import Toolbar from '@mui/material/Toolbar';
import MuiDrawer from '@mui/material/Drawer';
import { styled } from '@mui/material/styles';
import { FormattedMessage } from "react-intl";
import { useIdleTimer } from 'react-idle-timer';
import MenuIcon from '@mui/icons-material/Menu';
import { PersonPin } from '@mui/icons-material';
import IconButton from '@mui/material/IconButton';
import CssBaseline from '@mui/material/CssBaseline';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { isMobileOnly } from 'react-device-detect';

import logo from '../images/logo.png';
import human from '../images/human.jpg';
import Profile from './dashboard/profile';
import ListItems from './dashboard/listItems';
import MbSnackbar from './common/mbSnackbar';
import { defaultLocales } from './i18n';
import SubNavigation from './dashboard/subNavigation';
import { logoutUser } from './dashboard/dashboardActions';
import { authorizedUserAccess } from './login/loginAction';
import { getTokens, sessionClear } from './dashboard/helpers';
import SessionTimeoutModal from './logout/sessionTimeoutModal';
import { getApacheEnvs, getLocalAuth, getUserInfo } from './login/loginSlice';
import { ERROR_NAME, EXIT, CUSTROUTE, CUSTOMERPAYMENTDATA } from '../constants/routesURL';
import ConfirmationDialog from './customerPaymentData/confirmationDialog';
import { DASHBOARD_SLICE, LOGIN_SLICE } from '../constants/sliceConstants';
import { CustomerMaintainance } from './customerPaymentData/customerDataAction';
import { getConfirmationAlert, getUpdatedCustDetails, storeUpdatedInfo, updateRefreshStateRequired } from './customerPaymentData/customerDataSlice';
import { getInvlaidSession, setResolution, setToolBarStatus, snackBarActionDashboard, setListItemLoading } from './dashboard/dashboardSlice';
import { DATE_TIME_FORMAT_LONG, EXIT_KEY_LOGOUT, MODULE_ID, TRANS_SAVE_ACCOUNT_SUBTYPE, sessionItems } from '../constants/constants';
const drawerWidth = 200;

export default function Home() {
  const [openToolBar, setOpenToolBar] = React.useState(true);
  const [openProfile, setOpenProfile] = React.useState(null);
  const [openSesTO, setOpenSessionTO] = React.useState(false);
  const [openConfirmationDialog, setConfirmationDialog] = React.useState(false);
  const username = sessionStorage.getItem(sessionItems.Username);

  const navigate = useNavigate();
  const location = useLocation();
  const actionDispatch = useDispatch();
  const localAuth = useSelector(getLocalAuth);
  const getUserInformation = useSelector(getUserInfo);
  const getInValidSessionStatus = useSelector(getInvlaidSession);
  const globalLocale = useSelector(state => state.dashboard.locale);
  const exitReason = useSelector(state => state[LOGIN_SLICE].exitReason);
  const safeKickout = useSelector(state => state[LOGIN_SLICE].safeKickout);
  const loginStatus = useSelector(state => state[LOGIN_SLICE].loginStatus);
  const logoutStatus = useSelector(state => state[LOGIN_SLICE].logoutStatus);
  const snackBarPropertiesDashboard = useSelector(state => state[DASHBOARD_SLICE].snackBarPropertiesDashboard);
  const apacheEnvConfig = useSelector(getApacheEnvs);
  
  // store the window resolution.
  React.useEffect(() => {
    function updateScreenSize() {
      const { outerHeight, outerWidth, innerHeight, innerWidth } = window;
      actionDispatch(setResolution({ data: { outerHeight, outerWidth, innerHeight, innerWidth } }));
    }
    function inProperLogout(event) {
      // event.preventDefault();
      const username = getUserInformation && getUserInformation.userLogin;
      actionDispatch(logoutUser(username,MODULE_ID, localAuth, EXIT_KEY_LOGOUT, true))
     // return event.returnValue = 'Are you sure close the tab?';
    }
    window.addEventListener('resize', updateScreenSize);
    window.addEventListener("beforeunload", inProperLogout);
    updateScreenSize();
    return () => {
      window.removeEventListener('resize', updateScreenSize);
      window.removeEventListener("beforeunload", inProperLogout);
    }
  }, [actionDispatch]);

  React.useEffect(() => {
    const { uamToken, isoToken } = getTokens();
    if (loginStatus === true && logoutStatus === false && isoToken && (localAuth || uamToken)) {
      actionDispatch(setListItemLoading({ status: true }));
      actionDispatch(authorizedUserAccess(username, safeKickout, localAuth));
    } else {
      sessionClear();
      navigate(`/${EXIT}/${exitReason}`);
    }
  }, [loginStatus, logoutStatus, actionDispatch])

  /**
   * if current router url not from create customer, then provide the permission to reset 
   * the customerReducer state values.
   */
  React.useEffect(() => {
    if(!location.pathname.includes(CUSTOMERPAYMENTDATA)) 
        actionDispatch(updateRefreshStateRequired({status: true}));
  }, [location.pathname]);

  React.useEffect(() => {
    if (isEmpty(getInValidSessionStatus)) return;
    const { status, errorCode } = getInValidSessionStatus;
    if (status) {
      // navigate('/login')
      navigate(`/${ERROR_NAME}/${errorCode}`)
    }
  }, [getInValidSessionStatus, navigate])

  const idleTime = useMemo(() => {
    return apacheEnvConfig.idleTime;
  }, [apacheEnvConfig]);

  const handleOnIdle = event => {
    setOpenSessionTO(true);
  };

  const onHandleSessionClose = ({ key = EXIT_KEY_LOGOUT }) => {
    setOpenSessionTO(false);
    actionDispatch(logoutUser(username, MODULE_ID, localAuth, key, true));
  }

  const onHandleStayedIn = () => {
    setOpenSessionTO(false);
  }

  const onSnackBarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    actionDispatch(snackBarActionDashboard({ open: false, severity: '', snackBarMessage: '' }));
  }

  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setOpenToolBar((open) => !open);
    actionDispatch(setToolBarStatus(open))
  };

  const toggleProfile = (event) => {
    setOpenProfile(event.currentTarget)
  }

  const onCloseProfile = () => {
    setOpenProfile(null);
  }

  // const onHandleLocale = e => {
  //   setLocale(e.target.value);
  //   actionDispatch(setGlobalLocale(e.target.value));
  //   sessionStorage.setItem(sessionItems.CurrentLang, e.target.value)
  // }

  // const localesList = locales.map(loc => {
  //   const { label, value, sLabel } = loc;
  //   if (openToolBar && isMobileOnly) {
  //     return {
  //       label: sLabel,
  //       value
  //     }
  //   }
  //   return { label, value }
  // })

  const getLastLoggedInAt = React.useMemo(() => {
    try {
      if (!getUserInformation || !getUserInformation.userAuthApps) return {};
      const findAuth = getUserInformation.userAuthApps.find(g => g.moduleId === MODULE_ID);
      return findAuth && findAuth.lastLoggedinAt;
    }
    catch (err) {
      actionDispatch(snackBarActionDashboard({ open: true, severity: 'error', snackBarMessage: `${err.message}` }))
    }
  }, [getUserInformation])

  useIdleTimer(
    {
      timeout: idleTime,
      onIdle: handleOnIdle,
      debounce: 500,
      events: ['mousemove', 'keydown', 'wheel']
    }, [idleTime]) // Reinitialize useIdleTimer once idleTime changes

  const renderDrawerItems = () => {
    return (
      <>
        <Toolbar className='top-menu'>
          <IconButton className='mr' onClick={toggleDrawer(false)}>
            {openToolBar ? <ChevronLeftIcon /> : <MenuIcon />}
          </IconButton>
          <h5>
            {openToolBar ? 'MAYBANK UK (LONDON)' : ''}
          </h5>
        </Toolbar>
        <Divider className='divider-blue' />
        <List disablePadding component="nav">
          {openToolBar ? <ListItems /> : <></>}
        </List>
      </>
    )
  }

  const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
      '& .MuiDrawer-paper': {
        position: 'relative',
        whiteSpace: 'nowrap',
        width: drawerWidth,
        transition: theme.transitions.create('width', {
          easing: theme.transitions.easing.sharp,
          duration: theme.transitions.duration.enteringScreen,
        }),
        boxSizing: 'border-box',
        ...(!open && {
          overflowX: 'hidden',
          transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
          }),
          width: theme.spacing(7),
          [theme.breakpoints.up('sm')]: {
            width: theme.spacing(9),
          },
        }),
        zIndex: 1,
      },
    }),
  );

  const DrawerMobile = styled(MuiDrawer)(
    () => ({
      '& .MuiDrawer-paper': {
        width: drawerWidth,
      },
    }),
  );

  return (
    <React.Fragment>
      <div className={'header'}>
        <Box className={'header-content'}>
          {
            isMobileOnly &&
            <Stack alignItems={'center'} >
              <IconButton
                edge="start"
                color="inherit"
                aria-label="open drawer"
                onClick={toggleDrawer()}
                sx={{
                  marginRight: '36px',
                  ...(openToolBar && { display: 'block' }),
                }}
              >
                <MenuIcon />
              </IconButton>
            </Stack>
          }
          {
            isMobileOnly &&
            <Stack alignItems={'center'} flexDirection={"column"} >
              <img width={'90px'} style={{ marginTop: -10, marginBottom: 10 }} height={'30px'} className="logo" src={logo} margin={5} />
              <h6><FormattedMessage id="loginPage.maybank" defaultMessage={defaultLocales["loginPage.maybank"]} />|M-POP</h6>
            </Stack>
          }
          {
            !isMobileOnly &&
            <Stack alignItems={'center'} direction="row" >
              <h5>Maybank Payments
                <br /><span className='h2'>Operations Portal</span></h5>
            </Stack>
          }
          <Stack alignItems={'center'} direction="row" >
            {
              !isMobileOnly && <h5 className='h5'>Hello, {getUserInformation && `${getUserInformation.userFirstName}, ${getUserInformation.userLastName}`}
                {/* <br /><div>Last Login : {new Date(getLastLoggedInAt).toLocaleString(locale, { timeZone: 'Europe/London', dateStyle: "full", timeStyle: 'short' })} (EU/LDN) */}
                <br />
                <div>
                  {!String(getLastLoggedInAt).includes('T') && `Login :  ${moment(Date.now()).format(DATE_TIME_FORMAT_LONG).replace(',', ' at')}`}
                  {String(getLastLoggedInAt).includes('T') && `Last Login :  ${moment(new Date(getLastLoggedInAt)).format(DATE_TIME_FORMAT_LONG).replace(',', ' at')}`}
                </div></h5>
            }
            <IconButton size="large" onClick={toggleProfile}>
              <Avatar src={human} >
                {
                  getUserInformation ? `${getUserInformation.userFirstName[0]}${getUserInformation.userLastName[0]}`
                    : <PersonPin></PersonPin>
                }
              </Avatar>
            </IconButton>
          </Stack>
        </Box>
      </div>
      <div className='sidebar'>
        <Box sx={{ display: 'flex' }}>
          <CssBaseline />
          {
            isMobileOnly ?
              <DrawerMobile id='drawer' anchor='right' open={openToolBar} onClose={toggleDrawer(false)}>
                <Box
                  sx={{ width: drawerWidth }}
                  role="presentation"
                  onClick={toggleDrawer(openToolBar)}
                  onKeyDown={toggleDrawer(openToolBar)}
                >
                  {
                    renderDrawerItems()
                  }
                </Box>
              </DrawerMobile>
              :
              <Drawer id='drawer' variant="permanent" open={openToolBar}>
                {
                  renderDrawerItems()
                }
              </Drawer>
          }
          <SubNavigation />
          <Profile openProfile={openProfile} onCloseProfile={onCloseProfile} locale={globalLocale} />
          {
            openSesTO &&
            <SessionTimeoutModal openSesTO={openSesTO} onHandleSessionClose={onHandleSessionClose} onHandleStayedIn={onHandleStayedIn} />
          }
        </Box>
      </div>
      {
        snackBarPropertiesDashboard.open &&
        <MbSnackbar open={snackBarPropertiesDashboard.open} onClose={onSnackBarClose} severity={snackBarPropertiesDashboard.severity}
          message={snackBarPropertiesDashboard.snackBarMessage} />
      }
    </React.Fragment>
  );
}