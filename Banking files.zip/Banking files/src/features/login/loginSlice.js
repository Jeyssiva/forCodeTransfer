
import { createSelector, createSlice } from '@reduxjs/toolkit';
import { LOGIN_SLICE } from '../../constants/sliceConstants';
import { EXIT_KEY_LOGOUT, sessionItems } from '../../constants/constants';
import { sessionClear } from '../dashboard/helpers';
import { has } from 'lodash';
import { ADMIN_USERGROUPS, CHECKER_USERGROUPS, MAKER_USERGROUPS } from '../../constants/transactionConstants';
import { HEADERS } from '../../apacheEnvConfig';

const initialState = {
    username: '',
    password: '',
    loginStatus: undefined,
    loginMessage: null,
    snackBarProperties: {},
    safeKickout: false,
    logoutStatus: false,
    isLoadingLgn: false,
    isUserAlreadyLoggedIn: false,
    localAuth: false,
    userGroups: null,
    makerCheckerRole: {},
    exitReason: EXIT_KEY_LOGOUT,
    staticDataVersionLogin : 0,
    apacheEnvs: {...HEADERS}
};

function makerChecker(loggedInUserGroup) {
    const userGroupId = (loggedInUserGroup && loggedInUserGroup[0] && loggedInUserGroup[0].userGroupId) || null;
    const isMaker = MAKER_USERGROUPS.includes(userGroupId);
    const isChecker = CHECKER_USERGROUPS.includes(userGroupId);
    const isAdmin = ADMIN_USERGROUPS.includes(userGroupId);
    if (isMaker && isChecker) return { maker: true, checker: true, others: false }
    else if (isMaker) return { maker: true, checker: false, other: false }
    else if (isChecker) return { maker: false, checker: true, other: false }
    else if (isAdmin) return { maker: false, checker: false, others: true }
    else return { maker: false, checker: false, other: false }
}

const loginSlice = createSlice({
    name: LOGIN_SLICE,
    initialState,
    reducers: {
        loginSuccess(state, action) {
            const { userData, safeKickOut, isoTokenResp } = action.payload;
            const { data, lcAuth } = userData;
            
            const { userDetail: { userUserGroups, pfNo } } = data
            state.loginStatus = true;
            state.logoutStatus = false;
            state.username = data.userLogin;
            state.safeKickout = safeKickOut;
            state.isUserAlreadyLoggedIn = false;
            sessionStorage.setItem(sessionItems.Username, data.userLogin);
            sessionStorage.setItem(sessionItems.LoginStatus, true);
            sessionStorage.setItem(sessionItems.UAMToken, data.jwt);
            sessionStorage.setItem(sessionItems.CountryCode, data.userDetail.isoCountry);
            sessionStorage.setItem(sessionItems.ISOToken, isoTokenResp.id_token);
            sessionStorage.setItem(sessionItems.pfNumber, pfNo);
            sessionStorage.setItem(sessionItems.RoleId, (userUserGroups && userUserGroups[0] && userUserGroups[0].roleId) || null)
            state.userInformation = data.userDetail;
            state.userGroups = userUserGroups;
            state.isLoadingLgn = false;
            state.localAuth = lcAuth;
            state.makerCheckerRole = makerChecker(userUserGroups);
            //It is used for either update the static data list or schema list in indexedDB.
            state.staticDataVersionLogin = 1;
        },
        loginFailed(state, action) {
            const { data, messages } = action.payload;
            let displayMessages = [...messages];

            if(displayMessages.includes('User Already Logged In')) {
                state.isUserAlreadyLoggedIn = true;
                displayMessages = ["You are already logged in, Please kick out & try again"]
            }
            else state.isUserAlreadyLoggedIn = false;
            if(displayMessages.includes('Account locked in AD')) state.loginMessage = ["Your username/ credential has been locked"]
            else if(has(data, 'loginFailedAttempts')) state.loginMessage = [...displayMessages,  `Loggedin Attempts - ${data.loginFailedAttempts}`]
            else state.loginMessage = displayMessages;
            
            state.loginStatus = false;
            state.logoutStatus = true;
            sessionStorage.setItem(sessionItems.LoginStatus, false);
            sessionStorage.setItem(sessionItems.Username, data.userLogin);
            sessionStorage.setItem(sessionItems.UAMToken, data.jwt);
            sessionStorage.setItem(sessionItems.CountryCode, null); 
            sessionStorage.setItem(sessionItems.ISOToken, null);
            sessionStorage.setItem(sessionItems.pfNumber, null);
            sessionStorage.setItem(sessionItems.RoleId, null);
            state.isLoadingLgn = false;
            state.makerCheckerRole = {}
        },
        logout(state, action) {
            const {resData, key} = action.payload;
            const logoutState = {...initialState};
            logoutState.logoutStatus = resData;
            logoutState.loginStatus = false;
            logoutState.properLogout = true;
            logoutState.loginMessage = undefined;
            logoutState.makerCheckerRole = {};
            logoutState.exitReason = key;
            sessionClear();
            return logoutState; 
        },
        snackBarLoginActions(state, action) {
            state.snackBarProperties = { ...action.payload }
            state.isLoadingLgn = false;
        },
        setLoadingStatus(state, action) {
            const { status, messages } = action.payload;
            state.isLoadingLgn = status;
            state.loginMessage = messages;
        },
        setApacheEnv(state, action) {
            const { headerObj } = action.payload;
            state.apacheEnvs = {...headerObj};
        }
    }
})

// Selectors
const userGroup = (state) => state[LOGIN_SLICE].userGroups;
const localAuth = (state) => state[LOGIN_SLICE].localAuth;
const makChk = (state) => state[LOGIN_SLICE].makerCheckerRole;
const info = (state) => state[LOGIN_SLICE].userInformation;
const version = (state) => state[LOGIN_SLICE].staticDataVersionLogin;
const env = (state) => state[LOGIN_SLICE].apacheEnvs;

// Create the selector function
export const getUserGroup = createSelector(userGroup, (groups) => groups);
export const getLocalAuth = createSelector(localAuth, (auth) => auth);
export const getUserPriority = createSelector(makChk, (mak) => mak);
export const getUserInfo = createSelector(info, (i) => i);
export const getStaticDataVersionLogin = createSelector(version, v => v);
export const getApacheEnvs = createSelector(env, e => e);

export const {
    snackBarLoginActions,
    loginSuccess,
    loginFailed,
    logout,
    setLoadingStatus,
    setApacheEnv
} = loginSlice.actions;

export default loginSlice.reducer; 