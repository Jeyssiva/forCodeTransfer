
import CryptoJS from 'crypto-js';

export const encryptPassword = (password, moduleId, username) => {
    const ivKey = moduleId.padEnd(16, ' ');
    const iv = CryptoJS.enc.Utf8.parse(ivKey); // Ensure IV is 16 bytes long
    var secKey = username.toLowerCase().padEnd(16, ' ');
    const secretKey = CryptoJS.enc.Utf8.parse(secKey); // Ensure key length is appropriate
    // Encrypt the password
    const encrypted = CryptoJS.AES.encrypt(password, secretKey, {
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
        iv
    });
    // Convert the encrypted data to Base64
    const encryptedBase64 = encrypted.ciphertext.toString(CryptoJS.enc.Base64);
    return {
        encryptedData: encryptedBase64
    };
};
  
export const decryptPassword = (encryptedData, moduleId, username) => {
    // Parse the key from Base64
    // const secretKey = CryptoJS.enc.Utf8.parse(base64Key);
    // // Convert the IV from Base64 to a WordArray
    // const iv = CryptoJS.enc.Base64.parse(ivBase64);
    // Convert the encrypted data from Base64 to a WordArray
    const ivBase64 = CryptoJS.enc.Utf8.parse(moduleId);
    // Parse the key from Base64
    // const baseKey = 'isomkr01';
    const secretKey = CryptoJS.enc.Utf8.parse(username.toLowerCase());
    const encryptedWordArray = CryptoJS.enc.Base64.parse(encryptedData);
    // Decrypt the encrypted data
    const decrypted = CryptoJS.AES.decrypt({
        ciphertext: encryptedWordArray
    }, secretKey, {
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
        iv: ivBase64
    });
    // Convert decrypted data from WordArray to a UTF-8 string
    const decryptedText = decrypted.toString(CryptoJS.enc.Utf8);
    return decryptedText;
};