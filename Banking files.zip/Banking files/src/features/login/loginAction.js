import { MODULE_ID } from "../../constants/constants";
import { loginFailed, loginSuccess, setApacheEnv } from "./loginSlice";
import { networkISO, rewriteEnvSettings } from "../../connections/networkISO";
import { CatchErrorDisplay } from "../errorPage/errorHelpers";
import { AUTH, AUTHORISE, TOKEN } from "../../constants/apiConstants";
import { authorizationSuccess, setListItemLoading, snackBarActionDashboard } from "../dashboard/dashboardSlice";

import ApacheEnvConfig, { FETCH_UAM_SERVICE } from '../../apacheEnvConfig'

export const checkLogin = (username, password, domainname, safeKickOut, rememberMe = false) => {
    const data = {
        username,
        password,
        rememberMe,
        safeKickOut,
        moduleId: MODULE_ID,
        retrieveAM: false,
        retrievePrefs: false
    }
    return dispatch => {
        try {
            networkISO.auth(`${FETCH_UAM_SERVICE()}/${AUTH}`, data)
            .then(response => {
                if(!response) throw new Error('Failed to fetch') 
                if(!response.ok){
                    if(response.status)
                        throw new Error(`${response.status} - ${response.statusText}`)
                    else throw new Error('Failed to fetch')                
                }
                return response.json();
            })
            .then(resData => {
                const { status, lcAuth, data : { jwt } } = resData;
                if(status.toUpperCase() === 'SUCCESS') {
                    if(!lcAuth && !jwt)
                        dispatch(loginFailed({messages: ['Authentication Token not found'], data: {userLogin: username, jwt: null}}));
                    else if((!lcAuth && jwt) || lcAuth) {
                        /**
                         * 1. Either lcAuth = false && jwt must be available
                         * 2. lcAuth = true 
                         * Purpose of lcAuth - Fetching authorization's response from ISO Service rather than UAM.
                         */
                        networkISO.getISOToken(`${FETCH_UAM_SERVICE()}/${TOKEN}`, data)
                            .then(resToken => {
                                return resToken.json();
                            })
                            .then(isoTokenResp => {
                                dispatch(loginSuccess({userData: resData, safeKickOut, isoTokenResp}))
                            })
                            .catch(error => {
                                const findDisplayMessage = CatchErrorDisplay(error, TOKEN, dispatch);
                                if(findDisplayMessage)
                                    dispatch(loginFailed({messages: [findDisplayMessage.displayMessage], data: {userLogin: username, jwt: null}}));
                                else
                                    dispatch(loginFailed({messages: [error.message], data: {userLogin: username, jwt: null}}));
                            })
                    }
                }
                else dispatch(loginFailed(resData));
            })
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, AUTH, dispatch);
                if(findDisplayMessage)
                    dispatch(loginFailed({messages: [findDisplayMessage.displayMessage], data: {userLogin: username, jwt: null}}));
                else
                    dispatch(loginFailed({messages: [error.message], data: {userLogin: username, jwt: null}}))
            })
        }
        catch (error) {
            dispatch(loginFailed({ messages: [error.message], data: { userLogin: username, jwt: null } }))
        }
    }
}

export const authorizedUserAccess = (username, safeKickOut, lcAuth) => {
    return dispatch => {
        try {
            networkISO.loggedinUserProcess(`${FETCH_UAM_SERVICE()}/${AUTHORISE}`, {
                username,
                safeKickOut,
                moduleId: MODULE_ID,
                retrieveAM: true,
                retrievePrefs: false,
                lcAuth
            })
            .then(res => {
                if(!res) throw new Error('Failed to fetch') 
                if(!res.ok){
                    if(res.status)
                        throw new Error(`${res.status} - ${res.statusText}`)
                    else throw new Error('Failed to fetch')                
                }
                return res.json()
            })
            .then(resData => {
                dispatch(authorizationSuccess(resData));
            })
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, AUTHORISE, dispatch);
                if(findDisplayMessage)
                    dispatch(snackBarActionDashboard({open:true, severity: 'error', snackBarActions: findDisplayMessage.displayMessage}));
                else
                    dispatch(snackBarActionDashboard({open:true, severity: 'error', snackBarActions: error.message}));
                dispatch(setListItemLoading({status: false}));
            })
        }
        catch(error) {
            dispatch(snackBarActionDashboard({open:true, severity: 'error', snackBarActions: error.message}));
            dispatch(setListItemLoading({status: false}));
        }
    }
}

export const getEnvsFromConfFile = () => {
    return dispatch => {
        try {
            networkISO.head()
            .then((response) => {
                const {headers} = response;
                const headerObj = {
                    uamService : headers.get("X-REACT-APP-ISO-UAM-SERVICE")?.trim() || process.env.REACT_APP_ISO_UAM_SERVICE,
                    idleTime : headers.get("X-REACT-APP-IDLE-TIME-MS")?.trim() || process.env.REACT_APP_IDLE_TIME_MS,
                    autoLogoutAfterIdle : headers.get("X-REACT-APP-AUTO-LOGOUT")?.trim() || process.env.REACT_APP_AUTO_LOGOUT,
                    logonIdleTime : headers.get("X-REACT-APP-LOGON-IDLE-TIME-MS")?.trim() || process.env.REACT_APP_LOGON_IDLE_TIME_MS,
                    isoService : headers.get("X-REACT-APP-MBB-ISO-SERVICE")?.trim() || process.env.REACT_APP_MBB_ISO_SERVICE,
                    apiTimeout : headers.get("X-REACT-APP-API-TIMEOUT")?.trim() || process.env.REACT_APP_API_TIMEOUT,
                    authAPITimeout : headers.get("X-REACT-APP-AUTH-API-TIMEOUT")?.trim() || process.env.REACT_APP_AUTH_API_TIMEOUT,
                    transAPITimeout : headers.get("X-REACT-APP-SAVE-TRANS-API-TIMEOUT")?.trim() || process.env.REACT_APP_SAVE_TRANS_API_TIMEOUT,
                    custBICCode : headers.get("X-REACT-APP-CUSTOMER-BIC-CODE")?.trim() || process.env.REACT_APP_CUSTOMER_BIC_CODE
                }
                // console.log(headerObj);
                ApacheEnvConfig.setApacheConfig(headerObj);
                rewriteEnvSettings(headerObj);
                dispatch(setApacheEnv({headerObj}));
            })
            .catch(error => {
                console.log('error', error);
            })
        }
        catch(error) {
            console.log('error', error);
        }
 }
}