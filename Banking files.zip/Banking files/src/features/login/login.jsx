import { useEffect, useMemo, useState } from "react";
import { FadeLoader } from "react-spinners";
import { useNavigate } from 'react-router-dom';
import { useIdleTimer } from "react-idle-timer";
import { useDispatch, useSelector } from "react-redux";
import { FormattedMessage, useIntl } from "react-intl";
import { Box, Container, Grid, Checkbox, Divider, FormControlLabel, IconButton } from "@mui/material";

import logo from '../../images/logo.png';
import { defaultLocales } from "../i18n";
import MbButton from "../common/mbButton";
import { checkLogin, getEnvsFromConfFile } from "./loginAction";
import MbDropdown from "../common/mbDropdown";
import MbSnackbar from "../common/mbSnackbar";
import MbTextField from "../common/mbTextField";
import { encryptPassword } from "./loginHelpers";
import { HOME_PAGE } from "../../constants/routesURL";
import { LOGIN_SLICE } from "../../constants/sliceConstants";
import { getApacheEnvs, getLocalAuth, setLoadingStatus } from "./loginSlice";
import { getTokens, sessionClear } from "../dashboard/helpers";
import { DOMAINS, MODULE_ID } from "../../constants/constants";

function Login() {
  const intl = useIntl();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const localAuth = useSelector(getLocalAuth);
  const [errorStatus, setError] = useState({});
  const [errorMsg, setErrorMessage] = useState(null);
  const [loginCred, setLoginCredentials] = useState({});
  const [domainName, setDomainName] = useState('global');
  const [idleActivated, setIdleActivate] = useState(false);
  const loginStatus = useSelector(state => state[LOGIN_SLICE].loginStatus);
  const logoutStatus = useSelector(state => state[LOGIN_SLICE].logoutStatus);
  const loginMessage = useSelector(state => state[LOGIN_SLICE].loginMessage);
  const isLoadingLogin = useSelector(state => state[LOGIN_SLICE].isLoadingLgn);
  const isUserAlreadyLoggedIn = useSelector(state => state[LOGIN_SLICE].isUserAlreadyLoggedIn);
  const apacheEnvConfig = useSelector(getApacheEnvs);

  const userLength = 8;
  const passLength = 31;

  useEffect(() => {
    if(!window.location.hostname.includes('localhost'))
     dispatch(getEnvsFromConfFile());
  }, [])
  
  useEffect(() => {
    const { uamToken, isoToken } = getTokens();
    // if localAuth is true, then no need to consider the UAMToken.
    if (loginStatus === undefined || (!localAuth && !uamToken) || !isoToken) {
      sessionClear();
      navigate('/login');
      return
    }
    if (loginStatus === true && logoutStatus === false && isoToken && (localAuth || uamToken)) {
      setError({})
      setErrorMessage(null)
      navigate(HOME_PAGE)
    }
  }, [loginStatus, logoutStatus, localAuth, navigate]);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (idleActivated) {
      setErrorMessage(intl.formatMessage({ id: "loginPage.sessionInActive", defaultMessage: defaultLocales["loginPage.sessionInActive"] }));
      return null;
    }
    const { username, password } = loginCred;
    if (!username && !password) {
      setError({ username: true, password: true });
      setErrorMessage(defaultLocales['loginPage.invalidError'])
    } else if (!username || username.length < userLength) {
      setError({ username: true });
      setErrorMessage(defaultLocales['loginPage.invalidUser'])
    } else if (!password) {
      setError({ password: true });
      setErrorMessage(defaultLocales['loginPage.invalidError'])
    } else if (domainName !== 'global') {
      setError({ domainName: true });
      setErrorMessage(defaultLocales['loginPage.invalidDomain'])
    } else {
      setError({});
      setErrorMessage(null);
      const { encryptedData } = encryptPassword(password, MODULE_ID, username);
      dispatch(setLoadingStatus({ status: true, messages: null }));
      dispatch(checkLogin(username, encryptedData, domainName, true));
    }
  };

  const onHandleLoginIdle = () => {
    setIdleActivate(true);
    setErrorMessage(intl.formatMessage({ id: "loginPage.sessionTimout", defaultMessage: defaultLocales["loginPage.sessionTimout"] }));
  }
  
  const logonIdleTime = useMemo(() => {
    return apacheEnvConfig.idleTime;
  }, [apacheEnvConfig]);

  // Idle time for login inactivity 
  useIdleTimer({
    timeout: logonIdleTime,
    onIdle: onHandleLoginIdle,
    // onActive : onHandleLoginActive,
    debounce: 500,
    events: ['mousemove', 'keydown', 'wheel']
  }, [logonIdleTime])

  const onInputChange = (value, fieldName) => {
    setLoginCredentials((props) => ({ ...props, [fieldName]: value }))
  }

  const onSnackBarClose = () => {
    setErrorMessage('');
  }

  return (
    <Grid container columns={{ xs: 8, sm: 8, md: 16 }}>
      <Grid item xs={16}>
        <Container maxWidth={false} disableGutters
          className="login-container">
          <Box
            className="login-box"
          >
            <Box
              className="login-form"
              component="form" onSubmit={handleSubmit} noValidate
            >
              <center>
                <img className="logo" alt="logo" src={logo} />
                <span className="small-title"><FormattedMessage id="loginPage.maybank" defaultMessage={defaultLocales["loginPage.maybank"]} /></span>
              </center>
              <div className="title">
                <FormattedMessage id="loginPage.loginTitle" defaultMessage={defaultLocales["loginPage.loginTitle"]} />
              </div>
              <Divider key={"login_divid"} sx={{ width: '100%', margin: 0.5 }} orientation="horizontal" />
              <MbTextField
                id="username"
                name="username"
                variant="filled"
                margin="none"
                size="small"
                required
                error={errorStatus.username || false}
                autoComplete="off"
                autoFocus
                label={
                  <b className="bold"><FormattedMessage id="loginPage.username" defaultMessage={defaultLocales["loginPage.username"]} /></b>
                }
                key="txtUserName"
                inputProps={{ maxLength: userLength }}
                helperText={loginCred && loginCred.username ? `Max Length is ${userLength}` : ''}
                onChange={(e) => onInputChange(e.target.value, "username")}
              />
              <MbTextField
                id="password_"
                name="password"
                variant="filled"
                margin="none"
                size="small"
                enablePasswordAdornment={true}
                required
                autoComplete="off"
                error={errorStatus.password || false}
                label={
                  <b className="bold"><FormattedMessage id="loginPage.password" defaultMessage={defaultLocales["loginPage.password"]} /></b>
                }
                key="txtPassword"
                helperText={loginCred && loginCred.password ? `Max Length is ${passLength}` : ''}
                inputProps={{ maxLength: passLength }}
                onChange={(e) => onInputChange(e.target.value, "password")}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSubmit(e);
                }}
              />
              <MbDropdown
                id="domainname"
                size="small"
                margin="none"
                sxFormStyles={'mb'}
                dropdownList={DOMAINS} fullWidth={true}
                onDropdownChange={(e) => setDomainName(e.target.value)}
                error={errorStatus.domainName || false}
                labelName={<b className="bold">COMPANY</b>} labelValue={domainName}
                arrowIcon={true}
              />
              {
                isUserAlreadyLoggedIn &&
                <FormControlLabel
                  id={"safekickout"}
                  control={<Checkbox size="small" color="primary" name="safekickout" />}
                  onChange={(e) => onInputChange(e.target.checked, 'safekickout')} checked={loginCred.safekickout || false}
                  label={<b className="bold"><FormattedMessage id="loginPage.safekickout"
                    defaultMessage={defaultLocales["loginPage.safekickout"]} /></b>}
                />
              }
              {
                loginMessage && (
                  <MbSnackbar open={true}
                    severity={'error'}
                    message={JSON.stringify(loginMessage).replace(/[\[\]\"]/g, "")}
                    />
                )
              }
              {
                errorMsg && (
                  <MbSnackbar open={errorMsg ? true : false}
                    severity={'error'}
                    message={errorMsg} 
                    onClose={onSnackBarClose} />
                )
              }
              {
                isLoadingLogin ? (
                  <IconButton sx={{ display: 'flex', textAlign: 'center', width: 'auto' }}>
                    <FadeLoader
                      color={'#000000'}
                      loading={isLoadingLogin}
                      aria-label="Loading Spinner"
                      data-testid="loader" />
                  </IconButton>
                )
                  : (
                    <MbButton
                      variant="outlined"
                      color="secondary"
                      disabled={isLoadingLogin}
                      buttonName={
                        <FormattedMessage id="loginPage.loginButton" defaultMessage={defaultLocales["loginPage.loginButton"]} />
                      }
                      className={'button-signin'}
                      onHandleAction={handleSubmit}
                    />
                  )
              }
              <h5 className="warning-msg">*** <FormattedMessage id='loginPage.warningMsgPart1' defaultMessage={defaultLocales["loginPage.warningMsgPart1"]} /></h5>
              <br /><br /><h5 className="warning-msg">* <FormattedMessage id='loginPage.warningMsgPart2' defaultMessage={defaultLocales["loginPage.warningMsgPart2"]} /> *</h5>
            </Box>
          </Box>
        </Container>
      </Grid>
    </Grid>
  );
}

export default Login;