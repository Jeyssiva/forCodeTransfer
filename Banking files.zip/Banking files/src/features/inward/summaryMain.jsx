import * as React from 'react';
import Box from '@mui/material/Box';
import Label from '@mui/icons-material/Label';
import { TreeView } from '@mui/x-tree-view/TreeView';
import { Add, Folder, Remove } from '@mui/icons-material';
// import summaryJson from '../../summary.json';
import StyledTreeItem from './styledTreeItem';
import { useDispatch, useSelector } from 'react-redux';
import { loadSummary, loadSummaryResult } from '../dashboard/dashboardSlice';
import { countOfEmptyValues, getActualData, getChildProperties } from './helpers';
import ChildErrorPage from '../errorPage/childErrorPage';

function Summary() {
 
  const dispatch = useDispatch();
  const summaryResultJson = useSelector(state => state.dashboard.summaryResultList)
  const summaryJson = useSelector(state => state.dashboard.summaryList)

  React.useEffect(() => {
      dispatch(loadSummary());
      dispatch(loadSummaryResult());
  }, [dispatch])


  if (!summaryJson || !summaryJson.properties || !summaryResultJson ) return null;

  const renderTreeItem = (data, name, nodeId, parentDet) => {
    let processingData = { ...data };
    if (data.type === 'array') {
      processingData = data.items;
    }

    let hasChildren = processingData.required && processingData.required.length > 0 ? true : false;
    const infoValue = !hasChildren ?  getActualData(summaryResultJson, name, parentDet): null
    const labelIcon = hasChildren ? Folder : Label
    const color = hasChildren ? "#3c8039" : '#a250f5'
    const bgColor = hasChildren ? "#e6f4ea" : "#f3e8fd"
    const parentBadgeCount = hasChildren ? countOfEmptyValues(getChildProperties(summaryResultJson, parentDet)) : null;
    const parentBadgeVisible = hasChildren ? false : true;

    return (
      <Box
        sx={hasChildren ? {
          boxShadow: 3,
          borderRadius: 2,
          px: 1,
          py: 1,
          my: 1
        } : {}}
        key={`TreeBox_${processingData.title}` }
      >
        <StyledTreeItem key={processingData.title} nodeId={nodeId}
          labelText={name} labelInfo={infoValue} color={color}
          labelIcon={labelIcon} hasChildren={hasChildren} 
          bgColor={bgColor} 
          parentBadgeVisible={parentBadgeVisible}
          parentBadgeCount={parentBadgeCount}
          parentDetails = {parentDet}
          {...data}
          >
          {
            Array.isArray(processingData.required)
              ? processingData.required.map((childName, index) => {  
                const parentDetails = [...parentDet, {name: childName, type: processingData.properties[childName].type}];
                  return renderTreeItem(processingData.properties[childName], childName, 
                    `${nodeId}.${index + 1}`, parentDetails)
                })
              : null
          }
        </StyledTreeItem>
      </Box>
    )
  }

  try {
    return (
        <TreeView
          aria-label="summary"
          defaultExpanded={['1']}
          defaultCollapseIcon={<Remove />}
          defaultExpandIcon={<Add />}
          defaultEndIcon={<div style={{ width: 24 }} />}
          sx={{ height: 'auto', px: 1, flexGrow: 1, maxWidth: '100%', overflowY: 'auto' }}
        >
          {
            renderTreeItem(summaryJson.properties.requestBody, 'Request Body', '1', [{name: 'requestBody', type: 'object'}])
          }
        </TreeView>
      );
  }
  catch(err) {
    console.error(err);
    return <ChildErrorPage subTitle = {"common.wentWrong"}/>
  }
}

export default Summary;