import { Badge, Grid, IconButton } from "@mui/material";
import { memo } from "react";

const BadgeField = memo(function BadgeField({parentBadgeCount, parentBadgeVisible}){
    return <Grid item sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        maxWidth: '100%',
        width: '100%'
      }}>
        <IconButton color="inherit">
          <Badge badgeContent={parentBadgeCount} color="error" invisible={parentBadgeVisible} />
        </IconButton>
    </Grid> 
})

export default BadgeField;

