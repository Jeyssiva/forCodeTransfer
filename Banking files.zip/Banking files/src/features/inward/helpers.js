import { CUSTOM_REGEX_PATTERN } from "../../constants/constants";

// yyyy-MM-dd --> YYYYMMDD
export const convertCustomDateToDBDate = (dateValue) => {
    if(!dateValue || dateValue === "") return dateValue;
    try {
        new RegExp(CUSTOM_REGEX_PATTERN);
    } catch (error) {
      return dateValue;
    }
      
    const convertedFormat = dateValue.match(CUSTOM_REGEX_PATTERN);
    return `${convertedFormat[1]}${convertedFormat[2]}${convertedFormat[3]}`;
}

//YYYYMMDD -> yyyy-MM-dd
export const convertDBDateToCustomDate = (dateValue, regexPattern) => {
    if(!dateValue || dateValue === "") return dateValue;
    try {
        new RegExp(regexPattern);
    } catch(error) {
        return "";
    }

    const convertedFormat = dateValue.match(regexPattern);
    return `${convertedFormat[1]}-${convertedFormat[2]}-${convertedFormat[3]}`;
}
 
export const countOfEmptyValues = (obj) => {
    if (typeof obj === 'string') {
        return obj.trim() === '' ? 1 : 0;
    }

    if (Array.isArray(obj)) {
        let count = 0;
        for (const item of obj) {
            count += countOfEmptyValues(item);
        }
        return count;
    }

    if (typeof obj === 'object' && obj !== null) {
        let count = 0;
        for (const key in obj) {
            count += countOfEmptyValues(obj[key]);
        }
        return count;
    }

    return 0;
}

export const getActualData = (result, fieldName, parentInfo) => {
    let currentObj = result;
    for(let field of parentInfo.slice(0,-1)){
      if(field.type === 'array') {
        currentObj = currentObj[field.name][0] || {}
      } else {
         currentObj = currentObj[field.name] || {}
      }
    }

    return currentObj[fieldName];
  }

  export const getChildProperties = (result, parentInfo) => {
    let currentObj = result;
    for(let field of parentInfo){
      if(field.type === 'array') {
        currentObj = currentObj[field.name][0] || {}
      } else {
         currentObj = currentObj[field.name] || {}
      }
    }

    return currentObj;
  }

  export const currencyPatternMatch = (amount, regexPattern) => {
    try {
      new regexPattern(regexPattern);
    } catch (error) {
      return false;
    }
     return amount.match(regexPattern) !== null;
  }