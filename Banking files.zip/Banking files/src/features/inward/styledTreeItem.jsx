import * as React from "react";
import { Box, Grid, Typography } from "@mui/material";
import { styled, useTheme } from '@mui/material/styles';
import { TreeItem, treeItemClasses } from '@mui/x-tree-view/TreeItem';
import MbDateField from "../common/mbDateField";
import BadgeField from "./badgeField";
import MbCurrencyField from "../common/mbCurrencyField";
import MbTextField from "../common/mbTextField";
import { useDispatch } from "react-redux";
import { updateSummaryFields } from "../dashboard/dashboardSlice";
import MbRadio from "../common/mbRadio";
import MbDropdown from "../common/mbDropdown";
import { isMobileOnly } from "react-device-detect";

  const StyledTreeItemRoot = styled(TreeItem)(({ theme }) => ({
    color: theme.palette.text.secondary,
    [`& .${treeItemClasses.content}`]: {
      color: theme.palette.text.secondary,
      // borderTopRightRadius: theme.spacing(2),
      // borderBottomRightRadius: theme.spacing(2),
      paddingRight: theme.spacing(1),
      fontWeight: theme.typography.fontWeightMedium,
      '&.Mui-expanded': {
        fontWeight: theme.typography.fontWeightRegular,
      },
      '&:hover': {
        backgroundColor: theme.palette.action.hover,
      },
      '&.Mui-focused, &.Mui-selected, &.Mui-selected.Mui-focused': {
        // backgroundColor: `var(--tree-view-bg-color, ${theme.palette.action.selected})`,
        color: 'var(--tree-view-color)',
        fontWeight: 'bold'
      },
      [`& .${treeItemClasses.label}`]: {
        fontWeight: 'inherit',
        color: 'inherit',
      },
    },
    // [`& .${treeItemClasses.group}`]: {
    //   marginLeft: 0,
    //   [`& .${treeItemClasses.content}`]: {
    //     paddingLeft: theme.spacing(2),
    //   },
    // },
  }));
  
  const StyledTreeItem = React.memo(React.forwardRef(function StyledTreeItem(props, ref) {
    const theme = useTheme();
    const dispatch = useDispatch();

    const {
      bgColor,
      color,
      labelIcon,
      labelInfo,
      labelText,
      colorForDarkMode,
      bgColorForDarkMode,
      hasChildren,
      type,
      parentDetails,
      parentBadgeCount,
      parentBadgeVisible,
      enum: enumValue,
      format,
      pattern,
      ...other
    } = props;

    const styleProps = {
      '--tree-view-color': theme.palette.mode !== 'dark' ? color : colorForDarkMode,
      '--tree-view-bg-color':
        theme.palette.mode !== 'dark' ? bgColor : bgColorForDarkMode,
    };

    const onTreeItemFieldChange = event => {  
        dispatch(updateSummaryFields({value: event.target.value, parentDetails, fieldName: labelText}))
    }

    const renderFieldsComponents = () => {
      if(type === 'integer') {
        return ( 
          <MbTextField sx={{width: '100%'}} onTextFieldChange={onTreeItemFieldChange} type="number" label = {labelText} value = {labelInfo}/>
        )
      } else if (type === 'string' && enumValue && enumValue.length > 0 ){   
        const enumSplitUp = enumValue.map((e => {
          const splitUp = e.split('-');
          return {
              label: (splitUp[1] && splitUp[1].trim()) || splitUp[0].trim(),
              value: splitUp[0].trim()
          }
        }));  
        if(enumSplitUp.length === 2) {
          return (
            <MbRadio radioValue={labelInfo} radioList={enumSplitUp} onRadioChange={onTreeItemFieldChange} />
          )  
        } else {        
          return (      
            <MbDropdown labelName={labelText} labelValue={labelInfo} size="medium" fullWidth={true}
              onDropdownChange={onTreeItemFieldChange} dropdownList={enumSplitUp} />
          )
        }   
      } else if (type === 'string' && format) {
        return (
          <MbDateField onDateChange = {onTreeItemFieldChange} {...props}/>
        )
      } else if(type === 'string' && pattern) {
        return (
          <MbCurrencyField onCurrencyChange= {onTreeItemFieldChange} label = {labelText} value={labelInfo}/>
        )
      }
      else {
        return (
          <MbTextField sx={{width: '100%'}} onTextFieldChange={onTreeItemFieldChange} label = {labelText} value = {labelInfo}/>
        )
      }
    }

    return (
      <StyledTreeItemRoot
        label={
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              flexDirection: 'row',
              p: 0.5,
              pr: 0,
              fontWeight: hasChildren ? '900' : '600',
              fontStyle: !hasChildren ? 'oblique': 'normal',
              maxWidth: '95%',
              // backgroundColor: "#fec70b"
            }}
          >
            <Box component={labelIcon} color="inherit" sx={{ mr: 1 }} />
              {
                !isMobileOnly || (isMobileOnly && hasChildren) ?
                  <Grid item sx={{ maxWidth: '55%', width: '55%' , alignItems: 'flex-start', display: 'flex' }}>
                    <Typography variant="body2" sx={{ fontWeight: 'inherit',}}>
                      {labelText}
                    </Typography>
                  </Grid>
                : null
              }
            
                 <Grid item sx={{
                  display: 'flex',
                  alignItems: 'center',
                  maxWidth: '100%',
                  width: isMobileOnly ? '100%' : '45%'
                }}>
                  {
                    !hasChildren 
                    ?            
                      <Grid item sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'flex-start',
                        width: '100%',
                        maxWidth: '100%'
                      }}>
                        {
                          renderFieldsComponents() 
                        }
                      </Grid>
                   : <BadgeField {...props}/>
                  }
                </Grid>         
          </Box>
        }
        style={styleProps}
        {...other}
        ref={ref}
      />
    );
  }));

  export default StyledTreeItem;
  