import { createSlice } from "@reduxjs/toolkit";
import { MX_TEMPLATES } from "../../constants/sliceConstants";

const initialState = {
    // resultDataJson: {},
    snackBarPropertiesMX: {},
    // bodySchema: '',
    // ISOCurrencyList : [],
    // hierSchemaJson : {},
    // resultBodyDataJson : {},
    // originalHierSchemaJson : {},
    // treeItemExpandedList: {},
    // isTreeviewMounted: false,
    // mx_mt_OverlayMessage: {}
}
const mxTemplateSlice = createSlice({
    name : MX_TEMPLATES,
    initialState,
    reducers: {
        snackBarActionsMX(state,action) {
            state.snackBarPropertiesMX = {...action.payload}
        }
    }
})

export const {
     snackBarActionsMX
} = mxTemplateSlice.actions

export default mxTemplateSlice.reducer;