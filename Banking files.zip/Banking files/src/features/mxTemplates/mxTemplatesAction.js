import { snackBarActionsMX } from "./mxTemplatesSlice"
// import { loadSchemaandDataTemplates } from "../showMxTemplateAsTreeView/showMxTempSlice"
import { getTemplateSchemas } from "../showMxTemplateAsTreeView/showTempAction"

export const getSchemaandDataTemplates = (schemaName) => {
    return dispatch => {
        try {
            fetch(`/pacs_result/${schemaName}.xml`, {
                method: 'get',
                headers: {
                    "Content-Type":"application/xml; charset=utf-8"
                }
            })
            .then(resData => {
                return resData.text();
            })
            .then( responseData => {
                getTemplateSchemas(schemaName).then(resSchemas => {              
                     // Get a JSON object from each of the responses
                    return Promise.all(resSchemas.map(function (rSch) {
                        return rSch.text();
                    }));
                }).then(res => {
                    // console.log(res)
                   // dispatch(loadSchemaandDataTemplates({schemaData: res, bodyData: responseData}))
                })
            })   
        } catch(error) {
            dispatch(snackBarActionsMX({open: true, severity: 'error', snackBarMessage: error.message}))
        }
    }
}