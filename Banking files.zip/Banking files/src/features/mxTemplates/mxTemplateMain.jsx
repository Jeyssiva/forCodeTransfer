import * as React from 'react';
import { makeStyles } from '@mui/styles';
import { FormattedMessage } from 'react-intl';
import { isMobileOnly } from 'react-device-detect';
import { useDispatch, useSelector } from 'react-redux';
import { Container, Typography, Grid } from '@mui/material';

import MbSnackbar from '../common/mbSnackbar';
import MbDropdown from '../common/mbDropdown';
import { PacsVersion } from '../../constants/constants';
import { snackBarActionsMX, } from './mxTemplatesSlice';
import ChildErrorPage from '../errorPage/childErrorPage';
import { MX_TEMPLATES } from '../../constants/sliceConstants';
import { getSchemaandDataTemplates } from './mxTemplatesAction';
import { setMountedStatus } from '../showMxTemplateAsTreeView/showMxTempSlice';

const override = {
  display: "flex",
  margin: "0 auto",
  borderColor: "red",
};

const useStyles = makeStyles(() => ({
  dropdownFormStyles: {
    width: isMobileOnly ? '100%' : '35%'
  }
}));

export default function FullWidthTabs() {
  const [tabValue, setTabValue] = React.useState('saaHeader');
  const actionDispatch = useDispatch();
  // const dispatch = useDispatch();
  const snackBarPropertiesMX = useSelector(state => state[MX_TEMPLATES].snackBarPropertiesMX);
  // const hierSchemaJson = useSelector(state => state[MX_TEMPLATES].hierSchemaJson);
  // const isTreeviewMounted = useSelector(state => state[MX_TEMPLATES].isTreeviewMounted);
  const [selectedSchema, setSelectedSchema] = React.useState('pacs.008');
  const classes = useStyles();

  // React.useEffect(() => {
  //   actionDispatch(getSchemaandDataTemplates(selectedSchema));
  // }, [actionDispatch])

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const onSnackBarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    actionDispatch(snackBarActionsMX({ open: false, severity: '', snackBarMessage: '' }));
  }

  const onPacsDropdownChange = (e) => {
    actionDispatch(setMountedStatus({ status: false }));
    setSelectedSchema(e.target.value);
    setTabValue('saaHeader');
    actionDispatch(getSchemaandDataTemplates(e.target.value));
  }

  try {
    return (
      <Container maxWidth={false} disableGutters sx={{ height: 'auto', width: 'auto', marginTop: '10px', px: '10px' }}>
        {
          isMobileOnly ?
            <Grid sx={{ margin: 1, display: 'flex', flexDirection: 'column' }}>
              <Grid sx={{ width: '100%', margin: '4px' }}>
                <MbDropdown labelValue={selectedSchema}
                  labelName={<FormattedMessage id="mxTemplates.selectTemplate" />}
                  dropdownList={PacsVersion} size='large' sxFormStyles={classes.dropdownFormStyles}
                  onDropdownChange={onPacsDropdownChange} />
              </Grid>
              <Typography variant='h5' sx={{ fontWeight: 'bold', margin: '15px' }}>
                {selectedSchema.toUpperCase()}
              </Typography>
            </Grid>
            :
            <Grid sx={{ margin: 1, display: 'flex', flexDirection: 'row' }}>
              <Typography variant='h5' sx={{ fontWeight: 'bold', margin: '15px' }}>
                {selectedSchema.toUpperCase()}
              </Typography>
              <Grid sx={{ width: '85%', margin: '4px' }}>
                <MbDropdown labelValue={selectedSchema}
                  labelName={<FormattedMessage id="mxTemplates.selectTemplate" />}
                  dropdownList={PacsVersion} size='large' sxFormStyles={classes.dropdownFormStyles}
                  onDropdownChange={onPacsDropdownChange} />
              </Grid>
            </Grid>
        }

        <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesMX.open}
          severity={snackBarPropertiesMX.severity}
          message={snackBarPropertiesMX.snackBarMessage} />
      </Container>
    );
  }
  catch (err) {
    console.error(err);
    return <ChildErrorPage subTitle={"common.wentWrong"} />
  }
}
