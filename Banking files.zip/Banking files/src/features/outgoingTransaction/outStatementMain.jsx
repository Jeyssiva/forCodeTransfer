import * as React from 'react';
import { Refresh } from '@mui/icons-material';
import { FormattedMessage } from 'react-intl';
import { Container, Grid, Tab, Tabs, Divider, Box } from '@mui/material';

import { defaultLocales } from '../i18n';
import MbButton from '../common/mbButton';
import MbBreadCrumbs from '../common/mbBreadcrumbs';
import SuspenseLoader from '../viewTransactions/suspenseLoader';
import { TODAY_PAYMENT, OUT, OUTGOING_STATEMENT_TABS, SEARCH_PAYMENT, INITIAL_SEARCH_REQUEST, 
     OUTGOING_TAB_DATE_CATEGORY, 
     PREVIOUS_PAYMENT} from '../../constants/transactionConstants';

const ViewStatementsMain = React.lazy(() => import("../viewTransactions/statementsMain"));
const SearchStatementsMain = React.lazy(() => import("./search/searchStatementsMain"))

function OutStatementsMain({enqType, refreshPage, onHandleRefresh}) {
    const [selectedTab, setTab] = React.useState(TODAY_PAYMENT);
 
    const getSearchCriteria = React.useMemo(() => {
        let resultSearch = { ...INITIAL_SEARCH_REQUEST };
        const datePriority = OUTGOING_TAB_DATE_CATEGORY.find(d => d.value === selectedTab);
        return {searchFilter: {...resultSearch, ...datePriority}, datePriority: {minDate: datePriority.startdateRange, maxDate: datePriority.enddateRange}}
    },[selectedTab, enqType]);

    const onHandleTabChange = (e, newValue) => {
        setTab(newValue);
    }

    if (enqType === "") return;

    return (
        <>
            <Container maxWidth={false} disableGutters className="container-form">
                <MbBreadCrumbs crumbsList={[{ title: `viewTransactions.outTitle` }, 
                { title: `viewTransactions.${enqType}.title` }, 
                { title: `viewTransactions.${enqType}.${selectedTab}`}
                ]} />
                {
                    <h6>This module allows user to view and inquire about the bank statements.</h6>
                }
                <Divider className="divider" sx={{ textTransform: 'uppercase' }}><h5><b><FormattedMessage id={`viewTransactions.${enqType}.title`}
                    defaultMessage={defaultLocales[`viewTransactions.${enqType}.title`]} /></b></h5></Divider>
                <Box className="box">
                    <Grid sx={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'row', width: '100%', marginBottom: 2 }}>
                        <MbButton variant="outlined" buttonName={'Refresh'}
                            onHandleAction={onHandleRefresh}
                            startIcon={<Refresh />}
                        />
                    </Grid>
                    <Tabs
                        className='tab'
                        value={selectedTab}
                        //variant="scrollable"
                        indicatorColor="primary"
                        onChange={onHandleTabChange}
                    >
                        {
                            OUTGOING_STATEMENT_TABS.map(tabItem => {
                                return <Tab label={tabItem.label} value={tabItem.value} className={'tab-title'} key={`tab_${tabItem.label}`} />
                            })
                        }
                    </Tabs>
                    {
                        selectedTab === TODAY_PAYMENT &&
                        <Grid>
                            <React.Suspense fallback={<SuspenseLoader />}>
                                {
                                    <ViewStatementsMain
                                        key={`key_${TODAY_PAYMENT}`}
                                        transType={OUT}
                                        enqType={enqType}
                                        refreshPage={refreshPage}
                                        searchFilter={getSearchCriteria.searchFilter}
                                        onHandleRefresh={onHandleRefresh}
                                    />
                                }
                            </React.Suspense>
                        </Grid>
                    }
                    {
                        selectedTab === PREVIOUS_PAYMENT &&
                        <Grid>
                            <React.Suspense fallback={<SuspenseLoader />}>
                                {
                                    <SearchStatementsMain transType={OUT} enqType={enqType} refreshPage={refreshPage}
                                    datePriority={getSearchCriteria.datePriority} searchFilterFromParent={getSearchCriteria.searchFilter}
                                    paymentCategory={PREVIOUS_PAYMENT}/>
                                }
                            </React.Suspense>
                        </Grid>
                    }
                    {
                        selectedTab === SEARCH_PAYMENT &&
                        <Grid>
                            <React.Suspense fallback={<SuspenseLoader/>}>
                                <SearchStatementsMain transType={OUT} enqType={enqType} refreshPage={refreshPage}
                                    datePriority={getSearchCriteria.datePriority} searchFilterFromParent={getSearchCriteria.searchFilter}
                                    paymentCategory={SEARCH_PAYMENT}/>
                            </React.Suspense>
                        </Grid>
                    }
                </Box>
            </Container>
        </>
    )
}

export default React.memo(OutStatementsMain)