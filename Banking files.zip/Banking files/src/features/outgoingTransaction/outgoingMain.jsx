import * as React from 'react';
import { isEmpty } from 'lodash';
import { useSelector } from 'react-redux';
import { getSelectedMenuInfo } from '../dashboard/dashboardSlice';
import { ENQ_TYPE_BY_SELECTED_MENU, OUT, OUT_STATEMENTS } from '../../constants/transactionConstants';

const OutPaymentMain = React.lazy(() => import("../viewTransactions/transTypePaymentMain"));
const OutStatementMain = React.lazy(() => import("./outStatementMain"));

export default function OutgoingMain() {
    const [enqType, setEnqType] = React.useState('b2c');
    const [refreshPage, setRefresh] = React.useState(false);
    const selectedMenuInfo = useSelector(getSelectedMenuInfo);
    React.useEffect(() => {
        if (isEmpty(selectedMenuInfo)) return;
        const enType = ENQ_TYPE_BY_SELECTED_MENU[selectedMenuInfo.menuId]; // selectedMenuInfo.menuUrl.split('/')[2];
        setEnqType(enType);
    }, [selectedMenuInfo])
    const onHandleRefresh = () => {
        setRefresh(!refreshPage);
    }
    if (enqType === "") return;

    if(enqType === OUT_STATEMENTS) 
        return (
            <OutStatementMain enqType = {enqType} refreshPage = {refreshPage} onHandleRefresh = {onHandleRefresh}/>
        )
    else 
       return (
            <OutPaymentMain enqType = {enqType} transType={OUT} title={"outTitle"} subtitle={"outSubTitle"} refreshPage = {refreshPage} 
              onHandleRefresh = {onHandleRefresh}/>
       )
}