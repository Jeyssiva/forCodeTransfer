import React, { useCallback, useEffect, useState } from 'react';
import { Box, FormGroup, Stack } from '@mui/material';
import { FormattedMessage } from 'react-intl';
import MbDropdown from '../../common/mbDropdown';
import MbTextField from '../../common/mbTextField';
import { CASE_TYPES } from '../../../constants/mxTempConstants';
import MbButton from '../../common/mbButton';
import { DATE_TIME_FORMAT } from '../../../constants/constants';
import moment from 'moment';
import { defaultLocales } from '../../i18n';
import dayjs from 'dayjs';
import MbDateTimeMuiPicker from '../../common/mbDateTimeMuiPicker';
import { Search } from '@mui/icons-material';
import { INITIAL_SEARCH_REQUEST } from '../../../constants/transactionConstants';
import { getSnackBarSearch, snackBarActionSearch } from '../../viewTransactions/viewTransactionSlice';
import { useDispatch, useSelector } from 'react-redux';
import MbSnackbar from '../../common/mbSnackbar';
import { getCurrencyListPersist } from '../../showMxTemplateAsTreeView/persistedSlice';
import { bindPaymentDataStaticList } from '../../dashboard/dashboardActions';
import MbAutocomplete from '../../common/mbAutocomplete';

const SearchContainerMain = React.memo(({onSearchResult, datePriority = {}, searchTypes}) => {
    const [errorMsg, setErrorMessage] = useState({});
    const [searchCriteria, setSearch] = useState({ ...INITIAL_SEARCH_REQUEST });
    const loadCurrencyCodes = useSelector(getCurrencyListPersist);
    const snackBarPropertySearch = useSelector(getSnackBarSearch);
    const {minDate, maxDate} = datePriority;
    const actDispatch = useDispatch();

    useEffect(() => {
        const {searchType} = searchCriteria;
        if(searchType === 'currency' && loadCurrencyCodes.length === 0) {
            const reqBody = {
                ddListType : 'GBR_CURRENCY_LIST',
                dropDownListKey1 : "",
                dropDownListKey2 : ""
            }
            actDispatch(bindPaymentDataStaticList(reqBody));
        }
    }, [searchCriteria])

    const onHandleSearchInputChange = (eValue, fieldName, isUpper) => {
        setErrorMessage({});
        let sCriteria = { ...searchCriteria };
        if (fieldName === 'searchType') {
            sCriteria = { ...searchCriteria, 'searchText': "" }
        }
        setSearch({ ...sCriteria, [fieldName]: isUpper ? eValue.toUpperCase() : eValue });
    }
    const onHandleSearch = useCallback(() => {
        const { searchText, searchType, startdateRange, enddateRange } = searchCriteria;
      
        // Set default date range if only one is provided
        const updatedCriteria = { ...searchCriteria };
        if(!startdateRange && !enddateRange && !searchType && !searchText){
            updatedCriteria.startdateRange = minDate;
            updatedCriteria.enddateRange = maxDate;
            actDispatch(snackBarActionSearch({open: true, severity: 'error', snackBarMessage: 'Please select any search criteria'}));
            return;
        }
        if (startdateRange && !enddateRange) updatedCriteria.enddateRange = maxDate;
        if (!startdateRange && enddateRange) updatedCriteria.startdateRange = minDate;
        if (!startdateRange && !enddateRange && searchType && searchText) {
          updatedCriteria.startdateRange = minDate;
          updatedCriteria.enddateRange = maxDate;
        }
      
        // Validate date range: if start date is greater than end date, set error
        if (updatedCriteria.startdateRange && updatedCriteria.enddateRange && updatedCriteria.startdateRange > updatedCriteria.enddateRange) {
          setErrorMessage(prev => ({
            ...prev,
            startdateRange: defaultLocales["viewTransactions.startDateGreaterThan"]
          }));
          return;
        }
      
        // Validate search text when search type is provided
        if (searchType !== "" && searchText === "") {
          setErrorMessage(prev => ({
            ...prev,
            searchText: defaultLocales['viewTransactions.invalidError']
          }));
          return;
        }
      
        // Proceed with updating search criteria and triggering search result
        setSearch(updatedCriteria);
        onSearchResult(updatedCriteria);
      }, [searchCriteria, maxDate, minDate, setSearch, onSearchResult, setErrorMessage]);      

    const onHandleReset = useCallback(() => {
        setErrorMessage({});
        setSearch({...INITIAL_SEARCH_REQUEST});
        onSearchResult({...INITIAL_SEARCH_REQUEST, startdateRange: minDate, enddateRange: maxDate});
    },[]);

    const onAutocompleteSelectionChange = useCallback((e, obj) => {
       if(!obj) return;
       onHandleSearchInputChange(obj.code, 'searchText');
    },[searchCriteria])
  
      const onAutoCompleteInputChange = useCallback((eValue) => {
        if(eValue === 0) return; 
        onHandleSearchInputChange(eValue, 'searchText');
      }, [searchCriteria]);

    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
          return;
        }
        actDispatch(snackBarActionSearch({ open: false, severity: '', snackBarMessage: '' }));
    }

    const { startdateRange, enddateRange, searchType, searchText } = searchCriteria;
    const findCurrency = loadCurrencyCodes && loadCurrencyCodes.find(cur => cur.code === searchText) || {};

    return (
        <>
         <Box className = "box" sx={{width: '100%'}} >
            <FormGroup aria-label="position" row >
                <Stack direction="row" alignItems={"flex-start"} justifyContent={"space-between"} gap={0.5} sx={{ width: '100%' }}>
                    <MbDateTimeMuiPicker onDateChange={dateValue => {
                        const dValue = moment(dayjs(dateValue).toDate()).format(DATE_TIME_FORMAT)
                        return onHandleSearchInputChange(dValue, "startdateRange")
                    }}
                    labelText={<FormattedMessage id="auditlog.startDate"
                        defaultMessage={defaultLocales["auditlog.startDate"]}>
                        {msg => (
                            <span>
                                <h5>{msg}</h5>
                            </span>
                        )}
                    </FormattedMessage>}
                    inputStyle={'font-small'}
                    labelInfo={startdateRange} format={DATE_TIME_FORMAT}
                    maxDate={maxDate}
                    minDate={minDate}
                    size={'small'} />
                    <MbDateTimeMuiPicker onDateChange={dateValue => {
                        const dValue = moment(dayjs(dateValue).toDate()).format(DATE_TIME_FORMAT)
                        return onHandleSearchInputChange(dValue, "enddateRange")
                    }}
                        labelText={<FormattedMessage id="auditlog.endDate"
                            defaultMessage={defaultLocales["auditlog.endDate"]}>
                            {msg => (
                                <span>
                                    <h5>{msg}</h5>
                                </span>
                            )}
                        </FormattedMessage>}
                        inputStyle={'font-small'}
                        labelInfo={enddateRange}
                        format={DATE_TIME_FORMAT}
                        maxDate={maxDate}
                        minDate={minDate}
                        size={'small'}
                        error = {errorMsg.startdateRange ? true : false}
                        helperText = {errorMsg.startdateRange || ''}/>
                    <MbDropdown
                        id="auditlog.searchType"
                        fullWidth={true}
                        variant={"outlined"}
                        labelName={<FormattedMessage id="auditlog.searchType"
                            defaultMessage={defaultLocales["auditlog.searchType"]}>
                            {msg => (
                                <span>
                                    <h5>{msg}</h5>
                                </span>
                            )}
                        </FormattedMessage>}
                        labelValue={searchType || ''}
                        inputStyle={'dropdown-audit'}
                        onDropdownChange={(e) => onHandleSearchInputChange(e.target.value, 'searchType')}
                        dropdownList={searchTypes}
                        size="small" />
                    {
                        searchType === 'currency' ? 
                        <MbAutocomplete options={loadCurrencyCodes} optionLabel="description" optionValue="code" 
                            size = "small" inputStyle={'font-small'} labelText={ findCurrency.description || "Search Currency"} fullWidth = {true} 
                            onAutocompleteSelectionChange={onAutocompleteSelectionChange}
                            onAutoCompleteInputChange={onAutoCompleteInputChange}
                            error={errorMsg.searchText ? true : false}
                            helperText={errorMsg.searchText || ''}
                            value={findCurrency}
                            inputValue={searchText || ''}/> 
                        :
                        <MbTextField
                            id="searchText"
                            name="searchText"
                            label={
                                <FormattedMessage id="auditlog.searchText" defaultMessage={defaultLocales['auditlog.searchText']} >
                                    {msg => (
                                        <span>
                                            <h5>{msg}</h5>
                                        </span>
                                    )}
                                </FormattedMessage>}
                            size={"small"}
                            value={searchText}
                            key="txtSearchText"
                            inputStyle={'font-small'}
                            error={errorMsg.searchText ? true : false}
                            helperText={errorMsg.searchText || ''}
                            placeholder="case-insensitive"
                            caseType={CASE_TYPES.uppercase}
                            type = { searchType === 'amt' ? 'number' : 'search'}
                            onChange={(e) => onHandleSearchInputChange(e.target.value, 'searchText', true)}
                        />
                    }
                    <MbButton className={'button-audit-action'} fullWidth={true} startIcon={<Search />}
                        buttonName={<h5>Search</h5>} onHandleAction={onHandleSearch} >
                    </MbButton>
                    <MbButton className={'button-maybank'} fullWidth={true}
                        buttonName={<h5>Reset</h5>} onHandleAction={onHandleReset}>
                    </MbButton>
                </Stack>
            </FormGroup>
         </Box>
         <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertySearch.open}
            severity={snackBarPropertySearch.severity}
            message={snackBarPropertySearch.snackBarMessage} />
            </>
    )
})

export default SearchContainerMain;