import { Grid } from "@mui/material"
import ViewStatementsMain from "../../viewTransactions/statementsMain"
import { memo, useState } from "react";
import { PREVIOUS_PAYMENT, SEARCH_STATEMENTS_SEARCH_TYPES } from "../../../constants/transactionConstants";
import SearchContainerMain from "./searchContainerMain";
import { snackBarActionsTrans } from "../../viewTransactions/viewTransactionSlice";

const SearchStatementsMain = ({transType, enqType, refreshPage, searchFilterFromParent, datePriority, paymentCategory}) => {
    const [searchCriteria, setSearch] = useState({ ...searchFilterFromParent });
    //By Default,if paymentCatgory from archive then no need to call View Transaction Page at initial time.
    const [searchStarted, setStarted] = useState(paymentCategory === PREVIOUS_PAYMENT);

    const onHandleSearch = (searchCriteria) => {
        const {lookUpOn} = searchFilterFromParent;
      setSearch({...searchCriteria, lookUpOn});
      setStarted(true);
    }
    return (
        <Grid container>
            <SearchContainerMain enqType = {enqType} onSearchResult = {onHandleSearch} searchTypes = {SEARCH_STATEMENTS_SEARCH_TYPES} 
            datePriority= {datePriority} snackBarFunction = { snackBarActionsTrans }/>     
            {
                searchStarted &&
                <ViewStatementsMain transType={transType} enqType={enqType} refreshPage={refreshPage} 
                  searchFilter = {searchCriteria}/>
            }
        </Grid>
    )
}
export default memo(SearchStatementsMain)