import './errorPage.css';
import { Link } from "react-router-dom";
// import MbButton from "../common/mbButton";
// import { Link } from "react-router-dom";
import { defaultLocales } from "../i18n";
import MbButton from "../common/mbButton";
import { FormattedMessage } from "react-intl";
import { Grid, Typography } from "@mui/material";

export default function ErrorPage() {
    return (
        <Grid id="notfound">
            <Grid className="notfound">
                <Grid className="notfound-404">
                    <Typography variant="h1">Oops!</Typography>
                </Grid>
                <Typography variant="h2">
                    <FormattedMessage id='notfoundPage.pagenotfoundsubtitle'
                        defaultMessage={defaultLocales["notfoundPage.pagenotfoundsubtitle"]} />
                </Typography>
                <Typography>
                    <FormattedMessage id='notfoundPage.errorContent'
                        defaultMessage={defaultLocales["notfoundPage.errorContent"]} />
                </Typography>
                {/* <MbButton buttonName={
                    <FormattedMessage id ='notfoundPage.gotohomepage' 
                     defaultMessage={defaultLocales["notfoundPage.gotohomepage"]}/>}
                     component= {Link} to = {"/login"}></MbButton> */}
            </Grid>
        </Grid>
    )
}