import { CUSTOM_TIMEOUT_ERRORS } from "../../constants/apiConstants";
import { ABORT_ERROR, ERROR_STATUS, EXIT_KEY_SESSIONEXPIRED } from "../../constants/constants";
import { setInvalidSession } from "../dashboard/dashboardSlice";
import { sessionClear } from "../dashboard/helpers";
import { logout } from "../login/loginSlice";

export const CatchErrorDisplay = (error, apiName, dispatch) => {
    const {name, message} = error;
    if(name === ABORT_ERROR){
        const message = CUSTOM_TIMEOUT_ERRORS[apiName] || 'Sorry, Timeout Issue. Please Try again.';
        return {displayMessage: message};
    } else if(/\d/.test(message)) {
        const errorCode = message.match(/\d+/)[0];
        if(errorCode === '401' || errorCode === '502'){
            // sessionClear();
            dispatch(logout({resData: true, key: EXIT_KEY_SESSIONEXPIRED}))
            dispatch({type: 'auth/logout', payload : true});
            dispatch(setInvalidSession({status: true, errorCode}));
            return {displayMessage: message};
        } 
    }
    let errorMsg = message;
    errorMsg = errorMsg.replace(/[^a-zA-Z\s]/g, ''); // Remove special characters except for a few allowed ones
    const findDisplayMessage = ERROR_STATUS.find(err => err.errorMessage === errorMsg);
    return findDisplayMessage;
}

export const BackToInvalidSessionPage = (errorCode, dispatch) => {
    sessionClear();
    dispatch(setInvalidSession({status: true, errorCode}));
    return;
}