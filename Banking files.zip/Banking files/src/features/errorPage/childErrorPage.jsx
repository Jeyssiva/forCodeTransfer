import { Grid, Typography } from "@mui/material";
import './errorPage.css'
import { defaultLocales } from "../i18n";
import { FormattedMessage } from "react-intl";

export default function ChildErrorPage({subTitle = 'notfoundPage.pagenotfoundsubtitle'}) {
    return (
        <Grid id="notfound">
            <Grid className="notfound">
                <Grid className="notfound-404">
                    <Typography variant="h1">Oops!</Typography>
                </Grid>
                <Typography variant="h2">
                    {
                        <FormattedMessage id={`${subTitle}`}defaultMessage={defaultLocales[`${subTitle}`]}/>
                    }
                </Typography>
                <Typography>{
                    <FormattedMessage id ='notfoundPage.errorContent' 
                        defaultMessage={defaultLocales["notfoundPage.errorContent"]}/>}
                </Typography>
            </Grid>
        </Grid>
    )
}