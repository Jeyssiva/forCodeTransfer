import { useEffect } from 'react'
import { makeStyles } from '@mui/styles'
import { FormattedMessage } from 'react-intl'
import { Grid, Typography } from '@mui/material'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate, useParams } from 'react-router-dom'

import { defaultLocales } from '../i18n'
import MbButton from '../common/mbButton'
import { logoutUser } from "../dashboard/dashboardActions";
import { LOGIN_SLICE } from '../../constants/sliceConstants'
import { getTokens, sessionClear } from '../dashboard/helpers'
import { CUSTOM_ERROR_CODES } from '../../constants/constants'
import { EXIT_KEY_LOGOUT, MODULE_ID, sessionItems } from "../../constants/constants";

export const useStyles = makeStyles(() => ({
    title: {
        position: 'relative',
        height: '85vh'
    },
    subtitle: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        maxWidth: '30%',
        width: '100%',
        textAlign: 'center'
    },
    header: {
        color: '#000',
        fontSize: '30px',
        fontWeight: '700',
        marginBottom: '5px',
        /* text-transform: uppercase; */
        marginTop: '0'
    },
    subheader: {
        color: '#000',
        fontSize: '20px',
        fontWeight: '700',
        marginBottom: '10px',
        /* text-transform: uppercase; */
        marginTop: '0'
    }
}))

export default function InvalidSession() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { errorcode = 401 } = useParams();
    const localAuth = useSelector(state => state[LOGIN_SLICE].localAuth);
    const loginStatus = useSelector(state => state[LOGIN_SLICE].loginStatus);
    const errorDetails = CUSTOM_ERROR_CODES.find(c => c.code === Number(errorcode)) || {};

    useEffect(() => {
        const { uamToken, isoToken } = getTokens();
        if (loginStatus === undefined && !uamToken && !isoToken) {
            navigate('/');
        } else {
            sessionClear();
        }
    }, [dispatch, navigate, loginStatus]);

    const onLogout = () => {
        sessionClear();
        window.location.reload();
        // const username = sessionStorage.getItem(sessionItems.Username);
        // dispatch(logoutUser(username, MODULE_ID, localAuth, EXIT_KEY_LOGOUT));
        // navigate('/');
    }

    return (
        <Grid className={classes.title}>
            <Grid className={classes.subtitle}>
                <Typography className={classes.header}>
                    <FormattedMessage id='invalidSession.title'
                        defaultMessage={defaultLocales["invalidSession.title"]} />
                </Typography>
                <Typography className={classes.subheader}>
                    {`[ ${errorDetails.code} - ${errorDetails.statusText} ]`}
                </Typography>
                <Typography>
                    {`${errorDetails.subContent}`}
                </Typography>
                <br /><br /><br />
                <MbButton
                    fullWidth
                    size={"large"}
                    color="error"
                    variant={"outlined"}
                    buttonName={<FormattedMessage id="invalidSession.signout" defaultMessage={defaultLocales["invalidSession.signout"]} >
                    </FormattedMessage>}
                    onHandleAction={onLogout}>
                </MbButton>
            </Grid>
        </Grid>
    )
}