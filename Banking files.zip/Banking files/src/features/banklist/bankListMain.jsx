import * as React from 'react';
import { Box, Container, Grid, IconButton, InputLabel, Typography } from "@mui/material";
import { makeStyles } from '@mui/styles';
import { ActiveIndicator, AlphaNumbericHyphenPattern, AlphaNumericPattern, COUNTRY_CODES, MbbIndicator } from '../../constants/constants';
import MbTextField from '../common/mbTextField';
import {
    COUNTRYCODE, BANKNAME, initialState, reduce, BICCODE, SERVICEPROVIDER,
    ZIPCODE, ERRORPROPS, BANKNAMESELECTION, VALUECHANGES, CLEARCOUNTRYCHILDS,
    ACTIONCODE, CLEARALL, OPENDIALOG, CLEAR_ERRORPROPS
} from './bankReducer';
import MbDropdown from '../common/mbDropdown';
import MbRadio from '../common/mbRadio';
import { useDispatch, useSelector } from 'react-redux';
import { getBankList, updateBankInfo } from './bankActions';
import MbButton from '../common/mbButton';
import MbAutocomplete from '../common/mbAutocomplete';
import { BANK_MAINTAINANCE } from '../../constants/sliceConstants';
import MbSnackbar from '../common/mbSnackbar';
import { clearBankDetails, snackBarActions, updateBankListLoader } from './bankSlice';
import MbDialogBox from '../common/mbDialog';
import ChildErrorPage from '../errorPage/childErrorPage';
import { defaultLocales } from '../i18n';
import { FormattedMessage, useIntl } from 'react-intl';
import { isMobile, isMobileOnly } from 'react-device-detect';
import {
    AcquireIcon, BICCodeIcon, BankAddress, BankCodeIcon, BankNameIcon,
    CountryIcon, RoutingNumIcon, ServiceProviderIcon, ZipCodeIcon
} from './customIcons';
import { Refresh } from '@mui/icons-material';
import { SyncLoader } from 'react-spinners';

const useStyles = makeStyles(() => ({
    inputLabel: {
        alignItems: 'center',
        display: 'flex',
        justifyContent: 'center',
        fontWeight: 'bold',
        marginRight: '15px'
    },
    countryDropdown: {
        width: '300px',
        marginLeft: '15px',
        marginRight: '15px'
    },
    bankNameDropdown: {
        width: '450px',
        marginLeft: '15px',
        marginRight: '15px'
    },
    inputLabelInfo: {
        alignItems: 'center',
        display: 'flex',
        justifyContent: 'flex-start',
        fontWeight: 'bold',
        // flex: 1,
        marginRight: '13px'
    },
    bankDetGrid: {
        display: 'flex',
        flexDirection: 'row',
        marginTop: '12px'
    },
    inputFieldStyle: {
        width: '100%'
    },
    inputRadioStyle: {
        width: '365px',
        alignItems: 'flex-start'
    },
    buttonStyle: {
        marginRight: '5px',
        maxWidth: isMobile ? '100%' : '9%',
        marginBottom: '3px'
    },
    radioGrp: {
        justifyContent: 'center'
    },
    containerStyle: {
        maxWidth: '100%',
        padding: '0 10px'
    },
    overrideLoader: {
        display: "flex",
        margin: "0 auto",
        borderColor: "red"
    }
}))

const BankListMain = React.memo(function BankListMain() {
    const classes = useStyles();
    const [state, dispatch] = React.useReducer(reduce, initialState);
    // const toolBarStatus = useSelector(state => state[DASHBOARD_SLICE].isOpenToolBar);
    const { getBankLoaderStatus, bankDetailsbyCC, snackBarProperties } = useSelector(state => state[BANK_MAINTAINANCE]);
    const intl = useIntl();
    const actionDispatch = useDispatch();
    const { countryCode, bankName, biccode, bankCode,
        serviceProvider, acquirerId, routingNo, bankAddress1, bankAddress2, bankAddress3,
        bankAddress4, mbbIndicator, activeInd } = state.selectedBankDetail

    // if toolbar open and mobile view, rearrange the button positions
    // const buttonContainerStyle = toolBarStatus && isMobileOnly ? { flexDirection: "column", alignItems: "center" } : 
    //                     {flexDirection: 'row',  justifyContent: 'flex-end'};

    const getBankDetails = (cCode) => {
        actionDispatch(updateBankListLoader(true));
        const requestBody = {
            maxResults: 0,
            pageNo: 0,
            searchSortColumn: "BANK_NAME",
            sortDirection: "ASC",
            searchCriteria: [
                {
                    bankCode: "",
                    actionCode: "I",
                    serviceProvider: "",
                    countryCode: cCode
                }
            ]
        }
        actionDispatch(getBankList(requestBody, intl.formatMessage({ id: "bankList.bankLoadSuccess", defaultMessage: defaultLocales["bankList.bankLoadSuccess"] })));
    }
    const onCountryCodeChange = (event) => {
        dispatch({ type: COUNTRYCODE, fieldName: 'countryCode', value: event.target.value });
        dispatch({ type: CLEARCOUNTRYCHILDS });
        getBankDetails(event.target.value)
    }

    const onRefreshBankList = () => {
        if (countryCode && countryCode !== "") {
            getBankDetails(countryCode);
        } else {
            actionDispatch(snackBarActions({ open: true, severity: 'error', snackBarMessage: intl.formatMessage({ id: 'bankList.countryCodeRequired' }) }))
        }
    }

    const onBankNameChange = (e, obj, action) => {
        if (action !== 'clear') {
            dispatch({ type: BANKNAMESELECTION, value: obj });
        } else {
            dispatch({ type: CLEARCOUNTRYCHILDS })
        }
    }

    const onInputAutoCompleteChange = (iValue) => {
        // if(!iValue) return;
        dispatch({ type: VALUECHANGES, fieldName: 'bankName', value: iValue })
    }

    function onBankDetailsChange(event, type) {
        let valueText = event.target.value;
        if (type === BICCODE) valueText = valueText.toUpperCase();
        dispatch({ type: VALUECHANGES, fieldName: type, value: valueText })
    }

    const onHandleMbbIndiChange = (event) => {
        dispatch({ type: VALUECHANGES, fieldName: 'mbbIndicator', value: event.target.value })
        if (state.serviceProviderList.length > 0 && event.target.value === 'Y') {
            dispatch({ type: VALUECHANGES, fieldName: 'serviceProvider', value: 'MBB' })
        }
    }

    const onHandleServiceProviderChange = (event) => {
        dispatch({ type: VALUECHANGES, fieldName: 'serviceProvider', value: event.target.value })
        if (event.target.value === 'MBB') {
            dispatch({ type: VALUECHANGES, fieldName: 'mbbIndicator', value: 'Y' })
        }
    }

    const bicCodeValidation = (value, overallValidation = false) => {
        if (value === '' || value.length < 8 || value.length > 11 || !AlphaNumericPattern.test(value)) {
            dispatch({ type: ERRORPROPS, data: { fieldName: [BICCODE], errorText: intl.formatMessage({ id: "bankList.bicCodeValid" }) } });
            if (overallValidation === true) {
                return false;
            }
        } else {
            dispatch({ type: ERRORPROPS, data: { fieldName: [BICCODE], errorText: '' }, deletion: true });
            if (overallValidation === true) {
                return true;
            }
        }
    }

    const onBicCodeBlur = (event) => {
        bicCodeValidation(event.target.value, false);
    }

    const zipCodeValidation = (value, overallValidation) => {
        if (!value || value === "") return true;

        if (!AlphaNumbericHyphenPattern.test(value)) {
            dispatch({ type: ERRORPROPS, data: { fieldName: [ZIPCODE], errorText: intl.formatMessage({ id: 'bankList.zipCodeValid' }) } })
            if (overallValidation === true) {
                return false;
            }
        } else {
            dispatch({ type: ERRORPROPS, data: { fieldName: [ZIPCODE], errorText: '' }, deletion: true });
            if (overallValidation === true) {
                return true;
            }
        }
    }

    const onHandleZipcodeValidation = (event) => {
        event.preventDefault();
        zipCodeValidation(event.target.value, false)
    }

    const validateNecessaryFields = (value, fieldName, overallValidation) => {
        if (!value || value === "") {
            const errorText = state.serviceProviderList.length === 0 && fieldName === 'serviceProvider'
                ? intl.formatMessage({ id: 'bankList.serviceProvideValid' })
                : intl.formatMessage({ id: 'bankList.required' })
            dispatch({ type: ERRORPROPS, data: { fieldName, errorText } })
            if (overallValidation === true) {
                return false;
            }
        } else if (fieldName === 'serviceProvider' && mbbIndicator === 'Y' && serviceProvider !== 'MBB') {
            const errorText = intl.formatMessage({ id: 'bankList.requiredMBBifIndicatorYes' })
            dispatch({ type: ERRORPROPS, data: { fieldName, errorText } })
            if (overallValidation === true) {
                return false;
            }
        }
        else {
            dispatch({ type: ERRORPROPS, data: { fieldName, errorText: '' }, deletion: true });
            if (overallValidation === true) {
                return true;
            }
        }
    }

    const onNecessaryFieldsValidation = (event, fieldName) => {
        event.preventDefault();
        validateNecessaryFields(event.target.value, fieldName, false)
    }

    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        actionDispatch(snackBarActions({ open: false, severity: '', snackBarMessage: '' }));
    }

    function onHandleBankIntoManipulation(actionCode) {
        const validationArray = [bicCodeValidation(biccode, true), validateNecessaryFields(serviceProvider, 'serviceProvider', true),
        validateNecessaryFields(bankName, 'bankName', true), validateNecessaryFields(countryCode, 'countryCode', true),
        zipCodeValidation(bankAddress4, true)]
        if (validationArray.length === validationArray.filter(v => v === true).length) {
            if (actionCode === 'D') {
                dispatch({ type: OPENDIALOG, value: true })
            } else {
                dispatch({ type: VALUECHANGES, fieldName: [ACTIONCODE], value: actionCode })
                actionDispatch(updateBankInfo({ ...state.selectedBankDetail, actionCode },
                    intl.formatMessage({ id: 'bankList.actionSucceed' })));
                dispatch({ type: CLEAR_ERRORPROPS });
            }
        } else {
            actionDispatch(snackBarActions({ open: true, severity: 'error', snackBarMessage: intl.formatMessage({ id: 'bankList.fillRequireFields' }) }))
        }
    }

    const onHandleReset = React.useCallback(() => {
        dispatch({ type: CLEARALL })
        actionDispatch(clearBankDetails())
    }, [actionDispatch])

    const onHandleBankDelete = () => {
        dispatch({ type: VALUECHANGES, fieldName: [ACTIONCODE], value: 'D' });
        actionDispatch(updateBankInfo({ ...state.selectedBankDetail, actionCode: 'D' }, intl.formatMessage({ id: 'bankList.actionSucceed' })));
        dispatch({ type: OPENDIALOG, value: false })
        dispatch({ type: CLEARCOUNTRYCHILDS })
    }

    React.useEffect(() => {
        onHandleReset();
    }, [onHandleReset])

    try {
        return (
            <>
                <h4>Bank Listing</h4>
                <Container maxWidth={"false"} disableGutters className={'container-form'}>
                    <Box sx={{ bgcolor: 'background.paper', boxShadow: 2, borderRadius: '5px', padding: '20px' }}>
                        <Typography variant='h5' sx={{ fontWeight: 'bold' }}>
                            <FormattedMessage id='bankList.title' defaultMessage={defaultLocales["bankList.title"]} />
                        </Typography>
                        <Grid item sx={{ display: 'flex', flexDirection: 'column', mt: '15px' }}>
                            <Grid item sx={{ display: 'flex', flexDirection: 'row' }}>
                                <Grid item sx={{ width: '48%' }}>
                                    {/* Select Country */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbDropdown sxFormStyles={classes.inputFieldStyle}
                                            labelName={
                                                <>
                                                    <FormattedMessage id='bankList.selCountry' defaultMessage={defaultLocales["bankList.selCountry"]} />
                                                    <span style={{ color: 'red' }}>{'*'}</span>
                                                </>
                                            }
                                            labelValue={countryCode} dropdownList={COUNTRY_CODES} onDropdownChange={onCountryCodeChange}
                                            enableAdornment={true} DynamicIcon={CountryIcon}
                                            size="small" key={'bank_country'} error={state.errorProps && state.errorProps[COUNTRYCODE] !== undefined}
                                            helperText={state.errorProps && state.errorProps[COUNTRYCODE]} />
                                    </Grid>
                                    {/* BIC Code */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={
                                                <>
                                                    <FormattedMessage id='bankList.bicCode' defaultMessage={defaultLocales["bankList.bicCode"]} />
                                                    <span style={{ color: 'red' }}>{'*'}</span>
                                                </>
                                            }
                                            value={biccode} onTextFieldChange={(e) => onBankDetailsChange(e, BICCODE)} size="small"
                                            onHandleValidation={onBicCodeBlur} maxLength={11}
                                            error={state.errorProps && state.errorProps[BICCODE] !== undefined}
                                            helperText={state.errorProps && state.errorProps[BICCODE]}
                                            enableAdornment={true} DynamicIcon={BICCodeIcon} />
                                    </Grid>
                                    {/* Bank name */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={
                                                <>
                                                    <FormattedMessage id='bankList.bankName' defaultMessage={defaultLocales["bankList.bankName"]} />
                                                    <span style={{ color: 'red' }}>{'*'}</span>
                                                </>
                                            }
                                            value={bankName} maxLength={120}
                                            onTextFieldChange={(e) => onBankDetailsChange(e, BANKNAME)} size="small" title={bankName}
                                            onHandleValidation={(e) => onNecessaryFieldsValidation(e, BANKNAME)}
                                            error={state.errorProps && state.errorProps[BANKNAME] !== undefined}
                                            helperText={state.errorProps && state.errorProps[BANKNAME]}
                                            enableAdornment={true}
                                            DynamicIcon={BankNameIcon}

                                        />
                                    </Grid>
                                    {/* Service Provider */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbDropdown sxFormStyles={classes.inputFieldStyle}
                                            labelName={
                                                <>
                                                    <FormattedMessage id='bankList.serviceProvider' defaultMessage={defaultLocales["bankList.serviceProvider"]} />
                                                    <span style={{ color: 'red' }}>{'*'}</span>
                                                </>
                                            }
                                            labelValue={serviceProvider}
                                            dropdownList={state.serviceProviderList}
                                            onDropdownChange={onHandleServiceProviderChange}
                                            size="small" key={'bank_serviceprovider'}
                                            onHandleValidation={(e) => onNecessaryFieldsValidation(e, SERVICEPROVIDER)}
                                            error={state.errorProps && state.errorProps[SERVICEPROVIDER] !== undefined}
                                            helperText={state.errorProps && state.errorProps[SERVICEPROVIDER]}
                                            enableAdornment={true} DynamicIcon={ServiceProviderIcon}
                                        />
                                    </Grid>
                                    {/* Acquire Id */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={<FormattedMessage id='bankList.acquireId' defaultMessage={defaultLocales["bankList.acquireId"]} />}
                                            value={acquirerId} onTextFieldChange={(e) => onBankDetailsChange(e, 'acquirerId')} size="small"
                                            maxLength={20} enableAdornment={true} DynamicIcon={AcquireIcon} />
                                    </Grid>
                                    {/* Routing No */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={<FormattedMessage id='bankList.routingNo' defaultMessage={defaultLocales["bankList.routingNo"]} />}
                                            value={routingNo} onTextFieldChange={(e) => onBankDetailsChange(e, 'routingNo')} size="small"
                                            maxLength={20} enableAdornment={true} DynamicIcon={RoutingNumIcon} />
                                    </Grid>
                                    {/* Active Indicator */}
                                    <Grid item className={classes.bankDetGrid}>
                                        {
                                            isMobile ?
                                                <MbRadio sxStyles={classes.inputFieldStyle}
                                                    radioValue={activeInd} radioList={ActiveIndicator}
                                                    radioGrpStyles={classes.radioGrp}
                                                    label={
                                                        <>
                                                            <FormattedMessage id='bankList.activeInd' defaultMessage={defaultLocales["bankList.activeInd"]} />
                                                            <span style={{ color: 'red' }}>{'*'}</span>
                                                        </>
                                                    }
                                                    onRadioChange={(e) => onBankDetailsChange(e, 'activeInd')} key={'radio_activeind'} />
                                                : <> <InputLabel className={classes.inputLabelInfo}>
                                                    <FormattedMessage id='bankList.activeInd' defaultMessage={defaultLocales["bankList.activeInd"]} />
                                                    <span style={{ color: 'red' }}>{'*'}</span>
                                                    <span style={{ marginRight: 2 }}>{':'}</span>
                                                </InputLabel>
                                                    <MbRadio sxStyles={classes.inputRadioStyle}
                                                        radioValue={activeInd} radioList={ActiveIndicator}
                                                        radioGrpStyles={classes.radioGrp}
                                                        onRadioChange={(e) => onBankDetailsChange(e, 'activeInd')} key={'radio_activeind'} />
                                                </>
                                        }
                                    </Grid>
                                </Grid>
                                <Grid item sx={{ ml: '15px', width: '50%' }}>
                                    {/* Select Bank Name */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbAutocomplete sx={{ width: isMobileOnly ? '90%' : '95%', marginRight: '2px' }}
                                            // className = {classes.inputFieldStyle} 
                                            onAutocompleteSelectionChange={onBankNameChange}
                                            options={bankDetailsbyCC || []} size="small"
                                            labelText={
                                                <>
                                                    <FormattedMessage id='bankList.selBankName' defaultMessage={defaultLocales["bankList.selBankName"]} />
                                                    <span style={{ color: 'red' }}>{'*'}</span>
                                                </>
                                            }
                                            optionLabel={'bankNameDisplay'} optionValue={'biccode'} value={state.selectedBankDetail}
                                            onAutoCompleteInputChange={onInputAutoCompleteChange} inputValue={bankName}
                                            enableAdornment={true} DynamicIcon={BankNameIcon}
                                        />
                                        {
                                            getBankLoaderStatus
                                                ?
                                                <IconButton sx={{ width: '5%' }}>
                                                    <SyncLoader color={'#000000'}
                                                        loading={true}
                                                        size={4}
                                                        aria-label="Loading Spinner"
                                                        data-testid="loader" />
                                                </IconButton>
                                                :
                                                <IconButton sx={{ width: '5%' }} onClick={onRefreshBankList}>
                                                    <Refresh />
                                                </IconButton>
                                        }
                                    </Grid>
                                    {/* Bank Code */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={<FormattedMessage id='bankList.bankCode' defaultMessage={defaultLocales["bankList.bankCode"]} />}
                                            value={bankCode} onTextFieldChange={(e) => onBankDetailsChange(e, 'bankCode')} maxLength={20} size="small"
                                            enableAdornment={true} DynamicIcon={BankCodeIcon} />
                                    </Grid>
                                    {/* Address Line1 */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={<FormattedMessage id='bankList.addrLine1' defaultMessage={defaultLocales["bankList.addrLine1"]} />}
                                            value={bankAddress1} onTextFieldChange={(e) => onBankDetailsChange(e, 'bankAddress1')} size="small" maxLength={40}
                                            enableAdornment={true} DynamicIcon={BankAddress} />
                                    </Grid>
                                    {/* Address Line2 */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={<FormattedMessage id='bankList.addrLine2' defaultMessage={defaultLocales["bankList.addrLine2"]} />}
                                            value={bankAddress2} onTextFieldChange={(e) => onBankDetailsChange(e, 'bankAddress2')} size="small" maxLength={40}
                                            enableAdornment={true} DynamicIcon={BankAddress}
                                        />
                                    </Grid>
                                    {/* Address Line3 */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={<FormattedMessage id='bankList.addrLine3' defaultMessage={defaultLocales["bankList.addrLine3"]} />}
                                            value={bankAddress3}
                                            onTextFieldChange={(e) => onBankDetailsChange(e, 'bankAddress3')} size="small"
                                            maxLength={40} enableAdornment={true} DynamicIcon={BankAddress} />
                                    </Grid>
                                    {/* Zip code */}
                                    <Grid item className={classes.bankDetGrid}>
                                        <MbTextField className={classes.inputFieldStyle}
                                            label={<FormattedMessage id='bankList.zipCode' defaultMessage={defaultLocales["bankList.zipCode"]} />}
                                            value={bankAddress4}
                                            onTextFieldChange={(e) => onBankDetailsChange(e, 'bankAddress4')}
                                            maxLength={8}
                                            enableAdornment={true}
                                            onHandleValidation={onHandleZipcodeValidation} size="small"
                                            DynamicIcon={ZipCodeIcon}
                                            error={state.errorProps && state.errorProps[ZIPCODE] !== undefined}
                                            helperText={state.errorProps && state.errorProps[ZIPCODE]} />
                                    </Grid>
                                    {/* Mbb Indicator */}
                                    <Grid item className={classes.bankDetGrid}>
                                        {
                                            isMobile ?
                                                <MbRadio sxStyles={classes.inputFieldStyle}
                                                    radioGrpStyles={classes.radioGrp}
                                                    label={
                                                        <>
                                                            <FormattedMessage id='bankList.mbbInd' defaultMessage={defaultLocales["bankList.mbbInd"]} />
                                                            <span style={{ color: 'red' }}>{'*'}</span>
                                                        </>
                                                    }
                                                    radioValue={mbbIndicator} radioList={MbbIndicator}
                                                    onRadioChange={onHandleMbbIndiChange} />
                                                : <> <InputLabel className={classes.inputLabelInfo}>
                                                    <FormattedMessage id='bankList.mbbInd' defaultMessage={defaultLocales["bankList.mbbInd"]} />
                                                    <span style={{ color: 'red' }}>{'*'}</span>
                                                    <span style={{ marginRight: 2 }}>{':'}</span>
                                                </InputLabel>
                                                    <MbRadio sxStyles={classes.inputRadioStyle}
                                                        radioGrpStyles={classes.radioGrp}
                                                        radioValue={mbbIndicator} radioList={MbbIndicator}
                                                        onRadioChange={onHandleMbbIndiChange} />
                                                </>
                                        }
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item sx={{ mt: '10px', display: 'flex', flexDirection: 'row', justifyContent: 'flex-end' }}>
                                <MbButton className={classes.buttonStyle}
                                    buttonName={<FormattedMessage id='common.create' defaultMessage={defaultLocales["common.create"]} />}
                                    onHandleMouseDown={e => e.preventDefault()} onHandleAction={() => onHandleBankIntoManipulation('A')} />
                                <MbButton className={classes.buttonStyle}
                                    buttonName={<FormattedMessage id='common.update' defaultMessage={defaultLocales["common.update"]} />}
                                    onHandleMouseDown={e => e.preventDefault()} onHandleAction={() => onHandleBankIntoManipulation('U')} />
                                <MbButton className={classes.buttonStyle}
                                    buttonName={<FormattedMessage id='common.delete' defaultMessage={defaultLocales["common.delete"]} />}
                                    onHandleMouseDown={e => e.preventDefault()} onHandleAction={() => onHandleBankIntoManipulation('D')} />
                                <MbButton className={classes.buttonStyle}
                                    buttonName={<FormattedMessage id='common.reset' defaultMessage={defaultLocales["common.reset"]} />}
                                    onHandleAction={onHandleReset} />
                            </Grid>
                            <MbSnackbar onClose={onSnackBarClose} open={snackBarProperties.open} severity={snackBarProperties.severity}
                                message={snackBarProperties.snackBarMessage} />
                            <MbDialogBox openDialog={state.openDialog} onHandleClose={() => dispatch({ type: OPENDIALOG, value: false })}
                                onHandleYes={onHandleBankDelete}
                                dialogTitle={<FormattedMessage id='deleteDialog.title' defaultMessage={defaultLocales["deleteDialog.title"]} />}
                                dialogContent={<FormattedMessage id='deleteDialog.message' defaultMessage={defaultLocales["deleteDialog.message"]} />}
                            />
                        </Grid>
                    </Box>
                </Container>
            </>
        )
    } catch (err) {
        console.error(err);
        return <ChildErrorPage subTitle={"common.wentWrong"} />
    }
})
export default BankListMain;