import { networkRTS } from "../../connections/networkRTS"
import { TRANS_BANKLIST, TRANS_SUBTYPE, TRANS_UPDATELIST } from "../../constants/constants"
import { bankingListManipulation, getBankDetailsbyCode, snackBarActions, updateBankListLoader } from "./bankSlice"

export const getBankList =  (requestBody, localeMessage) => {
    return (dispatch) => {
        try {    
            networkRTS.post( `${process.env.REACT_APP_MBB_RT_SERVICE}getBankList`, TRANS_BANKLIST, TRANS_SUBTYPE, requestBody)
            .then((res) => {
                return res.json()
            })
            .then((data) => {
                const { statuscode, executionStatus, AdditionalStatusCodes } = data.responseHeader;
                if(statuscode === "200") {
                    dispatch(getBankDetailsbyCode(data));
                    dispatch(snackBarActions({open: true, severity: 'success', snackBarMessage: localeMessage}));
                    dispatch(updateBankListLoader(false));
                } else if(AdditionalStatusCodes){
                    dispatch(snackBarActions({open:true,severity: 'error', snackBarMessage: AdditionalStatusCodes[0].HostTxndesc}));
                    dispatch(updateBankListLoader(false));
                } else {
                    dispatch(snackBarActions({open:true,severity: 'error', snackBarMessage: executionStatus}));
                    dispatch(updateBankListLoader(false));
                }
            }).catch((error) => {
                dispatch(snackBarActions({open: true, severity: 'error', snackBarMessage: error.message}))
                dispatch(updateBankListLoader(false));
            })
        } catch(err) {
            dispatch(snackBarActions({open: true, severity: 'error', snackBarMessage: err.message}))
            dispatch(updateBankListLoader(false));
        }
    }
};

export const updateBankInfo = (requestBody, localeMessage) => {
    return (dispatch) => {
        try {
            networkRTS.post(`${process.env.REACT_APP_MBB_RT_SERVICE}updateBankList`, TRANS_UPDATELIST, TRANS_SUBTYPE, requestBody)
            .then(res => {
                return res.json()
            })
            .then((data) => {
                const { statuscode, executionStatus, AdditionalStatusCodes } = data.responseHeader;
                if(statuscode === "200") {
                    dispatch(bankingListManipulation(data));
                    dispatch(snackBarActions({open: true, severity: 'success', snackBarMessage: localeMessage}));
                } else if(AdditionalStatusCodes){
                    dispatch(snackBarActions({open:true,severity: 'error', snackBarMessage: AdditionalStatusCodes[0].HostTxndesc}));
                } else {
                    dispatch(snackBarActions({open:true,severity: 'error', snackBarMessage: executionStatus}));
                }  
            })
            .catch(error => {
                dispatch(snackBarActions({open: true, severity: 'error', snackBarMessage: error.message}))
            })
        } catch(error){
            dispatch(snackBarActions({open: true, severity: 'error', snackBarMessage: error.message}))
        };
    }
};