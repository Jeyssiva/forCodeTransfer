import { SERVICE_PROVIDER_DETAILS } from "../../constants/constants";

export const COUNTRYCODE = 'countryCode';
export const COUNTRYNAME = 'countryName';
export const BANKCODE = 'bankCode';
export const BANKNAME = 'bankName';
export const BICCODE = 'biccode';
export const SERVICEPROVIDER = 'serviceProvider';
export const ADDRLINE1 = 'bankAddress1';
export const ADDRLINE2 = 'bankAddress2';
export const ADDRLINE3 = 'bankAddress3';
export const ZIPCODE = 'bankAddress4';
export const ACQUIREID = 'acquirerId';
export const ROUTINGNO = 'routingNo';
export const MBBINDICATOR = 'mbbIndicator';
export const BANKNAMESELECTION = 'setBankNameSelection';
export const ERRORPROPS = 'setErrorProps';
export const VALUECHANGES = 'valueChanged';
export const ACTIVEINDICATOR = 'activeInd';
export const ACTIONCODE = 'actionCode'

export const CLEARCOUNTRYCHILDS = 'ClearCountryChilds';
export const CLEARALL = 'ClearAll';
export const CLEARBANKNAMECHILDS = 'ClearBankNameChilds';

export const OPENDIALOG = 'openDialog';
export const CLEAR_ERRORPROPS = 'ClearErrorProps';

const BankInfoTemplate = {
    countryCode: "",
    countryName: "",
    biccode: "",
    bankCode: "",
    bankName: "",
    acquirerId: "",
    routingNo: "",
    bankAddress1: "",
    bankAddress2: "",
    bankAddress3: "",
    bankAddress4: "",
    mbbIndicator: "Y",
    actionCode: "",
    activeInd: "A",
    serviceProvider: "MBB"
}

export const initialState= {
    serviceProviderList: [],   
    selectedBankDetail: {...BankInfoTemplate},
    errorProps : {},
    openDialog : false
}

export function reduce (state, action) {
    function clearCountryFields(){
        const emptyChildFields = {...state.selectedBankDetail};
        for (const key in emptyChildFields){   
            if(key === 'mbbIndicator') emptyChildFields[key] = 'Y'
            else if(key === 'activeInd') emptyChildFields[key] = 'A'
            else if(key === 'serviceProvider') emptyChildFields[key] = 'MBB'
            else if(key !== 'countryCode' && key !== 'countryName') emptyChildFields[key] = ""
        }
        return emptyChildFields;
    }

    switch(action.type) {
        case COUNTRYCODE: {
            return {
                 ...state,
                selectedBankDetail: {...state.selectedBankDetail, [action.fieldName] : action.value},
                serviceProviderList: SERVICE_PROVIDER_DETAILS.filter(l => l.parentId === action.value)
            }
        }
        case BANKNAME: {
            return {
                ...state,
                bankName: action.value
            }
        }
        case ERRORPROPS: {
            if(action.deletion) {
                const errorProp = {...state.errorProps};
                delete errorProp[action.data.fieldName];
                return {
                    ...state,
                    errorProps: errorProp
                }
            }
            return {
                ...state,
                errorProps: {...state.errorProps, [action.data.fieldName] : action.data.errorText}
            }
        }
        case VALUECHANGES: {
            return {
                ...state,
                selectedBankDetail: {...state.selectedBankDetail, [action.fieldName] : action.value}
            }
        }
        case BANKNAMESELECTION: {
            return {
                ...state,
                errorProps: {},
                selectedBankDetail: {...BankInfoTemplate, ...action.value, previousBicCode : action.value.biccode}
            }
        }
        case CLEARCOUNTRYCHILDS: {     
            return {
                ...state,
                errorProps: {},
                selectedBankDetail: {...clearCountryFields()}
            }
        }
        case CLEARALL: {
            return {
                ...state,
                errorProps: {},
                selectedBankDetail: {...BankInfoTemplate},
                serviceProviderList: []
            }
        }
        case OPENDIALOG: {
            return {
                ...state,
                openDialog: action.value
            }
        }
        case CLEAR_ERRORPROPS: {
            return {
                ...state,
                errorProps: {}
            }
        }
        default: {
            return { ...state }
        }
    }
}