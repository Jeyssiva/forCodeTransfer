import { createSlice } from "@reduxjs/toolkit";
import { BANK_MAINTAINANCE } from "../../constants/sliceConstants";

 const initialState = {
    bankDetailsbyCC : [],
    snackBarProperties: {},
    getBankLoaderStatus: false
};

const bankSlice = createSlice({
     name: BANK_MAINTAINANCE,
     initialState,
     reducers: {
        getBankDetailsbyCode(state, action) {
            state.bankDetailsbyCC = action.payload.responseBody.bankcode.map(item => {
                return {
                    ...item,
                    bankNameDisplay: `${item.bankName}(${item.biccode})`

                }
            });
        },
        snackBarActions(state,action) {
            state.snackBarProperties = {...action.payload}
        },
        bankingListManipulation(state,action) {
            const { actionCode, bankName, biccode, previousBicCode } = action.payload.responseBody;      
            if(actionCode === 'A') {
                state.bankDetailsbyCC = [...state.bankDetailsbyCC, 
                                {...action.payload.responseBody, bankNameDisplay : `${bankName}(${biccode})`}]
                                .sort((a,b) => a.bankName.localeCompare(b.bankName));
            }
            else if(actionCode === 'U') {
                const filteredBankList = state.bankDetailsbyCC
                                .filter(bankItem => bankItem.biccode !== previousBicCode);
                state.bankDetailsbyCC = [...filteredBankList, 
                                            {...action.payload.responseBody, bankNameDisplay : `${bankName}(${biccode})`}]
                                            .sort((a,b) => a.bankName.localeCompare(b.bankName));
            }            
            else 
                state.bankDetailsbyCC = state.bankDetailsbyCC.filter(bankItem => bankItem.biccode !== action.payload.responseBody.biccode);
        },
        clearBankDetails(state, action) {
            state.bankDetailsbyCC = [];
        },
        updateBankListLoader(state, action) {
            state.getBankLoaderStatus = action.payload;
        }
     }
})

export const {
    getBankDetailsbyCode,
    snackBarActions,
    bankingListManipulation,
    clearBankDetails,
    updateBankListLoader
} = bankSlice.actions;

export default bankSlice.reducer; 