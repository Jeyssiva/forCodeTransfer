import { getNestedProperty } from "../showMxTemplateAsTreeView/itemManipulateHelpers"

// SaaHeader - Add default sections
export const updateAdditionalSections = (saaHeaderData) => {
    const pDetails = ['Header', 'Message', 'NetworkInfo'];
    const additionalData = getNestedProperty(pDetails, saaHeaderData);
    additionalData['Network'] = {_text : 'SWIFTNet', hierIndex: 5}
    additionalData['SWIFTNetNetworkInfo'] = {'RequestType': {_text: 'pacs.009.001.08', hierIndex: 0}, 
                            'RequestSubtype': {_text: 'swift.cbprplus.cov.02', hierIndex: 1},
                        hierIndex : 8}

    //Add the Revision in SAA Header as manually
    saaHeaderData['Revision'] = {_text : '2.0.15', hierIndex: -1};
}

// Function used to add hierIndex for all parent sections and child fields.
export const hierIndexAddition = (hierSchemaData, resultJson) => {
    try {
        for(const shortTitle in resultJson) {
            if(typeof resultJson[shortTitle] === 'object' && 
                shortTitle !== '_attributes' && shortTitle !== '_text' && shortTitle !== 'ChoiceType' 
                && shortTitle !== 'error') {
                // if(shortTitle === 'Revision' || shortTitle === 'MessageIdentifier'){
                //     console.log('come');
                // }
                // console.log(`${shortTitle}`);
                const iName = !isNaN(shortTitle) ? `Item${shortTitle}` : shortTitle;
                // Get existing hierIndex, if schema's hierIndex is undefined, used the existing one.
                const hIndex = resultJson[shortTitle].hierIndex || 0;
                const {hierIndex} = hierSchemaData[iName] || {hierIndex: hIndex};
                // console.log(`${shortTitle}-${hierIndex}`);
                resultJson[shortTitle].hierIndex = hierIndex;
                if(resultJson[shortTitle] && Object.keys(resultJson[shortTitle]).length > 0 
                        && hierSchemaData[iName]?.children){
                    hierIndexAddition(hierSchemaData[iName].children, resultJson[shortTitle])
                }
            }
        }
    }
    catch(err){
        throw err;
    }
}