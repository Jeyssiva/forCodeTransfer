import { createSelector, createSlice } from "@reduxjs/toolkit"
import { SAVED_TEMPLATES_SLICE } from "../../../constants/sliceConstants"
import { cloneDeep } from "lodash";

export const templatesInitialState = {
    savedTemplatesList : [],
    savedTempLoading: false,
    snackBarSavedTemplates: {},
    accessSavedTempLoading: false,
    accessSavedTempMessage: '',
    snackBarAccessSavedTemplate: {},
    selectedTemplate : {},
    backPageDetails : {}
}

const savedTemplatesSlice = createSlice(({
   name : SAVED_TEMPLATES_SLICE,
   initialState: templatesInitialState,
   reducers : {
    setSavedTemplatesList(state, action) {
        const {responseBody} = action.payload;
        state.savedTemplatesList = {...responseBody, enqTxn : responseBody.enqTxn && responseBody.enqTxn.map(e => {
            return {
                ...e,
                id: e.templateStoreId
            }
        })} ;
    },
    setSavedTempLoading(state,action) {
        const {status} = action.payload;
        state.savedTempLoading = status;
    },
    snackBarActionSavedTemplates(state, action) {
        state.snackBarSavedTemplates = {...action.payload};
    },
    setAccessSavedTempLoading(state,action) {
        const {status, message} = action.payload;
        state.accessSavedTempLoading = status;
        state.accessSavedTempMessage = message;
    },
    snackBarActionAccessSavedTemplate(state, action) {
        state.snackBarAccessSavedTemplate = {...action.payload};
    },
    setSelectedTemplate(state, action) {
        state.selectedTemplate = action.payload.row 
    },
    removeTemplateFromList(state, action) {
        const {templateStoreId} = action.payload;
        state.savedTemplatesList = {...state.savedTemplatesList, enqTxn: state.savedTemplatesList.enqTxn
            .filter(f => f.templateStoreId !== templateStoreId)};
    },
    setBackPageDet(state, action) {
        state.backPageDetails = action.payload.data
    },
    updateTemplate(state, action) {
        const { enqTxn : [{ templateName, template, templateVersion, updatedDt }]  } = action.payload.responseBody;
        const {enqTxn = []} = cloneDeep(state.savedTemplatesList);
        state.savedTemplatesList = {...state.savedTemplatesList, enqTxn : enqTxn.map(enq => {
            if(enq.templateName === templateName) {
                return {
                    ...enq,
                    template,
                    templateVersion,
                    updatedDt
                }
            }
            return enq;
        })}
    }
   }
}))

const list = state => state[SAVED_TEMPLATES_SLICE].savedTemplatesList;
const loading = state => state[SAVED_TEMPLATES_SLICE].savedTempLoading;
const action = state => state[SAVED_TEMPLATES_SLICE].snackBarSavedTemplates;
const indicator = state =>{
    return {accessSavedTempLoadingIndicator :  state[SAVED_TEMPLATES_SLICE].accessSavedTempLoading, 
          accessSaveTempLoadingMessage : state[SAVED_TEMPLATES_SLICE].accessSavedTempMessage}
};
const accessAction = state => state[SAVED_TEMPLATES_SLICE].snackBarAccessSavedTemplate;
const selTemp = state => state[SAVED_TEMPLATES_SLICE].selectedTemplate;
const det = state => state[SAVED_TEMPLATES_SLICE].backPageDetails;

export const getSavedTemplatesList = createSelector(list, l => l);
export const getSavedTemplateLoading = createSelector(loading, load => load);
export const getSnackBarSavedTemplates = createSelector(action, act => act);
export const getAccessSavedTempLoadingDetails = createSelector(indicator, indi => indi);
export const getSnackBarAccessSavedTemplate = createSelector(accessAction, acc => acc);
export const getSelectedTemplate = createSelector(selTemp, s => s);
export const getBackPageDet = createSelector(det, d => d);

export const {
    setSavedTemplatesList,
    setSavedTempLoading,
    snackBarActionSavedTemplates,
    setAccessSavedTempLoading,
    snackBarActionAccessSavedTemplate,
    setSelectedTemplate,
    removeTemplateFromList,
    setBackPageDet,
    updateTemplate
} = savedTemplatesSlice.actions;
export default savedTemplatesSlice.reducer;