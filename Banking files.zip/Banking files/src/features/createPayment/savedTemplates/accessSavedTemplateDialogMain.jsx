import { Container, Dialog, DialogActions, DialogContent, DialogTitle, Grid, IconButton, Stack, Typography } from "@mui/material"
import { useDispatch, useSelector } from "react-redux"
import * as React from "react";
import { useLocation } from 'react-router-dom';
import MbSnackbar from "../../common/mbSnackbar";
import { memo } from "react";
import { getSelectedTemplate, getSnackBarAccessSavedTemplate, setAccessSavedTempLoading, 
  setSelectedTemplate, snackBarActionAccessSavedTemplate, snackBarActionSavedTemplates } from "./templatesSlice";
import MbBreadCrumbs from "../../common/mbBreadcrumbs";
import { getAllStaticDataFromSavedPayment } from "./templatesAction";
import { GET_DEFAULT_VALUES_SCHEMA_NAMES, GET_SECTION_DETAIL_SCHEMA_NAMES, TEMPLATE_REQACTION_UPDATE, TEMPLATE_SELECTION } from "../../../constants/createPaymentConstants";
import ShowMxTemplateMain from "../../showMxTemplateAsTreeView/showTemplateMain";
import { CREATEPAYMENT, MODULENAME, SAVEDTEMPLATES_CRUMBS } from "../../../constants/routesURL";
import { setSaaTreeMountedStatus } from "../../showMxTemplateAsTreeView/saaHeaderSlice";
import ProcessTemplateAction from "../../createPayment/processTemplateAction";
import SubmitPaymentActivities from "../../createPayment/submitPaymentActivities";
import { isEmpty } from "lodash";
import { CloseOutlined } from "@mui/icons-material";
import { findBodySchemaLoaded, findDefaultValuesLoaded, findMsgConfigLoaded, getSectionDetailRequests } from "../../showMxTemplateAsTreeView/validationHelpers";
import { getRequiredApiRequest } from "../../showMxTemplateAsTreeView/persistedSlice";
import { setMountedStatus } from "../../showMxTemplateAsTreeView/showMxTempSlice";
import { MSG_STATUS_DRAFT, SRCOFTXN_CREATEPAYMENT } from "../../../constants/mxTempConstants";
import { OUT } from "../../../constants/transactionConstants";
import { TRANS_TYPE } from "../../../constants/constants";
import { getScreenAccess } from "../../dashboard/dashboardSlice";

 const AccessSavedTemplate = memo (({openTemplate, onHandleClose}) => {
    const actDispatch = useDispatch();  
    const location = useLocation();
    //  const accessSavedTempLoadDet =useSelector(getAccessSavedTempLoadingDetails);
    const snackBarPropertiesAccess = useSelector(getSnackBarAccessSavedTemplate);
    const selectedTemplate = useSelector(getSelectedTemplate);
    const getRequiredApiReqData = useSelector(getRequiredApiRequest);
    const {selTemplate = {}} = location.state || {};
    const screenAccessDet = useSelector(getScreenAccess);

    const crumbs = React.useMemo(() => {
      return [
        {title: 'templateList.createPayment', formattedName: true, color: 'inherit', url :`/${MODULENAME}/${CREATEPAYMENT}` }, 
        {title: 'templateList.title' , formattedName : true, color: 'inherit', url :`/${MODULENAME}/${SAVEDTEMPLATES_CRUMBS}/` },
        {title: 'templateList.editTemplate', formattedName : true},
        {title: `${selectedTemplate.messageDefId}` }
      ]
    }, [selectedTemplate])

    React.useEffect(() => {
      return () => {
        actDispatch(snackBarActionAccessSavedTemplate({open:false}));
        actDispatch(setAccessSavedTempLoading({status: false}));
        actDispatch(setSaaTreeMountedStatus({status: false}));
        actDispatch(setSelectedTemplate({row: {}}))
        actDispatch(setMountedStatus({ status: false }));
      }
    }, [actDispatch])
    
    const findTempDetail = React.useMemo(() => {
      return TEMPLATE_SELECTION.find(t => t.value === selTemplate.messageDefId);
    }, [selTemplate])

    React.useEffect(() => {
      if(!selTemplate || isEmpty(selTemplate)) return;
      const findTempDtl = TEMPLATE_SELECTION.find(t => t.value === selTemplate.messageDefId);
      const {value: messageDefID, enqType} = findTempDtl;
      const inqReqBody = {
        ddListType:  !getRequiredApiReqData.countryList 
                  ? "GBR_COUNTRY_LIST, GBR_CURRENCY_LIST, GBR_PURPOSE_ALL"
                  : 'GBR_CURRENCY_LIST, GBR_PURPOSE_ALL' ,
        dropDownListKey1: "",
        dropDownListKey2: ""
      }
      let msgConfigBody = getSectionDetailRequests(TRANS_TYPE[OUT], screenAccessDet, 
        MSG_STATUS_DRAFT, SRCOFTXN_CREATEPAYMENT, messageDefID);
     
      const applicableFalseReq = {
        messageDefId: ['SAA_HEADER'],
        sourceOfTxn : SRCOFTXN_CREATEPAYMENT,
        isApplicable: 0
    }
      const bodySchema = findBodySchemaLoaded(messageDefID, getRequiredApiReqData);
      const msgConfigBySchema = findMsgConfigLoaded(TRANS_TYPE[OUT], SRCOFTXN_CREATEPAYMENT, MSG_STATUS_DRAFT, 
        screenAccessDet,
        messageDefID, getRequiredApiReqData, msgConfigBody);
    const msgConfigTransName = GET_SECTION_DETAIL_SCHEMA_NAMES[messageDefID];
      const requiredApis = {...getRequiredApiReqData, msgConfigBySchema, bodySchema};
      actDispatch(getAllStaticDataFromSavedPayment(messageDefID, requiredApis, 
        {msgConfigBody, msgConfigTransName }, inqReqBody, selTemplate, applicableFalseReq));
      actDispatch(setSelectedTemplate({row : selTemplate}));
    }, [])

    const onSnackBarClose = (event, reason) => {
      if(reason === 'clickaway'){
          return;
      }
      actDispatch(snackBarActionAccessSavedTemplate({open: false}));
    }

    try {
      return (
        <Dialog
            scroll='paper'
            fullWidth={true}
            maxWidth={false}
            open={openTemplate}
            aria-labelledby="scroll-dialog-title"
            aria-describedby="scroll-dialog-description"
        > 
        <DialogTitle>
          <Grid sx={{display: 'flex', flexDirection: 'column', height: '50px'}}>
              <MbBreadCrumbs crumbsList = {crumbs} />
              {/* <Typography variant='h5' sx = {{fontWeight: 'bold', display: 'flex', alignItems: 'center', width: '50%', fontSize: '13px'}}>
                    {selectedTemplate.templateName}
              </Typography> */}
              <Grid className="pop-title">
                  <Typography noWrap variant="h5" component={'span'}>
                      {selectedTemplate.templateName}
                  </Typography>
                  <IconButton onClick={onHandleClose}>
                      <CloseOutlined />
                  </IconButton>
              </Grid>
          </Grid>
        </DialogTitle>
        <DialogContent>
            <ShowMxTemplateMain/>
        </DialogContent>
        <DialogActions>
          <Stack direction="row" gap={1} justifyContent={"flex-end"} sx={{ width: '100%', marginTop: 1 }}>
            <SubmitPaymentActivities transType={'O'} selectedTemplate={findTempDetail.value} loadingAction = {setAccessSavedTempLoading}
                                    submissionType = {'Create'} handlePopupClose = {onHandleClose} snackBarFunction={snackBarActionSavedTemplates} />
            <ProcessTemplateAction transType={'O'} enqType={findTempDetail.enqType} 
                bizType={findTempDetail.biz} buttonName = {"Update Template"} reqAction = {TEMPLATE_REQACTION_UPDATE} 
                selectedTemplateDet = {selTemplate} loadingFunction={setAccessSavedTempLoading} 
                snackBarFunction={snackBarActionSavedTemplates} onCloseDtlPopup = {onHandleClose}/>
          </Stack>
        </DialogActions>
          <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesAccess.open} 
            severity={snackBarPropertiesAccess.severity} 
            message={snackBarPropertiesAccess.snackBarMessage}/>
        </Dialog>
      )
    }
    catch(err) {
      return (
        <Container maxWidth={false} disableGutters sx={{height: 'auto', width: 'auto', paddingTop: '10px', px: '5px'}}>
          <Typography>{"Sorry! No item found"}</Typography>
        </Container>
      )
    }
  })

  export default AccessSavedTemplate;