import { networkISO } from "../../../connections/networkISO"
import { INQUIRY, TEMPLATE_CONFIGURATION, VIEW_TEMPLATES } from "../../../constants/apiConstants"
import { TRANS_INQ_SUB_TYPE, TRANS_INQ_TYPE, TRANS_SECTION, TRANS_SECTION_SUBTYPE, VIEW_TEMPLATE_SUB_TYPE, 
    VIEW_TEMPLATE_TYPE } from "../../../constants/constants"
import { CatchErrorDisplay } from "../../errorPage/errorHelpers"
import { getAppOriFromPersistSavedTemplate } from "../../showMxTemplateAsTreeView/appHeaderSlice"
import { convertDataXMLtoJSONWithDeclaration } from "../../showMxTemplateAsTreeView/conversionHelpers"
import { getSaaOriFromPersistSavedTemplate } from "../../showMxTemplateAsTreeView/saaHeaderSlice"
import { setSavedTempLoading, setSavedTemplatesList, snackBarActionSavedTemplates } from "./templatesSlice"

import XMLSAAHEADERSCHEMA from '../../doc/saaHead_xsd/SAA_XML_v2_0.xsd';
import XMLAPPHEADERSCHEMA from '../../doc/appHead_xsd/head.001.001.02.xsd'; 
import { GET_PERSISTED_BODY_SCHEMA_NAMES, GET_SCHEMA_NAMES } from "../../../constants/createPaymentConstants"
import { setActiveMsgDefId } from "../../showMxTemplateAsTreeView/showMxTempSlice"
import { loadAllSchemaAsHier, loadElementAttributes } from "../../showMxTemplateAsTreeView/persistedSlice"
import _, { isEmpty } from "lodash"
import { getBodyOriFromPersistSavedTemplate } from "../../showMxTemplateAsTreeView/bodySlice"
import { FETCH_ISO_SERVICE } from "../../../apacheEnvConfig"
import { NAMES_TO_REMOVE } from "../../../constants/mxTempConstants"

export const templatesList = (requestBody) => {
    return dispatch => {
         try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${VIEW_TEMPLATES}`, 
                requestBody, VIEW_TEMPLATE_TYPE, VIEW_TEMPLATE_SUB_TYPE)
            .then((response) => {
                if(!response) throw new Error('Failed to fetch')
                if(!response.ok){
                    if(response.status)
                        throw new Error(`${response.status} - ${response.statusText}`)
                    else throw new Error('Failed to fetch') 
                }
                return response.json()
            })
            .then(responseData => {
                const {AdditionalStatusCodes, statuscode, executionStatus} = responseData.responseHeader;            
                if(statuscode === '200') {
                    dispatch(setSavedTempLoading({status: false}));
                    dispatch(setSavedTemplatesList(responseData));
                    //dispatch(snackBarPaymentAction({open:true, severity: 'success', snackBarMessage: statusMessage}))
                } else if(AdditionalStatusCodes) {
                   dispatch(snackBarActionSavedTemplates({open:true, severity: 'error', snackBarMessage: AdditionalStatusCodes[0].HostTxndesc}))
                } else {
                   dispatch(snackBarActionSavedTemplates({open:true, severity: 'error', snackBarMessage: executionStatus}))
                }
            })
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, VIEW_TEMPLATES, dispatch);
                if(findDisplayMessage)
                    dispatch(snackBarActionSavedTemplates({open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}`}));
                else
                    dispatch(snackBarActionSavedTemplates({open: true, severity: 'error', snackBarMessage: `${error.message}`}));
            })
        } catch (err){
            dispatch(snackBarActionSavedTemplates({open: true, severity: 'error', snackBarMessage: `${err.message}`}));
        }
        finally {
            dispatch(setSavedTempLoading({status: false}));
        }
    }
}

export const getAllStaticDataFromSavedPayment = (msgDefId, requiredApis, 
    {msgConfigBody, msgConfigTransName },
     inqReqBody, templateDetail, applicableFalseReq) => {
    const requests = {};
    const jsonData = convertDataXMLtoJSONWithDeclaration(templateDetail.template);
    return dispatch => {
        try {
            //Initialize an array to hold promises conditionally
            const apiPromises = [];
            if(!requiredApis.applicableFalse) {
                apiPromises.push(
                    networkISO.post(`${process.env.REACT_APP_MBB_ISO_SERVICE}/${TEMPLATE_CONFIGURATION}`, 
                        applicableFalseReq, TRANS_SECTION, TRANS_SECTION_SUBTYPE)
                )
                requests['applicableFalseDataPersist'] = {data: {}};
            }
            if(!requiredApis.saaHeader){
                apiPromises.push(fetch(XMLSAAHEADERSCHEMA, {
                    method: 'get',
                    headers: {
                        "Content-Type": "application/xml; charset=utf-8"
                    }
                }))
                requests['saaHeader'] = {data: {}};
            }
            if(!requiredApis.appHeader) {
                apiPromises.push(
                    fetch(XMLAPPHEADERSCHEMA, {
                        method: 'get',
                        headers: {
                            "Content-Type": "application/xml; charset=utf-8"
                        }
                    })
                )
                requests['appHeader'] = {data: {}};
            }
            if(!requiredApis.bodySchema){
                apiPromises.push(
                    fetch(`/schema_xsd/${GET_SCHEMA_NAMES[msgDefId]}.xsd`, {
                        method: 'get',
                        headers: {
                            "Content-Type": "application/xml; charset=utf-8"
                        }
                }))
                requests[GET_PERSISTED_BODY_SCHEMA_NAMES[msgDefId]] = {data: {}};
            }
            if(!requiredApis.msgConfigBySchema){
                apiPromises.push(
                    networkISO.post(`${FETCH_ISO_SERVICE()}/${TEMPLATE_CONFIGURATION}`, 
                        msgConfigBody, TRANS_SECTION, TRANS_SECTION_SUBTYPE)
                )
                requests[msgConfigTransName] = {data: {}};
            }
            if(!requiredApis.staticData){
                apiPromises.push(
                    networkISO.post(`${FETCH_ISO_SERVICE()}/${INQUIRY}`, 
                        inqReqBody, TRANS_INQ_TYPE, TRANS_INQ_SUB_TYPE)
                )
                requests['staticData'] = {data: {}}
            }
            if(apiPromises.length > 0){
                  Promise.allSettled(apiPromises)
                    .then(resSchemas => {
                        // Get a JSON object from each of the responses
                        const schemaPromises= resSchemas.map(result => {
                            if(result.status === 'fulfilled' && result.value.ok && result.value.status === 200) 
                                return result.value.text();
                            else return Promise.reject(new Error(`Api issue : ${result.reason}`))
                        });
                        return Promise.allSettled(schemaPromises);
                    })
                    .then(resData => {
                        Object.keys(requests).forEach((reqItem, index) => {
                            if(resData[index].status === 'fulfilled' && !resData[index].value.includes('<!DOCTYPE html>'))
                                requests[reqItem] = {data: resData[index].value}
                        })
                        if(requests[msgConfigTransName] && !isEmpty(requests[msgConfigTransName].data)){
                            const {responseBody : {enqTxn = []} = {}} = JSON.parse(requests[msgConfigTransName].data);
                            const elementAttributes = _.filter(enqTxn, p => NAMES_TO_REMOVE.includes(p.messagePath));
                            dispatch(setActiveMsgDefId({msgDefId}));
                            dispatch(loadAllSchemaAsHier({requiredApis, requests, msgConfigBody }));
                            dispatch(loadElementAttributes({msgDefId, elementAttributes}));
                            dispatch(getSaaOriFromPersistSavedTemplate({msgDefId, jsonData}));
                            dispatch(getAppOriFromPersistSavedTemplate({msgDefId, jsonData}));
                            dispatch(getBodyOriFromPersistSavedTemplate({msgDefId, jsonData}));
                        }
                    })
                    .catch(error => {
                        const findDisplayMessage = CatchErrorDisplay(error, TEMPLATE_CONFIGURATION, dispatch);
                        if(findDisplayMessage)
                            dispatch(snackBarActionSavedTemplates({open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}`}));
                        else
                            dispatch(snackBarActionSavedTemplates({open: true, severity: 'error', snackBarMessage: `${error.message}`}));
                    })
            } else {
                // Added Promise for provide some delay to load transaction data.
                let reqPromise =  new Promise((resolve, reject) => {   
                    setTimeout(() => {
                        resolve('success')
                    }, 0)
                })
                reqPromise.then(value => {
                    if(value === 'success') {
                        dispatch(setActiveMsgDefId({msgDefId}));          
                        dispatch(getSaaOriFromPersistSavedTemplate({msgDefId, jsonData}));
                        dispatch(getAppOriFromPersistSavedTemplate({msgDefId, jsonData}));
                        dispatch(getBodyOriFromPersistSavedTemplate({msgDefId, jsonData}));
                    }
                }
                );
            }
        }
        catch(error) {
            dispatch(snackBarActionSavedTemplates({open: true, severity: 'error', snackBarMessage: `${error.message}`}));
        }
    }  
}