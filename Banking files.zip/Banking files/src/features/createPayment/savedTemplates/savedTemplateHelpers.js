import { cloneDeep, has, isEmpty } from "lodash";
import { ERRORCODES } from "../../../constants/mxTempConstants";
import { createNewArrayItem, hasTextFieldAvailable, updateSchemaStructure } from "../../showMxTemplateAsTreeView/templateHelpers";
import moment from "moment";

// function for enable all fields and sections if 'SourceofTxn' = 'CreatePayment'
export function updateRawHierarchywithSavedTemplates(rawHierarchy, bodyDataResult, msgConfigData, expandedList = [], resetData = false) {
    try {
        for(const shortTitle in rawHierarchy){
            const {occuranceObj, hierIndex = 0, isFieldWithMultiEntry, nodeLevel, isChoicableProperty, 
              isContainsChoiceInsideSequence, elementType, isManualProperty, parentDetails} = rawHierarchy[shortTitle];
            // const [gg,g, p, f] = parentDetails.slice(-4);
            // if(gg === 'CdtTrfTxInf' && g === 'PmtTpInf' && p === 'SvcLvl' && f === 'ChoiceType' ){
            //   console.log('come');
            // }
  
            // if(p === 'Message' && f === 'MessageIdentifier'){
            //   console.log('come');
            // }
  
            //by default disabled multiple items option of AdrLine and CdtTrfTxInf
            if(shortTitle === 'AdrLine' || shortTitle === 'CdtTrfTxInf') 
              rawHierarchy[shortTitle].occuranceObj = {...rawHierarchy[shortTitle].occuranceObj, disabled: true};
             
            // if have data based on shortTitle
            if((shortTitle in bodyDataResult) || (shortTitle in msgConfigData)){
                //update hierIndex for which of the fields contains the data
                if(isEmpty(bodyDataResult[shortTitle])) bodyDataResult[shortTitle] ={hierIndex}
                else bodyDataResult[shortTitle].hierIndex = hierIndex;
  
                if(elementType) {
                  const {defaultValue, choiceType , isMandatory = false} = msgConfigData[shortTitle] || {};
                  // 1. If UETR exists - set the empty value
                  // 2. Set the Current date time into CreationDateTime or CreationDate.
                  
                  if(resetData) {
                    if(shortTitle === 'UETR') bodyDataResult[shortTitle]._text = ''
                    else if (shortTitle === 'CreDtTm' || shortTitle === 'CreDt') 
                      // Consider the local desktop timezone only rather than from settings 
                      bodyDataResult[shortTitle]._text = moment().local().format();
                  }
                  
                  if(bodyDataResult && bodyDataResult[shortTitle] && bodyDataResult[shortTitle]._text) {
                    if(defaultValue) rawHierarchy[shortTitle].disableField = true;
                    else if(choiceType) rawHierarchy[shortTitle].disableField = true;
                    else rawHierarchy[shortTitle].disableField = false;
                  } else if(isMandatory){
                    bodyDataResult[shortTitle] = {error : {_text : ERRORCODES['mandatory']}};
                  }
                  rawHierarchy[shortTitle].ismandatoryfield = isMandatory;
                }
                // update the expandedList for Treeview expansion.
                if(!has(rawHierarchy[shortTitle], 'elementType') || isFieldWithMultiEntry)        
                    expandedList.push(nodeLevel)
               
                // update the occuranceObj information
                if(occuranceObj){
                    rawHierarchy[shortTitle].hideChildForRequired = false;
                    const {isMandatory = false} = msgConfigData[shortTitle] || {};
                    if(occuranceObj.maxOccurs === 1) {
                        rawHierarchy[shortTitle].checkBoxProps = {...rawHierarchy[shortTitle].checkBoxProps, 
                          isTicked: true, disabled: isMandatory };
                    }
                    const count = (Array.isArray(bodyDataResult[shortTitle]) ? bodyDataResult[shortTitle].length : 1) || 1;
                    rawHierarchy[shortTitle].occuranceObj = {...rawHierarchy[shortTitle].occuranceObj, count,
                        showMinusForSingleItem : (count === 1 && occuranceObj.minOccurs === 0 && !isMandatory)
                          ? true : false,
                        restrictOccurs: occuranceObj.maxOccurs === 1 
                        ? true : bodyDataResult[shortTitle].length === occuranceObj.maxOccurs 
                        ? true : false, isItemRequired : isMandatory }
                }
                // If the section is Choicable element or combined with choice and sequence, display the specific element in the childen list.
                if(isChoicableProperty || isContainsChoiceInsideSequence){
                    const isTextFieldThere = hasTextFieldAvailable(bodyDataResult[shortTitle]);
                    let firstItem = ''
                    if(isTextFieldThere) {
                      firstItem = Object.keys(bodyDataResult[shortTitle])[0];
                      bodyDataResult[shortTitle].ChoiceType = {_text: firstItem};     
                    } else {
                      firstItem = msgConfigData[shortTitle].ChoiceType?.choiceType || '';
                      bodyDataResult[shortTitle] = {...bodyDataResult[shortTitle], "ChoiceType" : {_text: firstItem}};
                    }
                    const childElements = cloneDeep(rawHierarchy[shortTitle].children)
                    let resultChild = {}
                    Object.keys(childElements).forEach(ele => {
                        if(has(childElements[ele], 'isChoiceChildHidden')){
                            if(firstItem === ele) {
                                resultChild[ele] = {...childElements[ele], isChoiceChildHidden: false}
                            } else if(!childElements[ele].isManualProperty){
                                resultChild[ele] = {...childElements[ele], isChoiceChildHidden: true}
                            }
                        } else resultChild[ele] = childElements[ele]
                    })
                    rawHierarchy[shortTitle].children = resultChild;
                }

                if(Array.isArray(bodyDataResult[shortTitle]) && bodyDataResult[shortTitle].length > 1){
                  const {parentDetails, nodeLevel, isFieldWithMultiEntry, children, isChoicableProperty} = rawHierarchy[shortTitle];
                  const childInfo = cloneDeep(children);
                  let addChildItems = {};
                  const {choiceType = 0, isMandatory = false} = msgConfigData[shortTitle];
                  for(let i = 0; i < bodyDataResult[shortTitle].length; i++){
                      const newItemName = `Item${i}`
                      const newItem = createNewArrayItem(i, parentDetails, nodeLevel, false, hierIndex);
                      const cloneBodyData = cloneDeep(bodyDataResult[shortTitle][i]);
                      const isRemovableItem = !(parseInt(choiceType, 10) === i + 1 && isMandatory);
                      if(childInfo && !isFieldWithMultiEntry){
                        const cloneChildInfo = cloneDeep(childInfo);
                        updateSchemaStructure(cloneChildInfo, cloneBodyData, i, 0, parentDetails, isChoicableProperty);              
                        addChildItems[newItemName] = {...newItem, isRemovableItem, children: cloneChildInfo};
                        expandedList.push(newItem.nodeLevel);
                      } else {
                        const [singleItem] = Object.values(childInfo);
                        addChildItems[newItemName] = {...singleItem, ...newItem, isRemovableItem};
                      }
                      bodyDataResult[shortTitle][i] = {...cloneBodyData, hierIndex}
                  }
                  rawHierarchy[shortTitle].children = addChildItems
              }
            }
            if(rawHierarchy[shortTitle].children){
              updateRawHierarchywithSavedTemplates(rawHierarchy[shortTitle].children, bodyDataResult[shortTitle] || {}, msgConfigData[shortTitle] || {},
                  expandedList, resetData)
            }
        }
    }
    catch(err){
        console.log(err)
    }
  }