import dayjs from 'dayjs';
import moment from 'moment';
import { makeStyles } from '@mui/styles';
import { FormattedMessage } from 'react-intl';
import { useDispatch, useSelector } from 'react-redux';
import { Refresh, Search } from '@mui/icons-material';
import React, { memo, useEffect, useState } from 'react';
import { Grid, Stack } from '@mui/material';

import { defaultLocales } from '../../i18n';
import MbButton from '../../common/mbButton';
import MbDropdown from '../../common/mbDropdown';
import MbTextField from '../../common/mbTextField';
import MbDateMuiField from '../../common/mbDateMuiPicker';
import { GET_IDENTIFIER, SEARCH_SAVED_TEMPLATES_INITIAL_SEARCH } from '../../../constants/createPaymentConstants';
import { DATE_FORMAT, DATE_FORMAT_BACKEND } from '../../../constants/constants';
import { getBackPageDet, setSavedTempLoading, snackBarActionAccessSavedTemplate } from './templatesSlice';

export const useStyles = makeStyles(() => ({
  dateFieldStyle: {
    width: '21%',
    marginRight: '5px',
    '& .MuiInputBase-root': {
      height: '32px'
    }
  },
  buttonStyle: {
    marginLeft: '3px'
  },
  inputRoot: {
    '& .MuiInputBase-root': {
      height: '32px'
    }
  },
  dropdownRoot: {
    height: '32px', // Adjust the max height as needed,
    textAlign: 'left'
  },
  dropdownFormStyle: {
    width: '32%',
    marginRight: '5px'
  },
  inputStyle: {
    fontSize: '11px'
  }
}))

const SearchSavedTemplates = ({onHandleSearchCriteria}) => {
  const dispatch = useDispatch();
  const getBackPageDetail = useSelector(getBackPageDet);
  const { searchCriteria: sCriteria = { ...SEARCH_SAVED_TEMPLATES_INITIAL_SEARCH } } = getBackPageDetail;
  const [searchCriteria, setSearch] = useState(sCriteria);

  useEffect(() => {
    return () => {
      setSearch({ ...SEARCH_SAVED_TEMPLATES_INITIAL_SEARCH });
    }
  }, [dispatch])

  const onHandleInputChange = (eValue, fieldName) => {
    setSearch({ ...searchCriteria, [fieldName]: eValue })
  }

  const onHandleSearch = () => {
    try {
      const { startdateRange, enddateRange } = searchCriteria;
      let sCriteria = { ...searchCriteria };
      if ((startdateRange === '' || enddateRange === '') && (enddateRange || startdateRange)) {
        const sDate = (startdateRange === '' && enddateRange)
          ? `${moment().format(DATE_FORMAT_BACKEND)}` : startdateRange;
        const eDate = (enddateRange === '' && startdateRange)
          ? `${moment().format(DATE_FORMAT_BACKEND)}` : enddateRange;
        sCriteria = {
          ...sCriteria,
          startdateRange: sDate,
          enddateRange: eDate
        }
        setSearch({ ...searchCriteria, startdateRange: sDate, enddateRange: eDate });
      }
      onHandleSearchCriteria(sCriteria);
    }
    catch (err) {
      dispatch(setSavedTempLoading({ status: false }))
      dispatch( snackBarActionAccessSavedTemplate({ open: true, severity: 'error', snackBarMessage: err.message }))
    }
  }

  const onHandleReset = () => {
    setSearch({ ...SEARCH_SAVED_TEMPLATES_INITIAL_SEARCH });
    onHandleSearchCriteria({...SEARCH_SAVED_TEMPLATES_INITIAL_SEARCH});
  }

  return (
    <>
      <Grid item xs={8} md={2}>
        <MbDateMuiField
          labelText={
            <FormattedMessage id='templateList.dateFrom' defaultMessage={defaultLocales["templateList.dateFrom"]} >
              {msg => (
                <span>
                  <h5>{msg}</h5>
                </span>
              )}
            </FormattedMessage>}
          labelInfo={searchCriteria.startdateRange}
          format={DATE_FORMAT}
          views={['year', 'month', 'day']}
          size={'small'}
          isLabelShrinkNotReq={false}
          onDateChange={dateValue => {
            const dValue = moment(dayjs(dateValue).toDate()).format(DATE_FORMAT_BACKEND)
            return onHandleInputChange(dValue, "startdateRange")
          }} />
      </Grid>
      <Grid item xs={8} md={2}>
        <MbDateMuiField
          labelText={
            <FormattedMessage id='templateList.dateTo' defaultMessage={defaultLocales["templateList.dateTo"]} >
              {msg => (
                <span>
                  <h5>{msg}</h5>
                </span>
              )}
            </FormattedMessage>
          }
          labelInfo={searchCriteria.enddateRange}
          format={DATE_FORMAT}
          views={['year', 'month', 'day']}
          size={'small'}
          isLabelShrinkNotReq={false}
          onDateChange={dateValue => {
            const dValue = moment(dayjs(dateValue).toDate()).format(DATE_FORMAT_BACKEND)
            return onHandleInputChange(dValue, "enddateRange")
          }} />
      </Grid>
      <Grid item xs={8} md={2}>
        <MbDropdown
          id='templateList.identifier'
          fullWidth={true}
          variant={"outlined"}
          labelName={<FormattedMessage id='templateList.identifier' defaultMessage={defaultLocales["templateList.identifier"]} >
            {msg => (
              <span>
                <h5>{msg}</h5>
              </span>
            )}
          </FormattedMessage>}
          labelValue={searchCriteria.messageDefID}
          dropdownList={GET_IDENTIFIER || []}
          onDropdownChange={e => onHandleInputChange(e.target.value, "messageDefID")}
          size={'small'}
          isLabelShrinkNotReq={false}
        />
      </Grid>
      <Grid item xs={8} md={2}>
        <MbTextField
          id="templateName"
          isLabelShrinkNotReq={false}
          label={
            <FormattedMessage id='templateList.templateName' defaultMessage={defaultLocales["templateList.templateName"]}>
              {msg => (
                <span>
                  <h5>{msg}</h5>
                </span>
              )}
            </FormattedMessage>
          }
          size="small"
          value={searchCriteria.templateName}
          onTextFieldChange={e => onHandleInputChange(e.target.value, "templateName")}
        />
      </Grid>
      <Grid item xs={8} md={4}>
        <Stack direction="row" gap={1} sx={{ width: '100%' }}>
          <MbButton buttonName={<FormattedMessage id='common.search' defaultMessage={defaultLocales['common.search']} >{msg => (
            <span>
              <h5>{msg}</h5>
            </span>
          )}</FormattedMessage>}
            className={'button-action'} size={'small'} fullWidth startIcon={<Search />}
            onHandleAction={onHandleSearch} />
          <MbButton buttonName={<FormattedMessage id='common.reset' defaultMessage={defaultLocales['common.reset']} >
            {msg => (
              <span>
                <h5>{msg}</h5>
              </span>
            )}
          </FormattedMessage>}
            variant={'outlined'} size={'small'} fullWidth startIcon={<Refresh />}
            onHandleAction={onHandleReset} />
        </Stack>
      </Grid>
    </>
  );
}

export default memo(SearchSavedTemplates)

