import { Link } from 'react-router-dom';
import { makeStyles } from '@mui/styles';
import { FormattedMessage } from 'react-intl';
import { styled } from '@mui/material/styles';
import { useDispatch, useSelector } from 'react-redux';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import React, { Suspense, lazy, memo, useCallback, useEffect, useMemo, useState } from 'react';
import { Button, Container, Grid, Box, Divider } from '@mui/material';

import { defaultLocales } from '../../i18n';
import MbSnackbar from '../../common/mbSnackbar';
import { templatesList } from './templatesAction';
import MbBreadCrumbs from '../../common/mbBreadcrumbs';
import { templateMaintainence } from '../../createPayment/paymentAction';
import { resetJsonBody } from '../../showMxTemplateAsTreeView/bodySlice';
import { resetSaa } from '../../showMxTemplateAsTreeView/saaHeaderSlice';
import { resetJson } from '../../showMxTemplateAsTreeView/showMxTempSlice';
import { resetJsonApp } from '../../showMxTemplateAsTreeView/appHeaderSlice';
import ConfirmationDialog from '../../customerPaymentData/confirmationDialog';
import { TEMPLATE_SELECTION } from '../../../constants/createPaymentConstants';
import { RowsPerPageOptionsSavedTemplate } from '../../../constants/constants';
import { getBackPageDet, getSavedTemplateLoading, getSavedTemplatesList, getSnackBarSavedTemplates, 
  setBackPageDet, setSavedTempLoading, snackBarActionSavedTemplates } from './templatesSlice';
import FallbackPage from '../../../fallbackPage';

const AccessSavedTemplateMain = lazy(() => import("./accessSavedTemplateDialogMain"));
const SearchSavedMain = lazy(() => import('./searchSavedMain'));

export const useStyles = makeStyles(() => ({
  dateFieldStyle: {
    width: '21%',
    marginRight: '5px',
    '& .MuiInputBase-root': {
      height: '32px'
    }
  },
  buttonStyle: {
    marginLeft: '3px'
  },
  inputRoot: {
    '& .MuiInputBase-root': {
      height: '32px'
    }
  },
  dropdownRoot: {
    height: '32px', // Adjust the max height as needed,
    textAlign: 'left'
  },
  dropdownFormStyle: {
    width: '32%',
    marginRight: '5px'
  },
  inputStyle: {
    fontSize: '11px'
  }
}))

const StripedDataGrid = styled(DataGrid)(({ theme }) => ({
  '& .MuiDataGrid-cell': {
    // fontSize: '11px'
  },
  '& .MuiDataGrid-columnHeader': {
    // backgroundColor: '#A9A9A9', // Set your desired background color
    // height: '40px !important',
    // fontSize: '12px'
  },
  '& .MuiDataGrid-columnHeaderTitle': {
    // fontWeight: 'bold',
  },
  '& .MuiDataGrid-row--even': {
    backgroundColor: 'rgba(0, 0, 0, 0.04)',
  },
  '& .super-app-theme--noMenu': {
    // pointerEvents: 'none',
    // bgcolor : 'white',
    // height: 10,
    // fontWeight: 'bold'
  },
  '& .MuiDataGrid-filler': {
    // backgroundColor: '#A9A9A9'
  },
  // '& .MuiDataGrid-scrollbarFiller':{
  //   backgroundColor: '#A9A9A9'
  // }
}))

const SavedTemplates = () => {
  const dispatch = useDispatch();
  const [selTemplate, setTemplate] = useState({});
  const [deleteConfirmDialog, setConfirmDialog] = useState(false);
  const getSavedTempList = useSelector(getSavedTemplatesList);
  const getSavedTempLoading = useSelector(getSavedTemplateLoading);
  const getSnackBarSavedTemp = useSelector(getSnackBarSavedTemplates);
  const getBackPageDetail = useSelector(getBackPageDet);
  const { pageNumber: pgNo = 0, rowsPerPage: rowsPage = 10 } = getBackPageDetail;
  const [pageNumber, setPageNumber] = useState(pgNo);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPage);
  const [openTemplate, setOpenTemplate] = useState(false);
  const [refreshScreen, setRefreshScreen] = useState(false);

  const AccessSavedPage = useCallback((props) => {
   return (<Suspense fallback={<FallbackPage />}>
      <AccessSavedTemplateMain {...props} />
    </Suspense>)
  }, [openTemplate]);

  const SearchPage = useCallback((props) => {
     return (<Suspense fallback={<FallbackPage />}>
      <SearchSavedMain  {...props} />
     </Suspense>)
  }, [])

  useEffect(() => {
    const reqBody = {
      ...getReqBody
    }
    dispatch(setSavedTempLoading({ status: true }))
    dispatch(templatesList(reqBody));
  }, [pageNumber, rowsPerPage, refreshScreen, dispatch])

  useEffect(() => {
    return () => {
      dispatch(snackBarActionSavedTemplates({ open: false }));
      dispatch(setSavedTempLoading({ status: false }));
      dispatch(setBackPageDet({ data: {} }));
    }
  }, [dispatch])

  useEffect(() => {
    if(!openTemplate){
      dispatch(resetJson());
      dispatch(resetSaa());
      dispatch(resetJsonApp());
      dispatch(resetJsonBody());
    }
  }, [dispatch, openTemplate])

  const onHandleOpenSavedTemplate = () => {
    setOpenTemplate(true);
  }

  const onHandleCloseSavedTemplate = () => {
    setOpenTemplate(false);
  }

  const columns = useMemo(() => [
      {
        field: 'templateName',
        minWidth: 320,
        flex: 1,
        headerName: 'Template Name',
        headerClassName: 'super-app-theme--header',
        renderCell: (params) => (
          <Button component={Link} sx={{textTransform: "none", justifyContent: 'flex-start'}} state={{ selTemplate: params.row }} 
          variant='text' onClick={() => onHandleOpenSavedTemplate()}>{params.value}</Button>
        )
      },
      {
        field: 'messageDefId',
        flex: 1,
        minWidth :180,
        headerName: 'Identifier',
        headerClassName: 'super-app-theme--header'
      },
      {
        field: 'createdBy',
        flex: 1,
        headerName: 'Created By',
        headerClassName: 'super-app-theme--header'
      },
      {
        field: 'updatedBy',
        flex: 1,
        headerName: 'Modified By',
        headerClassName: 'super-app-theme--header'
      },
      {
        field: 'updatedDt',
        flex: 1,
        minWidth: 170,
        headerName: 'Last Modified Date (UTC)',
        filterable: false
       // filterOperators: customDateOperators,
      },
      {
        field: 'action',
        flex: 1,
        headerName: 'Action',
        filterable: false,
        sortable: false,
        headerClassName: 'super-app-theme--noMenu',
        renderCell: (params) => (
          <Grid sx={{ display: 'inline-flex', flexDirection: 'row' }}>
            <Button onClick={() => onDeleteAction(params)} sx={{ padding: 0, justifyContent: 'flex-start', minWidth: '30px', marginLeft: '4px' }}
              variant='text'>
              {
                <FormattedMessage id="common.delete" defaultMessage={defaultLocales['common.delete']} />
              }
            </Button>
          </Grid>
        ),
        minWidth: 120,
        editable: false,
      }
    ], []) 

  const getReqBody = useMemo(() => {
    return {
      sortBy: "updatedDt",
      sortDir: "DESC",
      pageNo: `${pageNumber}`,
      maxResults: `${rowsPerPage}`
    }
  }, [pageNumber, rowsPerPage])

  const handlePaginationChange = (pagiParams) => {
    const { page, pageSize } = pagiParams;
    setRowsPerPage(pageSize);
    setPageNumber(page);
  };

  const onHandleSearch = (sCriteria) => {
    try {
      const reqBody = {
        ...getReqBody,
        searchCriteria: { ...sCriteria }
      }
      dispatch(setSavedTempLoading({ status: true }))
      dispatch(templatesList(reqBody));
    }
    catch (err) {
      dispatch(setSavedTempLoading({ status: false }))
      dispatch(snackBarActionSavedTemplates({ open: true, severity: 'error', snackBarMessage: err.message }))
    }
  }

  const snackBarClose = (event, reason) => {
    if (reason === 'clickaway') return;
    dispatch(snackBarActionSavedTemplates({ open: false, severity: '', snackBarMessage: '' }));
  }

  const onDeleteAction = (params) => {
    setTemplate({ ...params.row });
    setConfirmDialog(true);
  }

  const onConfirmDeleteOk = () => {
    try {
      setConfirmDialog(false);
      const findTemplate = TEMPLATE_SELECTION.find(t => t.value === selTemplate.messageDefId);
      if (findTemplate) {
        const { biz, enqType } = findTemplate;
        const { templateStoreId, templateName, templateVersion, template } = selTemplate;
        const requestBody = { reqAction: 'InActive', templateName, templateStoreId, templateVersion, template, bizType: biz };
        const statusMessage = "Template Deleted";
        dispatch(templateMaintainence(requestBody, 'O', enqType, statusMessage, setSavedTempLoading, snackBarActionSavedTemplates, undefined,
          ({ status = 'fail' }) => {
            if (status === 'success') setRefreshScreen(!refreshScreen);
          }));
      } else {
        dispatch(snackBarActionSavedTemplates({ open: true, severity: 'error', snackBarMessage: 'Template Deletion Failed' }))
      }
    }
    catch (err) {
      dispatch(snackBarActionSavedTemplates({ open: true, severity: 'error', snackBarMessage: `${err.message}` }))
    }
  }

  const onConfirmDeleteCancel = () => {
    setConfirmDialog(false);
    setTemplate({});
  }

  return (
    <Container maxWidth={false} disableGutters className="container-form">
      <MbBreadCrumbs crumbsList={[{ title: `templateList.title` }]} />
      <h6>This module serves as a repository for SWIFT Outgoing Payment Templates saved under 'Create Payment Template'.</h6>
      <Divider className="divider" sx={{ textTransform: 'uppercase' }}><h5><b><FormattedMessage id={`templateList.subTitle`} defaultMessage={defaultLocales[`createPaymentInfo.title`]} /></b></h5></Divider>
      <Box className="box">
        <Grid container spacing={1} columns={{ xs: 4, sm: 8, md: 12 }} direction={"row"}>
          <SearchPage onHandleSearchCriteria={onHandleSearch}/>
          <Grid item xs={8} md={12}>
            <Divider className="divider"><h5>{getSavedTempList.totalCount} PAYMENT TEMPLATE(S) FOUND</h5></Divider>
          </Grid>
          <Grid item xs={8} md={12}>
            <StripedDataGrid
              rowHeight={33}
              loading={getSavedTempLoading}
              rows={getSavedTempList.enqTxn || []}
              columns={columns}
              paginationMode='server'
              rowCount={getSavedTempList.totalCount || 0}
              initialState={{
                pagination: { paginationModel: { pageSize: rowsPerPage, page: pageNumber } },
              }}
              slotProps={{
                pagination: {
                  showFirstButton: true,
                  showLastButton: true
                },
                toolbar: {
                  showQuickFilter: true,
                  csvOptions: { disableToolbarButton: true },
                  printOptions: { disableToolbarButton: true }
                }
              }}
              slots={{ toolbar: GridToolbar }}
              pageSizeOptions={RowsPerPageOptionsSavedTemplate}
              disableRowSelectionOnClick
              disableColumnResize={true}
              disableColumnSelector
              disableDensitySelector
              onPaginationModelChange={handlePaginationChange}
              getRowClassName={(params) => params.indexRelativeToCurrentPage % 2 === 0 ? 'MuiDataGrid-row--even' : 'MuiDataGrid-row--odd'}
            />
          </Grid>
        </Grid>
      </Box>
      <MbSnackbar onClose={snackBarClose} open={getSnackBarSavedTemp.open}
        severity={getSnackBarSavedTemp.severity} message={getSnackBarSavedTemp.snackBarMessage} />
      {
        deleteConfirmDialog &&
        <ConfirmationDialog onHandleOk={onConfirmDeleteOk} openDialog={deleteConfirmDialog}
          onHandleCancel={onConfirmDeleteCancel}
          dialogContent="Are you sure you want to delete the template?" />
      }
      {
        openTemplate && <AccessSavedPage openTemplate = {openTemplate} onHandleClose = {onHandleCloseSavedTemplate} />
      }
    </Container>
  );
}

export default memo(SavedTemplates)