import { createSelector, createSlice } from "@reduxjs/toolkit";
import { CREATE_PAYMENT_SLICE } from "../../constants/sliceConstants";

export const paymentInitialState = {
    snackBarPayment: {},
    attributesByBody: {},
    paymentLoading : false,
    loadingMessage : 'Loading...'
}

const paymentSlice = createSlice(({
    name: CREATE_PAYMENT_SLICE,
    initialState : paymentInitialState,
    reducers: {
        snackBarPaymentAction(state, action) {
            state.snackBarPayment = {...action.payload};
        },
        setPaymentLoading(state, action) {
            const {status, message} = action.payload;
            state.paymentLoading = status;
            state.loadingMessage = message;
        },
        setLoadingMessage(state, action) {
            state.loadingMessage = action.payload.message;
        },
        loadAttributesByBody(state, action) {
            state.attributesByBody = action.payload;
        }
    }
}))

const snackBarPay = state => state[CREATE_PAYMENT_SLICE].snackBarPayment;
const payload = state => state[CREATE_PAYMENT_SLICE].paymentLoading;
// const attributes = state => state[CREATE_PAYMENT_SLICE].attributesByBody;
const loadMsg = state => state[CREATE_PAYMENT_SLICE].loadingMessage;

export const getSnackBarPayment = createSelector(snackBarPay, tran => tran);
export const getPaymentLoading = createSelector(payload, pay => pay);
// export const getElementAttributes = createSelector(attributes, attri => attri);
export const getLoadingMessage = createSelector(loadMsg, load => load);

export const {
    snackBarPaymentAction,
    setPaymentLoading,
    loadAttributesByBody,
    setLoadingMessage
} = paymentSlice.actions

export default paymentSlice.reducer;