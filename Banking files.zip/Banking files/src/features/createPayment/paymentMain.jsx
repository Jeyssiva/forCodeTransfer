
import { makeStyles } from '@mui/styles';
import { Search } from "@mui/icons-material";
import { FormattedMessage } from 'react-intl';
import { useDispatch, useSelector } from 'react-redux';
import { memo, useEffect, useState } from 'react';
import { Container, Grid, Box, Divider, Stack } from '@mui/material';

import { defaultLocales } from '../i18n';
import MbButton from '../common/mbButton';
import LoadingViewer from '../loadingViewer';
import MbSnackbar from '../common/mbSnackbar';
import MbDropdown from '../common/mbDropdown';
import MbBreadCrumbs from '../common/mbBreadcrumbs';
import { FONT_SIZE, TRANS_TYPE } from '../../constants/constants';
import ChildErrorPage from '../errorPage/childErrorPage';
import { getAllStaticDataFromCreatePayment } from './paymentAction';
import ProcessTemplateAction from './processTemplateAction';
import SubmitPaymentActivity from './submitPaymentActivities';
import { resetJsonBody } from '../showMxTemplateAsTreeView/bodySlice';
import { resetJson } from '../showMxTemplateAsTreeView/showMxTempSlice';
import { resetJsonApp } from '../showMxTemplateAsTreeView/appHeaderSlice';
import ShowMxTemplateMain from '../showMxTemplateAsTreeView/showTemplateMain';
import { resetSaa, setSaaTreeMountedStatus } from '../showMxTemplateAsTreeView/saaHeaderSlice';
import {
    getLoadingMessage, getPaymentLoading, getSnackBarPayment, setPaymentLoading, snackBarPaymentAction
} from './paymentSlice';
import { GET_MESSAGE_TYPE, GET_SECTION_DETAIL_SCHEMA_NAMES, TEMPLATE_REQACTION_SAVE, TEMPLATE_SELECTION } from '../../constants/createPaymentConstants';
import { getRequiredApiRequest } from '../showMxTemplateAsTreeView/persistedSlice';
import { findBodySchemaLoaded, findMsgConfigLoaded, getSectionDetailRequests } from '../showMxTemplateAsTreeView/validationHelpers';
import { MSG_STATUS_DRAFT, SRCOFTXN_CREATEPAYMENT } from '../../constants/mxTempConstants';
import { OUT } from '../../constants/transactionConstants';
import { getScreenAccess } from '../dashboard/dashboardSlice';

const useStyles = makeStyles(() => ({
    inputLabelInfo: {
        alignItems: 'center',
        display: 'flex',
        justifyContent: 'flex-start',
        fontWeight: 'bold',
        marginRight: '13px',
        fontSize: '12px'
    },
    selectForm: {
        width: '65%',
        justifyContent: 'center'
    },
    radioGrp: {
        fontSize: '12px'
    },
    dropdownRoot: {
        height: '25px', // Adjust the max height as needed,
        textAlign: 'left'
    },
    inputStyle: {
        fontSize: FONT_SIZE
    },
    spinnerDialogPay : {
        position: 'absolute',
        top: '3%',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 9999
    }
}))

function PaymentMain() {
    // const [templateChange, setChange] = useState(null);
    const [selTemplate, setTemplate] = useState(null);
    const [reMounted, setRemounted] = useState(false);
    const [msgType, setMsgType] = useState('');
    const [bizType, setBizType] = useState('');
    const [bizList, setBizList] = useState([]);
    const [error, setError] = useState({});
    const dispatch = useDispatch();
    const classes = useStyles();
    const snackBarPayment = useSelector(getSnackBarPayment);
    const loadingStatus = useSelector(getPaymentLoading);
    const loadingMessage = useSelector(getLoadingMessage);
    const getRequiredApiReqData = useSelector(getRequiredApiRequest);
    const screenAccessDet = useSelector(getScreenAccess);

    useEffect(() => {
        dispatch(resetJson());
        dispatch(resetSaa());
        dispatch(resetJsonApp());
        dispatch(resetJsonBody());

        return () => {
            dispatch(setPaymentLoading({ status: false }));
            dispatch(snackBarPaymentAction({ open: false }));
        }
    }, [dispatch]);

    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        dispatch(snackBarPaymentAction({ open: false }));
    }

    const onMsgChange = (e) => {
        const findBiz = TEMPLATE_SELECTION.filter(t => t.enqType === e.target.value).map(m => {
            return {
                value: m.biz,
                label: m.biz
            }
        })
        setMsgType(e.target.value);
        setBizType('STD');
        setBizList(findBiz);
    }

    const onBizChange = (e) => {
        setBizType(e.target.value);
    }

    const onHandleSearch = () => {
        try {
            if (!msgType) {
                setError({ msgType: true })
                dispatch(snackBarPaymentAction({ open: true, severity: 'info', snackBarMessage: 'Please fill Required fields' }));
                return;
            }
            if (selTemplate && msgType === selTemplate.enqType && bizType === selTemplate.biz) {
                dispatch(snackBarPaymentAction({ open: true, severity: 'info', snackBarMessage: 'Selected Template already exists, Please choose another one' }));
                return;
            }
            const selectedTemplateDetail = TEMPLATE_SELECTION.find(t => t.enqType === msgType && t.biz === bizType);
            const {value: messageDefID} = selectedTemplateDetail;
            setRemounted(messageDefID);
            setTemplate(selectedTemplateDetail);
            setError({});
            dispatch(setSaaTreeMountedStatus({ status: true }));
            dispatch(resetJson());
            dispatch(resetSaa());
            dispatch(resetJsonApp());
            dispatch(resetJsonBody({ resetOriginalBody: true }));

            const inqReqBody = {
                ddListType:  !getRequiredApiReqData.countryList 
                          ? "GBR_COUNTRY_LIST, GBR_CURRENCY_LIST, GBR_PURPOSE_ALL"
                          : 'GBR_CURRENCY_LIST, GBR_PURPOSE_ALL' ,
                dropDownListKey1: "",
                dropDownListKey2: ""
            }
            let msgConfigBody = getSectionDetailRequests(TRANS_TYPE[OUT], screenAccessDet, MSG_STATUS_DRAFT, SRCOFTXN_CREATEPAYMENT, messageDefID);
            const applicableFalseReq = {
                messageDefId: ['SAA_HEADER'],
                sourceOfTxn: SRCOFTXN_CREATEPAYMENT,
                isApplicable: 0
            }
            const bodySchema = findBodySchemaLoaded(messageDefID, getRequiredApiReqData);
            const msgConfigBySchema = findMsgConfigLoaded(TRANS_TYPE[OUT], SRCOFTXN_CREATEPAYMENT, MSG_STATUS_DRAFT, 
                screenAccessDet,
                messageDefID, getRequiredApiReqData, msgConfigBody);
            const msgConfigTransName = GET_SECTION_DETAIL_SCHEMA_NAMES[messageDefID];
            const requiredApis = {...getRequiredApiReqData, msgConfigBySchema, bodySchema};
            dispatch(getAllStaticDataFromCreatePayment(messageDefID, requiredApis, 
                {msgConfigBody, msgConfigTransName }, inqReqBody, applicableFalseReq));
        }
        catch (err) {
            dispatch(snackBarPaymentAction({ open: true, severity: 'error', snackBarMessage: `${err.message}` }));
        }
    }

    try {
        return (
            <>
                <LoadingViewer loading={loadingStatus} message={loadingMessage} spinnerDialog = {classes.spinnerDialogPay}>
                    <Container maxWidth={false} disableGutters className="container-form">
                        <MbBreadCrumbs crumbsList={[{ title: `createPaymentInfo.title` }]} />
                        <h6>This module provides a payment template to facilitate the creation of SWIFT outgoing payments transactions.</h6>
                        <Divider className="divider" sx={{ textTransform: 'uppercase' }}><h5><b><FormattedMessage id={`createPaymentInfo.subTitle`} defaultMessage={defaultLocales[`createPaymentInfo.title`]} /></b></h5></Divider>
                        <Box className="box">
                            <Grid container spacing={1} columns={{ xs: 4, sm: 8, md: 12 }} direction={"row"}>
                                <Grid item xs={8} md={4}>
                                    <MbDropdown size='small'
                                        fullWidth={true}
                                        variant={"outlined"}
                                        inputStyle={'dropdown'}
                                        labelValue={msgType}
                                        dropdownList={GET_MESSAGE_TYPE}
                                        onDropdownChange={onMsgChange}
                                        error={error.msgType}
                                        labelName={<FormattedMessage id='createPaymentInfo.selectTemplate'
                                            defaultMessage={defaultLocales["createPaymentInfo.selectTemplate"]}>
                                            {msg => (
                                                <span>
                                                    {msg} <span style={{ color: 'red' }}>*</span>
                                                </span>
                                            )}
                                        </FormattedMessage>}
                                    />
                                </Grid>
                                <Grid item xs={8} md={4}>
                                    <MbDropdown size='small'
                                        fullWidth={true}
                                        variant={"outlined"}
                                        inputStyle={'dropdown'}
                                        labelValue={bizType}
                                        dropdownList={bizList}
                                        onDropdownChange={onBizChange}
                                        labelName={<FormattedMessage id='createPaymentInfo.selectBizType'
                                            defaultMessage={defaultLocales["createPaymentInfo.selectBizType"]} />}
                                    />
                                </Grid>
                                <Grid item xs={8} md={4}>
                                    <MbButton buttonName={<h5><FormattedMessage id='common.search' defaultMessage={defaultLocales["common.search"]} /></h5>}
                                        className={'button-action'} size={'small'} fullWidth startIcon={<Search />}
                                        onHandleAction={onHandleSearch} />
                                </Grid>
                                <Grid item xs={8} md={12} >
                                    <Divider className="divider" ><h5><b> {reMounted ? `(${msgType}) ${bizType}` : 'NO'}  PAYMENT TEMPLATE SELECTED</b></h5></Divider>
                                </Grid>
                                <Grid item xs={8} md={12} >
                                    {
                                        selTemplate && (
                                            <>
                                                <Stack direction="row" gap={1} justifyContent={"flex-end"} sx={{ width: '100%', marginTop: 1 }}>
                                                    <ProcessTemplateAction transType={'O'} enqType={selTemplate.enqType}
                                                        bizType={selTemplate.biz} buttonName={"Save As Template"} reqAction={TEMPLATE_REQACTION_SAVE}
                                                        loadingFunction={setPaymentLoading} snackBarFunction={snackBarPaymentAction} />
                                                    <SubmitPaymentActivity transType={'O'} selectedTemplate={selTemplate.value} loadingAction={setPaymentLoading}
                                                        submissionType={'Create'} buttonName={"Submit Payment"} snackBarFunction={snackBarPaymentAction}/>
                                                </Stack>
                                            </>
                                        )
                                    }
                                </Grid>
                                {
                                    selTemplate &&
                                    <Grid item xs={8} md={12} >
                                        <ShowMxTemplateMain staticHeight={265} reMounted={reMounted} />
                                    </Grid>
                                }
                            </Grid>
                        </Box>
                        <MbSnackbar onClose={onSnackBarClose} open={snackBarPayment.open}
                            severity={snackBarPayment.severity}
                            message={snackBarPayment.snackBarMessage} />
                    </Container>
                </LoadingViewer >
            </>
        )
    }
    catch (err) {
        console.error(err);
        return <ChildErrorPage subTitle={"common.wentWrong"} />
    }
}

export default memo(PaymentMain)
