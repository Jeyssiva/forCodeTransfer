import moment from 'moment';
import { cloneDeep, isEmpty } from "lodash";
import React, { memo, useCallback, useMemo } from 'react';
import { useDispatch, useSelector } from "react-redux";

import MbButton from '../common/mbButton';
import { createPaymentAction } from './paymentAction';
import { DATE_TIME_FORMAT } from '../../constants/constants';
import { hierIndexAddition, updateAdditionalSections } from './paymentHelpers';
import { convertDataJsontoXML } from "../showMxTemplateAsTreeView/conversionHelpers";
import { saveTransactionDetailAction } from '../viewTransactions/viewTransactionsAction';
import { crossSectionorFieldsValidation } from '../showMxTemplateAsTreeView/crossValidationBody';
import { GET_SUB_TYPE, PACS009COV, TEMPLATE_SELECTION } from '../../constants/createPaymentConstants';
import { APPHEADER_TAB, BODY_TAB, SAAHEADER_TAB, XML_NAMESPACE } from '../../constants/mxTempConstants';
import { getHierSchemaSaaHeader, getResultBodyDataSaaHeader } from '../showMxTemplateAsTreeView/saaHeaderSlice';
import { getHierSchemaAppHeader, getResultBodyDataAppHeader } from '../showMxTemplateAsTreeView/appHeaderSlice';
import { deepSearchByKey, rearrangeObjectByHierIndex, removeUnnecessaryProperty } from "../viewTransactions/helpers";
import { updateCrossValidationData, getResultBodyDataBody, getHierSchemaBody } from '../showMxTemplateAsTreeView/bodySlice';
import { setErrorsInTabMaintainance, snackBarActionsShowTemp } from "../showMxTemplateAsTreeView/showMxTempSlice";
import { getElementAttributes } from '../showMxTemplateAsTreeView/persistedSlice';

 function SubmitPaymentActivity({transType, selectedTemplate, buttonName = 'Submit', 
    loadingAction, txnDet = {}, submissionType, handlePopupClose = undefined, snackBarFunction }) {
    const resultBodyJsonSaa = useSelector(getResultBodyDataSaaHeader);
    const resultBodyJsonApp = useSelector(getResultBodyDataAppHeader);
    const resultBodyJsonBody = useSelector(getResultBodyDataBody);
    const hierBody = useSelector(getHierSchemaBody);
    const hierSaa = useSelector(getHierSchemaSaaHeader);
    const hierApp = useSelector(getHierSchemaAppHeader);
    const getElementAttributeList = useSelector(getElementAttributes);
    const actDispatch = useDispatch();

    const findTemplateDetail = useMemo(() => {
        return TEMPLATE_SELECTION.find(f => f.value === selectedTemplate);
    }, [selectedTemplate])

    const crossValidation = useCallback(
        async (bodyResult) => {
            try {
                actDispatch(loadingAction({ status: true, message: 'Validating Payment...' })); // Enable loading indicator
                await new Promise(resolve => setTimeout(resolve, 0)); // Allow UI to update
                const { updatedData = bodyResult, updatedHier = hierBody, treeList = [], expectRebind = false, err } =
                    crossSectionorFieldsValidation(hierBody, bodyResult, findTemplateDetail);
                if (err) {
                    actDispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: err.message }));
                    actDispatch(loadingAction({ status: false }));
                    return { crossStatus: false };
                }
                if (expectRebind) {
                    actDispatch(updateCrossValidationData({ resultData: updatedData, resultHier: updatedHier, treeList }));
                }
                return { updatedData, crossStatus: true };
            }
            catch (err) {
                throw err;
            }
        }, [selectedTemplate, submissionType, hierBody, resultBodyJsonBody])

    const checkingErrors = useCallback(
        async (updatedData, saaResult, appResult) => {
            try {
                actDispatch(loadingAction({ status: true, message: 'Checking Errors...' }));
                await new Promise(resolve => setTimeout(resolve, 0)); // Allow UI to update
                const errorMessages = {
                    body: deepSearchByKey(updatedData, 'error', [], [], { '_text': 1 }),
                    saa: deepSearchByKey(saaResult, 'error', [], [], { '_text': 1 }),
                    app: deepSearchByKey(appResult, 'error', [], [], { '_text': 1 }),
                };

                const errorCounts = {
                    body: errorMessages.body.length,
                    saa: errorMessages.saa.length,
                    app: errorMessages.app.length,
                };

                actDispatch(setErrorsInTabMaintainance({
                    tabMaintainance: {
                        [SAAHEADER_TAB]: { errors: errorMessages.saa, invisible: errorCounts.saa === 0, loaded: true },
                        [APPHEADER_TAB]: { errors: errorMessages.app, invisible: errorCounts.app === 0, loaded: true },
                        [BODY_TAB]: { errors: errorMessages.body, invisible: errorCounts.body === 0, loaded: true },
                    },
                }));

                const validationMessages = [];
                if (errorCounts.saa > 0) validationMessages.push('SAAHeader');
                if (errorCounts.app > 0) validationMessages.push('AppHeader');
                if (errorCounts.body > 0) validationMessages.push('Body');

                if (validationMessages.length > 0) {
                    actDispatch(snackBarActionsShowTemp({
                        open: true,
                        severity: 'error',
                        snackBarMessage: `Please fill mandatory fields - ${validationMessages.join(', ')}`,
                    }));
                    actDispatch(loadingAction({ status: false }));
                    return { errStatus: false }
                }
                return { errStatus: true }
            } catch (err) {
                throw err;
            }
        }, [selectedTemplate, submissionType, resultBodyJsonSaa, resultBodyJsonApp, resultBodyJsonBody])

    const sequenceData = useCallback(
        async (saaResult, appResult, updatedBodyData) => {
            try {
                actDispatch(loadingAction({ status: true, message: 'Sequencing Data...' }));
                await new Promise(resolve => setTimeout(resolve, 0)); // Allow UI to update
                const hierBodyData = cloneDeep(hierBody);
                const hierSaaData = cloneDeep(hierSaa['saaHeader'].children);
                const hierAppData = cloneDeep(hierApp);
                if (selectedTemplate === PACS009COV) updateAdditionalSections(saaResult);
                const reorderAndClean = (hierSchema, resultData) => {
                    hierIndexAddition(hierSchema, resultData)
                    const reordered = rearrangeObjectByHierIndex(resultData);
                    removeUnnecessaryProperty(reordered);
                    return reordered;
                };
                const reOrderSaa = reorderAndClean(hierSaaData, saaResult);
                const reOrderApp = reorderAndClean(hierAppData, appResult);
                const reOrderBody = reorderAndClean(hierBodyData, updatedBodyData);
                if (isEmpty(reOrderSaa) && isEmpty(reOrderBody) && isEmpty(reOrderApp)) {
                    actDispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: 'No Data Found' }));
                    actDispatch(loadingAction({ status: false }));
                    return { seqStatus: false };
                }
                return { seqStatus: true, reOrderSaa, reOrderApp, reOrderBody };
            } catch (err) {
                throw err;
            }
        }, [selectedTemplate, submissionType, hierSaa, hierApp, hierBody, resultBodyJsonSaa, resultBodyJsonApp, resultBodyJsonBody]);

    const submittingPayment = useCallback(
        async (reOrderSaa, reOrderApp, reOrderBody) => {
            try {
                actDispatch(loadingAction({ status: true, message: 'Submitting...' }));
                await new Promise(resolve => setTimeout(resolve, 0)); // Allow UI to update
                const elementAttributes  = getElementAttributeList[findTemplateDetail.value] || [];
                const findAttribute = (code) => elementAttributes.find(attr => attr.messagePath === code) || {};
                const dataPDUAttribute = findAttribute('DataPDU');
                const appHdrAttribute = findAttribute('AppHdr');
                const documentAttribute = findAttribute('Document');

                const bodyPart = {
                    ...(reOrderApp && { AppHdr: { ...reOrderApp.AppHdr, _attributes: { xmlns: appHdrAttribute.defaultValue || '' } } }),
                    ...(reOrderBody && { Document: { ...reOrderBody, _attributes: { xmlns: documentAttribute.defaultValue || '' } } })
                };
                const finalBodyPart = Object.keys(bodyPart).length > 0 ? { Body: bodyPart } : {};
                const finalResult = {
                    DataPDU: {
                        ...reOrderSaa,
                        ...finalBodyPart,
                        _attributes: { xmlns: dataPDUAttribute.defaultValue || '' }
                    }
                };
                return finalResult;
            } catch (err) {
                throw err;
            }
        }, [selectedTemplate, submissionType, getElementAttributeList, resultBodyJsonSaa, resultBodyJsonApp, resultBodyJsonBody]);

    const generateFinializedXML = useCallback(
        async () => {
            try {
                const bodyResult = cloneDeep(resultBodyJsonBody);
                const saaResult = cloneDeep(resultBodyJsonSaa['saaHeader']);
                const appResult = cloneDeep(resultBodyJsonApp);
                const { updatedData, crossStatus } = await crossValidation(bodyResult);
                if (!crossStatus) return null;
                const { errStatus } = await checkingErrors(updatedData, saaResult, appResult);
                if (!errStatus) return null;
                const finalBodyData = cloneDeep(updatedData);
                const { seqStatus, reOrderSaa, reOrderApp, reOrderBody } = await sequenceData(saaResult, appResult, finalBodyData);
                if (!seqStatus) return null;
                const finalResult = await submittingPayment(reOrderSaa, reOrderApp, reOrderBody);
                const convertJsonXML = convertDataJsontoXML({ _declaration: XML_NAMESPACE, ...finalResult });
                // console.log('convertJsonXML', convertJsonXML);
                return convertJsonXML;
            }
            catch (err) {
                throw err;
            }
        }, [selectedTemplate, submissionType, resultBodyJsonSaa, resultBodyJsonApp, resultBodyJsonBody]);

    const onHandleSaveCreatePayment = useCallback(
        async () => {
        try {
            const convertedXML = await generateFinializedXML();
            if(!convertedXML) return;
            const requestBody = {
                reqAction: 'Create',
                mxMessage: convertedXML,
                bizType: findTemplateDetail.biz,
                mtMessage: 'Payment created in Maybank Payment Operations Portal, MT message is not applicable'
            };
            const statusMessage = `Your Payment has been submitted for approval at ${moment().format(DATE_TIME_FORMAT)}`;
            actDispatch(createPaymentAction(requestBody, transType, findTemplateDetail.enqType, statusMessage, 
                loadingAction, snackBarFunction, handlePopupClose));
        }
        catch(err) {
            console.log(err);
            actDispatch(loadingAction({ status: false }));
            actDispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: 'Submitting Payment Failed' }));
        }
    },[selectedTemplate, submissionType, resultBodyJsonApp, resultBodyJsonSaa, resultBodyJsonBody]);

    const onHandleUpdateEditedTemplate = useCallback(
        async () => {
            try {
                const convertedXML = await generateFinializedXML();
                if (!convertedXML) return;
                const { verPkSeqNo, msgVerNo, msgId,
                    enqTxn: [{ msgStatus, messageDefId }] = [{}] } = txnDet || {};
                const requestBody = {
                    reqAction: 'Submit', mxMessage: convertedXML, verPkSeqNo, msgId,
                    msgVerNo, msgStatus, messageDefId
                };
                const statusMessage = `Your request has been submitted at ${moment().format(DATE_TIME_FORMAT)}`;
                actDispatch(saveTransactionDetailAction(requestBody, transType, GET_SUB_TYPE[messageDefId], statusMessage, false));
            }
            catch (err) {
                console.log(err);
                actDispatch(loadingAction({ status: false }));
                actDispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: 'Updating Payment Failed' }));
            }
        }, [selectedTemplate, submissionType, txnDet, resultBodyJsonApp, resultBodyJsonSaa, resultBodyJsonBody]);

    const onHandleButtonAction = useCallback(() => {
        if (submissionType === 'Create') {
            onHandleSaveCreatePayment();
        } else {
            onHandleUpdateEditedTemplate();
        }
    }, [selectedTemplate, submissionType, resultBodyJsonApp, resultBodyJsonSaa, resultBodyJsonBody])

    return (
        <MbButton className={'button-maybank'} buttonName={buttonName} onClick={onHandleButtonAction} />
    )
}

export default memo(SubmitPaymentActivity)