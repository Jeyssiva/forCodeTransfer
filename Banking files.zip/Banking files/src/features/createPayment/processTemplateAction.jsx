import React, { memo, useState } from 'react';
import SaveAsIcon from '@mui/icons-material/SaveAs';
import { getAllTabLoadedStatus } from "../showMxTemplateAsTreeView/showMxTempSlice";
import { cloneDeep, isEmpty } from "lodash";
import { useDispatch, useSelector } from "react-redux";
import { convertDataJsontoXML } from "../showMxTemplateAsTreeView/conversionHelpers";
import MbButton from '../common/mbButton';
import MbInputBoxPopup from '../common/mbInputBox';
import { templateMaintainence } from './paymentAction';
import { getResultBodyDataSaaHeader } from '../showMxTemplateAsTreeView/saaHeaderSlice';
import { getResultBodyDataAppHeader } from '../showMxTemplateAsTreeView/appHeaderSlice';
import { getResultBodyDataBody } from '../showMxTemplateAsTreeView/bodySlice';
import { removeUnnecessaryProperty } from '../viewTransactions/helpers';
import { TEMPLATE_REQACTION_UPDATE } from '../../constants/createPaymentConstants';

function SaveTemplateActivity({ transType, enqType, bizType, buttonName, reqAction,
    selectedTemplateDet = {}, loadingFunction, snackBarFunction, onCloseDtlPopup = undefined }) {
    const resultBodyJsonSaa = useSelector(getResultBodyDataSaaHeader);
    const resultBodyJsonApp = useSelector(getResultBodyDataAppHeader);
    const resultBodyJsonBody = useSelector(getResultBodyDataBody);
    // const resultOriginalJson = useSelector(getOriginalJson);
    const actDispatch = useDispatch();
    const findAlTabLoaded = useSelector(getAllTabLoadedStatus);
    const [openComment, setOpenComment] = useState(false);
    const [error, setError] = useState({});
    const onHandleOpenBox = () => {
        // Template Name Update is not required.
        if (reqAction === TEMPLATE_REQACTION_UPDATE) {
            const { templateName, templateVersion, templateStoreId } = selectedTemplateDet;
            onHandleSaveTemplate({ reqAction: TEMPLATE_REQACTION_UPDATE, bizType, templateName, templateVersion, templateStoreId });
        } else
            setOpenComment(true);
    }
    const onHandleClose = () => {
        setOpenComment(false);
        setError({})
    }
    const onHandleConfirmation = ({ comment }) => {
        // setOpenComment(false);
        const requestBody = { reqAction, templateName: comment.trim(), templateVersion: "1", bizType };
        onHandleSaveTemplate(requestBody);
    }
    const onHandleSaveTemplate = (reqBody) => {
        const bodyResult = cloneDeep(resultBodyJsonBody);
        const saaResult = cloneDeep(resultBodyJsonSaa['saaHeader']);
        const appResult = cloneDeep(resultBodyJsonApp);
        // const reOrderSaa = rearrangeObjectByHierIndex(saaResult);
        removeUnnecessaryProperty(bodyResult);
        // const reOrderBody = rearrangeObjectByHierIndex(bodyResult);
        removeUnnecessaryProperty(saaResult);
        // const reOrderApp = rearrangeObjectByHierIndex(appResult);
        removeUnnecessaryProperty(appResult);
        const finalResult = {}
        finalResult['DataPDU'] = {
            ...saaResult,
            ...(!isEmpty(appResult) || !isEmpty(bodyResult))
            && {
                Body: {
                    ...appResult,
                    ...(!isEmpty(bodyResult))
                    && { Document: bodyResult }
                }
            }
        };
        const convertJsonXML = convertDataJsontoXML(finalResult);
        // console.log('convertJsonXML', convertJsonXML);
        const requestBody = { ...reqBody, template: convertJsonXML };
        const statusMessage = 'Template Saved Successfully';
        actDispatch(loadingFunction({ status: true, message: 'Saving Template...' }));
        actDispatch(templateMaintainence(requestBody, transType, enqType, statusMessage, loadingFunction, 
            snackBarFunction, onCloseDtlPopup,
            ({ dialogClose }) => {
                if (dialogClose) {
                    setOpenComment(false);
                    setError({});
                } else {
                    setError({ status: true, message: 'Template name Already exists, Please try another name.' });
                }
            }));
    }
    if (!findAlTabLoaded) return null;

    try {
        return (
            <>
                <MbButton className={'button-maybank'}
                    startIcon={<SaveAsIcon />}  buttonName={<h5>{buttonName}</h5>} onClick={onHandleOpenBox} />
                {
                    openComment && <MbInputBoxPopup openDialog={openComment} title={<h5>{buttonName}</h5>}
                        multiline={false} maxLength={140} fieldName="Template Name" error={error && error.status}
                        errorText={error && error.message} inputValue={selectedTemplateDet.templateName || ''}
                        onHandleClose={onHandleClose} onHandleConfirm={onHandleConfirmation} size='small'
                        specialRegPattern={/^[^/]+$/} dialogWidth='500px' />
                }
            </>
        )
    }
    catch (err) {
        throw err;
    }
}
export default memo(SaveTemplateActivity)