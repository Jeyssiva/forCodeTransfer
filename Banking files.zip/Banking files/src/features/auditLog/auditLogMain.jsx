import {
    Divider, Container, FormGroup, Grid, IconButton, Table, TableBody, TableContainer,
    TableHead, TablePagination, TableRow, Tooltip, Typography, Stack, Box
} from "@mui/material";
import dayjs from "dayjs";
import moment from "moment";
import { isEmpty } from "lodash";
import { Search } from "@mui/icons-material";
import { FormattedMessage } from "react-intl";
import { useState, useEffect, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

import { defaultLocales } from "../i18n"
import MbButton from "../common/mbButton"
import { viewAuditDtl } from "./auditAction"
import LoadingViewer from "../loadingViewer"
import MbSnackbar from "../common/mbSnackbar"
import MbDropdown from "../common/mbDropdown"
import MbTextField from "../common/mbTextField"
import { TABLE_HEADERS } from "./auditConstants"
import { getUserInfo } from "../login/loginSlice";
import MbBreadCrumbs from '../common/mbBreadcrumbs';
import { CASE_TYPES } from "../../constants/mxTempConstants";
import MbDateTimeMuiField from "../common/mbDateTimeMuiPicker"
import { StyledTableCell, StyledTableRow } from "../viewTransactions/helpers"
import {
    DATE_FORMAT_BACKEND, DATE_TIME_FORMAT, DATE_TIME_FORMAT_BACKEND, DATE_TIME_FORMAT_LOG, RowsPerPageOptions
} from "../../constants/constants"

export default function AuditLogMain() {
    const getUserDetail = useSelector(getUserInfo);
    // const crumbs = [{ name: 'auditlog.title', lastItem: true }];
    const [isLoadingAudit, setLoadingAudit] = useState(false);
    const { userUserGroups: [{ roleId = '' } = {}] = [] } = getUserDetail || {};

    const initialSearchRequest = {
        searchType: '',
        searchText: '',
        dateFrom: `${moment().subtract(1, "days").format(DATE_FORMAT_BACKEND)}T00:00:00`,
        dateTo: `${moment().format(DATE_FORMAT_BACKEND)}T23:59:59`,
        roleName: roleId // Kindly pass the roleid instead of userGroupId because cmn_authority follows rolename only.
    }
    const [searchCriteria, setSearch] = useState({ ...initialSearchRequest });
    const actDispatch = useDispatch();
    const [auditList, setAuditList] = useState([]);
    const [pageNumber, setPageNumber] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [errorMsg, setErrorMessage] = useState(null);
    const [columnFilter, setColumnFilters] = useState({});
    const [auditSearch, setAuditSearch] = useState(false)

    const [snackBarPropertiesAudit, setSnackBarPropertiesAudit] =
        useState({ open: false, severity: '', snackBarMessage: '' });
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'ascending' });

    useEffect(() => {
        const requestBody = {
            ...getRequestBody
        };
        setLoadingAudit(true);
        actDispatch(viewAuditDtl(requestBody, setAuditList, setSnackBarPropertiesAudit, setLoadingAudit));
    }, [rowsPerPage, pageNumber, auditSearch])

    const getRequestBody = useMemo(() => {
        const searCriteria = { ...searchCriteria };
        return {
            maxResults: rowsPerPage,
            pageNo: pageNumber,
            sortDirection: "DESC",
            ...searCriteria,
            dateFrom: `${moment(searchCriteria.dateFrom).format(DATE_TIME_FORMAT_BACKEND)}`,
            dateTo: `${moment(searchCriteria.dateTo).format(DATE_TIME_FORMAT_BACKEND)}`
        }
    }, [rowsPerPage, pageNumber, searchCriteria])

    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackBarPropertiesAudit({ open: false, severity: '', snackBarMessage: '' });
    }

    const onHandleSearchInputChange = (eValue, fieldName, isUpper) => {
        setErrorMessage(null);
        let sCriteria = { ...searchCriteria };
        if (fieldName === 'searchType') {
            sCriteria = { ...searchCriteria, 'searchText': "" }
        }
        setSearch({ ...sCriteria, [fieldName]: isUpper ? eValue.toUpperCase() : eValue });
    }

    const onHandlePageChange = (e, newPage) => {
        setPageNumber(newPage)
    }

    const onHandleRowsChangePerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10))
        setPageNumber(0)
    }

    const onHandleSubmitSearch = (mode) => {
        const searCriteria = { ...searchCriteria };
        if (mode !== 'all' && searCriteria.searchType !== "" && searchCriteria.searchText === "") {
            setErrorMessage(defaultLocales['auditlog.invalidError']);
            return;
        }
        setPageNumber(0);
        setRowsPerPage(10);
        if (mode === 'all') {
            // Set 60 days if "Show All Logs"
            const sCritieria = {
                ...initialSearchRequest,
                dateFrom: `${moment().subtract(60, "days").format(DATE_FORMAT_BACKEND)}T00:00:00`,
                dateTo: `${moment().format(DATE_FORMAT_BACKEND)}T23:59:59`
            };
            setErrorMessage(null);
            setSearch(sCritieria);
        }

        setAuditSearch(!auditSearch);
    }

    // const onHandleSearchFilter = (inputValue, filterName) => {
    //     if (inputValue === '') {
    //         const cFilter = { ...columnFilter };
    //         delete cFilter[filterName]
    //         setColumnFilters(cFilter);
    //     } else setColumnFilters({ ...columnFilter, [filterName]: inputValue });
    // }

    const onHandleSortFilter = (key) => {
        let direction = 'ascending';
        if (sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    }

    const filteredAndSortAuditList = useMemo(() => {
        //filtering logic
        let filteredData = (auditList && auditList.auditLog) || [];

        if (!isEmpty(columnFilter)) {
            function filterArrayObjects(array, filter) {
                return array.filter(obj =>
                    Object.keys(filter).every(key => {

                        const filterValue = filter[key];
                        try {
                            const regex = new RegExp(filterValue, 'i'); // 'i' flag for case-insensitive matching
                            if (key === 'createdDt')
                                return regex.test(moment(obj[key]).format(DATE_TIME_FORMAT));
                            else
                                return regex.test(obj[key]);
                        } catch (error) {
                            snackBarPropertiesAudit({ open: true, severity: 'error', snackBarMessage: 'RegEx Issue' })
                            return;
                        }
                    })
                );
            }

            filteredData = filterArrayObjects(filteredData, columnFilter);
        }

        //sorting logic
        if (sortConfig.key) {
            filteredData.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? -1 : 1;
                }

                if (a[sortConfig.key] > b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? 1 : -1;
                }
                return 0;
            })
        }
        return filteredData || [];
    }, [auditList, columnFilter, sortConfig])

    return (
        <>
            <Container maxWidth={false} disableGutters className={'container-form'}>
                <MbBreadCrumbs crumbsList={[{ title: 'auditlog.title' }]} />
                <h6>This module logs detailed information about the inquiry and tracks the user's activity for up to 60 days.</h6>
                <Divider className="divider"><h5><b>SEARCH ACTIVITY LOG</b></h5></Divider>
                <Box className="box">
                    <FormGroup aria-label="position" row >
                        <Stack direction="row" alignItems={"flex-start"} justifyContent={"space-between"} gap={0.5} sx={{ width: '100%' }}>
                            <MbDateTimeMuiField onDateChange={dateValue => {
                                const dValue = moment(dayjs(dateValue).toDate()).format(DATE_TIME_FORMAT_LOG)
                                return onHandleSearchInputChange(dValue, "dateFrom")
                            }}
                                labelText={<FormattedMessage id="auditlog.startDate"
                                    defaultMessage={defaultLocales["auditlog.startDate"]}>
                                    {msg => (
                                        <span>
                                            <h5>{msg}</h5>
                                        </span>
                                    )}
                                </FormattedMessage>}
                                inputStyle={'font-small'}
                                labelInfo={searchCriteria.dateFrom} format={DATE_TIME_FORMAT}
                                size={'small'} />
                            <MbDateTimeMuiField onDateChange={dateValue => {
                                const dValue = moment(dayjs(dateValue).toDate()).format(DATE_TIME_FORMAT_LOG)
                                return onHandleSearchInputChange(dValue, "dateTo")
                            }}
                                labelText={<FormattedMessage id="auditlog.endDate"
                                    defaultMessage={defaultLocales["auditlog.endDate"]}>
                                    {msg => (
                                        <span>
                                            <h5>{msg}</h5>
                                        </span>
                                    )}
                                </FormattedMessage>}
                                inputStyle={'font-small'}
                                labelInfo={searchCriteria.dateTo}
                                format={DATE_TIME_FORMAT}
                                size={'small'} />
                            <MbDropdown
                                id="auditlog.searchType"
                                fullWidth={true}
                                variant={"outlined"}
                                labelName={<FormattedMessage id="auditlog.searchType"
                                    defaultMessage={defaultLocales["auditlog.searchType"]}>
                                    {msg => (
                                        <span>
                                            <h5>{msg}</h5>
                                        </span>
                                    )}
                                </FormattedMessage>}
                                labelValue={searchCriteria.searchType || ''}
                                inputStyle={'dropdown-audit'}
                                onDropdownChange={(e) => onHandleSearchInputChange(e.target.value, 'searchType')}
                                dropdownList={[{ value: '', label: 'Search All' }, { value: 'username', label: 'User Name' }, { value: 'activityname', label: 'Activity Name' }, { value: 'activitystatus', label: 'Activity Status' }]}
                                size="small" />
                            <MbTextField
                                id="searchText"
                                name="searchText"
                                label={
                                    <FormattedMessage id="auditlog.searchText" defaultMessage={defaultLocales['auditlog.searchText']} >
                                        {msg => (
                                            <span>
                                                <h5>{msg}</h5>
                                            </span>
                                        )}
                                    </FormattedMessage>}
                                size={"small"}
                                value={searchCriteria.searchText}
                                key="txtSearchText"
                                inputStyle={'font-small'}
                                error={errorMsg ? true : false}
                                helperText={errorMsg}
                                placeholder="case-insensitive"
                                caseType={CASE_TYPES.uppercase}
                                onChange={(e) => onHandleSearchInputChange(e.target.value, 'searchText', true)}
                            />
                            <MbButton className={'button-audit-action'} fullWidth={true} startIcon={<Search />}
                                buttonName={<h5>Search</h5>} onHandleAction={(e) => onHandleSubmitSearch(e)}>
                            </MbButton>
                            <MbButton className={'button-maybank'} fullWidth={true} onHandleAction={(e) => onHandleSubmitSearch('all')}
                                buttonName={<h5>Show all logs</h5>}>
                            </MbButton>
                        </Stack>
                    </FormGroup>
                    <LoadingViewer loading={isLoadingAudit} />
                    <Divider className="divider"><h5>{auditList.totalCount} ACTIVITY(IES) LOG DATA FOUND</h5></Divider>
                    <Grid>
                        <TableContainer>
                            <Table>
                                <TableHead>
                                    <TableRow sx={{ whiteSpace: 'nowrap' }}>
                                        {TABLE_HEADERS.map((headCell, index) => (
                                            <StyledTableCell
                                                key={index}
                                                align={headCell.numeric === true ? 'right' : 'left'}
                                                padding={'normal'}
                                            >
                                                {
                                                    headCell.label
                                                }&nbsp;
                                                <span>
                                                    <IconButton
                                                        onClick={e => onHandleSortFilter(headCell.id)}
                                                        edge="start">
                                                        {sortConfig.direction === 'ascending' ? <ArrowDropDownIcon /> : <ArrowDropUpIcon />}
                                                    </IconButton>
                                                </span>
                                            </StyledTableCell>)
                                        )}
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {/* {
                                    <TableRow key={0} sx={{ whiteSpace: 'nowrap' }}>
                                        {columnFilter && TABLE_HEADERS.map((headCell, index) =>
                                        (
                                            <StyledTableCell key={index + 1} >
                                                <MbTextField placeholder={headCell.label} size="small" enableAdornment={true} value={(columnFilter && columnFilter[headCell.id]) || ''}
                                                    onTextFieldChange={e => onHandleSearchFilter(e.target.value, headCell.id)} />
                                            </StyledTableCell>
                                        )
                                        )}
                                    </TableRow>
                                } */}
                                    {
                                        filteredAndSortAuditList && filteredAndSortAuditList.map((row, index) => {
                                            return (
                                                <StyledTableRow tabIndex={-1} key={index + 2}>
                                                    <StyledTableCell>{row.updatedDt}</StyledTableCell>
                                                    <StyledTableCell scope="row"> {row.updatedBy}</StyledTableCell>
                                                    <StyledTableCell>{row.direction}</StyledTableCell>
                                                    <StyledTableCell>{row.statusCode}</StyledTableCell>
                                                    <StyledTableCell>
                                                        <Tooltip title={<h5>{String(row.activityMessage).toUpperCase()}</h5>}>
                                                            <span className="table-long-text">{row.activityMessage}</span>
                                                        </Tooltip>
                                                    </StyledTableCell>
                                                    {/* <StyledTableCell>{row.serverIp}</StyledTableCell>
                                                <StyledTableCell>{row.clientIp}</StyledTableCell> */}
                                                </StyledTableRow>
                                            )
                                        })
                                    }
                                    {auditList && auditList.totalCount === 0 && (
                                        <TableRow
                                            sx={{
                                                height: 'auto',
                                            }}>
                                            <StyledTableCell colSpan={5}>
                                                <Typography sx={{ display: 'flex', justifyContent: 'center' }}>
                                                    <FormattedMessage id="viewTransactions.noRecords" defaultMessage={defaultLocales['viewTransactions.noRecords']} />
                                                </Typography>
                                            </StyledTableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <TablePagination component={"div"} count={auditList.totalCount ?? 0}
                            page={pageNumber}
                            rowsPerPageOptions={RowsPerPageOptions}
                            onPageChange={onHandlePageChange}
                            rowsPerPage={rowsPerPage} onRowsPerPageChange={onHandleRowsChangePerPage}
                            showFirstButton showLastButton />
                        <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesAudit.open}
                            severity={snackBarPropertiesAudit.severity}
                            message={snackBarPropertiesAudit.snackBarMessage} />
                    </Grid>
                    {
                        errorMsg && (
                            <MbSnackbar open={errorMsg ? true : false}
                                severity={'error'}
                                message={errorMsg} />
                        )
                    }
                </Box>
            </Container>
        </>
    )
}