export const TABLE_HEADERS = [
  {
    id: 'createdDt',
    label: 'Date Time',
    numeric: false
  },
  {
    id: 'createdBy',
    label: 'User Name',
    numeric: false
  },
  {
    id: 'direction',
    label: 'Activity Name',
    numeric: false
  },
  {
    id: 'statusCode',
    label: 'Activity Status',
    numeric: false
  },
  {
    id: 'activityMessage',
    label: 'Activity Information',
    numeric: false
  },
  // {
  //   id: 'serverIP',
  //   label: 'Server IP',
  //   numeric: false
  // },
  // {
  //   id: 'clientIP',
  //   label: 'Client IP',
  //   numeric: false
  // }
];
