import { FETCH_ISO_SERVICE } from "../../apacheEnvConfig";
import { networkISO } from "../../connections/networkISO";
import { AUDIT_DETAIL } from "../../constants/apiConstants";
import { BackToInvalidSessionPage, CatchErrorDisplay } from "../errorPage/errorHelpers";

export const viewAuditDtl = (requestBody, auditListDispatch, snackBarDispatch, loadingDispatch) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${AUDIT_DETAIL}`, requestBody, 'AUDIT', 'USER')
            .then(resData => {
                if(!resData) throw new Error('Failed to fetch');
                if(!resData.ok){
                    if(resData.status)
                        throw new Error(`${resData.status} - ${resData.statusText}`)
                    else throw new Error('Failed to fetch')                
                }
                return resData.json();
            })
            .then(responseData => {
                const {executionStatus, AdditionalStatusCodes, statuscode} = responseData.responseHeader;
                if(statuscode === '200') {
                    const { responseBody } = responseData;
                    auditListDispatch(responseBody)
                } else if(statuscode === '401' || statuscode === '502') {
                    BackToInvalidSessionPage(statuscode, dispatch);
                } else if(AdditionalStatusCodes) {
                    snackBarDispatch({open: true, severity: 'error', snackBarMessage: `${AdditionalStatusCodes[0].HostTxndesc}`})
                } else {
                    snackBarDispatch({open: true, severity: 'error', snackBarMessage: `${executionStatus}`})
                }
                loadingDispatch(false);
            })
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, AUDIT_DETAIL, dispatch);
                if(findDisplayMessage)
                    snackBarDispatch({open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}`})
                else 
                    snackBarDispatch({open: true, severity: 'error', snackBarMessage: `${error.message}`})
                loadingDispatch(false);
            })
        } catch(error) {
            loadingDispatch(false);
            snackBarDispatch({open: true, severity: 'error', snackBarMessage: `${error.message}`})
        }
    }
}
