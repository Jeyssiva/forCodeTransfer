import { Search } from "@mui/icons-material";
import { FormattedMessage } from "react-intl";
import { useLocation } from "react-router-dom";
import { useCallback, useContext, useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { Divider, Box, Stack, Grid } from "@mui/material";

import { defaultLocales } from "../i18n";
import MbButton from "../common/mbButton";
import LoadingViewer from "../loadingViewer";
import MbSnackbar from "../common/mbSnackbar";
import MbTextField from "../common/mbTextField";
import CustomerInfoList from "./customerInfoList";
import MbBreadCrumbs from '../common/mbBreadcrumbs';
import { viewCustomerInfoDtrl } from "./customerDataAction";
import { CASE_TYPES } from "../../constants/mxTempConstants";
import { getCountryListPersist } from "../showMxTemplateAsTreeView/persistedSlice";
import { getRefreshStateRequired, getSnackBarPaymentInfo, snackBarActionPaymentInfo, updateRefreshStateRequired } from "./customerDataSlice";
import { REFRESH_SCREEN, SET_BIND_PROPERTY, SET_SEARCH_CRITERIA, CustomerContext } from "./customerReducer";
import { TRANS_CUST_TRANSACTION, TRANS_VIEW_CUSTOMER_INFO, TRANS_VIEW_CUSTOMER_SUBTYPE } from "../../constants/constants";

export default function CustomerDataMain() {
    const location = useLocation();
    const actDispatch = useDispatch();

    const { state, dispatch } = useContext(CustomerContext);
    const countryListPersist = useSelector(getCountryListPersist);
    const snackBarPropertiesPayment = useSelector(getSnackBarPaymentInfo);
    const refreshStateRequired = useSelector(getRefreshStateRequired);
    const { searchCriteria: { accountNumber = "", customerName = "", customerNumber = "" }, loadingStatus, refreshCust } = state;

    // Triggers when navigate from transaction page for update the latest postal address into the Database.
    // Find the appropriate country information and store in redux.
    useEffect(() => {
        if (!location.state) return;
        let customerInfo = { ...location.state };
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'selectedCustomer', value: customerInfo })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'transactionSubtype', value: TRANS_CUST_TRANSACTION })
    }, [location, countryListPersist, dispatch])

    useEffect(() => {
        if (refreshCust) {
            actDispatch(viewCustomerInfoDtrl({ searchCustomer: { 'accountNumber': accountNumber, 'customerNumber': customerNumber, 'customerName': String(customerName).toUpperCase(), customerId: '' } }, TRANS_VIEW_CUSTOMER_INFO, TRANS_VIEW_CUSTOMER_SUBTYPE, dispatch));
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'refreshCust', value: false });
        }
    }, [refreshCust])

    useEffect(() => {
        
        return () => {
            actDispatch(snackBarActionPaymentInfo({ open : false}))
        }
    }, [])

    /**
     * While come to this component, chekc whether able to reset the customerReducer state values.
     * Avoid if currently beneficiary page.
     */
    useEffect(() => {
        if(refreshStateRequired) {
            dispatch({ type: REFRESH_SCREEN });
            actDispatch(updateRefreshStateRequired({status: false}));
        }
    }, [refreshStateRequired])

    const onInputSearchCriteria = (event, fieldName) => {
        dispatch({ type: SET_SEARCH_CRITERIA, fieldName, value: (fieldName === 'customerName') ? String(event.target.value).toUpperCase() : event.target.value })
    }

    const loadCustomerInfoDtl = useCallback((accountNumber, customerName, customerNumber) => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: true });
        actDispatch(viewCustomerInfoDtrl({ searchCustomer: { accountNumber: accountNumber, customerNumber: customerNumber, customerName: String(customerName).toUpperCase(), customerId: '' } },
            TRANS_VIEW_CUSTOMER_INFO, TRANS_VIEW_CUSTOMER_SUBTYPE, dispatch))
    }, [])

    const onHandleSearch = () => {
        const { accountNumber, customerName, customerNumber } = state.searchCriteria;
        if (accountNumber === '' && customerName === '' && customerNumber === '') {
            actDispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: 'Please fill in one of search criteria.' }))
        } else {
            loadCustomerInfoDtl(accountNumber, customerName, customerNumber);
        }
    }

    const onHandleRefresh = () => {
        const { accountNumber, customerName, customerNumber } = state.searchCriteria;
        if(accountNumber || customerName || customerNumber){
            loadCustomerInfoDtl(accountNumber, customerName, customerNumber);
        }
    }

    const onHandleReset = () => {
        dispatch({ type: REFRESH_SCREEN })
    }

    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        actDispatch(snackBarActionPaymentInfo({ open: false, severity: '', snackBarMessage: '' }));
    }

    return (
        <>
            <LoadingViewer loading={loadingStatus} />
            <MbBreadCrumbs crumbsList={[{ title: 'createCustomerInfo.title_cus' }]} />
            <h6>This module keeps mandatory customer's information required for SWIFT ISO20022 incoming or outgoing payments.</h6>
            <Divider className="divider"><h5><b>SEARCH CUSTOMER INFORMATION</b></h5></Divider>
            <Box className="box">
                <Grid container spacing={1} columns={{ xs: 4, sm: 8, md: 12 }} direction="row">
                    {/* <Grid item xs={8} md={12} >
                        <h3 className="margin">Customer Information</h3>
                        <h6 className="margin">Enter either Maybank Account Number, Customer Number or Customer Name to search :</h6>
                    </Grid> */}
                    <Grid item xs={8} md={3} >
                        {/* Account Number */}
                        <MbTextField
                            id="accNum"
                            name="accNum"
                            maxLength={34}
                            label={
                                <FormattedMessage id="createCustomerInfo.accNum"
                                    defaultMessage={defaultLocales["createCustomerInfo.accNum"]}>
                                    {msg => (
                                        <span>
                                            <h5>{msg}</h5>
                                        </span>
                                    )}
                                </FormattedMessage>
                            }
                            size={"small"}
                            value={accountNumber}
                            onChange={(e) => onInputSearchCriteria(e, 'accountNumber')} />
                    </Grid>
                    <Grid item xs={8} md={3} >
                        {/* Customer Number */}
                        <MbTextField
                            id="custNum"
                            name="custNum"
                            label={
                                <FormattedMessage id="createCustomerInfo.custNum"
                                    defaultMessage={defaultLocales["createCustomerInfo.custNum"]}>
                                    {msg => (
                                        <span>
                                            <h5>{msg}</h5>
                                        </span>
                                    )}
                                </FormattedMessage>
                            }
                            size={"small"}
                            value={customerNumber}
                            maxLength={6}
                            onChange={(e) => onInputSearchCriteria(e, 'customerNumber')} />
                    </Grid>
                    <Grid item xs={8} md={3} >
                        {/* CustomerName */}
                        <MbTextField
                            id="custName"
                            name="custName"
                            label={
                                <FormattedMessage id="createCustomerInfo.custName"
                                    defaultMessage={defaultLocales["createCustomerInfo.custName"]}>
                                    {msg => (
                                        <span>
                                            <h5>{msg}</h5>
                                        </span>
                                    )}
                                </FormattedMessage>
                            }
                            size={"small"}
                            value={customerName}
                            caseType={CASE_TYPES.uppercase}
                            placeholder={""}
                            maxLength={140}
                            onChange={(e) => onInputSearchCriteria(e, 'customerName')} />
                    </Grid>
                    <Grid item xs={8} md={3} >
                        <Stack direction="row" gap={1} sx={{ width: '100%' }}>
                            <MbButton className={'button-action'} size={'small'} fullWidth startIcon={<Search />}
                                buttonName={<h5>Search</h5>} onHandleAction={onHandleSearch}>
                            </MbButton>
                            <MbButton variant={'outlined'} size={'small'} fullWidth
                                buttonName={<h5>Reset</h5>} onHandleAction={onHandleReset}>
                            </MbButton>
                        </Stack>
                    </Grid>
                </Grid>
                <CustomerInfoList onHandleRefresh={onHandleRefresh}/>
            </Box>
            <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesPayment.open}
                severity={snackBarPropertiesPayment.severity}
                message={snackBarPropertiesPayment.snackBarMessage} />
        </>
    )
}