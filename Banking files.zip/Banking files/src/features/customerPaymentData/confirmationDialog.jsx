import { Close, Done } from "@mui/icons-material";
import { Grid, Typography, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, IconButton } from "@mui/material";

import MbButton from "../common/mbButton";

export default function ConfirmationDialog({ openDialog, onHandleOk, onHandleCancel,
    dialogTitle = 'Confirmation', dialogContent = 'Do you Continue?', children }) {

    return (
        <Dialog
            open={openDialog}
            aria-labelledby="confirm-dialog-title"
            aria-describedby="confirm-dialog-description">
            <DialogTitle id="confirm-dialog-title">
                <Grid className="pop-title">
                    <Typography noWrap variant="h5" component={'span'} textTransform={"uppercase"}>
                        {dialogTitle}
                    </Typography>
                </Grid>
            </DialogTitle>
            <DialogContent dividers={true}>
                <DialogContentText>
                    {dialogContent}
                </DialogContentText>
                {children}
            </DialogContent>
            <DialogActions>
                <MbButton
                    variant="outlined"
                    buttonName={'YES'}
                    startIcon={<Done />}
                    onHandleAction={onHandleOk}
                />
                <MbButton
                    variant="outlined"
                    color="warning"
                    buttonName={'CANCEL'}
                    startIcon={<Close />}
                    onHandleAction={onHandleCancel}
                />
            </DialogActions>
        </Dialog>
    )
}