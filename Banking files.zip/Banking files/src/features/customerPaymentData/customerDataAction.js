import { networkISO } from "../../connections/networkISO";
import { CatchErrorDisplay } from "../errorPage/errorHelpers";
import { closeTxnDtlPopupAndUpdateVTxnList, snackBarActionsTrans } from "../viewTransactions/viewTransactionSlice";
import { snackBarActionPaymentInfo } from "./customerDataSlice";
import { TRANS_SAVE_ACCOUNT_SUBTYPE, TRANS_VIEW_CUSTOMER_INFO } from "../../constants/constants";
import { SET_SEARCH_CRITERIA, SET_BENEFICIARY_LIST_BY_CUSTOMER, SET_BIND_PROPERTY, SET_CUSTOMER_LIST, SET_CUS_BENE_STATUS_LIST, FETCH_CUSTOMER_INFO_FOR_NAVIGATION, initialState } from "./customerReducer";
import { CUSTOMER_MAINTAINANCE, VIEW_BENE_INFO_DETAIL, VIEW_CUST_INFO_DETAIL, VIEW_CUST_BENE_STATUS_INFO_DETAIL, ACTIONS_PENDING } from "../../constants/apiConstants";
import { isEmpty } from "lodash";
import { FETCH_ISO_SERVICE } from "../../apacheEnvConfig";

export const viewCustomerInfoDtrl = (requestBody, transactionType, transactionSubType, reduceDispatch, updatedCustomerFromNavigation = {}) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${VIEW_CUST_INFO_DETAIL}`, requestBody, transactionType, transactionSubType)
                .then(resData => {
                    if (!resData) throw new Error('Failed to fetch')
                    if (!resData.ok) {
                        if (resData.status)
                            throw new Error(`${resData.status} - ${resData.statusText}`)
                        else throw new Error('Failed to fetch')
                    }
                    return resData.json();
                })
                .then(responseData => {
                    const { executionStatus, AdditionalStatusCodes, statuscode } = responseData.responseHeader;
                    if (statuscode === '200') {
                        const { responseBody } = responseData;
                        if(isEmpty(updatedCustomerFromNavigation)){
                             //If custInfo is empty, then 
                            if (responseBody.custInfo && responseBody.custInfo.length === 0) {
                                dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${executionStatus}` }))
                            }
                            reduceDispatch({ type: SET_CUSTOMER_LIST, responseBody })
                            reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
                        } else {
                            //if it is from navigation and existing customer, then bind appropriate details in corresponding selectedcustomer object
                            if (responseBody.custInfo && responseBody.custInfo.length === 1)
                                reduceDispatch({ type: FETCH_CUSTOMER_INFO_FOR_NAVIGATION, custInfo: responseBody.custInfo[0], updatedCustomerFromNavigation, fetchedCustInfo: true })
                            else // if not existing customer, bind ausual information
                                reduceDispatch({ type: FETCH_CUSTOMER_INFO_FOR_NAVIGATION, custInfo: null, updatedCustomerFromNavigation, fetchedCustInfo : false })
                        }
                    } else if (AdditionalStatusCodes) {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${AdditionalStatusCodes[0].HostTxndesc}` }))
                    } else {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${executionStatus}` }))
                    }
                })
                .catch(error => {
                    const findDisplayMessage = CatchErrorDisplay(error, VIEW_CUST_INFO_DETAIL, dispatch);
                    if (findDisplayMessage)
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}` }));
                    else
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
                    reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
                })
        } catch (error) {
            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
            reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
        }
    }
}

export const viewBeneDetail = (requestBody, transactionType, transactionSubType, reduceDispatch) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${VIEW_BENE_INFO_DETAIL}`, requestBody, transactionType, transactionSubType)
                .then(resData => {
                    if (!resData) throw new Error('Failed to fetch')
                    if (!resData.ok) {
                        if (resData.status)
                            throw new Error(`${resData.status} - ${resData.statusText}`)
                        else throw new Error('Failed to fetch')
                    }
                    return resData.json();
                })
                .then(responseData => {
                    const { executionStatus, AdditionalStatusCodes, statuscode } = responseData.responseHeader;
                    if (statuscode === '200') {
                        const { responseBody = {} } = responseData;
                        reduceDispatch({ type: SET_BENEFICIARY_LIST_BY_CUSTOMER, responseBody });
                    } else if (AdditionalStatusCodes) {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${AdditionalStatusCodes[0].HostTxndesc}` }))
                    } else {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${executionStatus}` }))
                    }
                    reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
                })
                .catch(error => {
                    const findDisplayMessage = CatchErrorDisplay(error, VIEW_BENE_INFO_DETAIL, dispatch);
                    if (findDisplayMessage)
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}` }))
                    else
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }))
                    reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
                })
        } catch (error) {
            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
            reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
        }
    }
}

export const CustomerMaintainance = (requestBody, transactionSubType = TRANS_SAVE_ACCOUNT_SUBTYPE, snackBarActionPaymentInfo, reduceDispatch, actionsMode) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${CUSTOMER_MAINTAINANCE}`, requestBody, TRANS_VIEW_CUSTOMER_INFO, transactionSubType)
                .then(resData => {
                    if (!resData) throw new Error('Failed to fetch')
                    if (!resData.ok) {
                        if (resData.status)
                            throw new Error(`${resData.status} - ${resData.statusText}`)
                        else throw new Error('Failed to fetch')
                    }
                    return resData.json();
                })
                .then(responseData => {
                    const { executionStatus, AdditionalStatusCodes, statuscode } = responseData.responseHeader;
                    if (statuscode === '200') {
                        if (actionsMode.search(/cust_editadd/) !== -1) {
                            // Close the transaction detail popup once saved the customer detail. 
                            dispatch(closeTxnDtlPopupAndUpdateVTxnList());
                            dispatch(snackBarActionsTrans({ open: true, severity: 'success', snackBarMessage: `${requestBody.message}` }));
                        } else if (actionsMode.search(/cust_add/) !== -1 ||  actionsMode.search(/cust_edit/) !== -1) {
                            reduceDispatch({ type: SET_SEARCH_CRITERIA, fieldName: 'accountNumber', value: requestBody.custInfo[0].custBankAcNo })
                            reduceDispatch({ type: SET_SEARCH_CRITERIA, fieldName: 'customerNumber', value: requestBody.custInfo[0].custNumber })
                            reduceDispatch({ type: SET_SEARCH_CRITERIA, fieldName: 'customerName', value: String(requestBody.custInfo[0].custName).toUpperCase() })
                            reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'refreshCust', value: true });
                            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'success', snackBarMessage: requestBody.message }));
                        } else if (actionsMode.search(/cust/) !== -1) {
                            reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'refreshCust', value: true });
                            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'success', snackBarMessage: requestBody.message }));
                        } else if (actionsMode.search(/bene/) !== -1) {
                            reduceDispatch({ type: SET_SEARCH_CRITERIA, fieldName: 'accountNumber', value: requestBody.custInfo[0].custBankAcNo })
                            reduceDispatch({ type: SET_SEARCH_CRITERIA, fieldName: 'customerNumber', value: requestBody.custInfo[0].custNumber })
                            reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'refreshBene', value: !initialState.refreshBene });
                            reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'beneSearchCriteria', value: initialState.beneSearchCriteria });
                            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'success', snackBarMessage: requestBody.message }));
                        }
                        reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: false })
                    } else if (AdditionalStatusCodes) {
                        if (actionsMode.search(/cust_editadd/) !== -1) {
                            dispatch(snackBarActionsTrans({ open: true, severity: 'error', snackBarMessage: `${AdditionalStatusCodes[0].HostStatusDesc}` }));
                        } else {
                            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${AdditionalStatusCodes[0].HostStatusDesc}` }));
                        }
                    } else {
                        if (actionsMode.search(/cust_editadd/) !== -1) {
                            dispatch(snackBarActionsTrans({ open: true, severity: 'error', snackBarMessage: `${executionStatus}` }));
                        } else {
                            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${executionStatus}` }))
                        }
                    }
                })
                .catch(error => {
                    const findDisplayMessage = CatchErrorDisplay(error, CUSTOMER_MAINTAINANCE, dispatch);
                    if (findDisplayMessage) {
                        if (actionsMode.search(/cust_editadd/) !== -1) {
                            dispatch(snackBarActionsTrans({ open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}` }));
                        } else {
                            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}` }));
                        }
                    } else {
                        if (actionsMode.search(/cust_editadd/) !== -1) {
                            dispatch(snackBarActionsTrans({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
                        } else {
                            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
                        }
                    }
                })
        } catch (error) {
            if (actionsMode.search(/cust_editadd/) !== -1) {
                dispatch(snackBarActionsTrans({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
            } else {
                dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
            }
        }
    }
}

export const viewCustBeneStatusInfoDtl = (requestBody, transactionType, transactionSubType, reduceDispatch) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${VIEW_CUST_BENE_STATUS_INFO_DETAIL}`, requestBody, transactionType, transactionSubType)
                .then(response => {
                    if (!response) throw new Error('Failed to fetch')
                    if (!response.ok) {
                        if (response.status)
                            throw new Error(`${response.status} - ${response.statusText}`)
                        else throw new Error('Failed to fetch')
                    }
                    return response.json();
                }).then(responseData => {
                    const { responseBody, responseHeader } = responseData;
                    if (responseHeader.statuscode === '200' && responseHeader.executionStatus === "Success") {
                        reduceDispatch({ type: SET_CUS_BENE_STATUS_LIST, responseBody });
                        // //if (requestBody.type === "search") {
                        // let message = responseBody.totalCount === 0 ? `No Record Found.` 
                        // : `Total - ${responseBody.totalCount}, Per Page - ${responseBody.pendingList?.length || 0} Records Found.`;
                        // dispatch(snackBarActionPaymentInfo({ open: true, severity: 'success', snackBarMessage: message }))
                        // //}
                    } else {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${responseHeader.executionStatus}` }))
                    }
                })
                .catch(error => {
                    const findDisplayMessage = CatchErrorDisplay(error, VIEW_CUST_BENE_STATUS_INFO_DETAIL, dispatch);
                    if (findDisplayMessage) {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}` }));
                    } else {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
                    }
                })
        } catch (error) {
            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
        }
    }
}

export const SubmitPendingApprovalDtl = (requestBody, reqItem, transactionType, transactionSubType, refreshPending, reduceDispatch) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${ACTIONS_PENDING}`, requestBody, transactionType, transactionSubType)
                .then(response => {
                    if (!response) throw new Error('Failed to fetch')
                    if (!response.ok) {
                        if (response.status)
                            throw new Error(`${response.status} - ${response.statusText}`)
                        else throw new Error('Failed to fetch')
                    }
                    return response.json();
                }).then(responseData => {
                    const { responseHeader } = responseData;
                    if (responseHeader.statuscode === '200' && responseHeader.executionStatus === "Success") {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'success', snackBarMessage: `${requestBody.type} information : ${requestBody.name} was ${requestBody.status} Successfully.` }))
                        reduceDispatch({ type: SET_BIND_PROPERTY, fieldName: 'refreshPending', value: !refreshPending });
                    } else {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${responseHeader.executionStatus}` }))
                    }
                })
                .catch(error => {
                    const findDisplayMessage = CatchErrorDisplay(error, ACTIONS_PENDING, dispatch);
                    if (findDisplayMessage) {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}` }));
                    } else {
                        dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
                    }
                })
        } catch (error) {
            dispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }));
        }
    }
}