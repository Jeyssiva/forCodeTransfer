import React from "react"
import { FormattedMessage } from "react-intl"
import { Divider, Grid, Typography } from "@mui/material"

import { defaultLocales } from "../i18n"
import PostalAddress from "./postalAddress"
import MbDropdown from "../common/mbDropdown"
import MbTextField from "../common/mbTextField"
import { CASE_TYPES } from "../../constants/mxTempConstants"
import { CUSTOMER_TYPE } from "../../constants/customerDataConstants"

export default function CustomerDetailsForm({ errors, item, actionsMode, onHandleChange, setFieldValue, apacheEnvConfig }) {
    const { custBICCode } = apacheEnvConfig;
    const { status, custId, custBankAcNo, custNumber, custName, companyNumber, bicCode, gcifCode, 
        leiCode, custType, shortName, addressInfo, comment, updatedBy } = item;

    return (
        <Grid container spacing={1} columns={{ xs: 4, sm: 4, md: 12 }} direction="row">
            <Grid item xs={4} md={12} >
                <Divider sx={{ width: '100%', margin: 2 }}>
                    <Typography component={'span'} variant="body1" textTransform={"uppercase"}>
                        <b>
                            <FormattedMessage id={`createCustomerInfo.${actionsMode.search(/cust/) !== -1 ? 'customer' : 'beneficiary'}`} defaultMessage={defaultLocales[`createCustomerInfo.${actionsMode.search(/cust/) !== -1 ? 'customer' : 'beneficiary'}`]}>
                                {msg => (
                                    <span>
                                        {msg}
                                    </span>
                                )}
                            </FormattedMessage>
                        </b>
                    </Typography>
                </Divider>
            </Grid>
            {(actionsMode.search(/view/) !== -1) && (
                <>
                    <Grid item xs={2} md={6} >
                        <Typography component={'span'} variant="body2">
                            <FormattedMessage id="createCustomerInfo.status"
                                defaultMessage={defaultLocales["createCustomerInfo.status"]}>
                                {msg => (
                                    <span>
                                        {msg}
                                    </span>
                                )}
                            </FormattedMessage>
                        </Typography>
                    </Grid>
                    <Grid item xs={2} md={6} >
                        <MbTextField
                            id="status"
                            name="status"
                            size={"small"}
                            value={status || ''}
                            placeholder={"-"}
                            caseType={CASE_TYPES.uppercase}
                            disabled={actionsMode.search(/view/) !== -1 ? true : false}
                            variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                        />
                    </Grid>
                </>
            )}
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.custType"
                        defaultMessage={defaultLocales["createCustomerInfo.custType"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbDropdown id="custType" name={"custType"}
                    size={"small"}
                    fullWidth
                    placeholder={"-"}
                    labelValue={custType || ''}
                    dropdownList={CUSTOMER_TYPE}
                    onDropdownChange={onHandleChange}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.accNum"
                        defaultMessage={defaultLocales["createCustomerInfo.accNum"]}>
                        {msg => (
                            <span>
                                {msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField
                    id="custBankAcNo"
                    name="custBankAcNo"
                    size={"small"}
                    value={custBankAcNo || ''}
                    placeholder={"-"}
                    // enableNumber
                    maxLength={34}
                    onChange={onHandleChange}
                    helperText={errors.custBankAcNo}
                    error={errors.custBankAcNo ? true : false}
                    disabled={(actionsMode.search(/view/) !== -1 || actionsMode.search(/edit/) !== -1) ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.custNum"
                        defaultMessage={defaultLocales["createCustomerInfo.custNum"]}>
                        {msg => (
                            <span>
                                {msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField id="custNumber" name="custNumber" size={"small"} value={custNumber || ''} placeholder={"-"} disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    helperText={errors.custNumber} error={errors.custNumber ? true : false}
                    maxLength={6} variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'} onChange={onHandleChange} />
            </Grid>
            {custType === 'C' &&
                <>
                    <Grid item xs={2} md={6} >
                        <Typography component={'span'} variant="body2">
                            <FormattedMessage id="createCustomerInfo.comNum"
                                defaultMessage={defaultLocales["createCustomerInfo.comNum"]}>
                                {msg => (
                                    <span>
                                        {msg}
                                    </span>
                                )}
                            </FormattedMessage>
                        </Typography>
                    </Grid>
                    <Grid item xs={2} md={6} >
                        <MbTextField id="companyNumber" name="companyNumber" size={"small"} value={companyNumber || ''} placeholder={"-"} disabled={actionsMode.search(/view/) !== -1 ? true : false}
                             variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'} onChange={onHandleChange} />
                    </Grid>
                </>
            }
            <Grid item xs={2} md={6}>
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.custId"
                        defaultMessage={defaultLocales["createCustomerInfo.custId"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id="custId" name="custId" size={"small"} value={custId || ''} placeholder={"-"}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false} onChange={onHandleChange}
                    helperText={errors.custId} error={errors.custId ? true : false}
                    maxLength={35} variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.shortName"
                        defaultMessage={defaultLocales["createCustomerInfo.shortName"]}>
                        {msg => (
                            <span>
                                {msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id="shortName" name="shortName" size={"small"} value={shortName || ''} placeholder={'-'}
                    disabled={(actionsMode.search(/view/) !== -1) ? true : false} onChange={onHandleChange}
                    helperText={errors.shortName} error={errors.shortName ? true : false}
                    caseType={CASE_TYPES.uppercase} variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'} />
            </Grid>
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.custName"
                        defaultMessage={defaultLocales["createCustomerInfo.custName"]}>
                        {msg => (
                            <span>
                                {msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id="custName" name="custName" size={"small"} value={custName || ''} placeholder={"-"}
                    disabled={(actionsMode.search(/view/) !== -1) ? true : false} onChange={onHandleChange}
                    helperText={errors.custName} error={errors.custName ? true : false} maxLength={140}
                    multiline rows = {6} caseType={CASE_TYPES.uppercase} 
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'} />
            </Grid>
            <Grid item xs={2} md={6}>
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.bic"
                        defaultMessage={defaultLocales["createCustomerInfo.bic"]}>
                        {msg => (
                            <span>
                                OTHERS: {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id={"bicCode"} name={"bicCode"} size={"small"}
                    value={bicCode || custBICCode} placeholder={"-"} caseType={CASE_TYPES.uppercase}
                    onTextFieldChange={null} onChange={onHandleChange}
                    disabled={(actionsMode.search(/view/) !== -1 || actionsMode.search(/edit/) !== -1) ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6}>
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.lei"
                        defaultMessage={defaultLocales["createCustomerInfo.lei"]}>
                        {msg => (
                            <span>
                                &emsp;&emsp;&emsp;&emsp;&nbsp;{msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id={"leiCode"} name={"leiCode"} size="small"
                    value={leiCode || ''} placeholder={"-"} caseType={CASE_TYPES.uppercase}
                    onTextFieldChange={null} onChange={onHandleChange} maxLength={20}
                    helperText={errors.leiCode} error={errors.leiCode ? true : false}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6}>
                <Typography component={'span'} variant="body1">
                    <FormattedMessage id="createCustomerInfo.gcifCode"
                        defaultMessage={defaultLocales["createCustomerInfo.gcifCode"]}>
                        {msg => (
                            <span>
                                &emsp;&emsp;&emsp;&ensp;{msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id={"gcifCode"} name={"gcifCode"} size={"small"}
                    value={gcifCode || ''} placeholder={"-"}
                    caseType={CASE_TYPES.uppercase}
                    helperText={errors.gcifCode}
                    error={errors.gcifCode ? true : false}
                    onTextFieldChange={null} onChange={onHandleChange}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <PostalAddress
                errors={errors}
                item={addressInfo}
                actionsMode={actionsMode}
                parentName={'addressInfo'}
                onHandleChange={onHandleChange}
                setFieldValue={setFieldValue}
            />
            {(actionsMode.search(/actions/) !== -1) && (
                <>
                    <Grid item xs={2} md={6}>
                        <Typography component={'span'} variant="body2">
                            <FormattedMessage id="createCustomerInfo.updatedBy"
                                defaultMessage={defaultLocales["createCustomerInfo.updatedBy"]}>
                                {msg => (
                                    <span>
                                        {msg}
                                    </span>
                                )}
                            </FormattedMessage>
                        </Typography>
                    </Grid>
                    <Grid item xs={2} md={6}>
                        <MbTextField id={"updatedBy"} name={"updatedBy"} size={"small"}
                            value={updatedBy || ''}
                            caseType={CASE_TYPES.uppercase}
                            helperText={errors.updatedBy}
                            onTextFieldChange={null}
                            disabled={true}
                            variant={'standard'}
                        />
                    </Grid>
                </>
            )}
            {(actionsMode.search(/view/) !== -1) && (
                <Grid item xs={4} md={12}>
                    <MbTextField
                        id="comment"
                        name="comment"
                        label="Comment By Authorisers"
                        margin="normal"
                        multiline
                        disabled={true}
                        maxRows={5}
                        value={comment || "-"}
                        variant="filled"
                    />
                </Grid>
            )}
        </Grid>
    )
}