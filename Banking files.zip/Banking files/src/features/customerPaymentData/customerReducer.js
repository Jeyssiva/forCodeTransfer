import { useSelector } from "react-redux";
import { createContext, useReducer } from "react";

import { CUSTOMER_NAME_OPTIONS } from "../../constants/customerDataConstants";
import { TRANS_SAVE_ACCOUNT_SUBTYPE, sessionItems, ACTIONS_MODE } from "../../constants/constants";
import { getCountryListPersist } from "../showMxTemplateAsTreeView/persistedSlice";

export const SET_SEARCH_CRITERIA = 'searchCriteriaProperty';
export const SET_SELECTED_TAB = 'setSelectedTab';
export const SET_SEARCH_SWITCH = 'setSearchSwitch';
export const SET_CUST_INFO_HEIGHT = 'setCustInfoHeight';
export const SET_BIND_PROPERTY = 'setBindProperty';
export const SET_CUSTOMER_LIST = 'setCustomerList';
export const SET_SELECTED_CUSTOMER = 'setSelectedCustomer';
export const SET_SELECTED_BENEFICIARY = 'setSelectedBeneficiary';
export const SET_SELECTED_COUNTRY = 'setSelectedCountry';
export const SET_CUS_BENE_STATUS_LIST = 'setCusBeneStatusList';
export const SET_BENEFICIARY_LIST_BY_CUSTOMER = 'setBeneListCustomer';
export const SELECTED_BENEFICIARY = 'selectedBeneficiary';
export const DELETE_BENEFICIARY = 'deleteBeneficiary';
export const SAVE_BENEFICIARY = 'saveBeneficiary';
export const ADD_BENEFICIARY = 'addBeneficiary';
export const ADD_BENE_ADDRESS = 'addBeneAddress';
export const SAME_CUSTOMER_ADDRESS = 'sameCustomerAddress';
export const RESET_ALL = 'resetAll';
export const REFRESH_SCREEN = 'refreshScreen';
export const RESET_PAGE_OPTIONS = 'resetPageOptions';
export const FETCH_CUSTOMER_INFO_FOR_NAVIGATION = 'customerInfoForNavigation';
export const OPEN_CUSTOMER_FOR_NAVIGATION = 'openCustomerForNavigation';
export const SET_ERROR_PROPS = 'setErrorProps';
export const BENE_SEARCH = 'beneSearch';

const customerInfo = {
    status: 'PENDING',
    custInfoPk: 0,
    custType: 'I',
    custBankAcNo: '',
    custNumber: '',
    companyNumber: '',
    shortName: '',
    custName: '',
    custId: '',
    bicCode: '',
    leiCode: '',
    gcifCode: '',
    custSrcCountry: sessionStorage.getItem(sessionItems.CountryCode),
}

const addressInfo = {
    addressPk: 0,
    custInfofk: 0,
    beneInfofk: 0,
    addressType: 'RES',
    dept: '',
    subDept: '',
    streetName: '',
    buildingNo: '',
    buildingName: '',
    floor: '',
    postBox: '',
    room: '',
    postCode: '',
    townName: '',
    townLocName: '',
    districtName: '',
    countrySubDv: '',
    country: '',
    countryName: "",
}

const beneficiaryInfo = {
    status: 'PENDING',
    beneficiaryPk: 0,
    custInfofk: '',
    srcCountry: sessionStorage.getItem(sessionItems.CountryCode),
    benId: '',
    beneAcNo: '',
    beneAcName: '',
    beneBicCode: '',
    beneLeiCode: '',
    beneSortCode: '',
    beneIbanNumber: ''
}

export const CustomerContext = createContext();

export const initialState = {
    searchCriteria: {
        accountNumber: '',
        customerName: '',
        customerNumber: '',
        dateFrom: '',
        dateTo: '',
        status: 'PENDING'
    },
    customerNameByAccount: CUSTOMER_NAME_OPTIONS.value,
    originalCustomerList: [],
    originalCustBeneStatusList: [],
    newCustomer: { ...customerInfo, addressInfo },
    newBeneficiary: { ...beneficiaryInfo, 'benAddressInfo': addressInfo },
    updatedCustomerList: [{ ...customerInfo, ...CUSTOMER_NAME_OPTIONS, actionCode: 'A', addressInfo }],
    selectedCustomer: { ...customerInfo, addressInfo },
    loadingStatus: false,
    openDialog: false,
    actionsMode: "",
    selectedBeneficiary: { ...beneficiaryInfo, benAddressInfo: { ...addressInfo } },
    openConfirmationDialog: false,
    openConfirmationBeneDialog: false,
    dialogContent: '',
    transactionSubtype: TRANS_SAVE_ACCOUNT_SUBTYPE,
    confirmationMode: '',
    expectedCustomerValue: '',
    refreshCust: false,
    refreshBene: false,
    refreshPending: false,
    beneSearch: false,
    pageNum : 0,
    rowsPerPage : 10,
    foundCustomerForNavigation: false
}

export function reduce(state, action, countryList) {
    switch (action.type) {
        case SET_SEARCH_CRITERIA: {
            return {
                ...state,
                searchCriteria: { ...state.searchCriteria, [action.fieldName]: action.value }
            }
        }
        case SET_SELECTED_CUSTOMER: {
            return {
                ...state,
                selectedCustomer: action.data,
                // customerNameByAccount: action.data.value || ''
            }
        }
        case SET_SELECTED_BENEFICIARY: {
            return {
                ...state,
                selectedBeneficiary: action.data,
            }
        }
        case SET_BIND_PROPERTY: {
            const { fieldName, value } = action;
            return {
                ...state,
                [fieldName]: value
            }
        }
        case SET_CUS_BENE_STATUS_LIST: {
            return {
                ...state,
                originalCustBeneStatusList: action.responseBody,
                loadingStatus : false
            }
        }
        case SET_CUSTOMER_LIST: {
            const updatedList = action.responseBody.custInfo.map(info => {
                return {
                    ...info,
                    label: `${info.custBankAcNo}_${info.custName}_${info.custNumber}`,
                    value: `${info.custBankAcNo}_${info.custName}_${info.custNumber}`,
                    actionCode: 'NA'
                }
            })
            return {
                ...state,
                // loadingStatus: false,
                originalCustomerList: [...updatedList],
                updatedCustomerList: [...updatedList, { ...state.newCustomer }],
                selectedCustomer: updatedList.length > 0
                    // ? initialState.selectedCustomer
                    // : updatedList.length === 1 
                    ? updatedList[0]
                    : { ...initialState.newCustomer },
                customerNameByAccount: updatedList.length > 0
                    // ? '' 
                    // : updatedList.length === 1 
                    ? updatedList[0].value
                    : CUSTOMER_NAME_OPTIONS.value
            }
        }
        case SET_SELECTED_COUNTRY: {
            const { parentName, subParent, data } = action;
            return {
                ...state,
                [parentName]: {
                    ...state[parentName], [subParent]: {
                        ...state[parentName][subParent],
                        country: data.code, countryName: data.description
                    }
                },
            }
        }
        case SET_BENEFICIARY_LIST_BY_CUSTOMER: {
            const { gcifCode } = state.selectedCustomer;
            const { custInfo, totalCount } = action.responseBody;
            const getCurrentCustBeneDet = custInfo.find(cus => cus.gcifCode === gcifCode);
            const { beneInfo = [] } = getCurrentCustBeneDet || {};
            const updatedBeneInfo = [...beneInfo.map(b => {
                return {
                    ...b,
                    actionCode: 'NA',
                    accBic1: (b.beneAcNo ?? '-') + b.beneBicCode,
                    accBic2: (b.beneIbanNumber ?? '-') + b.beneBicCode,
                    accBic3: (b.beneAcNo ?? '-') + (b.beneSortCode ?? '-') + b.beneBicCode,
                    accBic4: (b.beneIbanNumber ?? '-') + (b.beneSortCode ?? '-') + b.beneBicCode
                }
            })]
            return {
                ...state,
                loadingStatus : false,
                selectedCustomer: { ...state.selectedCustomer, totalCount, beneInfo: updatedBeneInfo },
                updatedCustomerList: state.updatedCustomerList.map(u => {
                    if (u.custInfoPk === state.selectedCustomer.custInfoPk) {
                        return {
                            ...u,
                            beneInfo: updatedBeneInfo
                        }
                    }
                    return u;
                })
            }
        }
        case SELECTED_BENEFICIARY: {
            const { valueData, beneMode } = action;
            return {
                ...state,
                selectedBeneficiary: {
                    ...valueData,
                    accBic1: (valueData.beneAcNo ?? '-') + valueData.beneBicCode,
                    accBic2: (valueData.beneIbanNumber ?? '-') + valueData.beneBicCode,
                    accBic3: (valueData.beneAcNo ?? '-') + (valueData.beneSortCode ?? '-') + valueData.beneBicCode,
                    accBic4: (valueData.beneIbanNumber ?? '-') + (valueData.beneSortCode ?? '-') + valueData.beneBicCode
                },
                beneMode
            }
        }
        case DELETE_BENEFICIARY: {
            const { valueData } = action;
            return {
                ...state,
                selectedCustomer: valueData.actionCode === 'A' ?
                    {
                        ...state.selectedCustomer,
                        beneInfo: [...state.selectedCustomer.beneInfo.filter(f => f.beneficiaryPk !== valueData.beneficiaryPk)]
                    }
                    :
                    {
                        ...state.selectedCustomer,
                        beneInfo: [...state.selectedCustomer.beneInfo.map(b => {
                            if (b.beneficiaryPk === valueData.beneficiaryPk) {
                                return {
                                    ...b,
                                    actionCode: 'D',
                                    updatedBy: sessionStorage.getItem(sessionItems.Username)
                                }
                            }
                            return b;
                        })]
                    },
                updatedCustomerList: state.updatedCustomerList.map(u => {
                    if (u.custInfoPk === state.selectedCustomer.custInfoPk) {
                        return {
                            ...u,
                            actionCode: valueData.actionCode === 'A' ? state.selectedCustomer.actionCode : 'U',
                            updatedBy: sessionStorage.getItem(sessionItems.Username),
                            beneInfo: valueData.actionCode === 'A' ?
                                [...state.selectedCustomer.beneInfo.filter(f => f.beneficiaryPk !== valueData.beneficiaryPk)]
                                :
                                [...state.selectedCustomer.beneInfo.map(b => {
                                    if (b.beneficiaryPk === valueData.beneficiaryPk) {
                                        return {
                                            ...b,
                                            actionCode: 'D',
                                            updatedBy: sessionStorage.getItem(sessionItems.Username)
                                        }
                                    }
                                    return b;
                                })]
                        }
                    }
                    return u;
                })
            }
        }
        case SAVE_BENEFICIARY: {
            return {
                ...state,
                selectedCustomer: {
                    ...state.selectedCustomer,
                    beneInfo: [
                        ...state.selectedCustomer.beneInfo, { ...action.valueData }
                    ]
                },
                updatedCustomerList: state.updatedCustomerList.map(save => {
                    if (save.custInfoPk === state.selectedCustomer.custInfoPk) {
                        return {
                            ...save,
                            actionCode: 'U',
                            updatedBy: sessionStorage.getItem(sessionItems.Username),
                            beneInfo: [
                                ...state.selectedCustomer.beneInfo, { ...action.valueData }
                            ]
                        }
                    }
                    return save;
                })
            }
        }
        case ADD_BENEFICIARY: {
            const { fieldName, value } = action;
            return {
                ...state,
                selectedBeneficiary: {
                    ...state.selectedBeneficiary,
                    [fieldName]: value
                }
            }
        }
        case ADD_BENE_ADDRESS: {
            const { fieldName, value } = action;
            return {
                ...state,
                selectedBeneficiary: {
                    ...state.selectedBeneficiary,
                    benAddressInfo: { ...state.selectedBeneficiary.benAddressInfo, [fieldName]: value }
                }
            }
        }
        case SAME_CUSTOMER_ADDRESS: {
            return {
                ...state,
                selectedBeneficiary: {
                    ...state.selectedBeneficiary, benAddressInfo: { ...action.valueObject }
                }
            }
        }
        case RESET_ALL: {
            return {
                ...state,
                ...(delete initialState.searchCriteria && initialState)
            }
        }
        case REFRESH_SCREEN: {
            return {
                ...state,
                ...initialState
            }
        }
        case RESET_PAGE_OPTIONS:{
            return {
                ...state,
                pageNum: 0,
                rowsPerPage : 10
            }
        }
        case FETCH_CUSTOMER_INFO_FOR_NAVIGATION: {
            const {updatedCustomerFromNavigation, custInfo, fetchedCustInfo} = action;
            const {custNumber = '', shortName = '', custId = '', leiCode = '', gcifCode = '', companyNumber = ''} = custInfo || {};
            return {
                ...state,
                selectedCustomer : {...updatedCustomerFromNavigation, custNumber, shortName, custId, leiCode, gcifCode, companyNumber},
                foundCustomerForNavigation : fetchedCustInfo,
                actionsMode: ACTIONS_MODE[10],
                openDialog: true
            }         
        }
        case OPEN_CUSTOMER_FOR_NAVIGATION: {
            return {
                ...state,
                actionsMode: ACTIONS_MODE[10],
                openDialog: true,
                selectedCustomer: {...action.updatedCustomer},
                foundCustomerForNavigation: false
            }
        }
        case BENE_SEARCH: {
            const { refreshBene, pageNum, rowsPerPage } = action;
            return {
                ...state, 
                refreshBene,
                pageNum,
                rowsPerPage
            }
        }
        default: {
            return { ...state }
        }
    }
}

export const CustomerProvider = ({ children }) => {
    const countryList = useSelector(getCountryListPersist);
    const [state, dispatch] = useReducer((state, action) => reduce(state, action, countryList), initialState);

    return (
        <CustomerContext.Provider value={{ state, dispatch }}>
            {children}
        </CustomerContext.Provider>
    )
}