import dayjs from 'dayjs';
import moment from 'moment';
import { Search } from "@mui/icons-material";
import { FormattedMessage } from "react-intl";
import { useDispatch, useSelector } from "react-redux";
import React, { useContext, useEffect, useMemo } from 'react';
import { Divider, TablePagination, Link, Box, Stack, Grid, TableContainer, Table, TableHead, TableBody, TableRow, Typography } from "@mui/material";

import { defaultLocales } from "../../i18n";
import MbButton from "../../common/mbButton";
import LoadingViewer from "../../loadingViewer";
import MbSnackbar from "../../common/mbSnackbar";
// import MbDropdown from '../common/mbDropdown';
import { getUserInfo } from '../../login/loginSlice';
// import { STATUS } from '../../constants/constants';
import MbBreadCrumbs from '../../common/mbBreadcrumbs';
import MbDateMuiPicker from '../../common/mbDateMuiPicker';
import { COUNTRY_ADMIN_ROLE } from '../../../constants/transactionConstants';
import CustBeneModalDialog from "../../customerPaymentData/custBeneModalDialog";
import { StyledTableCell, StyledTableRow } from '../../viewTransactions/helpers';
import { viewCustBeneStatusInfoDtl } from "../../customerPaymentData/customerDataAction";
import { getSnackBarPaymentInfo, snackBarActionPaymentInfo } from "../../customerPaymentData/customerDataSlice";
import { ACTIONS_MODE, TRANS_VIEW_STATUS, TRANS_VIEW_STATUS_SUBTYPE, DATE_TIME_FORMAT, DATE_TIME_FORMAT_LOG, sessionItems, RowsPerPageOptions, DATE_FORMAT } from "../../../constants/constants";
import { CustomerContext, SET_SEARCH_CRITERIA, REFRESH_SCREEN, SET_BIND_PROPERTY, SET_SELECTED_CUSTOMER, SET_SELECTED_BENEFICIARY, SET_CUS_BENE_STATUS_LIST, RESET_PAGE_OPTIONS } from '../../customerPaymentData/customerReducer';

export default function PendingActionsCustomerPayment() {
    const actDispatch = useDispatch();
    const { state, dispatch } = useContext(CustomerContext);
    const snackBarPropertiesPayment = useSelector(getSnackBarPaymentInfo);
    const getUserDetail = useSelector(getUserInfo);
    const { searchCriteria: { dateFrom, dateTo, status }, loadingStatus, openDialog,
        originalCustBeneStatusList, refreshPending, pageNum, rowsPerPage, beneSearch } = state;

    const { pendingList = [], totalCount = 0 } = originalCustBeneStatusList || {};
    const { userLogin = '', userUserGroups: [{ userGroupId = '' } = {}] = [] } = getUserDetail || {};

    const getRequestBody = useMemo(() => {
        const dtFrom = dateFrom && moment(new Date(dateFrom)).set({ hour: 0, minute: 0, second: 0 }).format(DATE_TIME_FORMAT_LOG);
        const dtTo = dateTo && moment(new Date(dateTo)).set({ hour: 23, minute: 59, second: 59 }).format(DATE_TIME_FORMAT_LOG);
        return {
            "maxResults": rowsPerPage,
            "pageNo": pageNum,
            "sortDirection": "ASC",
            "dateFrom": dtFrom,
            "dateTo": dtTo,
            "status": status
        }
    }, [pageNum, rowsPerPage, dateFrom, refreshPending, beneSearch, dateTo])

    useEffect(() => {
        const requestBody = {
            ...getRequestBody
        }
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: true });
        actDispatch(viewCustBeneStatusInfoDtl(requestBody, TRANS_VIEW_STATUS, TRANS_VIEW_STATUS_SUBTYPE,
            dispatch));
    }, [actDispatch, pageNum, rowsPerPage, beneSearch, refreshPending, status]);

    useEffect(() => {
        return () => {
            dispatch({ type: REFRESH_SCREEN });
            actDispatch(snackBarActionPaymentInfo({open: false}));
        }
    }, [])

    const onInputSearchCriteria = (event, fieldName) => {
        dispatch({ type: SET_SEARCH_CRITERIA, fieldName, value: ((fieldName === 'status') ? event.target.value : event) });
    }

    const onHandleRefresh = () => {
        dispatch({ type: REFRESH_SCREEN })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'refreshPending', value: !refreshPending });
    }

    const onHandleSearch = () => {
        const { dateFrom, dateTo } = state.searchCriteria;
        if (dateFrom === "" || dateTo === "") {
            actDispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: 'Please fill all the fields.' }))
        } else {
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'beneSearch', value: !beneSearch });
            dispatch({ type: RESET_PAGE_OPTIONS });
        }
    }

    const onHandleViewCustBeneDialog = (custInfoPk, type) => {
        const found = originalCustBeneStatusList && originalCustBeneStatusList.pendingList &&
            originalCustBeneStatusList.pendingList.find(item => (type === 'CUSTOMER') ? item.custInfoPk === custInfoPk : item.beneficiaryPk === custInfoPk) || {};
        dispatch({ type: (type === 'CUSTOMER') ? SET_SELECTED_CUSTOMER : SET_SELECTED_BENEFICIARY, data: found || {} })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: String(found.type).toUpperCase() === 'CUSTOMER' ? ACTIONS_MODE[8] : ACTIONS_MODE[9] })
    }

    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        actDispatch(snackBarActionPaymentInfo({ open: false, severity: '', snackBarMessage: '' }));
    }

    const onHandlePageChange = (e, newPage) => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'pageNum', value: newPage })
    }

    const handleChangeRowsPerPage = (event) => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'rowsPerPage', value: parseInt(event.target.value, 10) })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'pageNum', value: 0 })
    }

    return (
        <>
            <LoadingViewer loading={loadingStatus} />
            <MbBreadCrumbs crumbsList={[{ title: 'createCustomerInfo.title_pend' }]} />
            <h6>This module lists the actions required for maintaining Customer Payment and Beneficiary Data.</h6>
            <Divider className="divider"><h5><b>SEARCH PENDING ACTIONS LISTING</b></h5></Divider>
            <Box className="box">
                <Grid container spacing={1} columns={{ xs: 4, sm: 8, md: 12 }} direction="row">
                    <Grid item xs={8} md={4} >
                        {/* Date From */}
                        <MbDateMuiPicker
                            id="dateFrom"
                            name="dateFrom"
                            size={"small"}
                            format={DATE_FORMAT}
                            labelInfo={dayjs(dateFrom)}
                            labelText={<b className="bold">From</b>}
                            onDateChange={(e) => onInputSearchCriteria(e, 'dateFrom')} />
                    </Grid>
                    <Grid item xs={8} md={4} >
                        {/* Date To */}
                        <MbDateMuiPicker
                            id="dateTo"
                            name="dateTo"
                            size={"small"}
                            format={DATE_FORMAT}
                            labelInfo={dayjs(dateTo)}
                            labelText={<b className="bold">To</b>}
                            onDateChange={(e) => onInputSearchCriteria(e, 'dateTo')} />
                    </Grid>
                    {/* <Grid item xs={8} md={3} >                            
                            <MbDropdown
                                id="status"
                                size="small"
                                margin="none"
                                sxFormStyles={'mb'}
                                labelValue={status}
                                arrowIcon={true}
                                fullWidth={true}
                                variant={'outlined'}
                                dropdownList={STATUS}
                                onDropdownChange={(e) => onInputSearchCriteria(e, 'status')}
                                labelName={<b className="bold">Status</b>}
                            />
                        </Grid> */}
                    <Grid item xs={8} md={4} >
                        <Stack direction="row" justifyContent={"center"} gap={1} sx={{ width: '100%' }}>
                            <MbButton className={'button-action'} size={'small'} fullWidth startIcon={<Search />}
                                buttonName={<h5>Search</h5>} onHandleAction={onHandleSearch}>
                            </MbButton>
                            <MbButton variant={'outlined'} size={'small'} fullWidth
                                buttonName={<h5>Reset</h5>} onHandleAction={onHandleRefresh}>
                            </MbButton>
                        </Stack>
                    </Grid>
                </Grid>
                <Divider className="divider"><h5>{totalCount} PENDING ACTION(S) FOUND</h5></Divider>
                <TableContainer>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <StyledTableCell>No</StyledTableCell>
                                <StyledTableCell>Requested Date (UTC)</StyledTableCell>
                                <StyledTableCell>Item</StyledTableCell>
                                <StyledTableCell>Type</StyledTableCell>
                                <StyledTableCell>Activity</StyledTableCell>
                                <StyledTableCell>Requestor</StyledTableCell>
                                <StyledTableCell>Actions</StyledTableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {
                                pendingList && pendingList.map((item, key) => {
                                    return (
                                        <StyledTableRow tabIndex={-1} key={key}>
                                            <StyledTableCell scope="row" align="left">{key + 1 + (pageNum * rowsPerPage)}</StyledTableCell>
                                            <StyledTableCell scope="row" align="left">{item.updatedDt}</StyledTableCell>
                                            {/* {String(item.type).toUpperCase() === 'CUSTOMER' ? item.custName : item.beneAcName} {`<ACC NO: ${String(item.type).toUpperCase() === "CUSTOMER" ? item.custBankAcNo || '-' : item.beneAcNo || '-'}> ${String(item.type).toUpperCase() === 'BENEFICIARY' ? `<IBAN: ${item.beneIbanNumber || '-'}>` : ``}`} */}
                                            <StyledTableCell scope="row" align="left" sx={{ maxWidth: 250 }}>{item.item || ''}</StyledTableCell>
                                            <StyledTableCell scope="row" align="left">{item.type}</StyledTableCell>
                                            <StyledTableCell scope="row" align="left">{item.activityType}</StyledTableCell>
                                            <StyledTableCell scope="row" align="left">{item.updatedBy}</StyledTableCell>
                                            <StyledTableCell scope="row" align="left">
                                                <Stack direction="row" gap={1}>
                                                    <Link
                                                        component="button"
                                                        variant="body2"
                                                        onClick={(e) => onHandleViewCustBeneDialog((item.type === 'CUSTOMER') ? item.custInfoPk : item.beneficiaryPk, item.type)}
                                                    >
                                                        {(userLogin !== item.updatedBy || userGroupId === COUNTRY_ADMIN_ROLE) && 'Pending Approval'}
                                                    </Link>
                                                </Stack>
                                            </StyledTableCell>
                                        </StyledTableRow>
                                    )
                                })}
                            {pendingList.length === 0 && (
                                <TableRow sx={{
                                    height: 53,
                                }}>
                                    <StyledTableCell colSpan={7}>
                                        <Typography sx={{ display: 'flex', justifyContent: 'center' }}>
                                            <FormattedMessage id="viewTransactions.noRecords" defaultMessage={defaultLocales['viewTransactions.noRecords']} />
                                        </Typography>
                                    </StyledTableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination component={"div"}
                    count={totalCount}
                    page={pageNum}
                    rowsPerPageOptions={RowsPerPageOptions}
                    rowsPerPage={rowsPerPage}
                    showFirstButton
                    showLastButton
                    onPageChange={onHandlePageChange}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </Box>
            {openDialog && <CustBeneModalDialog state={state} dispatch={dispatch} />}
            <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesPayment.open}
                severity={snackBarPropertiesPayment.severity}
                message={snackBarPropertiesPayment.snackBarMessage} />
        </>
    )
}