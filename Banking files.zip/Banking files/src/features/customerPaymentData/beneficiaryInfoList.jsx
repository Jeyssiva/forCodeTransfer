import { isEmpty } from "lodash";
import { Add, Refresh, Search } from "@mui/icons-material";
import { FormattedMessage } from "react-intl";
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from "react-redux";
import { useContext, useEffect, useMemo, useState } from "react";
import { Divider, Stack, TablePagination, FormGroup, Typography } from "@mui/material";

import { defaultLocales } from "../i18n"
import MbButton from "../common/mbButton";
import { getUserInfo } from "../login/loginSlice";
import ConfirmationDialog from "./confirmationDialog";
import CustBeneModalDialog from "./custBeneModalDialog";
import { ACTIONS_MODE, RowsPerPageOptions, TRANS_VIEW_BENE_INFO_SUBTYPE, TRANS_VIEW_CUSTOMER_INFO } from "../../constants/constants";
import { CustomerMaintainance, viewBeneDetail } from "./customerDataAction";
import { snackBarActionPaymentInfo } from "./customerDataSlice";
import { SELECTED_BENEFICIARY, SET_BIND_PROPERTY, CustomerContext, BENE_SEARCH } from "./customerReducer";
import MbDropdown from "../common/mbDropdown";
import MbTextField from "../common/mbTextField";
import { CASE_TYPES } from "../../constants/mxTempConstants";
import { BENE_SEARCH_CRITERIA } from "../../constants/customerDataConstants";
import { length_patternMatching } from "./customerHelpers";
import BenefiaryTable from "./beneficiaryTable";

export default function BeneficiaryInfoList() {
    const navigate = useNavigate();
    const actDispatch = useDispatch();
    const { state, dispatch } = useContext(CustomerContext);
    const { openDialog, dialogContent, confirmationMode, openConfirmationDialog, 
        selectedCustomer, selectedBeneficiary, 
        newBeneficiary, transactionSubtype, pageNum, rowsPerPage, refreshBene } = state;
    const {beneInfo : beneficiaryInfoList = [], custBankAcNo, custNumber, activeInd, custName, totalCount } = selectedCustomer || {} ;
    const {beneAcName, beneAcNo, beneIbanNumber } = selectedBeneficiary || {};
 
    const initialSearch = {searchType: '', searchText: ''};
    const [searchCriteria, setSearchCriteria] = useState({searchType: '', searchText: ''});
    const {searchText, searchType} = searchCriteria || {};
    const [errorProps, setErrorProps] = useState({});

    const getRequestBody = useMemo(() => {
        return {
            maxResults: rowsPerPage,
            pageNo: pageNum,
            searchCriteria,
            searchBeneficiary: { 'accountNumber': custBankAcNo, 'customerNumber': custNumber }
        }
    }, [rowsPerPage, pageNum, searchCriteria])

    // By Default, reset the pagenumber, rowsperpage and beneficiary's search criteria
    useEffect(() => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'rowsPerPage', value: 10 });
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'pageNum', value: 0 });
        setSearchCriteria({...initialSearch})
    }, [])
    
    useEffect(() => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: true });
        actDispatch(viewBeneDetail(
            { ...getRequestBody }, 
            TRANS_VIEW_CUSTOMER_INFO, TRANS_VIEW_BENE_INFO_SUBTYPE, dispatch));
    }, [refreshBene, pageNum, rowsPerPage]);

    const onHandleAddBeneDialog = () => {
        dispatch({ type: SELECTED_BENEFICIARY, valueData: newBeneficiary, beneMode: 'add' })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: ACTIONS_MODE[4] })
    }

    const onConfirmOk = () => {
        if (confirmationMode === 'DeleteBeneficiary') {
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: true });
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: ACTIONS_MODE[7] })
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: false })
            const reqBody = {
                custInfo: [{ ...selectedCustomer, actionCode: '', 'beneInfo': [{ ...selectedBeneficiary, actionCode: 'D', status: 'PENDING', comment: '' }]}],
                message: `Beneficiary : ${beneAcName} <AccNo : ${beneAcNo || '-'} | IBAN : ${beneIbanNumber || '-'} deleting request was submitted for approval.`
            }
            actDispatch(CustomerMaintainance(reqBody, transactionSubtype, snackBarActionPaymentInfo, dispatch, ACTIONS_MODE[7]))
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
        }
    }

    const onConfirmCancel = () => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: false })
    }

    const onHandleBack = () => {
        navigate(-1)
    }

    const onHandlePageChange = (e, newPage) => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'pageNum', value: newPage });
    }
    const handleChangeRowsPerPage = (event) => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'rowsPerPage', value: parseInt(event.target.value, 10) });
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'pageNum', value: 0 });
    }
    
    const onHandleSearchInputChange = (eValue, fieldName, isUpper) => {
        let sCriteria = { ...searchCriteria };
        if (fieldName === 'searchType') {
            sCriteria = { ...searchCriteria, 'searchText': "" }
        }
        setSearchCriteria((props) => ({ ...props, ...sCriteria, [fieldName]: isUpper ? eValue.toUpperCase() : eValue }))
    }

    const onHandleSubmitSearch = (mode) => {
        const { searchType, searchText } = searchCriteria;
        setErrorProps({});
        if(mode === 'reset'){
            setSearchCriteria({...initialSearch});
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'refreshBene', value: !refreshBene })
            return;
        }
        if (!searchType && !searchText) {
            actDispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: 'Please fill Search Criteria' }));
            return;
        }
        if (searchType && !searchText) {
            setErrorProps({'searchText' : 'Required'})
            return;
        } 
        if(!searchType  && searchText) {
            setErrorProps({'searchType' : 'Required'})
            return;
        }
        const { isMatched, message } = length_patternMatching(searchType, searchText);
        if(!isMatched) {
            setErrorProps({'searchText' : message})
            return;
        }
        dispatch({ type: BENE_SEARCH, refreshBene: !refreshBene, pageNum :0, rowsPerPage: 10 })
    }

    const onHandleRefresh = () => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'refreshBene', value: !refreshBene });
    }

    const {searchType : errorType = '', searchText: errorText = ''} = errorProps;

    return (
        <>
            <Stack direction="row" gap={1} sx={{ width: '100%', justifyContent: 'flex-end', marginBottom: 2, marginTop: 2 }}>
                <MbButton className="button-action" buttonName={<h5>BACK</h5>} onHandleAction={onHandleBack}/>
            </Stack>
            <Divider className="divider">
                <Typography variant="subtitle2" sx={{ fontWeight: 'bold', 
                    whiteSpace: selectedCustomer?.custName?.length > 50 ? 'break-spaces' : 'nowrap'}} gutterBottom>
                    {totalCount} BENEFICIARY(IES) DATA FOUND FOR CUSTOMER {selectedCustomer.custName} [ACC. NO: {selectedCustomer.custBankAcNo}]
                </Typography>
            </Divider>
            {/* <h3 className="margin">Beneficiary Information</h3> */}
            <FormGroup aria-label="position" row >
                <Stack direction="row" alignItems={"flex-start"} justifyContent={"space-between"} gap={0.5} sx={{ width: '100%' }}> 
                    <MbDropdown
                        id="bene.searchType"
                        fullWidth={true}
                        variant={"outlined"}
                        labelName={<FormattedMessage id="createCustomerInfo.searchType"
                            defaultMessage={defaultLocales["createCustomerInfo.searchType"]}>
                            {msg => (
                                <span>
                                    <h5>{msg}</h5>
                                </span>
                            )}
                        </FormattedMessage>}
                        labelValue={searchType || ''}
                        inputStyle={'dropdown-audit'}
                        onDropdownChange={(e) => onHandleSearchInputChange(e.target.value, 'searchType')}
                        dropdownList={BENE_SEARCH_CRITERIA}
                        error = {!isEmpty(errorType)}
                        helperText={errorType}
                        size="small" />
                    <MbTextField
                        id="searchText"
                        name="searchText"
                        label={
                            <FormattedMessage id="createCustomerInfo.searchText" defaultMessage={defaultLocales['createCustomerInfo.searchText']} >
                                {msg => (
                                    <span>
                                        <h5>{msg}</h5>
                                    </span>
                                )}
                            </FormattedMessage>}
                        size={"small"}
                        value={searchText}
                        key="txtSearchText"
                        inputStyle={'font-small'}
                        error = {!isEmpty(errorText)}
                        helperText={errorText}
                        placeholder="case-insensitive"
                        caseType={CASE_TYPES.uppercase}
                        onChange={(e) => onHandleSearchInputChange(e.target.value, 'searchText', true)}
                    />
                    <MbButton className={'button-action'} fullWidth={true} startIcon={<Search />}
                        buttonName={<h5>Search</h5>} onHandleAction={(e) => onHandleSubmitSearch(e)}>
                    </MbButton>
                    <MbButton className={'button-reset'} fullWidth variant="outlined"
                        onHandleAction={(e) => onHandleSubmitSearch('reset')} buttonName={<h5>Reset</h5>}>
                    </MbButton>
                </Stack>
            </FormGroup>
            <Stack direction="row" gap={1} sx={{ width: '100%', justifyContent: 'flex-end', marginBottom: 2, marginTop: 2 }}>
                <MbButton variant={'outlined'} startIcon={<Add />}
                    // disabled the add bene button , if new customer is in pending state
                    buttonName={<h5>ADD</h5>} onHandleAction={onHandleAddBeneDialog}
                    disabled={activeInd === 'I'} />
                    {
                        beneficiaryInfoList && beneficiaryInfoList.length > 0 &&
                        <MbButton variant={'outlined'} startIcon={<Refresh />}
                            buttonName={<h5>Refresh</h5>} onHandleAction={onHandleRefresh} />
                    }
            </Stack>
            <BenefiaryTable beneficiaryInfoList = {beneficiaryInfoList}/>
            <TablePagination component={"div"}
                count={totalCount}
                page={pageNum}
                rowsPerPageOptions={RowsPerPageOptions}
                rowsPerPage={rowsPerPage}
                showFirstButton
                showLastButton
                onPageChange={onHandlePageChange}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
            {openDialog && <CustBeneModalDialog state={state} dispatch={dispatch} />}
            {openConfirmationDialog && <ConfirmationDialog openDialog={openConfirmationDialog} onHandleOk={onConfirmOk} onHandleCancel={onConfirmCancel} dialogContent={dialogContent} />}
        </>
    )
}