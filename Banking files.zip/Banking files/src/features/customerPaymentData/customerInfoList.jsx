import { isEqual } from "lodash";
import { Add, Refresh } from "@mui/icons-material";
import { FormattedMessage } from "react-intl";
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from "react-redux";
import { useContext, useState, useEffect } from "react";
import { Divider, Typography, Stack, Link, TableContainer, Table, TableHead, TableBody, TableRow } from "@mui/material";

import { defaultLocales } from "../i18n"
import MbButton from "../common/mbButton";
import { getUserInfo } from "../login/loginSlice";
import ConfirmationDialog from "./confirmationDialog";
import CustBeneModalDialog from "./custBeneModalDialog";
import { ACTIONS_MODE } from "../../constants/constants";
import { CustomerMaintainance } from "./customerDataAction";
import { snackBarActionPaymentInfo } from "./customerDataSlice";
import { COUNTRY_ADMIN_ROLE } from "../../constants/transactionConstants";
import { StyledTableCell, StyledTableRow } from '../viewTransactions/helpers';
import { SWIFT_PAGE, CUSTOMERPAYMENTDATA, BENEROUTE } from "../../constants/routesURL";
import { SET_SELECTED_CUSTOMER, SET_BIND_PROPERTY, CustomerContext } from "./customerReducer";
import { APPROVED_STATUS, RETURNED_STATUS, PENDING_STATUS } from "../../constants/customerDataConstants";

export default function CustomerInfoList({onHandleRefresh}) {
    const navigate = useNavigate();
    const actDispatch = useDispatch();
    const getUserDetail = useSelector(getUserInfo);
    const { state, dispatch } = useContext(CustomerContext);
    const [customerInfoList, setCustomerInfoList] = useState([]);
    const { userLogin = '', userUserGroups: [{ userGroupId = '' } = {}] = [] } = getUserDetail || {};
    const { searchCriteria, originalCustomerList, openDialog, confirmationMode, selectedCustomer, openConfirmationDialog, dialogContent, newCustomer, transactionSubtype } = state;

    useEffect(() => {
        if (!isEqual(originalCustomerList, customerInfoList)) {
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: true });
            if (searchCriteria.accountNumber === '' && searchCriteria.customerName === '' && searchCriteria.customerNumber === '') {
                setCustomerInfoList([]);
            } else {
                setCustomerInfoList(originalCustomerList ?? []);
            }
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
        }
    }, [originalCustomerList, customerInfoList, dispatch, searchCriteria])

    const onHandleViewCustDialog = (bankAccNum, custNum) => {
        const findCustomerObj = customerInfoList.find(item => (item.custBankAcNo === bankAccNum && item.custNumber === custNum)) || {};
        dispatch({ type: SET_SELECTED_CUSTOMER, data: findCustomerObj || {} })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: ACTIONS_MODE[1] })
    }

    const onHandleAddCustDialog = () => {
        dispatch({ type: SET_SELECTED_CUSTOMER, data: newCustomer })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: ACTIONS_MODE[0] })
    }

    const onHandleEditCustDialog = (bankAccNum, custNum) => {
        const findCustomerObj = customerInfoList.find(item => (item.custBankAcNo === bankAccNum && item.custNumber === custNum)) || {};
        dispatch({ type: SET_SELECTED_CUSTOMER, data: findCustomerObj || {} })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: ACTIONS_MODE[2] })
    }

    const onHandleDeleteCustDialog = (bankAccNum, custNum) => {
        const findCustomerObj = customerInfoList.find(item => (item.custBankAcNo === bankAccNum && item.custNumber === custNum)) || {};
        dispatch({ type: SET_SELECTED_CUSTOMER, data: findCustomerObj || {} })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'dialogContent', value: 'Are you sure you want to delete this customer?' })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'confirmationMode', value: 'DeleteCustomer' })
    }

    const onHandleManageBene = (bankAccNum, custNum) => {
        const findCustomerObj = customerInfoList.find(item => (item.custBankAcNo === bankAccNum && item.custNumber === custNum)) || {};
        dispatch({ type: SET_SELECTED_CUSTOMER, data: findCustomerObj || {} });
        // const { custBankAcNo, custNumber } = findCustomerObj;
        // const reqBody = {
        //     searchBeneficiary: {
        //         accountNumber: custBankAcNo,
        //         customerNumber: custNumber
        //     }
        // }
        // dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: true });
        // actDispatch(viewBeneDetail(reqBody, TRANS_VIEW_CUSTOMER_INFO, TRANS_VIEW_BENE_INFO_SUBTYPE, dispatch));
        navigate(`${SWIFT_PAGE}${CUSTOMERPAYMENTDATA}/${BENEROUTE}`, { state: { title: 'createCustomerInfo.title_cus', url: window.location.pathname } });
    }

    const onConfirmOk = () => {
        if (confirmationMode === 'DeleteCustomer') {
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: true });
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: ACTIONS_MODE[3] })
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: false })

            const reqBody = {
                custInfo: [{ ...selectedCustomer, actionCode: 'D', status: 'PENDING', comment: '' }],
                message: `Customer : ${selectedCustomer.custName} <AccNo : ${selectedCustomer.custBankAcNo} | CustNo: ${selectedCustomer.custNumber}> delete request was submitted for approval.`
            }
            actDispatch(CustomerMaintainance(reqBody, transactionSubtype, snackBarActionPaymentInfo, dispatch, ACTIONS_MODE[3]));
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
        }
    }

    const onConfirmCancel = () => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: false })
    }

    return (
        <>
            <Divider className="divider" ><h5>{customerInfoList.length} CUSTOMER PAYMENT DATA FOUND</h5></Divider>
            <Stack direction="row" gap={1} sx={{ width: '100%', justifyContent: 'flex-end', marginBottom: 2 }}>
                <MbButton variant={'outlined'} startIcon={<Add />} buttonName={<h5>ADD</h5>} onHandleAction={onHandleAddCustDialog}/>
                {
                    customerInfoList && customerInfoList.length > 0 &&
                     <MbButton variant={'outlined'} startIcon={<Refresh />} buttonName={<h5>refresh</h5>} onHandleAction={onHandleRefresh}/>
                }
            </Stack>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>Status</StyledTableCell>
                            <StyledTableCell>Bank Account Number</StyledTableCell>
                            <StyledTableCell>Customer Number</StyledTableCell>
                            <StyledTableCell>Customer Name</StyledTableCell>
                            <StyledTableCell>Updated Date (UTC)</StyledTableCell>
                            <StyledTableCell>Updated By</StyledTableCell>
                            <StyledTableCell>Actions</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {customerInfoList && customerInfoList.length > 0 && customerInfoList.map((item, key) => {
                            return (
                                <StyledTableRow tabIndex={-1} key={key}>
                                    <StyledTableCell scope="row" align="left">
                                        <span style={{ color: `${(item.status.toLowerCase() === PENDING_STATUS ? 'red' : 'green')}` }}>
                                            <b>{String(item.status).toLocaleUpperCase()}</b></span></StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.custBankAcNo}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.custNumber}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.custName}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.updatedDt}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.updatedBy}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">
                                        <Stack direction="row" gap={1} >
                                            <Link
                                                component="button"
                                                variant="body2"
                                                onClick={(e) => onHandleViewCustDialog(item.custBankAcNo, item.custNumber)}                                            >
                                                View
                                            </Link>
                                            {
                                                (item.status.toLowerCase() === APPROVED_STATUS || (item.status.toLowerCase() === RETURNED_STATUS
                                                    && (userLogin !== item.updatedBy || userGroupId === COUNTRY_ADMIN_ROLE))) && (
                                                    <>
                                                        <h3>|</h3>
                                                        <Link
                                                            component="button"
                                                            variant="body2"
                                                            onClick={(e) => onHandleEditCustDialog(item.custBankAcNo, item.custNumber)}
                                                        >
                                                            Edit
                                                        </Link>
                                                        <h3>|</h3>
                                                        <Link
                                                            component="button"
                                                            variant="body2"
                                                            onClick={(e) => onHandleDeleteCustDialog(item.custBankAcNo, item.custNumber)}
                                                        >
                                                            Delete
                                                        </Link>
                                                    </>
                                                )
                                            }
                                            <h3>|</h3>
                                            <Link
                                                component="button"
                                                variant="body2"
                                                onClick={(e) => onHandleManageBene(item.custBankAcNo, item.custNumber)}
                                            >
                                                Manage Beneficiary
                                            </Link>
                                        </Stack>
                                    </StyledTableCell>
                                </StyledTableRow>
                            )
                        }
                        )}
                        {customerInfoList && customerInfoList.length === 0 && (
                            <TableRow sx={{
                                height: 53,
                            }}>
                                <StyledTableCell colSpan={7}>
                                    <Typography sx={{ display: 'flex', justifyContent: 'center' }}>
                                        <FormattedMessage id="viewTransactions.noRecords" defaultMessage={defaultLocales['viewTransactions.noRecords']} />
                                    </Typography>
                                </StyledTableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </TableContainer>
            {openDialog && <CustBeneModalDialog state={state} dispatch={dispatch} />}
            {openConfirmationDialog && <ConfirmationDialog openDialog={openConfirmationDialog} onHandleOk={onConfirmOk} onHandleCancel={onConfirmCancel} dialogContent={dialogContent} />}
        </>
    )
}