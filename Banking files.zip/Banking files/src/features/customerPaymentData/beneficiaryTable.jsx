import { FormattedMessage } from "react-intl";
import {  useSelector } from "react-redux";
import { memo, useContext} from "react";
import { Typography, Stack, Link, TableContainer, Table, TableHead, TableBody, TableRow } from "@mui/material";

import { defaultLocales } from "../i18n"
import { getUserInfo } from "../login/loginSlice";
import { ACTIONS_MODE } from "../../constants/constants";
import { COUNTRY_ADMIN_ROLE } from "../../constants/transactionConstants";
import { StyledTableCell, StyledTableRow } from '../viewTransactions/helpers';
import { SELECTED_BENEFICIARY, SET_BIND_PROPERTY, CustomerContext } from "./customerReducer";
import { APPROVED_STATUS, PENDING_STATUS, RETURNED_STATUS } from "../../constants/customerDataConstants";

const BenefiaryTable = memo(({beneficiaryInfoList = []}) => {
    const getUserDetail = useSelector(getUserInfo);
    const {dispatch } = useContext(CustomerContext);
    const { userLogin = '', userUserGroups: [{ userGroupId = '' } = {}] = [] } = getUserDetail || {};
    
    const onHandleViewBeneDialog = (bankAccNum, name, beneIbanNumber) => {
        const findBeneObj = beneficiaryInfoList.find(item => (item.beneAcNo === bankAccNum && item.beneAcName === name && item.beneIbanNumber === beneIbanNumber)) || {};
        dispatch({ type: SELECTED_BENEFICIARY, valueData: findBeneObj || {}, beneMode: 'view' })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: ACTIONS_MODE[5] })
    }
    const onHandleEditBeneDialog = (bankAccNum, name, beneIbanNumber) => {
        const findBeneObj = beneficiaryInfoList.find(item => (item.beneAcNo === bankAccNum && item.beneAcName === name && item.beneIbanNumber === beneIbanNumber)) || {};
        dispatch({ type: SELECTED_BENEFICIARY, valueData: findBeneObj || {}, beneMode: 'edit' })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'actionsMode', value: ACTIONS_MODE[6] })
    }

    const onHandleDeleteBeneDialog = (bankAccNum, name, beneIbanNumber) => {
        const findBeneObj = beneficiaryInfoList.find(item => (item.beneAcNo === bankAccNum && item.beneAcName === name && item.beneIbanNumber === beneIbanNumber)) || {};
        dispatch({ type: SELECTED_BENEFICIARY, valueData: findBeneObj || {}, beneMode: 'delete' })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'dialogContent', value: 'Are you sure you want to delete this beneficiary?' })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'confirmationMode', value: 'DeleteBeneficiary' })
    }

    return (
        <>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>Status</StyledTableCell>
                            <StyledTableCell>Account Number</StyledTableCell>
                            <StyledTableCell>Beneficiary Name</StyledTableCell>
                            <StyledTableCell>BIC</StyledTableCell>
                            <StyledTableCell>IBAN</StyledTableCell>
                            <StyledTableCell>Sort Code</StyledTableCell>
                            <StyledTableCell>Updated Date (UTC)</StyledTableCell>
                            <StyledTableCell>Updated By</StyledTableCell>
                            <StyledTableCell>Actions</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {beneficiaryInfoList && beneficiaryInfoList.length > 0 && beneficiaryInfoList.sort((a, b) => {
                            if (a.status.toLowerCase() === 'pending' && b.status.toLowerCase() !== 'pending') return -1;
                            if (a.status.toLowerCase() !== 'pending' && b.status.toLowerCase() === 'pending') return 1;
                        }).map((item, key) => {
                            return (
                                <StyledTableRow tabIndex={-1} key={key}>
                                    <StyledTableCell scope="row" align="left">
                                        <span style={{ color: `${(String(item.status).toLowerCase() === PENDING_STATUS ? 'red' : 'green')}` }}>
                                            <b>{String(item.status).toLocaleUpperCase()}</b></span></StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.beneAcNo || '-'}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.beneAcName}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.beneBicCode}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.beneIbanNumber || '-'}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.beneSortCode || '-'}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.updatedDt}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">{item.updatedBy}</StyledTableCell>
                                    <StyledTableCell scope="row" align="left">
                                        <Stack direction="row" gap={1} >
                                            <Link
                                                component="button"
                                                variant="body2"
                                                onClick={(e) => onHandleViewBeneDialog(item.beneAcNo, item.beneAcName, item.beneIbanNumber)}                                            >
                                                View
                                            </Link>
                                            {
                                                (item.status.toLowerCase() === APPROVED_STATUS ||
                                                    (item.status.toLowerCase() === RETURNED_STATUS
                                                        && (userLogin !== item.updatedBy || userGroupId === COUNTRY_ADMIN_ROLE)))
                                                && (
                                                    <>
                                                        <h3>|</h3>
                                                        <Link
                                                            component="button"
                                                            variant="body2"
                                                            onClick={(e) => onHandleEditBeneDialog(item.beneAcNo, item.beneAcName, item.beneIbanNumber)}
                                                        >
                                                            Edit
                                                        </Link>
                                                        <h3>|</h3>
                                                        <Link
                                                            component="button"
                                                            variant="body2"
                                                            onClick={(e) => onHandleDeleteBeneDialog(item.beneAcNo, item.beneAcName, item.beneIbanNumber)}
                                                        >
                                                            Delete
                                                        </Link>
                                                    </>
                                                )}
                                        </Stack>
                                    </StyledTableCell>
                                </StyledTableRow>
                            )
                        }
                        )}
                        {beneficiaryInfoList && beneficiaryInfoList.length === 0 && (
                            <TableRow sx={{
                                height: 53,
                            }}>
                                <StyledTableCell colSpan={9}>
                                    <Typography sx={{ display: 'flex', justifyContent: 'center' }}>
                                        <FormattedMessage id="viewTransactions.noRecords" defaultMessage={defaultLocales['viewTransactions.noRecords']} />
                                    </Typography>
                                </StyledTableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </TableContainer>
        </>
    )
})
export default BenefiaryTable;