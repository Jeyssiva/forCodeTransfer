import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux"
import { FormattedMessage } from "react-intl"
import Autocomplete from '@mui/material/Autocomplete';
import { Grid, Typography, Divider } from "@mui/material"

import { defaultLocales } from "../i18n"
import MbDropdown from "../common/mbDropdown"
import MbTextField from "../common/mbTextField"
import { CASE_TYPES } from "../../constants/mxTempConstants"
import { ADDRESS_TYPES } from "../../constants/customerDataConstants";
import { getCountryListPersist } from "../showMxTemplateAsTreeView/persistedSlice";
import { bindPaymentDataStaticList } from "../dashboard/dashboardActions";

export default function PostalAddress({ errors, item, actionsMode, parentName, onHandleChange, setFieldValue }) {
    const loadCountryList = useSelector(getCountryListPersist);
    const actDispatch = useDispatch();

    const { dept, subDept, streetName, buildingNo, buildingName, floor, postBox, room, postCode, townName, townLocName, 
        districtName, countrySubDv, country, addressType, countryName } = item;
    const isViewMode = actionsMode.search(/view/) !== -1;

    // Fetch the Country list from Database
    useEffect(() => {
        if(loadCountryList.length === 0 && (actionsMode.search(/edit/) !== -1  || actionsMode.search(/add/) !== -1)){        
            const dReqBody = {
                ddListType: "GBR_COUNTRY_LIST",
                dropDownListKey1: "",
                dropDownListKey2: ""
            }
            actDispatch(bindPaymentDataStaticList(dReqBody))
        }
    }, [])

    const onCountryInputChange = (value) => {
        setFieldValue(`${parentName}.country`, value?.code);
    }

    return (
        <>
            <Grid item xs={4} md={12} >
                <Divider sx={{ width: '100%', margin: 2 }}>
                    <Typography component={'span'} variant="body1" textTransform={"uppercase"}>
                        <b><FormattedMessage id="createCustomerInfo.postalAddress" defaultMessage={defaultLocales["createCustomerInfo.postalAddress"]} /></b>
                    </Typography>
                </Divider>
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Address Type */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.addressType"
                        defaultMessage={defaultLocales["createCustomerInfo.addressType"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbDropdown name={`${parentName}.addressType`} fullWidth size={"small"}
                    labelValue={addressType || ''} dropdownList={ADDRESS_TYPES}
                    onDropdownChange={onHandleChange}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Room number */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.roomNum"
                        defaultMessage={defaultLocales["createCustomerInfo.roomNum"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    id={`${parentName}.room`}
                    name={`${parentName}.room`}
                    size={"small"}
                    value={room || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    onChange={onHandleChange}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.room : errors.addressInfo?.room) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.room : errors.addressInfo?.room)}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            {/* Post box */}
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.postBox"
                        defaultMessage={defaultLocales["createCustomerInfo.postBox"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.postBox`}
                    size={"small"}
                    value={postBox || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.postBox : errors.addressInfo?.postBox) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.postBox : errors.addressInfo?.postBox)}
                />
            </Grid>
            {/* Floor */}
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.floor"
                        defaultMessage={defaultLocales["createCustomerInfo.floor"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.floor`}
                    size={"small"}
                    value={floor || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.floor : errors.addressInfo?.floor) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.floor : errors.addressInfo?.floor)}
                />
            </Grid>
            {/* Building Number */}
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.buildingNum"
                        defaultMessage={defaultLocales["createCustomerInfo.buildingNum"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.buildingNo`}
                    size={"small"}
                    value={buildingNo || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.buildingNo : errors.addressInfo?.buildingNo) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.buildingNo : errors.addressInfo?.buildingNo)}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Building Name */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.buildingName"
                        defaultMessage={defaultLocales["createCustomerInfo.buildingName"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.buildingName`}
                    size={"small"}
                    value={buildingName || ''}
                    multiline rows = {2}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.buildingName : errors.addressInfo?.buildingName) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.buildingName : errors.addressInfo?.buildingName)}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Street Name */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.streetName"
                        defaultMessage={defaultLocales["createCustomerInfo.streetName"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.streetName`}
                    size={"small"}
                    value={streetName || ''}
                    placeholder={'-'}
                    multiline rows = {3}
                    caseType={CASE_TYPES.uppercase}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.streetName : errors.addressInfo?.streetName) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.streetName : errors.addressInfo?.streetName)}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Town name */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.townName"
                        defaultMessage={defaultLocales["createCustomerInfo.townName"]}>
                        {msg => (
                            <span>
                                {msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.townName`}
                    size={"small"}
                    value={townName || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.townName : errors.addressInfo?.townName)}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.townName : errors.addressInfo?.townName) ? true : false}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                    maxLength={35}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Town Location Name */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.townLocName"
                        defaultMessage={defaultLocales["createCustomerInfo.townLocName"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.townLocName`}
                    size={"small"}
                    value={townLocName || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.townLocName : errors.addressInfo?.townLocName) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.townLocName : errors.addressInfo?.townLocName)}
                    onChange={onHandleChange}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* District Name */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.districtName"
                        defaultMessage={defaultLocales["createCustomerInfo.districtName"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.districtName`}
                    size={"small"}
                    value={districtName || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.districtName : errors.addressInfo?.districtName) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.districtName : errors.addressInfo?.districtName)}
                    onChange={onHandleChange}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Post Code */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.postCode"
                        defaultMessage={defaultLocales["createCustomerInfo.postCode"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.postCode`}
                    size={"small"}
                    maxLength={16}
                    placeholder={'-'}
                    value={postCode || ''}
                    onChange={onHandleChange}
                    caseType={CASE_TYPES.uppercase}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.postCode : errors.addressInfo?.postCode) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.postCode : errors.addressInfo?.postCode)}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Country */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.country"
                        defaultMessage={defaultLocales["createCustomerInfo.country"]}>
                        {msg => (
                            <span>
                                {msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                {
                    isViewMode ? 
                    <MbTextField
                        name={`${parentName}.countryName`}
                        size={"small"}
                        placeholder={'-'}
                        value={countryName || ''}
                        disabled={true}
                        variant={'standard'}
                    />
                    : <Autocomplete
                        freeSolo
                        id={`${parentName}.country`}
                        name={`${parentName}.country`}
                        options={loadCountryList}
                        size={"small"}
                        getOptionLabel={(option) => option["description"] || ""}
                        isOptionEqualToValue={(option, value) => option["code"] === value["code"] || ""}
                        onChange={(e, value) => onCountryInputChange(value)}
                        value={loadCountryList.find(c => c?.code === country) || ""}
                        renderOption={(props, option) => {
                            return (
                                <li {...props} key={option.code} value={option.code} >{option.description}</li>
                            )
                        }}
                        renderInput={(params) => {
                            return <MbTextField {...params}
                                variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                                inputProps={{ ...params.inputProps, style: { textTransform: "uppercase" } }}
                                error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.country : errors.addressInfo?.country) ? true : false}
                                helperText={(actionsMode.search(/bene/) !== -1 ? String(errors?.benAddressInfo?.country || '').toUpperCase() || '' : String(errors.addressInfo?.country || '').toUpperCase())}
                            />
                        }}
                        disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    />
                }
                
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Country SubDivision */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.countrySubDivision"
                        defaultMessage={defaultLocales["createCustomerInfo.countrySubDivision"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.countrySubDv`}
                    size={"small"}
                    value={countrySubDv || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.countrySubDv : errors.addressInfo?.countrySubDv) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.countrySubDv : errors.addressInfo?.countrySubDv)}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Department */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.department"
                        defaultMessage={defaultLocales["createCustomerInfo.department"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.dept`}
                    size={"small"}
                    value={dept || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.dept : errors.addressInfo?.dept) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.dept : errors.addressInfo?.dept)}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                {/* Sub Department */}
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.subDepartment"
                        defaultMessage={defaultLocales["createCustomerInfo.subDepartment"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6} >
                <MbTextField
                    name={`${parentName}.subDept`}
                    size={"small"}
                    value={subDept || ''}
                    placeholder={'-'}
                    caseType={CASE_TYPES.uppercase}
                    error={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.subDept : errors.addressInfo?.subDept) ? true : false}
                    helperText={(actionsMode.search(/bene/) !== -1 ? errors?.benAddressInfo?.subDept : errors.addressInfo?.subDept)}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    onChange={onHandleChange}
                />
            </Grid>
        </>
    )
}