import React from "react"
import { FormattedMessage } from "react-intl"
import { Divider, Grid, Typography } from "@mui/material"

import { defaultLocales } from "../i18n"
import PostalAddress from "./postalAddress"
import MbTextField from "../common/mbTextField"
import { CASE_TYPES } from "../../constants/mxTempConstants"

export default function BeneficiaryDetailsForm({ errors, item, actionsMode, onHandleChange, selectedBene, setFieldValue }) {

    const { status, beneAcNo, beneAcName, beneBicCode, beneLeiCode, beneSortCode, beneIbanNumber, benAddressInfo, comment, updatedBy } = item;
    const [disabledFields, setDisabledFields] = React.useState({ beneIbanNumber: beneIbanNumber, beneAcNo: beneAcNo, beneSortCode: beneSortCode, beneBicCode: beneBicCode });

    return (
        <Grid container spacing={1} columns={{ xs: 4, sm: 4, md: 12 }} direction="row">
            <Grid item xs={4} md={12} >
                <Divider sx={{ width: '100%', margin: 2 }}>
                    <Typography component={'span'} variant="body1" textTransform={"uppercase"}>
                        <b>
                            <FormattedMessage id={`createCustomerInfo.beneficiary`} defaultMessage={defaultLocales[`createCustomerInfo.beneficiary`]}>
                                {msg => (
                                    <span>
                                        {msg}
                                    </span>
                                )}
                            </FormattedMessage>
                        </b>
                    </Typography>
                </Divider>
            </Grid>
            {(actionsMode.search(/view/) !== -1) && (
                <>
                    <Grid item xs={2} md={6} >
                        <Typography component={'span'} variant="body2">
                            <FormattedMessage id="createCustomerInfo.status"
                                defaultMessage={defaultLocales["createCustomerInfo.status"]}>
                                {msg => (
                                    <span>
                                        {msg}
                                    </span>
                                )}
                            </FormattedMessage>
                        </Typography>
                    </Grid>
                    <Grid item xs={2} md={6} >
                        <MbTextField
                            id="status"
                            name="status"
                            size={"small"}
                            value={status || ''} placeholder={"-"}
                            disabled={actionsMode.search(/view/) !== -1 ? true : false}
                            variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                        />
                    </Grid>
                </>
            )}
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.creditAccNumber"
                        defaultMessage={defaultLocales["createCustomerInfo.creditAccNumber"]}>
                        {msg => (
                            <span>
                                {msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField
                    id="beneAcNo"
                    name="beneAcNo"
                    size={"small"}
                    value={beneAcNo || ''}
                    placeholder={"-"}
                    maxLength={34}
                    onChange={onHandleChange}
                    helperText={errors.beneAcNo}
                    error={errors.beneAcNo ? true : false}
                    disabled={actionsMode.search(/view/) !== -1
                        // || (actionsMode.search(/edit/) !== -1 && disabledFields.beneAcNo) 
                        ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6} >
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.creditName"
                        defaultMessage={defaultLocales["createCustomerInfo.creditName"]}>
                        {msg => (
                            <span>
                                {msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id="beneAcName" name="beneAcName" size={"small"} value={beneAcName || ''} placeholder={"-"}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false} onChange={onHandleChange}
                    helperText={errors.beneAcName} error={errors.beneAcName ? true : false} maxLength={140}
                    multiline rows = {6} caseType={CASE_TYPES.uppercase} 
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'} />
            </Grid>
            <Grid item xs={2} md={6}>
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.bic"
                        defaultMessage={defaultLocales["createCustomerInfo.bic"]}>
                        {msg => (
                            <span>
                                OTHERS: {msg}<span style={{ color: 'red' }}>*</span>
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id={"beneBicCode"} name={"beneBicCode"} size={"small"}
                    value={beneBicCode || ''} placeholder={"-"} caseType={CASE_TYPES.uppercase}
                    onTextFieldChange={null} onChange={onHandleChange} maxLength={11}
                    helperText={errors.beneBicCode} error={errors.beneBicCode ? true : false}
                    disabled={actionsMode.search(/view/) !== -1 
                       // || (actionsMode.search(/edit/) !== -1 && disabledFields.beneBicCode)
                        ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6}>
                <Typography component={'span'} variant="body2">
                    <FormattedMessage id="createCustomerInfo.lei"
                        defaultMessage={defaultLocales["createCustomerInfo.lei"]}>
                        {msg => (
                            <span>
                                &emsp;&emsp;&emsp;&emsp;&nbsp;{msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id={"beneLeiCode"} name={"beneLeiCode"} size="small"
                    value={beneLeiCode || ''} placeholder={"-"} caseType={CASE_TYPES.uppercase}
                    onTextFieldChange={null} onChange={onHandleChange}
                    disabled={actionsMode.search(/view/) !== -1 ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                    helperText={errors.beneLeiCode} error={errors.beneLeiCode ? true : false}
                />
            </Grid>
            <Grid item xs={2} md={6}>
                <Typography component={'span'} variant="body1">
                    <FormattedMessage id="createCustomerInfo.iban"
                        defaultMessage={defaultLocales["createCustomerInfo.iban"]}>
                        {msg => (
                            <span>
                                &emsp;&emsp;&emsp;&ensp;{msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id={"beneIbanNumber"} name={"beneIbanNumber"} size={"small"}
                    value={beneIbanNumber || ''} placeholder={"-"} caseType={CASE_TYPES.uppercase}
                    onTextFieldChange={onHandleChange}
                    helperText={errors.beneIbanNumber} error={errors.beneIbanNumber ? true : false}
                    disabled={actionsMode.search(/view/) !== -1
                        // || (actionsMode.search(/edit/) !== -1 && disabledFields.beneIbanNumber) 
                        ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <Grid item xs={2} md={6}>
                <Typography component={'span'} variant="body1">
                    <FormattedMessage id="createCustomerInfo.sortCode"
                        defaultMessage={defaultLocales["createCustomerInfo.sortCode"]}>
                        {msg => (
                            <span>
                                &emsp;&emsp;&emsp;&ensp;{msg}
                            </span>
                        )}
                    </FormattedMessage>
                </Typography>
            </Grid>
            <Grid item xs={2} md={6}>
                <MbTextField id={"beneSortCode"} name={"beneSortCode"} size={"small"}
                    value={beneSortCode || ''} placeholder={"-"} caseType={CASE_TYPES.uppercase}
                    onTextFieldChange={null} onChange={onHandleChange}
                    helperText={errors.beneSortCode} error={errors.beneSortCode ? true : false}
                    disabled={actionsMode.search(/view/) !== -1
                        // || (actionsMode.search(/edit/) !== -1 && disabledFields.beneSortCode) 
                        ? true : false}
                    variant={actionsMode.search(/view/) !== -1 ? 'standard' : 'outlined'}
                />
            </Grid>
            <PostalAddress
                errors={errors}
                item={benAddressInfo}
                actionsMode={actionsMode}
                parentName={'benAddressInfo'}
                onHandleChange={onHandleChange}
                setFieldValue={setFieldValue}
            />
            {(actionsMode.search(/actions/) !== -1) && (
                <>
                    <Grid item xs={2} md={6}>
                        <Typography component={'span'} variant="body2">
                            <FormattedMessage id="createCustomerInfo.updatedBy"
                                defaultMessage={defaultLocales["createCustomerInfo.updatedBy"]}>
                                {msg => (
                                    <span>
                                        {msg}
                                    </span>
                                )}
                            </FormattedMessage>
                        </Typography>
                    </Grid>
                    <Grid item xs={2} md={6}>
                        <MbTextField id={"updatedBy"} name={"updatedBy"} size={"small"}
                            value={updatedBy || ''}
                            caseType={CASE_TYPES.uppercase}
                            helperText={errors.updatedBy}
                            onTextFieldChange={null}
                            disabled={true}
                            variant={'standard'}
                        />
                    </Grid>
                </>
            )}
            {(actionsMode.search(/view/) !== -1) && (
                <Grid item xs={4} md={12}>
                    <MbTextField
                        id="comment"
                        name="comment"
                        label="Comment By Authorisers"
                        margin="normal"
                        multiline
                        disabled={true}
                        maxRows={5}
                        value={comment || "-"}
                        variant="filled"
                    />
                </Grid>
            )}
        </Grid>
    )
}