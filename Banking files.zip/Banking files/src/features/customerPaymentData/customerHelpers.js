import _ from "lodash";
import { BENE_ACC_NAME_PATTERN, BENE_ACC_NUMBER, BENE_ACC_NUMBER_PATTERN, BENE_IBAN_PATTERN, BENE_NAME } from "../../constants/customerDataConstants";

export const addressExceptions = ['addressPk', 'custInfofk', 'beneInfofk', 'createdBy', 'updatedBy'];

export const customerExceptions = ['actionCode', 'custInfoPk', 'createdBy', 'updatedBy', 'custSrcCountry', 'label', 'value']

export function areOtherPropertiesEmpty(obj, exceptions) {
    return Object.keys(obj).every(key => 
        exceptions.includes(key) || !obj[key]
    );
}

export function arePropertiesEmpty(obj) {
    // Helper function to check if a value is considered "empty"
    function isEmpty(value) {
        return value === '' || value === 0;
    }

    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            if (key === 'addressInfo') {
                // Check properties inside addressInfo
                const addressInfo = obj[key];
                for (const addrKey in addressInfo) {
                    if (addressInfo.hasOwnProperty(addrKey)) {
                        if (!addressExceptions.includes(addrKey)) {
                            if (!isEmpty(addressInfo[addrKey])) {
                                return false;
                            }
                        }
                    }
                }
            } else if (!customerExceptions.includes(key)) {
                if (!isEmpty(obj[key])) {
                    return false;
                }
            }
        }
    }
    return true;
}

export const deepEqual = (p1, p2, excludedProps) => {
    // Helper function to compare objects while ignoring excluded properties
    const compareObjects = (obj1, obj2) => {
        for (const key in obj1) {
            if (excludedProps.includes(key)) continue; // Skip excluded properties
            
            if (typeof obj1[key] === 'object' && obj1[key] !== null) {
                // Recursively compare objects
                if (!compareObjects(obj1[key], obj2[key])) {
                    return false;
                }
            } else {
                // Compare primitive values
                if (obj1[key] !== obj2[key]) {
                    return false;
                }
            }
        }
        return true;
    };

    return compareObjects(p1, p2);
};

export function length_patternMatching (fieldName, inputValue) {
    if(fieldName === 'beneIbanNumber'){
        if(inputValue.length > 34) return { eligible: true, isMatched : false, message: 'Max 34 Chars Allowed'};
        const regex =  BENE_IBAN_PATTERN
        const isMatched = regex.test(inputValue);
        return {eligible : true, isMatched, message : 'Matches a string with exactly 2 uppercase letters, followed by 2 digits, and then 1 to 30 alphanumeric characters only.'}
    } else if(fieldName === BENE_NAME){
        if(inputValue.length > 140) return { eligible: true, isMatched : false, message: 'Max 140 Chars Allowed'};
        const digit6 = BENE_ACC_NAME_PATTERN;
        const isMatched = digit6.test(inputValue);
        return {eligible : true, isMatched, message : 'Alpha Numeric and Special characters are ,@/.-()&!+ and single space allowed only.'}
    } else if(fieldName === BENE_ACC_NUMBER){
        if(inputValue.length > 34) return { eligible: true, isMatched: false, message: 'Max 34 Chars Allowed'};
        const alphanumericspace = BENE_ACC_NUMBER_PATTERN;
        const isMatched = alphanumericspace.test(inputValue);
        return {eligible:true, isMatched, message: 'Bank Account Number must be only alphanumeric with single space and no trailing/leading spaces.'}
    }
    return {};
}

// Deep compare two objects including only specific fields using Lodash
export function deepCompareWithIncludeProperties(obj1, obj2, includeFields = []) {
    // Helper function to filter only the specified fields (including nested fields) from an object
    function pickFields(obj, includeFields) {
        if (Array.isArray(obj)) {
            return obj.map(item => pickFields(item, includeFields)); // Handle arrays
        }

        if (typeof obj === 'object' && obj !== null) {
            let result = {};
            includeFields.forEach(field => {
                const keys = field.split('.'); // Handle nested fields (e.g., 'address.name')
                let tempObj = obj;
                let tempResult = result;

                // Traverse the path of the nested field
                for (let i = 0; i < keys.length; i++) {
                    if (tempObj && tempObj[keys[i]] !== undefined) {
                        if (i === keys.length - 1) {
                            tempResult[keys[i]] = tempObj[keys[i]]; // Set value at the final key
                        } else {
                            tempResult[keys[i]] = tempResult[keys[i]] || {}; // Create the next level if it doesn't exist
                            tempResult = tempResult[keys[i]]; // Drill down
                        }
                        tempObj = tempObj[keys[i]];
                    }
                }
            });
            return result;
        }

        return obj; // If it's a primitive value, return it as is
    }

    // Clone the objects and filter them based on includeFields
    const cleanedObj1 = pickFields(obj1, includeFields);
    const cleanedObj2 = pickFields(obj2, includeFields);

    // Use _.isEqual to compare the filtered objects
    return _.isEqual(cleanedObj1, cleanedObj2);
}