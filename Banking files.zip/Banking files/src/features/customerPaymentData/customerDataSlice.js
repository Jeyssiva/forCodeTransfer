import { createSelector, createSlice } from "@reduxjs/toolkit";
import { CREATE_CUSTOMER_TRANSATIONS } from "../../constants/sliceConstants";

export const customerInitialState = {
    snackBarPaymentTrans : {},
    loaderStatus: false,
    refreshStateRequired: false
}

const paymentInfoSlice = createSlice({
    name: CREATE_CUSTOMER_TRANSATIONS,
    initialState : customerInitialState,
    reducers: {
        snackBarActionPaymentInfo(state, action) {
            state.snackBarPaymentTrans = { ...action.payload };
        },
        updateRefreshStateRequired(state, action) {
            state.refreshStateRequired = action.payload.status;
        }
    }
})

export const {
    snackBarActionPaymentInfo,
    updateRefreshStateRequired
} = paymentInfoSlice.actions;

const loadStatus = state => state[CREATE_CUSTOMER_TRANSATIONS].loaderStatus;
const snack = state => state[CREATE_CUSTOMER_TRANSATIONS].snackBarPaymentTrans;
const refreshState = state => state[CREATE_CUSTOMER_TRANSATIONS].refreshStateRequired;

export const getLoadStatus = createSelector(loadStatus, (status) => status);
export const getSnackBarPaymentInfo = createSelector(snack, (s) => s);
export const getRefreshStateRequired = createSelector(refreshState, r => r);

export default paymentInfoSlice.reducer;