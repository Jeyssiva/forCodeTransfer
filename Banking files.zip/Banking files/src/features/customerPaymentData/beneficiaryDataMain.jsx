import { Box } from "@mui/material";
import {  useContext, useEffect } from 'react';
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import LoadingViewer from "../loadingViewer";
import MbSnackbar from "../common/mbSnackbar";
import MbBreadCrumbs from "../common/mbBreadcrumbs";
import BeneficiaryInfoList from './beneficiaryInfoList';
import { CustomerContext } from "./customerReducer";
import { getSnackBarPaymentInfo, snackBarActionPaymentInfo, updateRefreshStateRequired } from "./customerDataSlice";

export default function BeneficiaryDataMain() {
    const location = useLocation();
    const actDispatch = useDispatch();
    const { state, dispatch } = useContext(CustomerContext);
    const snackBarPropertiesPayment = useSelector(getSnackBarPaymentInfo);
    const { loadingStatus } = state;

    /**
     * Avoid to reset the customerReducer state values if bene page.
     */
    useEffect(() => {
        updateRefreshStateRequired({status : false});
    }, [])
   
    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        actDispatch(snackBarActionPaymentInfo({ open: false, severity: '', snackBarMessage: '' }));
    }

    return (
        <>
            <LoadingViewer loading={loadingStatus}>
                <MbBreadCrumbs crumbsList={[location.state, { title: 'createCustomerInfo.title_bene' }]} />
                <h6>This module keeps mandatory beneficiary's information required for SWIFT ISO20022 incoming or outgoing payments.</h6>
                <Box className="box">
                    {/* <h3>Beneficiary Payment Data</h3> */}
                    <BeneficiaryInfoList/>
                </Box>
            </LoadingViewer>
            <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesPayment.open}
                severity={snackBarPropertiesPayment.severity}
                message={snackBarPropertiesPayment.snackBarMessage} />
        </>
    )
}