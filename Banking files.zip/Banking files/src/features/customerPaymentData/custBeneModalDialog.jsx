import React from "react";
import * as Yup from "yup";
import { isEmpty } from "lodash";
import { Formik, Form } from 'formik';
import { FormattedMessage } from "react-intl";
import ErrorIcon from '@mui/icons-material/Error';
import { CloseOutlined } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { Grid, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Typography, Tooltip } from "@mui/material"

import { defaultLocales } from "../i18n"
import MbButton from "../common/mbButton";
import MbTextField from "../common/mbTextField";
import { getApacheEnvs, getUserInfo } from "../login/loginSlice";
import ConfirmationDialog from "./confirmationDialog";
import CustomerDetailsForm from "./customerDetailsForm";
import { CustomerMaintainance } from "./customerDataAction";
import { CASE_TYPES } from "../../constants/mxTempConstants";
import BeneficiaryDetailsForm from "./beneficiaryDetailsForm";
import { SubmitPendingApprovalDtl } from "./customerDataAction";
import { snackBarActionPaymentInfo } from "./customerDataSlice";
import { initialState, SET_BIND_PROPERTY } from "./customerReducer";
import { deepCompareWithIncludeProperties } from "./customerHelpers";
import { ACTIONS_MODE, sessionItems } from "../../constants/constants";
import { COUNTRY_ADMIN_ROLE } from "../../constants/transactionConstants";
import { closeTxnDtlPopupAndUpdateVTxnList } from "../viewTransactions/viewTransactionSlice";
import { INCLUDE_ADDRESS_FIELDS, INCLUDE_BENE_FIELDS_DEEP_COMPARE, INCLUDE_CUSTOMER_FIELDS_DEEP_COMPARE } from "../../constants/createPaymentConstants";
import { ADDRESS_PATTERN, BENE_ACC_NAME_PATTERN, BENE_ACC_NUMBER_PATTERN, BENE_IBAN_PATTERN, CUST_BANK_ACC_NUM_PATTERN, CUST_NAME_PATTERN, CUST_SHORT_NAME_PATTERN } from "../../constants/customerDataConstants";

export default function CustBeneModalDialog({ state = initialState, dispatch }) {
    const actDispatch = useDispatch();
    const getUserDetail = useSelector(getUserInfo);
    const apacheEnvConfig = useSelector(getApacheEnvs);

    const [comment, setComment] = React.useState("");
    const { userLogin = '', userUserGroups: [{ userGroupId = '' } = {}] = [] } = getUserDetail || {};
    const { openConfirmationDialog, dialogTitle, dialogContent, confirmationMode, actionsMode,
        openDialog, selectedCustomer, selectedBeneficiary, transactionSubtype, refreshPending, foundCustomerForNavigation } = state;

    const item = React.useMemo(() => {
        if (actionsMode.search(/cust/) === 0) return selectedCustomer;
        else return selectedBeneficiary;
    }, [actionsMode])

    const generateActionsMode = () => {
        if (actionsMode.search(/editadd/) !== -1) {
            if (foundCustomerForNavigation) return 'U'
            else return 'A'
        }
        if (actionsMode.search(/add/) !== -1) return 'A';
        if (actionsMode.search(/edit/) !== -1) return 'U';
        if (actionsMode.search(/delete/) !== -1) return 'D';
    }

    const handleClose = () => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: false })
        if(actionsMode === ACTIONS_MODE[10]){
            actDispatch(closeTxnDtlPopupAndUpdateVTxnList())
        }
    }

    const onFormSubmit = async (values) => {
        try {
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });

            let myParams = {};
            let mySuccessMsg = '';
            const myValues = values;

            if (actionsMode.search(/cust/) !== -1) {
                const mapAddressInfo = INCLUDE_ADDRESS_FIELDS.map(a => `addressInfo.${a}`);
                const deepCompare = deepCompareWithIncludeProperties(values, selectedCustomer, [...INCLUDE_CUSTOMER_FIELDS_DEEP_COMPARE, ...mapAddressInfo]);
                //No need to consider deep comparison if it is from navigation
                if (deepCompare && actionsMode !== ACTIONS_MODE[10]) {
                    actDispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: 'Please make some changes in customer page for submission' }));
                    return;
                }

                delete myValues.status;
                delete myValues.label;
                delete myValues.value;
                delete myValues.beneInfo;
                delete myValues.createdBy;
                delete myValues.createdDt;
                delete myValues.updatedBy;
                delete myValues.updatedDt;
                delete myValues.addressInfo.beneInfofk;
                delete myValues.addressInfo.createdBy;
                delete myValues.addressInfo.createdDt;
                delete myValues.addressInfo.updatedBy;
                delete myValues.addressInfo.updatedDt;

                myParams = {
                    ...myValues,
                    status: "PENDING",
                    custName: String(myValues.custName).toUpperCase(),
                    shortName: String(myValues.shortName).toUpperCase(),
                    actionCode: generateActionsMode(),
                    comment: '',
                    ...(actionsMode.search(/add/) !== -1) && { custSrcCountry: sessionStorage.getItem(sessionItems.CountryCode) },
                }

                mySuccessMsg = `Customer information : ${myValues.custName} <AccNo : ${myValues.custBankAcNo}> | CustNo: ${myValues.custNumber}> ${(actionsMode.search(/editadd/) === 0) ? 'edit/add' : actionsMode.split("_")[1]} request was submitted for approval.`;

            } else if (actionsMode.search(/bene/) !== -1) {
                if (actionsMode.search(/bene_edit/) !== -1) {
                    const mapAddressInfo = INCLUDE_ADDRESS_FIELDS.map(a => `benAddressInfo.${a}`);
                    const deepCompare = deepCompareWithIncludeProperties(values, selectedBeneficiary, [...INCLUDE_BENE_FIELDS_DEEP_COMPARE, ...mapAddressInfo])
                    if (deepCompare) {
                        actDispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: 'Please make some changes in beneficiary page for submission' }));
                        return;
                    }
                }

                delete myValues.accBic1;
                delete myValues.accBic2;
                delete myValues.accBic3;
                delete myValues.status;
                delete myValues.addressid;
                delete myValues.createdBy;
                delete myValues.createdDt;
                delete myValues.updatedBy;
                delete myValues.updatedDt;
                delete myValues.addressInfo;
                delete myValues.benAddressInfo.custInfofk;
                delete myValues.benAddressInfo.createdBy;
                delete myValues.benAddressInfo.createdDt;
                delete myValues.benAddressInfo.updatedBy;
                delete myValues.benAddressInfo.updatedDt;

                const modifiedBeneInfo = {
                    ...myValues,
                    comment: '',
                    status: "PENDING",
                    actionCode: generateActionsMode(),
                    beneAcName: String(myValues.beneAcName).toUpperCase(),
                    beneBicCode: String(myValues.beneBicCode).toUpperCase(),
                    beneSortCode: (myValues.beneSortCode) && String(myValues.beneSortCode).toUpperCase(),
                    beneIbanNumber: (myValues.beneIbanNumber) && String(myValues.beneIbanNumber).toUpperCase(),
                    ...(actionsMode.search(/add/) !== -1) && { comment: '' },
                    ...(actionsMode.search(/add/) !== -1) && { custInfofk: selectedCustomer.custInfoPk },
                    ...(actionsMode.search(/add/) !== -1) && { srcCountry: sessionStorage.getItem(sessionItems.CountryCode) },
                    ...(actionsMode.search(/add/) !== -1) && { benAddressInfo: { ...myValues.benAddressInfo, beneInfofk: 0 } },
                }

                // const existingBeneList = (!has(selectedCustomer, 'beneInfo')) ? [] : (selectedCustomer.beneInfo.filter((item) => (item.beneAcNo !== modifiedBeneInfo.beneAcNo) && (!item.beneAcName.includes(modifiedBeneInfo.beneAcName))));
                // const newExistingBeneList = existingBeneList.map(({ accBic1, accBic2, accBic3, addressInfo, ...item }) => item);
                myParams = { ...selectedCustomer, actionCode: '', 'beneInfo': [modifiedBeneInfo] }

                mySuccessMsg = `Beneficiary information : ${myValues.beneAcName} <AccNo : ${myValues.beneAcNo || '-'} | <IBAN : ${myValues.beneIbanNumber || '-'}> ${actionsMode.split("_")[1]} request was submitted for approval.`;
            }

            const reqBody = {
                custInfo: [myParams],
                message: `${mySuccessMsg}`
            };

            actDispatch(CustomerMaintainance(reqBody, transactionSubtype, snackBarActionPaymentInfo, dispatch, actionsMode));
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
        } catch (error) {
            actDispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `${error.message}` }))
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'loadingStatus', value: false });
        }
    }

    const onHandleActionsDialog = (type) => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: true })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'dialogTitle', value: <>{type} Confirmation</> })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'dialogContent', value: <>Are you sure you want to {String(type).toUpperCase()} this {item.activityType} request?</> })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'confirmationMode', value: `${type}` })
    }

    const onConfirmOk = () => {
        if (confirmationMode === 'returned' && comment === "") {
            actDispatch(snackBarActionPaymentInfo({ open: true, severity: 'error', snackBarMessage: `Please leave the comment to proceed the request.` }))
            return;
        }

        if (confirmationMode === 'approved' || confirmationMode === 'returned') {
            const reqBody = {
                "type": item.type,
                "comment": comment || '',
                "custInfoPk": item.type === 'CUSTOMER' ? item.custInfoPk : item.custInfofk,
                "activityType": item.activityType,
                "beneficiaryPk": item.beneficiaryPk,
                "status": String(confirmationMode).toUpperCase(),
                "name": item.type === 'CUSTOMER' ? item.custName : item.beneAcName,
            }
            actDispatch(SubmitPendingApprovalDtl(reqBody, item, "CUSTOMER", "PENDINGDASHBOARD", refreshPending, dispatch));
        }
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: false })
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: false })
    }

    const onConfirmCancel = () => {
        dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openConfirmationDialog', value: false })
    }

    const getErrorMsg = (object) => {
        let newObj = {};
        const myObjList = Object.values(object);
        for (let key in myObjList) {
            if (typeof myObjList[key] === 'object' && myObjList[key] !== null) {
                for (let i in myObjList[key]) {
                    if (myObjList[key][i]) {
                        newObj = { ...newObj, [i]: myObjList[key][i] };
                    }
                }
            } else if (myObjList[key] !== newObj[key - 1]) {
                newObj = { ...newObj, [key]: myObjList[key] };
            }
        }
        return newObj;
    }

    return (
        <>
            <Formik
                initialValues={item}
                onSubmit={onFormSubmit}
                validationSchema={
                    Yup.object().shape({
                        custBankAcNo: (actionsMode.search(/cust/) !== -1) ? Yup.string().required("Bank Account Number is required.")
                            .matches(CUST_BANK_ACC_NUM_PATTERN, "Bank Account Number must be only alphanumeric and hyphen with single space and no trailing/leading spaces.")
                            .max(34, "Total maximum characters allowed was 34.") : null,
                        custNumber: (actionsMode.search(/cust/) !== -1) ? Yup.string().required("Bank Customer Number is required.")
                        .matches(/^[0-9]+$/, "Bank Customer Number must be only digits.").max(6, "Total maximum characters allowed was 6.")
                        .notOneOf([Yup.ref('gcifCode'), null], 'Same customer number and GCIF code is not allowed.') : null,
                        custName: (actionsMode.search(/cust/) !== -1) ? Yup.string().required("Customer Name is required.")
                        .matches(CUST_NAME_PATTERN, "AlphaNumeric and Special characters are /-?:().,+!#$&%*=^_'{|}~;@[]\ and double quotes with single space allowed and no trailing/leading spaces.")
                        .max(140, "Total maximum characters allowed was 140.")
                        : null,
                        shortName: (actionsMode.search(/cust/) !== -1) ? Yup.string().required("Report Name is required.")
                        .matches(CUST_SHORT_NAME_PATTERN, "AlphaNumeric and Special characters are ,@/.-()& with single space allowed and no trailing/leading spaces.")
                        .max(140, "Total maximum characters allowed was 140.")
                        : null,
                        gcifCode: (actionsMode.search(/cust/) !== -1) ? Yup.string().required("GCIF code is required.")
                        .test('no-leading-trailing-spaces', 'Trailing & Leading Spaces Not allowed', value => value === value?.trim())
                        .notOneOf([Yup.ref('custNumber'), null], 'Same customer number and GCIF code is not allowed.') : null,
                        custId: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                        .test('no-leading-trailing-spaces', 'Trailing & Leading Spaces Not allowed', value => !value || value === value.trim())
                        .nullable() : null,
                        leiCode: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(20, "Total maximum characters allowed was 20.")
                        .test('no-leading-trailing-spaces', 'Trailing & Leading Spaces Not allowed', value => !value || value === value.trim())
                        .nullable() : null,
                        addressInfo: Yup.object().shape({
                            country: (actionsMode.search(/cust/) !== -1) ? Yup.string().required("Country is required.") : null,
                            townName: (actionsMode.search(/cust/) !== -1) ? Yup.string().required("Town name is required.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .max(35, "Total maximum characters allowed was 35.") : null,
                            dept: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            subDept: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            streetName: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            buildingNo: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(16, "Total maximum characters allowed was 16.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            buildingName: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            floor: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            postBox: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(16, "Total maximum characters allowed was 16.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            room: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            postCode: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(16, "Total maximum characters allowed was 16.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            townLocName: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            districtName: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            countrySubDv: (actionsMode.search(/cust/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                        }),
                        beneAcNo: (actionsMode.search(/bene/) !== -1) ? Yup.string().when(['beneIbanNumber'], {
                            is: (beneIbanNumber) => isEmpty(beneIbanNumber),
                            then: (schema) => schema.required('Either Bank Account Number or IBAN is required.'),
                            otherwise: (schema) => schema.optional().nullable()
                        }).max(34, "Total maximum characters allowed was 34.")
                            .matches(BENE_ACC_NUMBER_PATTERN, "Bank Account Number must be only alphanumeric with single space and no trailing/leading spaces.")
                            : null,
                        beneIbanNumber: (actionsMode.search(/bene/) !== -1) ? Yup.string().when(['beneAcNo'], {
                            is: (beneAcNo) => isEmpty(beneAcNo),
                            then: (schema) => schema.required('Either Bank Account Number or IBAN is required.'),
                            otherwise: (schema) => schema.optional().nullable()
                        }).matches(BENE_IBAN_PATTERN, "Matches a string with exactly 2 uppercase letters, followed by 2 digits, and then 1 to 30 alphanumeric characters and no trailing/leading spaces only.")
                            : null,
                        beneAcName: (actionsMode.search(/bene/) !== -1) ? Yup.string().required("Beneficiary Name is required.")
                           .matches(BENE_ACC_NAME_PATTERN, "AlphaNumeric and Special characters are /-?:().,+!#$&%*=^_'{|}~;@[]\ and double quotes with single space allowed and no trailing/leading spaces.")
                           .max(140, "Total maximum characters allowed was 140.") : null,
                        beneBicCode: (actionsMode.search(/bene/) !== -1) ? Yup.string().required("BIC code is required.")
                        .test('no-leading-trailing-spaces', 'Trailing & Leading Spaces Not allowed', value => value === value?.trim())
                        .max(11, "Total maximum characters allowed was 11.") : null,
                        beneLeiCode: (actionsMode.search(/bene/ !== -1)) ? Yup.string()
                        .test('no-leading-trailing-spaces', 'Trailing & Leading Spaces Not allowed', value => !value || value === value?.trim())
                        .nullable() : null,
                        benAddressInfo: Yup.object().shape({
                            country: (actionsMode.search(/bene/) !== -1) ? Yup.string().required("Country is required.") : null,
                            townName: (actionsMode.search(/bene/) !== -1) ? Yup.string().required("Town name is required.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .max(35, "Total maximum characters allowed was 35.") : null,
                            dept: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            subDept: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            streetName: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            buildingNo: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(16, "Total maximum characters allowed was 16.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            buildingName: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            floor: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            postBox: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(16, "Total maximum characters allowed was 16.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            room: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(70, "Total maximum characters allowed was 70.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            postCode: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(16, "Total maximum characters allowed was 16.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            townLocName: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            districtName: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                            countrySubDv: (actionsMode.search(/bene/) !== -1) ? Yup.string().max(35, "Total maximum characters allowed was 35.")
                            .matches(ADDRESS_PATTERN, "AlphaNumeric and Special Characters are '-/,()#&@. with single space and no trailing/leading spaces" )
                            .nullable() : null,
                        }),
                        beneSortCode: (actionsMode.search(/bene/) !== -1) ? Yup.string().matches(/^(\d{6}|\d{2} \d{2} \d{2})$/, 'Pattern Not Matched. eg: 01 01 01, 010101.').nullable() : null,
                    }, ['beneAcNo', 'beneIbanNumber', 'custNumber', 'gcifCode'])}
            >
                {({ errors, values, handleChange, resetForm, submitForm, setFieldValue }) => {

                    return (
                        <>
                            <Dialog
                                scroll='paper'
                                open={openDialog}
                                aria-labelledby="new-dialog-title"
                                aria-describedby="new-dialog-description"
                            >
                                <DialogTitle id="new-dialog-title">
                                    <Grid className="pop-title">
                                        <Typography noWrap variant="h5" component={'span'} textTransform={"uppercase"}>
                                            <b><FormattedMessage id={`createCustomerInfo.${actionsMode}`} defaultMessage={defaultLocales[`createCustomerInfo.${actionsMode}`]} /></b>
                                        </Typography>
                                        <IconButton onClick={handleClose}>
                                            <CloseOutlined />
                                        </IconButton>
                                    </Grid>
                                </DialogTitle>
                                <DialogContent dividers={true}>
                                    <Form encType={"multipart/form-data"}>
                                        {(actionsMode.search(/cust/) !== -1) && <CustomerDetailsForm errors={errors} item={values} onHandleChange={handleChange} 
                                                    actionsMode={actionsMode} setFieldValue={setFieldValue} apacheEnvConfig = {apacheEnvConfig} />}
                                        {(actionsMode.search(/bene/) !== -1) && <BeneficiaryDetailsForm errors={errors} item={values} onHandleChange={handleChange} actionsMode={actionsMode} setFieldValue={setFieldValue} />}
                                    </Form>
                                </DialogContent>
                                <DialogActions>
                                    {
                                        Object.keys(errors).length > 0 && (<Tooltip title={<h5>{`${Object.values(getErrorMsg(errors))}`}</h5>} placement="top">
                                            <IconButton >
                                                <ErrorIcon size={17} color="error" />
                                            </IconButton>
                                        </Tooltip>)
                                    }
                                    {((actionsMode.search(/add/) !== -1) || (actionsMode.search(/edit/) !== -1)) &&
                                        <MbButton className={'button-maybank'}
                                            buttonName={<h5>Submit</h5>} onHandleAction={submitForm}>
                                        </MbButton>
                                    }
                                    {(actionsMode.search(/edit/) !== -1) &&
                                        <MbButton variant="outlined" color={"primary"} className="button-cancel"
                                            buttonName={<h5>Reset</h5>} onHandleAction={resetForm}>
                                        </MbButton>
                                    }
                                    {((actionsMode.search(/actions/) !== -1)
                                        && (userLogin !== item.updatedBy || userGroupId === COUNTRY_ADMIN_ROLE)) &&
                                        <MbButton className={'button-maybank'}
                                            buttonName={<h5>Approve</h5>} onHandleAction={(e) => onHandleActionsDialog('approved')}>
                                        </MbButton>
                                    }
                                    {((actionsMode.search(/actions/) !== -1)
                                        && (userLogin !== item.updatedBy || userGroupId === COUNTRY_ADMIN_ROLE)) &&
                                        <MbButton variant={"outlined"} className={'button-maybank'}
                                            buttonName={<h5>Returned</h5>} onHandleAction={(e) => onHandleActionsDialog('returned')}>
                                        </MbButton>
                                    }
                                </DialogActions>
                            </Dialog>
                            {openConfirmationDialog &&
                                <>
                                    <ConfirmationDialog openDialog={openConfirmationDialog} onHandleOk={onConfirmOk} onHandleCancel={onConfirmCancel} dialogTitle={dialogTitle} dialogContent={dialogContent} >
                                        {confirmationMode === 'returned' &&
                                            <MbTextField
                                                id="comment"
                                                name="comment"
                                                label="Comment"
                                                required
                                                error={true}
                                                margin="normal"
                                                multiline
                                                maxRows={5}
                                                value={comment}
                                                placeholder={""}
                                                caseType={CASE_TYPES.uppercase}
                                                variant="filled"
                                                onTextFieldChange={(e) => setComment(e.target.value)}
                                            />
                                        }
                                    </ConfirmationDialog>
                                </>
                            }
                        </>
                    )
                }}
            </Formik>
        </>
    )
}