import { Outlet } from 'react-router-dom';
import { Container } from "@mui/material";

export default function CustBeneHome() {

    return (
        <>
            <Container maxWidth={false} disableGutters className="container-form">
                <Outlet />
            </Container>
        </>
    )
}