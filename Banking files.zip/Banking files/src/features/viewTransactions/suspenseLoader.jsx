import { Grid } from "@mui/material"
import { memo } from "react"

const SuspenseViewLoader = () => {
    return (
        <Grid variant='h7' sx={{display:'flex', width: '100%', height: '60vh', alignItems: 'center', justifyContent: 'center'}}>
            {"Loading..."}</Grid>
    )
}

export default memo(SuspenseViewLoader)