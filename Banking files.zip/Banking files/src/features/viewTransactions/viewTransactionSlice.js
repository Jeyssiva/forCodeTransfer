import { createSelector, createSlice } from "@reduxjs/toolkit"
import { VIEW_TRANSACTIONS } from "../../constants/sliceConstants"
import { cloneDeep } from "lodash";

export const viewTransInitialState = {
    transactionsList : [],
    snackBarPropertiesTrans: {},
    mx_mt_OverlayMessage: {},
    isLoadingTxnDet : false,
    fieldAccessList: null,
    pageDetBackTo : {
        pageNumber : 0, rowsPerPage : 10, transType : '', enqType : '', selectedMenuId : ''
    },
    tempTransactionLoading : false,
    createPaymentLoaded : false,
    disableMkrChkrActivity : false,
    tempLoadingMessage : 'Loading...',
    txnDetonReferenceNumClick : {},
    closePopupAfterSuccess : false,
    snackBarPropSearch: {}
}

const viewTransSlice = createSlice({
    name : VIEW_TRANSACTIONS,
    initialState : viewTransInitialState,
    reducers: {
        loadTransactions(state, action) {
            const { data: totalCount, enqType } = action.payload;
            state.transactionsList = totalCount === 0 ?  {...action.payload.data, enqTxn: []} : action.payload.data;
        },
        snackBarActionsTrans(state,action) {
            state.snackBarPropertiesTrans = {...action.payload}
            state.isLoadingTxnDet = false;
            // state.transactionsList = {totalCount :0, enqTxn: []}
        },
        loadMxMTOverlayMessage(state, action) {
            const {resData} = action.payload;
            state.mx_mt_OverlayMessage = resData.responseBody.enqTxn[0];
        },
        setLoadingTxn(state, action) {
            state.isLoadingTxnDet = action.payload.status;
        },
        loadFieldAccessList(state, action) {
            const {hierarchyResult} = action.payload;
            // const parentList = sectionHierarchy.filter(p => p.parentSectionId === null && p.sectionRowSeq === 1);
            // const hierarchyResult = generateFieldAccessHierarchy(sectionHierarchy, parentList);
            state.fieldAccessList = hierarchyResult;
        },
        setPages(state, action) {
            state.pageDetBackTo = {...action.payload}
        },
        resetPages(state, action) {
            state.pageDetBackTo = null // {pageNumber : 0, rowsPerPage : 10, transType : '', enqType : '', selectedMenuId : ''}
        },
        setTemplateLoading(state, action) {
            const {status, message} = action.payload;
            state.tempTransactionLoading = status;
            state.tempLoadingMessage = message;
        },
        createPaymentLoadedAction(state, action) {
            state.createPaymentLoaded = action.payload.status;
        },
        setDisableMkrChkrActivity(state, action) {
            state.disableMkrChkrActivity = action.payload.status;
        },
        resetTransactionsList(state, action) {
            const {list, loadingStatus} = action.payload;
            state.transactionsList = {...state.transactionsList, totalCount: 0, enqTxn : list};
            state.isLoadingTxnDet = loadingStatus;
        },
        loadTxnDetonReferenceNumClick(state, action) {
            const { rowData } = action.payload;
            state.txnDetonReferenceNumClick = rowData;
        },
        closeTxnDtlPopupAndUpdateVTxnList(state,action) {
            const { confirmStatus = false, responseBody = {} } = action.payload || {};
          
            if(responseBody && responseBody.enqTxn && responseBody.enqTxn[0]) {
                const {createdBy, createdDt, updatedBy, updatedDt, messageId, messageLatestVersion, uetr, messageCountry, messageDefID, 
                    messageType, messageTxnType, messageTxnFlow , msgStatus, debitBic, creditBic, transactionCurrency, 
                    transactionAmount , debitAccount, creditAccount, status, statusDescription, txnDate, acknowledgementDate} = responseBody.enqTxn[0];
                
                const transList = cloneDeep(state.transactionsList);
                const tEnqTxn = [
                    ...transList.enqTxn.map(enq => {
                        if(enq.uetr === uetr && enq.messageId === messageId) {
                            return {
                                createdBy, createdDt, updatedBy, updatedDt,messageId, messageLatestVersion, uetr, messageCountry, messageDefID, 
                                messageType, messageTxnType, messageTxnFlow , msgStatus, debitBic, creditBic, transactionCurrency, 
                                transactionAmount , debitAccount, creditAccount, status, statusDescription, txnDate, acknowledgementDate
                            }
                        }
                        
                        return enq;
                    })
                ]
                state.transactionsList = {...transList, enqTxn : tEnqTxn};
            }

            // If Customer Navigation Popup is not required, then allow to close the popup.
            if(!confirmStatus) state.closePopupAfterSuccess = true;
        },
        resetCloseTxnDtlPopup(state, action) {
            state.closePopupAfterSuccess = false;
        },
        snackBarActionSearch(state, action) {
            state.snackBarPropSearch = {...action.payload};
        }
    }  
})

//Selectors
const fieldAccess = state => state[VIEW_TRANSACTIONS].fieldAccessList;
const transList = state => state[VIEW_TRANSACTIONS].transactionsList;
const backDet = state => state[VIEW_TRANSACTIONS].pageDetBackTo;
const snackBarTrans = state => state[VIEW_TRANSACTIONS].snackBarPropertiesTrans;
const disability = state => state[VIEW_TRANSACTIONS].disableMkrChkrActivity;
const loading = state => state[VIEW_TRANSACTIONS].isLoadingTxnDet;
const indicator = state =>{
    return {tempLoadingIndicator :  state[VIEW_TRANSACTIONS].tempTransactionLoading, 
          tempLoadingMessage : state[VIEW_TRANSACTIONS].tempLoadingMessage}
};
const txnDet = state => state[VIEW_TRANSACTIONS].txnDetonReferenceNumClick;
const closePopup = state => state[VIEW_TRANSACTIONS].closePopupAfterSuccess;
const snackBarSearch = state => state[VIEW_TRANSACTIONS].snackBarPropSearch;

// create selectors
export const getFieldAccess = createSelector(fieldAccess, getAccess => getAccess);
export const selectorTransList = createSelector(transList, list => list);
export const getPageBackTo = createSelector(backDet, det => det);
export const getSnackBarTrans = createSelector(snackBarTrans, tran => tran);
export const getDisableMkrChkrActivity = createSelector(disability, disable => disable);
export const getLoadingTxnDet = createSelector(loading, load => load);
export const getTempLoadingDetails = createSelector(indicator, indi => indi);
export const getTxnDetonReferenceNumClick = createSelector(txnDet, t => t);
export const getClosePopupAfterSuccess = createSelector(closePopup, c => c);
export const getSnackBarSearch = createSelector(snackBarSearch, sear => sear);

export const {
    loadTransactions,
    snackBarActionsTrans,
    loadMxMTOverlayMessage,
    setLoadingTxn,
    loadFieldAccessList,
    setPages,
    resetPages,
    setTemplateLoading,
    createPaymentLoadedAction,
    setDisableMkrChkrActivity,
    resetTransactionsList,
    loadTxnDetonReferenceNumClick,
    closeTxnDtlPopupAndUpdateVTxnList,
    resetCloseTxnDtlPopup,
    snackBarActionSearch
} = viewTransSlice.actions;

export default viewTransSlice.reducer