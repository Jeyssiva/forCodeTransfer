import { networkISO } from "../../connections/networkISO";
import { setSaveSelectedMxMTResult } from "../showMxTemplateAsTreeView/showMxTempSlice";
import { closeTxnDtlPopupAndUpdateVTxnList, loadTransactions, resetTransactionsList, setDisableMkrChkrActivity, 
    setLoadingTxn, setTemplateLoading, snackBarActionsTrans } from "./viewTransactionSlice";
import { loadMxMTOverlayMessage } from "./viewTransactionSlice";
import { CatchErrorDisplay } from "../errorPage/errorHelpers";
import { snackBarActionDashboard } from "../dashboard/dashboardSlice";
import { ABORT_ERROR } from "../../constants/constants";
import { SAVE_TRANSACTION_DETAILS, VIEW_TRANSACTIONS, VIEW_TRANSACTION_DETAILS } 
    from "../../constants/apiConstants";
import { REPAIR_APPROVE_FROM_TRANSACTIONS } from "../../constants/transactionConstants";
import { FETCH_ISO_SERVICE, FETCH_TRANS_API_TIMEOUT } from '../../apacheEnvConfig';

// vTxnDtl - For View Raw MxMessage Data.
export const getSelectedMxMTMsgData = (requestBody, transactionType, transactionSubType) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${VIEW_TRANSACTION_DETAILS}`, requestBody, transactionType, transactionSubType)
            .then(resData => {
                if(!resData) throw new Error('Failed to fetch');
                if(!resData.ok){
                    if(resData.status)
                        throw new Error(`${resData.status} - ${resData.statusText}`)
                    else throw new Error('Failed to fetch')                
                }
                return resData.json();
            })
            .then(responseData => {
                const {executionStatus, AdditionalStatusCodes, statuscode} = responseData.responseHeader;
                if(statuscode === '200') {
                    dispatch(loadMxMTOverlayMessage({resData : responseData}))
                } else if(AdditionalStatusCodes) {
                    dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: AdditionalStatusCodes[0].HostTxndesc}))
                } else {
                    dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: executionStatus}))
                }
            })
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, VIEW_TRANSACTION_DETAILS, dispatch);
                if(findDisplayMessage)
                    dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}`}))
                else 
                    dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: `${error.message}`}))
            })
        } catch(error) {
            dispatch(snackBarActionDashboard({open: true, severity: 'error', snackBarMessage: `${error.message}`}))
        }
    }
}

// vTxn
export const getAllTransationsByPagination = (requestBody, transactionType, transactionSubType, enqType) => {
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${VIEW_TRANSACTIONS}`, 
                    requestBody, transactionType, transactionSubType)
            .then(response => {
                if(!response) throw new Error('Failed to fetch') 
                if(!response.ok){
                    if(response.status)
                        throw new Error(`${response.status} - ${response.statusText}`)
                    else throw new Error('Failed to fetch')
                }
               return response.json()
            })
            .then(resData => {
                const {executionStatus, AdditionalStatusCodes, statuscode} = resData.responseHeader;            
                if(statuscode === '200') {            
                    dispatch(loadTransactions({data: resData.responseBody, enqType}))
                } else if(AdditionalStatusCodes) {
                    dispatch(snackBarActionsTrans({open:true, severity: 'error', snackBarMessage: AdditionalStatusCodes[0].HostTxndesc}))
                } else {
                    dispatch(snackBarActionsTrans({open:true, severity: 'error', snackBarMessage: executionStatus}))
                }
                dispatch(setLoadingTxn({status: false}))
            })     
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, VIEW_TRANSACTIONS, dispatch);
                if(findDisplayMessage)
                    dispatch(snackBarActionsTrans({open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}`}))
                else 
                    dispatch(snackBarActionsTrans({open: true, severity: 'error', snackBarMessage:  `${error.message}`}))
                dispatch(resetTransactionsList({list: [], loadingStatus: false}));
            })
        }
        catch(error) {
            dispatch(snackBarActionsTrans({open:true, severity: 'error', snackBarMessage: `${error.message}`}));
            dispatch(resetTransactionsList({list: [], loadingStatus: false}));
        }
    }
}

/**
 * 
 * @param {Request Body} requestBody 
 * @param {Transaction Type} transactionType 
 * @param {Transaction Sub Type} transactionSubType 
 * @param {Success message} message 
 * @param {Confirmation Status for Navigate into Customer Payment Page } confirmStatus 
 * @param {Repair/Approve activities from which page} fromWhere 
 * @returns 
 */
export const saveTransactionDetailAction = (requestBody, transactionType, transactionSubType, message, 
    confirmStatus, fromWhere = REPAIR_APPROVE_FROM_TRANSACTIONS ) => {    
    return dispatch => {
        try {
            networkISO.post(`${FETCH_ISO_SERVICE()}/${SAVE_TRANSACTION_DETAILS}`,
            requestBody, transactionType, transactionSubType.toUpperCase(), FETCH_TRANS_API_TIMEOUT())
            .then(response => {
                if(!response) throw new Error('Failed to fetch')
                if(!response.ok){
                    if(response.status)
                        throw new Error(`${response.status} - ${response.statusText}`)
                    else throw new Error('Failed to fetch')
                }
            return response.json();
            })
            .then(resData => {
                const { responseHeader, responseBody } = resData;
                const {executionStatus, AdditionalStatusCodes, statuscode} = responseHeader;            
                if(statuscode === '200') {
                    dispatch(setSaveSelectedMxMTResult({responseBody, confirmStatus}));
                    if(fromWhere === REPAIR_APPROVE_FROM_TRANSACTIONS){
                        dispatch(closeTxnDtlPopupAndUpdateVTxnList({confirmStatus, responseBody}));
                    }
                    dispatch(snackBarActionsTrans({open:true, severity: 'success', snackBarMessage: message}));
                } else if(AdditionalStatusCodes) {
                    dispatch(snackBarActionsTrans({open:true, severity: 'error', snackBarMessage: AdditionalStatusCodes[0].HostTxndesc}))
                } else {
                    dispatch(snackBarActionsTrans({open:true, severity: 'error', snackBarMessage: executionStatus}))
                }
                dispatch(setTemplateLoading({status: false}));
            })
            .catch(error => {
                const findDisplayMessage = CatchErrorDisplay(error, SAVE_TRANSACTION_DETAILS, dispatch);
                if(error.name === ABORT_ERROR)
                {
                    dispatch(setDisableMkrChkrActivity({status: true}));
                    dispatch(snackBarActionsTrans({open: true, severity: 'success', snackBarMessage: 'Your request has been processed, Please check the Message status at Transaction page.'}));
                }
                else if(findDisplayMessage)
                    dispatch(snackBarActionsTrans({open: true, severity: 'error', snackBarMessage: `${findDisplayMessage.displayMessage}`}));
                else 
                    dispatch(snackBarActionsTrans({open: true, severity: 'error', snackBarMessage:  `${error.message}`}));
                dispatch(setTemplateLoading({status: false}));
            })
        }
        catch(error) {
            dispatch(snackBarActionsTrans({open: true, snackBarMessage: `${error.message}`}))
            dispatch(setTemplateLoading({status: false}))
        }
    }
}
