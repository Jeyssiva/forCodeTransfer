import { styled } from "@mui/styles";
import { has, isEqual } from "lodash";
import { TableCell, TableRow, tableCellClasses } from "@mui/material";

export const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {      
      fontWeight: 'bold',
      padding: '10px 10px',
      fontSize: '13px',
      borderTopStyle: 'solid',
      borderTopColor: 'lightgrey',
      borderTopWidth: 'thin',
      // border:'5px',
      // borderBlockEndColor: 'black'
      // backgroundColor: 'darkgrey',
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: '12px',
      padding: '5px 10px',      
    },
  }));  
  
 export const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 1,
    },
  }));

  export const generateFieldAccessHierarchy = (sectionDetails, parentSections) => {
    const hierarchy = {};
    if(parentSections) {  
      parentSections.forEach(pSec => {
        const {sectionId} = pSec;
        const parent = {...pSec}
        const findIsParent = sectionDetails.filter(s=> s.parentSectionId === pSec.sectionId);
        if(findIsParent && findIsParent.length > 0){
          const pHierarchy = generateFieldAccessHierarchy(sectionDetails, findIsParent)
          parent.children = pHierarchy
        }
        hierarchy[sectionId] = parent;
      })
    }
    return hierarchy;
  }

  // This method is used in two wayS
  // 1. find any errors is available or not 
  // 2. for remove unnecessary data if available in child section. 
  export function deepSearchByKey(object, originalKey, matches = [], keysNotConsider, originalValue, propertyKey = '') {
    if(object !== null) {
        if(Array.isArray(object)) {
            for(let arrayItem of object) {
              deepSearchByKey(arrayItem, originalKey, matches, keysNotConsider, originalValue);
            }
        } else if(typeof object == 'object') {
            for(let key of Object.keys(object)) {
              if(!keysNotConsider.includes(key)) {
                if(key === originalKey && !isEqual(object[key], originalValue)) 
                {
                  matches.push({key: propertyKey, value: object})
                }
                 else deepSearchByKey(object[key], originalKey, matches, keysNotConsider, originalValue, `${propertyKey}${key}->`); 
              }
            }
        }
    }
    return matches;
  }

  export const removeUnnecessaryProperty = (resultJson) => {  
     for(const shortTitle in resultJson) {
      if(shortTitle !== '_attributes' && shortTitle !== '_text') 
      {
        if(has(resultJson[shortTitle], 'ChoiceType')) delete resultJson[shortTitle].ChoiceType;
        // Receives any data is available in child section using the deepSearchByKey
        // If matches there, there keep the parent section
        // otherwise, remove the result json.
        let matches = deepSearchByKey(resultJson[shortTitle], '_text', [], 
              ['error', 'ChoiceType'], '');
        if(matches.length === 0) {
          if(Array.isArray(resultJson))
            resultJson.splice(shortTitle, 1)
          else delete resultJson[shortTitle];
        }
        if(has(resultJson[shortTitle], 'error')) delete resultJson[shortTitle].error;
        if(resultJson[shortTitle] && Object.keys(resultJson[shortTitle]).length > 0 ){
          removeUnnecessaryProperty(resultJson[shortTitle])
        }
      }
     }
  }

  export const numberWithCommas = (x) => {
    return Number(x).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }
//  export function rearrangeObjectByHierIndex(obj) {
//   try {
//     const keys = Object.keys(obj);
//     keys.sort((key1, key2) => {
//         // if(!obj[key1] || !obj[key2]) return 0;
//         console.log(obj[key1]);
//         console.log(obj[key2]);
//         const hierIndex1 = obj[key1].hierIndex || 0;
//         const hierIndex2 = obj[key2].hierIndex || 0;
//         return hierIndex1 - hierIndex2;
//     });

//     const rearranged = {};
//     keys.forEach(key => {
//         rearranged[key] = obj[key];
//         if (typeof obj[key] === 'object' && !Array.isArray(obj[key])) {
//             rearranged[key] = rearrangeObjectByHierIndex(obj[key]);
//         }
//     });
//     return rearranged;
//   } catch(error){
//     console.log(error)
//   }
// }

export function rearrangeObjectByHierIndex(obj, arrayObjects = []) {
  try {
      const keys = Object.keys(obj);
      // Sort keys based on hierIndex
      keys.sort((key1, key2) => {
        const {isFMultiEntry : entry1 = false, hIndex : hIndx1 = 0} = arrayObjects.find(k1 => k1.key === key1) || {};
        const {isFMultiEntry : entry2 = false, hIndex : hIndx2 = 0} = arrayObjects.find(k2 => k2.key === key2) || {};
        const hierIndex1 = entry1 ? hIndx1 || 0 : (obj[key1] && obj[key1].hierIndex) || 0;
        const hierIndex2 = entry2 ? hIndx2 || 0 : (obj[key2] && obj[key2].hierIndex) || 0;
        return hierIndex1 - hierIndex2;
      });
      const rearranged = {};
      keys.forEach(key => {
          // Check if the current key is an array
          if (Array.isArray(obj[key])) {
              // If it's an array, handle each element individually 
                rearranged[key] = obj[key].map(item => {
                if (typeof item === 'object' && !Array.isArray(item)) {
                    return rearrangeObjectByHierIndex(item);
                } else {
                    return item; // Handle non-object elements in the array
                }
              });
          } else if (typeof obj[key] === 'object' && !Array.isArray(obj[key])) {
              const resultArrayObjects = findArraysFromObject(obj[key]);
              // If it's an object, recursively rearrange it
              rearranged[key] = rearrangeObjectByHierIndex(obj[key], resultArrayObjects);
          } else {
              // For non-object and non-array values, directly assign
              rearranged[key] = obj[key];
          }
      });
      return rearranged;
  } catch (error) {
      console.error(error);
      return obj; // Return original object in case of error
  }
}

// Get the object data contains the Array or not
// If Array, then check whether isFieldWithMultipleEntry, 
// If yes, get the hierIndex from there
function findArraysFromObject(objArray) {
  const results = [];
  Object.keys(objArray).forEach(eachObj => {
    if(Array.isArray(objArray[eachObj])){
      const {isFieldWMultiEnty: isFMultiEntry,hIndex} = isFieldWithMultiEntryIndex(objArray[eachObj]);
      results.push({key: eachObj, isFMultiEntry, hIndex })
    }
  })
  return results;
}

function isFieldWithMultiEntryIndex(arrayObject){
  const firstItem = arrayObject[0].hierIndex;
  const filterData = arrayObject.filter(f => f.hierIndex === firstItem);
  if(arrayObject.length === filterData.length){
    return {isFieldWMultiEnty : true, hIndex: firstItem}
  } else {
    return {isFieldWMultiEnty : false, hIndex: 0}
  }
}