import * as React from "react";
import moment from "moment";
import { isEmpty } from "lodash";
import { useContext } from "react";
import { useLocation } from 'react-router-dom';
import { FormattedMessage } from "react-intl";
import { CloseOutlined } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { Dialog, IconButton, DialogContent, DialogTitle, DialogActions, Grid, Typography } from "@mui/material";

import MbSnackbar from "../common/mbSnackbar";
import MakerActivities from './makerActivities';
import CheckerActivities from './checkerActivities';
import { getUserInfo } from "../login/loginSlice";
import ConfirmationDialog from "../customerPaymentData/confirmationDialog";
import ShowMxTemplateMain from "../showMxTemplateAsTreeView/showTemplateMain";
import { getScreenAccess, getSelectedMenuInfo } from "../dashboard/dashboardSlice";
import { setTemplateLoading, snackBarActionsTrans, getSnackBarTrans, getDisableMkrChkrActivity, 
    getTxnDetonReferenceNumClick, closeTxnDtlPopupAndUpdateVTxnList, getTempLoadingDetails } from "./viewTransactionSlice";
import CustBeneModalDialog from "../customerPaymentData/custBeneModalDialog";
import { COUNTRY_ADMIN_ROLE, ENQ_TYPE_BY_SELECTED_MENU, REPAIR_APPROVE_FROM_TRANSACTIONS, TRANS_TYPE_BY_SELECTED_MENU } from "../../constants/transactionConstants";
import { saveTransactionDetailAction } from "./viewTransactionsAction";
import { convertDataXMLtoJSONWithDeclaration } from "../showMxTemplateAsTreeView/conversionHelpers";
import { MSG_STATUS_DRAFT, MSG_STATUS_DRAFTRETURN, MSG_STATUS_PENDING_APPROVAL, SRCOFTXN_MIDAS } from "../../constants/mxTempConstants";
import { initialState, SET_BIND_PROPERTY, CustomerContext, OPEN_CUSTOMER_FOR_NAVIGATION } from "../customerPaymentData/customerReducer";
import { getConfirmNaviMsg, getSelectedTxnDet, setConfirmNaviMsg, setMountedStatus } from "../showMxTemplateAsTreeView/showMxTempSlice";
import { getRequiredApiRequest } from "../showMxTemplateAsTreeView/persistedSlice";
import { getAllStaticTransactionDataAction } from "../showMxTemplateAsTreeView/showTempAction";
import {  GET_SECTION_DETAIL_SCHEMA_NAMES } from "../../constants/createPaymentConstants";
import { ACCESS_LEVEL_ALL, ACCESS_LEVEL_READ, ACCESS_LEVEL_WRITE, DATE_TIME_FORMAT, TRANS_TYPE, 
    TRANS_VIEW_CUSTOMER_INFO, TRANS_VIEW_CUSTOMER_SUBTYPE } from "../../constants/constants";
import { viewCustomerInfoDtrl } from "../customerPaymentData/customerDataAction";
import { FadeLoader } from "react-spinners";
import { findBodySchemaLoaded, findMsgConfigLoaded, getSectionDetailRequests } from "../showMxTemplateAsTreeView/validationHelpers";

const ViewSelectedTransactionDialogMain = ({ transType, openViewRef, onHandleClose }) => {
    const location = useLocation();
    let { selTransaction: { messageId = "", messageLatestVersion, updatedBy,
        msgStatus: msgStatusFromLocation, messageDefID, messageTxnType, sourceOfTxn = SRCOFTXN_MIDAS } = {} } 
        = location.state || {};

    const actDispatch = useDispatch();
    const [enqType, setEnqType] = React.useState('b2c');
    const { state, dispatch } = useContext(CustomerContext);
    const { openDialog } = state;
    const screenAccessDet = useSelector(getScreenAccess);
    const selectedTxnDet = useSelector(getSelectedTxnDet);
    const confirmCustNaviMsg = useSelector(getConfirmNaviMsg);
    const selectedMenuInfo = useSelector(getSelectedMenuInfo);
    const snackBarPropertiesTrans = useSelector(getSnackBarTrans);
    const disableActivity = useSelector(getDisableMkrChkrActivity);
    const getRequiredApiReqData = useSelector(getRequiredApiRequest);
    const getUserDetail = useSelector(getUserInfo);
    const loadTxnDetonReferenceNumClick = useSelector(getTxnDetonReferenceNumClick);
    const getLoadingForPaymentAction = useSelector(getTempLoadingDetails);

    const { enqTxn: [{ msgStatus, mxMessage }] = [{ msgStatus: msgStatusFromLocation }] }
        = selectedTxnDet || {};

    const onHandleConfirmNaviCancel = () => {
        actDispatch(setConfirmNaviMsg({ status: false }));
        actDispatch(closeTxnDtlPopupAndUpdateVTxnList());
    }

    const onHandleConfirmNaviOk = () => {
        try {
            const { selectedCustomer } = initialState;
            const resultJson = convertDataXMLtoJSONWithDeclaration(mxMessage);
            const fitName = enqType === 'b2b' ? 'FICdtTrf' : 'FIToFICstmrCdtTrf';
            const getCreditTransfer = resultJson["DataPDU"]["Body"]["Document"][fitName]["CdtTrfTxInf"] || {};
            const getDebt = enqType === 'b2c'
                ? getCreditTransfer["Dbtr"] || {}
                : (getCreditTransfer["Dbtr"] && getCreditTransfer["Dbtr"]["FinInstnId"]) || {};
            const getDebtAcct = (getCreditTransfer && getCreditTransfer["DbtrAcct"]) || {};
            const custBankAcNo = (getDebtAcct
                && getDebtAcct["Id"]
                && getDebtAcct["Id"]["Othr"]
                && getDebtAcct["Id"]["Othr"]["Id"]
                && getDebtAcct["Id"]["Othr"]["Id"]._text) || '';
            const custName = (getDebt && getDebt["Nm"] && getDebt["Nm"]._text) || '';
            const getPostalAddress = (getDebt && getDebt["PstlAdr"]) || {};
            const addressInfo = {
                ...selectedCustomer.addressInfo,
                dept: (getPostalAddress["Dept"] && getPostalAddress["Dept"]._text) || '',
                subDept: (getPostalAddress["SubDept"] && getPostalAddress["SubDept"]._text) || '',
                streetName: (getPostalAddress["StrtNm"] && getPostalAddress["StrtNm"]._text) || '',
                buildingNo: (getPostalAddress["BldgNb"] && getPostalAddress["BldgNb"]._text) || '',
                buildingName: (getPostalAddress["BldgNm"] && getPostalAddress["BldgNm"]._text) || '',
                floor: (getPostalAddress["Flr"] && getPostalAddress["Flr"]._text) || '',
                postBox: (getPostalAddress["PstBx"] && getPostalAddress["PstBx"]._text) || '',
                room: (getPostalAddress["Room"] && getPostalAddress["Room"]._text) || '',
                postCode: (getPostalAddress["PstCd"] && getPostalAddress["PstCd"]._text) || '',
                townName: (getPostalAddress["TwnNm"] && getPostalAddress["TwnNm"]._text) || '',
                townLocName: (getPostalAddress["TwnLctnNm"] && getPostalAddress["TwnLctnNm"]._text) || '',
                districtName: (getPostalAddress["DstrctNm"] && getPostalAddress["DstrctNm"]._text) || '',
                countrySubDv: (getPostalAddress["CtrySubDvsn"] && getPostalAddress["CtrySubDvsn"]._text) || '',
                country: (getPostalAddress["Ctry"] && getPostalAddress["Ctry"]._text) || '',
            }
            const updatedCustomer = { ...selectedCustomer, addressInfo, custBankAcNo, custName };     
            //Check whether the customer is exists or not, if yes get some information from the resultData
            if(custBankAcNo)
                actDispatch(viewCustomerInfoDtrl({ searchCustomer: { accountNumber: custBankAcNo, 
                    customerNumber: '', customerName: '', customerId: '' } },
                    TRANS_VIEW_CUSTOMER_INFO, TRANS_VIEW_CUSTOMER_SUBTYPE, dispatch, updatedCustomer));
            else 
            {
                dispatch({ type: OPEN_CUSTOMER_FOR_NAVIGATION, updatedCustomer});
            }
                
            actDispatch(setConfirmNaviMsg({ status: false }));
        }
        catch (err) {
            actDispatch(snackBarActionsTrans({ open: true, severity: 'error', snackBarMessage: `${err.message}` }));
        }
    }

    const onSnackBarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        actDispatch(snackBarActionsTrans({ open: false, severity: '', snackBarMessage: '' }));
    }

    const onHandleAction = (actionData, naviStatus = false, txnDetails) => {
        const { verPkSeqNo } = txnDetails || {};
        const requestBody = {
            ...actionData, msgId: messageId, msgVerNo: messageLatestVersion,
            msgStatus, verPkSeqNo, messageDefId: messageDefID
        };
        const statusMessage = `Your request has been submitted at ${moment().format(DATE_TIME_FORMAT)}`;
        actDispatch(setTemplateLoading({ status: true }));
        actDispatch(saveTransactionDetailAction(requestBody, TRANS_TYPE[transType], enqType, statusMessage, 
            naviStatus, REPAIR_APPROVE_FROM_TRANSACTIONS));
    }

    const renderActivitiesButtons = React.useCallback(() => {
        const getUsername = getUserDetail?.userLogin;
        const userGroupIdbyLoggedInUser = getUserDetail?.userUserGroups[0]?.userGroupId;
        if (isEmpty(screenAccessDet) || disableActivity) return null;
      
        // If Screen Access Permission = WRITE || ALL
        // Transaction Status Should be Draft || Draft Return
        // Current Transaction's updatedBy(userLogin) is not Equal to loggedinUser or Role is COUNTRY_ADMIN
        // If all condition are eligible, applicable for submit the transaction.
        if ((screenAccessDet.levelName === ACCESS_LEVEL_WRITE || screenAccessDet.levelName === ACCESS_LEVEL_ALL)
            && [MSG_STATUS_DRAFT, MSG_STATUS_DRAFTRETURN].includes(msgStatus.toLowerCase())
            && (updatedBy !== getUsername || userGroupIdbyLoggedInUser === COUNTRY_ADMIN_ROLE))
            return <MakerActivities onHandleAction={onHandleAction} />

        // If Screen Access Permission is Equal to READ || ALL
        // Transaction Status should be Pending Approval
        // Current Transaction's updatedBy(userLogin) is not Equal to loggedinUser or Role is COUNTRY_ADMIN
        // If all condition are eligible, applicable for approve/reject/return.
        if ((screenAccessDet.levelName === ACCESS_LEVEL_READ || screenAccessDet.levelName === ACCESS_LEVEL_ALL)
            && msgStatus.toLowerCase() === MSG_STATUS_PENDING_APPROVAL
            && (updatedBy !== getUsername || userGroupIdbyLoggedInUser === COUNTRY_ADMIN_ROLE))
            return <CheckerActivities onHandleAction={onHandleAction} />
        return null;
    }, [selectedMenuInfo, msgStatus, disableActivity, getUserDetail, onHandleAction, screenAccessDet, updatedBy]);

    React.useEffect(() => {
        if (!selectedMenuInfo || isEmpty(selectedMenuInfo)) return;
        // const [uType,tType, enType] = selectedMenuInfo.menuUrl.split('/');
        const enType = ENQ_TYPE_BY_SELECTED_MENU[selectedMenuInfo.menuId];
        const tType = TRANS_TYPE_BY_SELECTED_MENU[selectedMenuInfo.menuId];
        setEnqType(enType);
        const {msgStatus : mStatusAtClick} = loadTxnDetonReferenceNumClick || {};
        const {countryList} = getRequiredApiReqData || {};

        let msgConfigBody = getSectionDetailRequests(messageTxnType, screenAccessDet, mStatusAtClick, sourceOfTxn, messageDefID);
        const applicableFalseReq = {
            messageDefId: ['SAA_HEADER'],
            sourceOfTxn,
            isApplicable: 0
        }
        const inqReqBody = {
          ddListType:  !countryList 
                    ? "GBR_COUNTRY_LIST, GBR_CURRENCY_LIST, GBR_PURPOSE_ALL"
                    : 'GBR_CURRENCY_LIST, GBR_PURPOSE_ALL' ,
          dropDownListKey1: "",
          dropDownListKey2: ""
        }
        const txnReqBody = {
          messageDefId: messageDefID,
          msgId: messageId,
          msgVerNo: messageLatestVersion,
          msgTypeToView : "Mx"
        }
       
        const msgConfigBySchema = findMsgConfigLoaded(messageTxnType,sourceOfTxn, msgStatus, screenAccessDet,
            messageDefID, getRequiredApiReqData, msgConfigBody);
        const bodySchema = findBodySchemaLoaded(messageDefID, getRequiredApiReqData);
        const secDtlTransName = GET_SECTION_DETAIL_SCHEMA_NAMES[messageDefID];
        const requiredApis = {...getRequiredApiReqData, msgConfigBySchema, bodySchema};
        actDispatch(getAllStaticTransactionDataAction(messageDefID, secDtlTransName, 
            requiredApis, msgConfigBody, inqReqBody, applicableFalseReq,
            {txnReqBody, transType: TRANS_TYPE[tType], enquiryType: enType.toUpperCase()}, getUserDetail, screenAccessDet));
        
        // loadTxnDet(tType, enType, messageId, messageLatestVersion);
        return () => {
            dispatch({ type: SET_BIND_PROPERTY, fieldName: 'openDialog', value: false });
            actDispatch(setMountedStatus({ status: false }));
        }
    }, [])

    const {tempLoadingIndicator = false} = getLoadingForPaymentAction || {};
    return (
        <Dialog
            scroll='paper'
            fullWidth={true}
            maxWidth={false}
            open={openViewRef}
            onClose={onHandleClose}
            aria-labelledby="scroll-dialog-title"
            aria-describedby="scroll-dialog-description"
        >
                <DialogTitle bid="scroll-dialog-title">
                    <Grid className="pop-title">
                        <Typography noWrap variant="h5" component={'span'} textTransform={"uppercase"}>
                            <FormattedMessage id='viewTransactions.viewMessageDialog.viewRef'>
                                {
                                    (msg) => `${msg} - [${messageId}]`
                                }
                            </FormattedMessage>
                        </Typography>
                        <IconButton onClick={onHandleClose}>
                            <CloseOutlined />
                        </IconButton>
                    </Grid>
                </DialogTitle>                
                <DialogContent dividers={true} className="pop-content">
                    <ShowMxTemplateMain />
                </DialogContent>
                <DialogActions>
                    {
                        tempLoadingIndicator ? 
                            <Grid sx={{display: 'flex', flexDirection: 'column'}}>
                                <IconButton>
                                <FadeLoader
                                    color={'#000000'}
                                    loading={tempLoadingIndicator}
                                    aria-label="Loading Spinner"
                                    data-testid="loader"/> 
                                </IconButton>
                                {/* <Typography variant='body'>{tempLoadingMessage}</Typography> */}
                            </Grid>         
                        : renderActivitiesButtons()
                    }
                </DialogActions>
            <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesTrans.open}
                severity={snackBarPropertiesTrans.severity}
                message={snackBarPropertiesTrans.snackBarMessage} />
            {
                confirmCustNaviMsg && <ConfirmationDialog openDialog={confirmCustNaviMsg}
                    dialogContent="Debtor information has been changed. Please proceed to complete the update at 'Customer Payment Data'."
                    onHandleCancel={onHandleConfirmNaviCancel} onHandleOk={onHandleConfirmNaviOk} />
            }
            {openDialog && <CustBeneModalDialog state={state} dispatch={dispatch} />}
        </Dialog>
    )
}

export default ViewSelectedTransactionDialogMain;