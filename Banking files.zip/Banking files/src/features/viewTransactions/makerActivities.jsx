import MbButton from "../common/mbButton";
import { FormattedMessage } from "react-intl";
import { defaultLocales } from "../i18n";
import { useDispatch, useSelector } from "react-redux";
import { getOriginalJson, snackBarActionsShowTemp, getAllTabLoadedStatus,
    getSelectedTxnDet, setErrorsInTabMaintainance } from "../showMxTemplateAsTreeView/showMxTempSlice";
import { cloneDeep } from "lodash";
import { deepSearchByKey, rearrangeObjectByHierIndex, removeUnnecessaryProperty } from "./helpers";
import { convertDataJsontoXML } from "../showMxTemplateAsTreeView/conversionHelpers";
import { getResultBodyDataSaaHeader } from "../showMxTemplateAsTreeView/saaHeaderSlice";
import { getResultBodyDataAppHeader } from "../showMxTemplateAsTreeView/appHeaderSlice";
import { getResultBodyDataBody } from "../showMxTemplateAsTreeView/bodySlice";
import { SRCOFTXN_CREATEPAYMENT } from "../../constants/mxTempConstants";
import SubmitPaymentActivities from "../createPayment/submitPaymentActivities";
import { setTemplateLoading } from "./viewTransactionSlice";
import { memo, useCallback } from "react";

function MakerActivities({onHandleAction}) {  
    const resultBodyJsonSaa = useSelector(getResultBodyDataSaaHeader);
    const resultBodyJsonApp = useSelector(getResultBodyDataAppHeader);
    const resultBodyJsonBody = useSelector(getResultBodyDataBody);
    const resultOriginalJson = useSelector(getOriginalJson);
    const selTxnDet = useSelector(getSelectedTxnDet);
    const actDispatch = useDispatch();
    const findAllLoaded = useSelector(getAllTabLoadedStatus);

    // const onHandleApproval = () => {
    //     const bodyResult = cloneDeep(resultBodyJsonBody);
    //     const errorMessages = deepSearchByKey(bodyResult , 'error', [], [], {'_text' : 1})
    //     actDispatch(setErrorsInTabMaintainance({tabMaintainance: 
    //         {'saaHeader' : {errors: [], invisible: true, loaded: true}, 
    //          'appHead': {errors : [], invisible: true, loaded: true}, 
    //          'body': {errors: errorMessages, invisible: errorMessages.length === 0, loaded: true}
    //         }}))
    //     if(errorMessages.length > 0){
    //         actDispatch(snackBarActionsShowTemp({open: true, severity: 'error', snackBarMessage: 'Please fill required fields - Body'}))
    //     } else {
    //         const saaResult = cloneDeep(resultBodyJsonSaa['saaHeader']);
    //         removeUnnecessaryProperty(saaResult);
    //         const rearrangeBodyObjects = rearrangeObjectByHierIndex(bodyResult);
    //         removeUnnecessaryProperty(rearrangeBodyObjects);
    //         const appResult = cloneDeep(resultBodyJsonApp);
    //         removeUnnecessaryProperty(appResult);
    //         const finalResult =  cloneDeep(resultOriginalJson)
    //         finalResult['DataPDU'] = {...finalResult['DataPDU'], ...saaResult, Body: {...appResult, Document: rearrangeBodyObjects}};
    //         const convertJsonXML = convertDataJsontoXML(finalResult);
    //         // console.log(convertJsonXML);
    //         onHandleAction({reqAction: 'Submit', mxMessage : convertJsonXML}, true, selTxnDet)
    //     }
    // }
    
    const onHandleApproval = useCallback(() => {
        const bodyResult = cloneDeep(resultBodyJsonBody);
        const errorMessages = deepSearchByKey(bodyResult, 'error', [], [], { '_text': 1 });   
        const errorsInTabMaintenance = {
            saaHeader: { errors: [], invisible: true, loaded: true },
            appHead: { errors: [], invisible: true, loaded: true },
            body: { errors: errorMessages, invisible: !errorMessages.length, loaded: true }
        };
        actDispatch(setErrorsInTabMaintainance({ tabMaintainance: errorsInTabMaintenance }));
        if (errorMessages.length > 0) {
            actDispatch(snackBarActionsShowTemp({
                open: true,
                severity: 'error',
                snackBarMessage: 'Please fill required fields - Body'
            }));
            return;
        }
        const saaResult = cloneDeep(resultBodyJsonSaa['saaHeader']);
        removeUnnecessaryProperty(saaResult);
        const rearrangeBodyObjects = rearrangeObjectByHierIndex(bodyResult);
        removeUnnecessaryProperty(rearrangeBodyObjects);
        const appResult = cloneDeep(resultBodyJsonApp);
        removeUnnecessaryProperty(appResult);
        const finalResult =  cloneDeep(resultOriginalJson)
        finalResult['DataPDU'] = {...finalResult['DataPDU'], ...saaResult, Body: {...appResult, Document: rearrangeBodyObjects}};
        const convertJsonXML = convertDataJsontoXML(finalResult);
        // console.log(convertJsonXML);
        onHandleAction({reqAction: 'Submit', mxMessage : convertJsonXML}, true, selTxnDet)
    }, [selTxnDet, resultBodyJsonSaa, resultBodyJsonApp, resultBodyJsonBody]);

    if(!findAllLoaded) return null;
    const{enqTxn} = selTxnDet || {};
    const {sourceOfTxn = undefined, messageDefId, messageTxnType} = (enqTxn && enqTxn[0]) || {};
    return (
        <>
        {
            sourceOfTxn === SRCOFTXN_CREATEPAYMENT 
            ? <SubmitPaymentActivities buttonName={<FormattedMessage id = {'common.submitApproval'} defaultMessage={defaultLocales['common.submitApproval']}/>}
                transType={messageTxnType} selectedTemplate={messageDefId} txnDet = {selTxnDet} submissionType = {'Update'} 
                loadingAction = {setTemplateLoading} />
            :
                <MbButton className={'button-maybank'} onHandleAction={onHandleApproval}
                buttonName={<FormattedMessage id = {'common.submitApproval'} defaultMessage={defaultLocales['common.submitApproval']}/>}/>
        }
        </>
    )
}

export default memo(MakerActivities);