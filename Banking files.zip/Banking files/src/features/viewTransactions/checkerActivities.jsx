import MbButton from "../common/mbButton";
import { FormattedMessage } from "react-intl";
import { defaultLocales } from "../i18n";
import { useState } from "react";
import MbInputBoxPopup from "../common/mbInputBox";
import { useSelector } from "react-redux";
import { getAllTabLoadedStatus, getSelectedTxnDet } from "../showMxTemplateAsTreeView/showMxTempSlice";

export default function CheckerActivities({onHandleAction}) {
    const [openComment, setOpenComment] = useState(false);
    const [title, setTitle] = useState('');
    const selectedTxnDet = useSelector(getSelectedTxnDet);
    const {enqTxn : [{mxMessage = ''} = {}] = []} = selectedTxnDet || {};
    const findAllLoaded = useSelector(getAllTabLoadedStatus)
    if(!findAllLoaded) return null;

    const onHandleOpenBox = (actionName) => {
        setOpenComment(true);
        setTitle(actionName)
    }

    const onHandleConfirmation = ({comment}) => {
        onHandleAction({reqAction: title, comment, mxMessage }, false, selectedTxnDet)
        setOpenComment(false);
    }

    return (
        <>
            <MbButton className="button-maybank"  
                buttonName={<FormattedMessage id = 'common.approve' defaultMessage={defaultLocales['common.approve']}/>}
                onHandleAction={e => onHandleAction({reqAction: "Approve",comment: "", mxMessage}, false, selectedTxnDet)}/>
            <MbButton className="button-maybank"  
                buttonName={<FormattedMessage id = 'common.reject' defaultMessage={defaultLocales['common.reject']}/>}
                onHandleAction={e => onHandleOpenBox('Reject')}/>
            <MbButton className="button-maybank"  
                buttonName={<FormattedMessage id = 'common.returned' defaultMessage={defaultLocales['common.returned']}/>}
                onHandleAction={e => onHandleOpenBox('Return')}/>
            {
                openComment && <MbInputBoxPopup openDialog={openComment} title = {`Reason for ${title}`}
                multiline = {true} maxLength={200} fieldName = "Comment" rows = {4}
                onHandleClose={(e) => setOpenComment(false)} onHandleConfirm={onHandleConfirmation}/>
            }
        </>
    )
}