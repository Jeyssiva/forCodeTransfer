import * as React from 'react';
import { isEmpty } from 'lodash';
import { Refresh } from '@mui/icons-material';
import { FormattedMessage } from 'react-intl';
import { useDispatch, useSelector } from 'react-redux';
import { Container, Grid, Link, Tab, Tabs, Divider, Box } from '@mui/material';

import { defaultLocales } from '../i18n';
import MbButton from '../common/mbButton';
import MbBreadCrumbs from '../common/mbBreadcrumbs';
import SuspenseLoader from './suspenseLoader';
import { getScreenAccess } from '../dashboard/dashboardSlice';
import { getPageBackTo, resetPages } from './viewTransactionSlice';
import { ACCESS_LEVEL_ALL, ACCESS_LEVEL_READ } from '../../constants/constants';
import { MSG_STATUS, TRANSTYPE_PAYMENT_TABS, PREVIOUS_PAYMENT, OUTCOMING_TABLE_HEADERS, TODAY_PAYMENT,
     OUT, IN, SEARCH_PAYMENT, INITIAL_SEARCH_REQUEST, OUTGOING_TAB_DATE_CATEGORY, INCOMING_TABLE_HEADERS } 
     from '../../constants/transactionConstants';

const ViewTransactionsMain = React.lazy(() => import("./viewTransactionsMain"));
const SearchPaymentsMain = React.lazy(() => import("../outgoingTransaction/search/searchPaymentsMain"));

function OutPaymentsMain({enqType, refreshPage, onHandleRefresh, title, subtitle, transType}) {
    const actDispatch = useDispatch();
    const [selectedTab, setTab] = React.useState(TODAY_PAYMENT);
    const [showAllTodayPayments, setAllTodayPayments] = React.useState(null);

    const pageDetBackTo = useSelector(getPageBackTo);
    const screenAccessDet = useSelector(getScreenAccess);

    const headers = React.useMemo(() => {
        if (isEmpty(screenAccessDet)) return [];
        if(transType === IN) return [...INCOMING_TABLE_HEADERS]
        if ((screenAccessDet.levelName === ACCESS_LEVEL_READ || screenAccessDet.levelName === ACCESS_LEVEL_ALL))
            return [...OUTCOMING_TABLE_HEADERS, { id: 'requestor', label: 'Requestor', numeric: false }];
        else return [...OUTCOMING_TABLE_HEADERS];
    }, [screenAccessDet])

    const getSearchCriteria = React.useMemo(() => {
        let resultSearch = { ...INITIAL_SEARCH_REQUEST };
        const {startdateRange, enddateRange, lookUpOn} = OUTGOING_TAB_DATE_CATEGORY.find(d => d.value === selectedTab);
        if (selectedTab === TODAY_PAYMENT && !showAllTodayPayments) {
            resultSearch.status = [
                MSG_STATUS['pendingApproval'],
                MSG_STATUS['draft'],
                MSG_STATUS['draftReturn']
            ]
        } else {
            resultSearch.status = []
        }
        return {searchFilter: {...resultSearch, startdateRange, enddateRange, lookUpOn}, datePriority: {minDate: startdateRange, maxDate: enddateRange}}
    },[selectedTab, enqType, showAllTodayPayments]);

    const onHandleTabChange = (e, newValue) => {
        setTab(newValue);
        setAllTodayPayments(null);
        if (!isEmpty(pageDetBackTo)) actDispatch(resetPages());
    }

    const onHandleShowAllTodayPayments = (value) => {
        setAllTodayPayments(value);
    }

    if (enqType === "") return;

    return (
        <>
            <Container maxWidth={false} disableGutters className="container-form">
                <MbBreadCrumbs crumbsList={[{ title: `viewTransactions.${title}` }, 
                { title: `viewTransactions.${enqType}.title` }, 
                { title: `viewTransactions.${selectedTab}` }
                ]} />
                {
                    <h6>
                        <FormattedMessage id = {`viewTransactions.${subtitle}`} 
                        defaultMessage={`viewTransactions.${subtitle}`}/></h6>
                }
                <Divider className="divider" sx={{ textTransform: 'uppercase' }}><h5>
                    <b><FormattedMessage id={`viewTransactions.${enqType}.title`}
                    defaultMessage={defaultLocales[`viewTransactions.${enqType}.title`]} /></b></h5></Divider>
                <Box className="box">
                    <Grid sx={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'row', width: '100%', marginBottom: 2 }}>
                        <MbButton variant="outlined" buttonName={'Refresh'}
                            onHandleAction={onHandleRefresh}
                            startIcon={<Refresh />}
                        />
                    </Grid>
                    <Tabs
                        className='tab'
                        value={selectedTab}
                        //variant="scrollable"
                        indicatorColor="primary"
                        onChange={onHandleTabChange}
                    >
                        {
                            TRANSTYPE_PAYMENT_TABS.map(tabItem => {
                                return <Tab label={tabItem.label} value={tabItem.value} className={'tab-title'} key={`tab_${tabItem.label}`} />
                            })
                        }
                    </Tabs>
                    {
                        selectedTab === TODAY_PAYMENT &&
                        <Grid>
                            <React.Suspense fallback={<SuspenseLoader />}>
                                {
                                    <ViewTransactionsMain
                                        key={`key_${TODAY_PAYMENT}`}
                                        transType={transType}
                                        enqType={enqType}
                                        tableHeaders={headers}
                                        refreshPage={refreshPage}
                                        backPageDetails={pageDetBackTo}
                                        screenAccessDet={screenAccessDet}
                                        switchActivated={showAllTodayPayments}
                                        searchFilter={getSearchCriteria.searchFilter}
                                        onHandleRefresh={onHandleRefresh}
                                    />
                                }                      
                            </React.Suspense>
                        </Grid>
                    }
                    {
                        selectedTab === PREVIOUS_PAYMENT &&
                        <Grid>
                            <React.Suspense fallback={<SuspenseLoader />}>
                                <SearchPaymentsMain transType = {transType} enqType={enqType}  tableHeaders={headers} 
                                    refreshPage={refreshPage} screenAccessDet={screenAccessDet} datePriority = {getSearchCriteria.datePriority}
                                    searchFilterFromParent={getSearchCriteria.searchFilter} paymentCategory = {PREVIOUS_PAYMENT}
                                />
                            </React.Suspense>
                        </Grid>
                    }
                    {
                        selectedTab === SEARCH_PAYMENT &&
                        <Grid>
                            <React.Suspense fallback={<SuspenseLoader/>}>
                                 <SearchPaymentsMain transType = {transType} enqType={enqType}  tableHeaders={headers} 
                                   refreshPage={refreshPage} screenAccessDet={screenAccessDet} datePriority = {getSearchCriteria.datePriority}
                                   searchFilterFromParent={getSearchCriteria.searchFilter} paymentCategory = {SEARCH_PAYMENT}
                                 />
                            </React.Suspense>
                        </Grid>
                    }
                    {
                        !isEmpty(screenAccessDet)
                        && (screenAccessDet.levelName === ACCESS_LEVEL_READ || screenAccessDet.levelName === ACCESS_LEVEL_ALL)
                        && selectedTab === TODAY_PAYMENT && transType === OUT &&
                        <Grid sx={{ display: 'flex', width: '100%', alignItems: 'center' }}>
                            {
                                !showAllTodayPayments ?
                                    <>
                                        <h6>Today Payments display Draft, Pending Approval and Return transactions. Click </h6>
                                        <Link sx={{ mx: '4px', fontSize: 'x-small' }} component="button" variant="body2"
                                            onClick={e => onHandleShowAllTodayPayments(true)}>View All,</Link>
                                        <h6>for all transactions.</h6>
                                    </>
                                    :
                                    <>
                                        <Link sx={{ mx: '4px', fontSize: 'x-small' }} component="button" variant="body2"
                                            onClick={e => onHandleShowAllTodayPayments(false)}>Back</Link>
                                        <h6>to page.</h6>
                                    </>
                            }
                        </Grid>
                    }
                </Box>
            </Container>
        </>
    )
}

export default React.memo(OutPaymentsMain)