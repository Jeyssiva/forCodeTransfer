import * as React from 'react';
import {
  Button, Grid, IconButton, Table, TableBody, TableContainer,
  TableHead, TablePagination, TableRow, Tooltip, Typography
} from "@mui/material";
import { isMobileOnly } from 'react-device-detect';
import { FormattedMessage } from 'react-intl';
import { defaultLocales } from '../i18n';
import { makeStyles } from '@mui/styles';
import { useDispatch, useSelector } from 'react-redux';
import ViewMessageDialogMain from './viewMessageTemplate/viewRawMsgDialogMain';
import { StyledTableCell, StyledTableRow } from './helpers'
import { RowsPerPageOptions, TRANS_TYPE } from '../../constants/constants';
import {  getAllTransationsByPagination } from './viewTransactionsAction';
import MbSnackbar from '../common/mbSnackbar';
import { isEmpty } from 'lodash';
import {
  getLoadingTxnDet, getSnackBarTrans, selectorTransList,
  setLoadingTxn, snackBarActionsTrans
} from './viewTransactionSlice';
import { InfoOutlined } from '@mui/icons-material';
import { INITIAL_SEARCH_REQUEST, OUT, STATEMENT_HEADERS } from '../../constants/transactionConstants';
import LoadingViewer from '../loadingViewer';
export const useStyles = makeStyles(() => ({
  searchCriteria: {
    width: '23%',
    marginRight: '10px'
  },
  viewButtonStyle: {
    padding: '5px 16px'
  },
  tableContainer: {
    borderRadius: 1,
    overflowY: 'auto'
  }
}))

const ViewStatementsMain = React.memo(function ViewStatementsMain({ transType, enqType, scrollNeed = false,
  searchFilter = { ...INITIAL_SEARCH_REQUEST },refreshPage, tableHeaders = STATEMENT_HEADERS }) {
  const [pageNumber, setPageNumber] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [openViewMXMTMsg, setOpenViewMXMTMsg] = React.useState(false);
  const [selectedTableRow, setSelectedTableRow] = React.useState({});
  const snackBarPropertiesTrans = useSelector(getSnackBarTrans);
  const transactionsList = useSelector(selectorTransList);
  const isLoadingTxnDet = useSelector(getLoadingTxnDet);
  const actDispatch = useDispatch();

  const loadingTxn = (tType, enType, rows, pageNum, sFilter) => {
    const reqBody = {
      "maxResults": rows,
      "pageNo": pageNum,
      "searchSortColumn": "createdDt",
      "sortDirection": "DESC",      
      "searchCriteria": [
        {
          ...sFilter
        }
      ]
    }      
    actDispatch(setLoadingTxn({status: true}));
    actDispatch(getAllTransationsByPagination(reqBody, TRANS_TYPE[tType], enType.toUpperCase(), enType))
  }

  React.useEffect(() => {
    if (isEmpty(enqType)) return;
    loadingTxn(transType, enqType, rowsPerPage, pageNumber, searchFilter);
  }, [enqType, rowsPerPage, pageNumber, refreshPage, actDispatch, searchFilter])

  const onHandlePageChange = (e, newPage) => {
    setPageNumber(newPage)
  }
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10))
    setPageNumber(0)
  }
  const onSnackBarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    actDispatch(snackBarActionsTrans({ open: false, severity: '', snackBarMessage: '' }));
  }
  const onHandleCloseViewMsgDialog = () => {
    setOpenViewMXMTMsg(false)
    setSelectedTableRow({})
  }
  const onHandleViewMXMTMessage = (selRow) => {
    setOpenViewMXMTMsg(true)
    setSelectedTableRow(selRow)
  }

  const totalCount = transactionsList ? transactionsList.totalCount : 0;
  const maxResults = transactionsList ? transactionsList.maxResults : 0;
  const tableContainerStyle = maxResults > 10 && scrollNeed ? { height: '510px', maxHeight: '800px', overflowY: 'auto', borderRadius: 1 } : {};
  const tableStyle = maxResults > 10 && scrollNeed ? { height: '440px', maxHeight: '800px' } : {};

  if (enqType === "") return;

  return (
    <>
      <LoadingViewer loading={isLoadingTxnDet}>
        <Grid sx={scrollNeed ? { m: 0.5 } : { m: 0.5, width: '99.5%' }}>
          <TableContainer sx={{ ...tableContainerStyle }}>
            <Table
              aria-labelledby='tableTitle'
              size={'small'} sx={{ ...tableStyle }} >
              <TableHead>
                <TableRow key={'head'} sx={{ height: isMobileOnly ? '30px' : '50px' }}>
                  {tableHeaders.map((headCell, index) => (
                    <StyledTableCell
                      key={`key_${index}`}
                      align={headCell.numeric === true ? 'right' : 'left'}
                      padding={'normal'}
                    >
                      {
                        headCell.label
                      }
                    </StyledTableCell>))}
                </TableRow>
              </TableHead>
              <TableBody>
                {
                  transactionsList
                  && transactionsList.enqTxn
                  && transactionsList.enqTxn.map((row, index) => {
                    return (
                      <StyledTableRow tabIndex={-1} key={index}>
                        <StyledTableCell scope="row" align="left">                
                            <h5 className='table-body-content'>{row.messageId}</h5>
                        </StyledTableCell>
                        <StyledTableCell align="left">
                          {
                            row.statusDescription ?
                              <Grid>
                                {row.msgStatus}
                                <Tooltip title={<h5>{row.statusDescription}</h5>}>
                                  <IconButton sx={{ marginLeft: '2px', padding: 0 }}>
                                    <InfoOutlined />
                                  </IconButton>
                                </Tooltip>
                              </Grid>
                              : row.msgStatus
                          }
                        </StyledTableCell>
                        <StyledTableCell align='left'>{row.messageTxnFlow}</StyledTableCell>
                        <StyledTableCell align='left'>{row.txnDate}</StyledTableCell>
                        <StyledTableCell align="left">{row.acknowledgementDate}</StyledTableCell>
                        <StyledTableCell>
                          <Button sx={{ padding: 0, justifyContent: 'center' }} variant='text' onClick={() => onHandleViewMXMTMessage(row)}>
                            {<FormattedMessage id="common.view" defaultMessage={defaultLocales['common.view']} />}
                          </Button>
                        </StyledTableCell>
                        <StyledTableCell align="right">{row.openingBalance}</StyledTableCell>
                        <StyledTableCell align="right">{row.closingBalance}</StyledTableCell>
                        <StyledTableCell align="left">{row.transactionCurrency}</StyledTableCell>
                      </StyledTableRow>
                    )
                  })
                }
                {totalCount === 0 && (
                  <TableRow
                    sx={{
                      height: 53,
                    }}>
                    <StyledTableCell colSpan={transType === OUT ? 10 : 8}>
                      <Typography sx={{ display: 'flex', justifyContent: 'center' }}>
                        <FormattedMessage id="viewTransactions.noRecords" defaultMessage={defaultLocales['viewTransactions.noRecords']} />
                      </Typography>
                    </StyledTableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
            <TablePagination component={"div"} count={totalCount || 0}
              page={pageNumber}
              rowsPerPageOptions={RowsPerPageOptions}
              onPageChange={onHandlePageChange}
              rowsPerPage={rowsPerPage} onRowsPerPageChange={handleChangeRowsPerPage}
              showFirstButton showLastButton />
          </TableContainer>
        </Grid>
      </LoadingViewer>
      {
        openViewMXMTMsg
        && <ViewMessageDialogMain openDialog={openViewMXMTMsg}
          selectedTableRowData={selectedTableRow} enqType={enqType} transType={transType}
          onHandleClose={onHandleCloseViewMsgDialog} />
      }
      <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesTrans.open}
        severity={snackBarPropertiesTrans.severity}
        message={snackBarPropertiesTrans.snackBarMessage} />
    </>
  )
})
export default ViewStatementsMain
