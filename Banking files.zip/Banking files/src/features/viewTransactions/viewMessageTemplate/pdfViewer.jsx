
import { DialogContent, DialogContentText, Dialog, DialogTitle, Grid, Typography } from "@mui/material";
import { PDFViewer, StyleSheet, Page, View, Document, Text, PDFDownloadLink } from "@react-pdf/renderer";
import MbButton from "../../common/mbButton";
import { CloseOutlined, FileDownloadOutlined } from "@mui/icons-material";
import { FormattedMessage } from "react-intl";
import { defaultLocales } from "../../i18n";
import { convertDataXMLtoJSONWithDeclaration } from "../../showMxTemplateAsTreeView/conversionHelpers";
import { has } from "lodash";
import moment from "moment";

const styles = StyleSheet.create({
    page: {
        backgroundColor: "white",
        color: "black",
        marginTop: 10,
        marginLeft: 20,
        marginRight: 10
    },
    section: {
        //   marginLeft: 20,
        //   marginRight: 10
    },
    viewer: {
        width: window.innerWidth, //the pdf viewer will take up all of the width and height
        height: window.innerHeight,
    },
    text: {
        fontSize: '12'
    },
    textNodeColor: {
        color: 'rgb(212, 57, 0)',
        fontSize: '12'
    },
    textProperty: {
        marginLeft: '15px',
        fontSize: '12'
    },
    viewParent: {
        fontSize: '12',
        marginLeft: '10px'
    },
    attriKey : {
        color: 'rgb(0, 116, 217)'
    },
    attriValue : {
        color: 'rgb(46, 204, 64)'
    }
});

export default function PdfViewer({ openPdfDialog, onHandlePdfClose, mxMessage, mtMessage, msgId, msgStatus }) {
    // Parse XML content into JavaScript object
    const parsedXML = convertDataXMLtoJSONWithDeclaration(mxMessage);
    const fileName = `${msgId}_${msgStatus}_${moment().format('DDMMYYYYHHmmss')}.pdf`
    const renderXMLToPdf = (data) => {
        try {
            return Object.keys(data).map((key, index) => {
                if (key === '_attributes' || key === '_declaration') return;
                // If key consists the array elements,
                if (Array.isArray(data[key])) {
                    const {attriKeys, attriValues} = getAttributes(data[key]);
                    return data[key].map((item, idx) => {
                        // If the element contains _text only, print the text
                        return has(item, '_text') ? (
                            <View key={`${key}-${idx}`} style={styles.viewParent}>
                                <Text>
                                    {'<'}<Text style={styles.textNodeColor}>{`${key}`}</Text>
                                    {attriKeys && attriKeys.length > 0 && 
                                        attriKeys.map((item, index) => {
                                            return (
                                                <Text style={styles.text}>
                                                    <Text style={styles.attriKey}>{item}</Text>
                                                    <Text style={styles.text}>{'='}</Text>
                                                    <Text style={styles.attriValue}>{`"${attriValues[index]}"`}</Text>
                                                </Text>
                                            )
                                    })}
                                    {'>'}
                                    {`${item._text}`}
                                    {'</'}<Text style={styles.textNodeColor}>{key}</Text>{'>'}
                                </Text>
                            </View>
                        ) : 
                        // If the element contains child element, iterate the child element once again as recursive.
                        <View key={`${key}-${idx}`} style={styles.viewParent}>
                            <Text>{'<'}<Text style={styles.textNodeColor}>{key}</Text>{'>'}</Text>
                            {renderXMLToPdf(item)}
                            <Text>{'</'}<Text style={styles.textNodeColor}>{key}</Text>{'>'}</Text>
                        </View>;
                    });
                }
                if (has(data[key], '_text')) {
                    const {attriKeys, attriValues} = getAttributes(data[key]);
                    if(attriKeys && attriKeys.length > 0) {
                        return (
                            <Text style={styles.textProperty}>
                                {'<'}<Text style={styles.textNodeColor}>{`${key} `}</Text> 
                                {attriKeys.map((item, index) => {
                                    return (
                                        <Text style={styles.text}>
                                            <Text style={styles.attriKey}>{item}</Text>
                                            <Text style={styles.text}>{'='}</Text>
                                            <Text style={styles.attriValue}>{`"${attriValues[index]}"`}</Text>
                                        </Text>
                                    )
                                })}
                                {'>'}
                                {`${data[key]._text}`}
                                {'</'}<Text style={styles.textNodeColor}>{`${key}`}</Text>{'>'}
                            </Text>
                        )
                    } else {
                        return (
                            <Text style={styles.textProperty}>
                                {'<'}<Text style={styles.textNodeColor}>{`${key}`}</Text>{'>'}
                                {`${data[key]._text}`}
                                {'</'}<Text style={styles.textNodeColor}>{`${key}`}</Text>{'>'}
                            </Text>
                        )
                    }
                    
                } else {
                    const {attriKeys, attriValues} = getAttributes(data[key]);
                    return (
                        <View style={styles.viewParent}>
                            <Text>
                                {'<'}
                                {
                                    attriKeys && attriKeys.length > 0 ? 
                                    <><Text style={styles.textNodeColor}>{`${key} `}</Text>
                                    {
                                        attriKeys.map((item, index) => {
                                            return (
                                                <Text style={styles.text}>
                                                    <Text style={styles.attriKey}>{item}</Text>
                                                    <Text style={styles.text}>{'='}</Text>
                                                    <Text style={styles.attriValue}>{`"${attriValues[index]}" `}</Text>
                                                </Text>
                                            )
                                        }) 
                                    }
                                    </>
                                    : <Text style={styles.textNodeColor}>{`${key}`}</Text>
                                }
                                {'>'}
                            </Text>
                            {renderXMLToPdf(data[key])}
                            <Text>{'</'}<Text style={styles.textNodeColor}>{`${key}`}</Text>{'>'}</Text>
                        </View>
                    )
                }
            })
        }
        catch(error) {
            alert(error);
            console.error(error);
        }
    }

    const getAttributes = (xmlSections) => {
        const attriKeys = [];
        const attriValues = [];
        if (has(xmlSections, '_attributes')) {
            const attriList = xmlSections['_attributes'];
            Object.keys(attriList).forEach(key => {
                attriKeys.push(key);
                attriValues.push(attriList[key]);
            })
        }
        return {attriKeys, attriValues};
    }

    const getDeclarations = () => {
        if (parsedXML._declaration && parsedXML._declaration._attributes) {
            const {attriKeys, attriValues} = getAttributes(parsedXML._declaration);
            return  <Text style={{ ...styles.text, whiteSpace: 'nowrap' }}>
                        <Text style={styles.text}>{'<?'}</Text>
                        <Text style={styles.textNodeColor}>{'xml ' }</Text>
                        {
                            attriKeys && attriKeys.map((item, index) => {
                                return (
                                    <Text style={styles.text}>
                                        <Text style={styles.attriKey}>{item}</Text>
                                        <Text style={styles.text}>{'='}</Text>
                                        <Text style={styles.attriValue}>{`"${attriValues[index]}" `}</Text>
                                    </Text>
                                )
                            })
                        }
                        <Text style={styles.text}>{'?>'}</Text>
                    </Text>
        }
        return null
    }

    const MXMTDocument = () => {
        return (
            <Document>
                <Page size={'A4'} style={styles.page}>
                    <View style={styles.section}>
                        <Text>MX Message</Text>
                        <Text>------------------</Text>
                        {getDeclarations()}
                        {/* <Text style={styles.text}>{'<'}
                            <Text style={styles.textNodeColor}>{'DataPDU'}</Text>
                            {' xmlns="urn:swift:saa:xsd:saa.2.0">'}</Text> */}
                        {renderXMLToPdf(parsedXML)}
                        {/* <Text style={styles.text}>
                            {'</'}
                            <Text style={styles.textNodeColor}>{'DataPDU'}</Text>
                            {'>'}
                        </Text> */}
                        <View style={{ margin: '10px' }}></View>
                        <Text>MT Message</Text>
                        <Text>------------------</Text>
                        <Text style={styles.text}>
                            {/* Hai */}
                            {mtMessage}
                        </Text>
                    </View>
                </Page>
            </Document>
        )
    }

    const renderClose = () => {
        return  <MbButton startIcon={<CloseOutlined />} buttonName={"Close"} onHandleAction={onHandlePdfClose} />
    }
    return (
        <Dialog
            fullScreen
            open={openPdfDialog}
            onClose={onHandlePdfClose}
            aria-labelledby="scroll-pdf-dialog-title"
            aria-describedby="scroll-pdf-dialog-description"
        >
            <DialogTitle id="scroll-pdf-dialog-title" sx={{ padding: 'initial' }} >
                <Grid sx={{ margin: 1, display: 'flex', flexDirection: 'row', height: '50px' }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold', display: 'flex', alignItems: 'center', width: '58%', padding: 'none' }}>
                        <FormattedMessage id='viewTransactions.printPreview'
                            defaultMessage={defaultLocales['viewTransactions.printPreview']} >
                            {
                                (msg) => `${msg} - ${fileName}`
                            }
                        </FormattedMessage>
                    </Typography>
                    <Grid item sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', width: '40%' }}>
                        <PDFDownloadLink document={<MXMTDocument />} fileName={fileName}>
                            {({ loading, error }) => (loading || error
                                ?
                                <Grid>
                                    <Typography sx={{ marginRight: '2px' }} variant="h6">
                                        {
                                            loading ? <FormattedMessage id={'viewTransactions.loadingDoc'}
                                            defaultMessage={defaultLocales['viewTransactions.loadingDoc']} />
                                            : error
                                        }
                                    </Typography>
                                </Grid>
                                : <Grid >
                                    <MbButton sx={{ marginRight: '10px' }}
                                        buttonName={<FormattedMessage id={'common.download'}
                                            defaultMessage={defaultLocales['common.download']} />}
                                        startIcon={<FileDownloadOutlined />}
                                    ></MbButton>
                                </Grid>         
                            )}
                        </PDFDownloadLink>
                        {renderClose()}
                    </Grid>
                </Grid>
            </DialogTitle>
            <DialogContent sx={{ padding: '5px' }}>
                <DialogContentText
                    id='scroll-pdf-dialog-description'
                    tabIndex={-1}>
                    <PDFViewer style={styles.viewer} showToolbar={false}>
                        <MXMTDocument />
                    </PDFViewer>
                </DialogContentText>
            </DialogContent>
        </Dialog>
    )
}