import XmlViewer from 'react-xml-viewer';
import { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { isDesktop } from "react-device-detect";
import { useDispatch, useSelector } from "react-redux";
import { CloseOutlined, PrintOutlined } from "@mui/icons-material";
import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Grid, 
    Tab, Tabs, Typography, IconButton } from "@mui/material";

import PdfViewer from "./pdfViewer";
import { defaultLocales } from "../../i18n";
import MbButton from "../../common/mbButton";
import { getSelectedMxMTMsgData } from "../viewTransactionsAction.js";
import { VIEW_TRANSACTIONS } from "../../../constants/sliceConstants.js";
import { MXMessageTabs, TRANS_TYPE } from "../../../constants/constants";

const customTheme = {
    attributeKeyColor: "#0074D9",
    attributeValueColor: "#2ECC40"
};

export default function ViewMessageDialogMain(
    { selectedTableRowData, enqType, transType, openDialog, onHandleClose }) {
    const [msgTabValue, setMsgTabValue] = useState('mx');
    const [openPdfViewer, setPdfViewer] = useState(false);
    const [dialogWidth, SetDialogWidth] = useState('md');
    const actionDispatch = useDispatch();
    const getMxMTMessage = useSelector(state => state[VIEW_TRANSACTIONS].mx_mt_OverlayMessage);

    useEffect(() => {
        SetDialogWidth('md');
        const requestBody = {
            messageDefId: selectedTableRowData.messageDefID,
            msgId: selectedTableRowData.messageId,
            msgVerNo: selectedTableRowData.messageLatestVersion,
            msgTypeToView: "BOTH"
        }
        actionDispatch(getSelectedMxMTMsgData(requestBody, TRANS_TYPE[transType], enqType.toUpperCase()))
    }, [selectedTableRowData])

    const onHandleMessageTabChange = (evet, tabValue) => {
        setMsgTabValue(tabValue);
    }

    const onHandlePdfViewerClose = () => {
        setPdfViewer(false)
    }

    return (
        <Dialog
            open={openDialog}
            onClose={onHandleClose}
            scroll='paper'
            aria-labelledby="scroll-dialog-title"
            aria-describedby="scroll-dialog-description"
            maxWidth={dialogWidth}
        >
            <DialogTitle sx={{ padding: '12px 16px' }} id="scroll-dialog-title">
                <Grid sx={{ display: 'flex', flexDirection: 'row', width: '100%' }}>
                    <Typography variant="h5" sx={{ width: '85%', padding: '10px' }}>
                        <FormattedMessage id="viewTransactions.viewMessageDialog.viewMxMTMsg">
                            {
                                (msg) => `${msg} - ${selectedTableRowData.messageId}`
                            }
                        </FormattedMessage>
                    </Typography>
                    <Grid sx={{ width: '15%', display: 'flex', justifyContent: 'flex-end' }}>
                        <IconButton onClick={onHandleClose}>
                            <CloseOutlined />
                        </IconButton>
                        {/* <MbDropdown labelName={'Set Width'} labelValue={dialogWidth} sxFormStyles={classes.widthDropdown}
                            dropdownList={DIALOGWIDTHS} onDropdownChange={(e) => SetDialogWidth(e.target.value)} /> */}
                    </Grid>
                </Grid>
            </DialogTitle>
            <DialogContent dividers={true} sx={{ padding: '5px' }}>
                <DialogContentText
                    id='scroll-dialog-description'
                    tabIndex={-1}
                >
                    <Tabs
                        sx={{ bgcolor: '#e3e3e3', color: 'black', borderTopLeftRadius: 1, borderTopRightRadius: 1 }}
                        value={msgTabValue}
                        onChange={onHandleMessageTabChange}
                        indicatorColor="secondary"
                        textColor="inherit"
                        variant="fullWidth"
                        aria-label="full width tabs example"
                    >
                        {
                            MXMessageTabs.map(msg => {
                                return <Tab label={msg.label} value={msg.value}
                                    sx={{ fontWeight: 'bold', textTransform: "none" }} key={`tab_${msg.label}`}
                                    id={`full-width-tab-${msg.value}`} aria-controls={`full-width-tabpanel-${msg.value}`} />
                            })
                        }
                    </Tabs>
                    {
                        msgTabValue === 'mx'
                            ?
                            getMxMTMessage && getMxMTMessage.mxMessage
                                ? <XmlViewer xml={getMxMTMessage.mxMessage} theme={customTheme} />
                                : <FormattedMessage id="viewTransactions.rawMessages.noDataFound"
                                    defaultMessage={defaultLocales['viewTransactions.rawMessages.noDataFound']} />
                            : null
                    }
                    {
                        msgTabValue === 'mt'
                            ? getMxMTMessage && getMxMTMessage.mtMessage
                                ? <Typography sx={{ whiteSpace: 'pre-wrap' }}>{getMxMTMessage.mtMessage}</Typography>
                                : <FormattedMessage id="viewTransactions.rawMessages.noDataFound"
                                    defaultMessage={defaultLocales['viewTransactions.rawMessages.noDataFound']} />
                            : null
                    }
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                {
                    isDesktop &&
                    <MbButton startIcon={<PrintOutlined />} className='button-action' buttonName={<FormattedMessage id="common.print" />}
                        onHandleAction={() => setPdfViewer(true)} />
                }
                {/* <MbButton startIcon={<CloseOutlined />} buttonName={<FormattedMessage id="common.close" />}
                    onHandleAction={onHandleClose} /> */}
            </DialogActions>
            {
                openPdfViewer && getMxMTMessage && <PdfViewer openPdfDialog={openPdfViewer} mxMessage={getMxMTMessage.mxMessage}
                    mtMessage={getMxMTMessage.mtMessage} msgId={selectedTableRowData.messageId}
                    msgStatus={selectedTableRowData.msgStatus}
                    onHandlePdfClose={onHandlePdfViewerClose} />
            }
        </Dialog>
    )
}