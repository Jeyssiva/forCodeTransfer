
import { DialogContent, DialogContentText, Dialog, DialogTitle, Grid, Typography } from "@mui/material";
import { PDFViewer, StyleSheet, Page, View, Document, Text, PDFDownloadLink } from "@react-pdf/renderer";
import MbButton from "../../common/mbButton";
import { CloseOutlined, FileDownloadOutlined } from "@mui/icons-material";
import { FormattedMessage } from "react-intl";
import { defaultLocales } from "../../i18n";
import moment from "moment";

const styles = StyleSheet.create({
    page: {
        backgroundColor: "white",
        color: "black",
        marginTop: 10,
        marginLeft: 20,
        marginRight: 10
    },
    section: {
        //   marginLeft: 20,
        //   marginRight: 10
    },
    viewer: {
        width: window.innerWidth, //the pdf viewer will take up all of the width and height
        height: window.innerHeight,
    },
    text: {
        fontSize: '12'
    },
    textNodeColor: {
        color: 'red'
    },
    textProperty: {
        marginLeft: '15px',
        fontSize: '12'
    },
    viewParent: {
        fontSize: '12',
        marginLeft: '10px'
    }
});

export default function PdfViewer({ openPdfDialog, onHandlePdfClose, mxMessage, mtMessage, msgId, msgStatus }) {
    const tagRegex = /<([^>]+)>([^<]*)<\/\1>|<([^>]+)>/g;
    const mxMsgArray = mxMessage !== "" && mxMessage !== undefined
        ? Array.from(mxMessage.matchAll(tagRegex), match => match[0])
        : [];
    const fileName = `${msgId}_${msgStatus}_${moment().format('DDMMYYYYHHmmss')}.pdf`
    //  [snackBarProp, setSnackBarProp] = useState({ open: false, severity: '', snackBarMessage: '' })

    const MXMTDocument = () => {
        return (
            <Document>
                <Page size={'A4'} style={styles.page}>
                    <View style={styles.section}>
                        <Text>MX Message</Text>
                        <Text>------------------</Text>
                        {
                            mxMsgArray.map(item => {
                                return <Text style={styles.text}> {item} </Text>
                            })
                        }
                        <View style={{ margin: '10px' }}></View>
                        <Text>MT Message</Text>
                        <Text>------------------</Text>
                        <Text style={styles.text}>
                            {/* Hai */}
                            {mtMessage}
                        </Text>
                    </View>
                </Page>
            </Document>
        )
    }

    return (
        <>
            <Dialog
                fullScreen
                open={openPdfDialog}
                onClose={onHandlePdfClose}
                // scroll = 'paper'
                aria-labelledby="scroll-pdf-dialog-title"
                aria-describedby="scroll-pdf-dialog-description"
            >
                <DialogTitle id="scroll-pdf-dialog-title" sx={{ padding: 'initial' }} >
                    <Grid sx={{ margin: 1, display: 'flex', flexDirection: 'row', height: '50px' }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 'bold', display: 'flex', alignItems: 'center', width: '58%', padding: 'none' }}>
                            <FormattedMessage id='viewTransactions.printPreview'
                                defaultMessage={defaultLocales['viewTransactions.printPreview']} >
                                {
                                    (msg) => `${msg} - ${fileName}`
                                }
                            </FormattedMessage>
                        </Typography>
                        <Grid item sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', width: '40%' }}>
                            <PDFDownloadLink document={<MXMTDocument />} fileName={fileName}
                                onClick={e => alert('Success')} >
                                {({ blob, url, loading, error }) => (loading
                                    ? <Typography sx={{ marginRight: '5px' }} variant="h6">
                                        <FormattedMessage id={'viewTransactions.loadingDoc'}
                                            defaultMessage={defaultLocales['viewTransactions.loadingDoc']} />
                                    </Typography>
                                    : <MbButton sxButtonStyle={{ marginRight: '10px' }}
                                        buttonName={<FormattedMessage id={'common.download'}
                                            defaultMessage={defaultLocales['common.download']} />}
                                        startIcon={<FileDownloadOutlined />}
                                    // onHandleAction={(e) => setSnackBarProp({open: true, severity: 'success', snackBarMessage: 'Success'})}
                                    ></MbButton>)}
                            </PDFDownloadLink>
                            <MbButton startIcon={<CloseOutlined />}
                                buttonName={<FormattedMessage id={'common.close'}
                                    defaultMessage={defaultLocales['common.close']} />}
                                onHandleAction={onHandlePdfClose} />
                        </Grid>
                    </Grid>
                </DialogTitle>
                <DialogContent sx={{ padding: '5px' }}>
                    <DialogContentText
                        id='scroll-pdf-dialog-description'
                        tabIndex={-1}
                    >
                        <PDFViewer style={styles.viewer} showToolbar={false}>
                            <MXMTDocument />
                        </PDFViewer>
                    </DialogContentText>
                </DialogContent>
                {/* {
                snackBarProp.open &&
                    <MbSnackbar onClose={onSnackBarClose} open={snackBarProp.open} 
                        severity={snackBarProp.severity} 
                        message={snackBarProp.snackBarMessage}/>
             } */}
            </Dialog>
        </>
    )
}