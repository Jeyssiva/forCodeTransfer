import * as React from 'react';
import {
  Button, Grid, IconButton, Table, TableBody, TableContainer,
  TableHead, TablePagination, TableRow, Tooltip, Typography
} from "@mui/material";
import { isMobileOnly } from 'react-device-detect';
import { FormattedMessage } from 'react-intl';
import { defaultLocales } from '../i18n';
import { makeStyles } from '@mui/styles';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import ViewMessageDialogMain from './viewMessageTemplate/viewRawMsgDialogMain';
import { StyledTableCell, StyledTableRow } from './helpers'
import { ACCESS_LEVEL_ALL, ACCESS_LEVEL_READ, RowsPerPageOptions, TRANS_TYPE } from '../../constants/constants';
import {  getAllTransationsByPagination } from './viewTransactionsAction';
import MbSnackbar from '../common/mbSnackbar';
import { isEmpty } from 'lodash';
import {
  getClosePopupAfterSuccess,
  getLoadingTxnDet, getSnackBarTrans, loadTxnDetonReferenceNumClick, resetCloseTxnDtlPopup, selectorTransList, setDisableMkrChkrActivity,
  setLoadingTxn, setTemplateLoading, snackBarActionsTrans
} from './viewTransactionSlice';
import { getScreenAccess } from '../dashboard/dashboardSlice';
import { InfoOutlined } from '@mui/icons-material';
import { INITIAL_SEARCH_REQUEST, OUT, OUTCOMING_TABLE_HEADERS } from '../../constants/transactionConstants';
import LoadingViewer from '../loadingViewer';
import { resetSaa } from '../showMxTemplateAsTreeView/saaHeaderSlice';
import { resetJsonApp } from '../showMxTemplateAsTreeView/appHeaderSlice';
import { resetJsonBody } from '../showMxTemplateAsTreeView/bodySlice';
import { resetJson } from '../showMxTemplateAsTreeView/showMxTempSlice';
import ViewSelectedTransactionDialogMain from './viewSelectedTransactionDialogMain';
export const useStyles = makeStyles(() => ({
  searchCriteria: {
    width: '23%',
    marginRight: '10px'
  },
  viewButtonStyle: {
    padding: '5px 16px'
  },
  tableContainer: {
    borderRadius: 1,
    overflowY: 'auto'
  }
}))

const ViewTransactionsMain = React.memo(function ViewTransactionsMain({ transType, enqType, scrollNeed = false,
  searchFilter = { ...INITIAL_SEARCH_REQUEST }, refreshPage, switchActivated = null, tableHeaders = OUTCOMING_TABLE_HEADERS }) {
  const [pageNumber, setPageNumber] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [openViewMXMTMsg, setOpenViewMXMTMsg] = React.useState(false);
  const [openViewTxnAsDtl, setOpenTxnAsDtl] = React.useState(false);
  const [selectedTableRow, setSelectedTableRow] = React.useState({});
  const snackBarPropertiesTrans = useSelector(getSnackBarTrans);
  const transactionsList = useSelector(selectorTransList);
  const screenAccessDet = useSelector(getScreenAccess);
  const isLoadingTxnDet = useSelector(getLoadingTxnDet);
  const closePopup = useSelector(getClosePopupAfterSuccess);

  const actDispatch = useDispatch();

  React.useEffect(() => {
    if(!openViewTxnAsDtl) {
      actDispatch(setTemplateLoading({status: false}));
      actDispatch(resetJson());
      actDispatch(resetSaa());
      actDispatch(resetJsonApp());
      actDispatch(resetJsonBody());
    }
  }, [actDispatch, openViewTxnAsDtl]);

  const loadingTxn = (tType, enType, rows, pageNum, sFilter) => {
    const reqBody = {
      "maxResults": rows,
      "pageNo": pageNum,
      "searchSortColumn": "createdDt",
      "sortDirection": "DESC",      
      "searchCriteria": [
        {
          ...sFilter
        }
      ]
    }      
    actDispatch(setLoadingTxn({status: true}));
    //The state is used for disable maker/checker's actions after any timeout API.
    //Here, revert the the disable status should be false while view transactions.
    actDispatch(setDisableMkrChkrActivity({status: false}));
    actDispatch(getAllTransationsByPagination(reqBody, TRANS_TYPE[tType], enType.toUpperCase(), enType))
  }
  React.useEffect(() => {
    if (switchActivated === null) return;
    if (pageNumber !== 0 || rowsPerPage !== 10) {
      setPageNumber(0);
      setRowsPerPage(10);
    }
  }, [switchActivated])

  React.useEffect(() => {
    if (isEmpty(enqType)) return;
    loadingTxn(transType, enqType, rowsPerPage, pageNumber, searchFilter);
  }, [enqType, rowsPerPage, pageNumber, refreshPage, actDispatch, searchFilter, transType])

  React.useEffect(() => {
    if (!closePopup) return;
    setOpenTxnAsDtl(false);
    actDispatch(resetCloseTxnDtlPopup());
  }, [closePopup, actDispatch]);

  React.useEffect(() => {
    if (!enqType || transType === OUT) return;
    setPageNumber(0);
    setRowsPerPage(10);
  }, [enqType, transType])

  const onHandlePageChange = (e, newPage) => {
    setPageNumber(newPage)
  }
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10))
    setPageNumber(0)
  }
  const onSnackBarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    actDispatch(snackBarActionsTrans({ open: false, severity: '', snackBarMessage: '' }));
  }
  const onHandleCloseViewMsgDialog = () => {
    setOpenViewMXMTMsg(false)
    setSelectedTableRow({})
  }
  const onHandleViewMXMTMessage = (selRow) => {
    setOpenViewMXMTMsg(true)
    setSelectedTableRow(selRow)
  }
  // const onHandleBackView = () => {
  //   onHandleBackViewMain({ pageNumber, rowsPerPage });
  // }

  const onHandleCloseViewTxnAsDtl = () => {
    setOpenTxnAsDtl(false);
  }

  const onHandleViewReferenceNo = (row) => {
    setOpenTxnAsDtl(true)
    actDispatch(loadTxnDetonReferenceNumClick({rowData:row}))
  }

  const totalCount = transactionsList ? transactionsList.totalCount : 0;
  const maxResults = transactionsList ? transactionsList.maxResults : 0;
  const tableContainerStyle = maxResults > 10 && scrollNeed ? { height: '510px', maxHeight: '800px', overflowY: 'auto', borderRadius: 1 } : {};
  const tableStyle = maxResults > 10 && scrollNeed ? { height: '440px', maxHeight: '800px' } : {};

  if (enqType === "") return;

  return (
    <>
      <LoadingViewer loading={isLoadingTxnDet}>
        <Grid sx={scrollNeed ? { m: 0.5 } : { m: 0.5, width: '99.5%' }}>
          <TableContainer sx={{ ...tableContainerStyle }}>
            <Table
              aria-labelledby='tableTitle'
              size={'small'} sx={{ ...tableStyle }} >
              <TableHead>
                <TableRow key={'head'} sx={{ height: isMobileOnly ? '30px' : '50px' }}>
                  {tableHeaders.map((headCell, index) => (
                    <StyledTableCell
                      key={`key_${index}`}
                      align={headCell.numeric === true ? 'right' : 'left'}
                      padding={'normal'}
                    >
                      {
                        headCell.label
                      }
                    </StyledTableCell>))}
                </TableRow>
              </TableHead>
              <TableBody>
                {
                  transactionsList
                  && transactionsList.enqTxn
                  && transactionsList.enqTxn.map((row, index) => {
                    return (
                      <StyledTableRow tabIndex={-1} key={index}>
                        <StyledTableCell scope="row" align="left">
                          <Button component={Link} state={{ selTransaction: row }} sx={{ padding: 0 }} variant='text'
                            onClick={() => onHandleViewReferenceNo(row)}>
                            <h5 className='table-body-content'>{row.messageId}</h5>
                          </Button>
                        </StyledTableCell>
                        <StyledTableCell align="left">
                          {
                            row.statusDescription ?
                              <Grid>
                                {row.msgStatus}
                                <Tooltip title={<h5>{row.statusDescription}</h5>}>
                                  <IconButton sx={{ marginLeft: '2px', padding: 0 }}>
                                    <InfoOutlined />
                                  </IconButton>
                                </Tooltip>
                              </Grid>
                              : row.msgStatus
                          }
                        </StyledTableCell>
                        {
                          transType === OUT &&
                          <StyledTableCell align='left'>
                            {`${row.messageTxnFlow}`}
                          </StyledTableCell>
                        }
                        <StyledTableCell align="left">{row.debitBic}</StyledTableCell>
                        <StyledTableCell align="left">{row.createdDt}</StyledTableCell>
                        <StyledTableCell align="left">{row.updatedDt}</StyledTableCell>
                        {
                          transType === OUT && <StyledTableCell align='left'>{row.acknowledgementDate}</StyledTableCell>
                        }
                        <StyledTableCell>
                          <Button sx={{ padding: 0, justifyContent: 'center' }} variant='text' onClick={() => onHandleViewMXMTMessage(row)}>
                            {<FormattedMessage id="common.view" defaultMessage={defaultLocales['common.view']} />}
                          </Button>
                        </StyledTableCell>
                        <StyledTableCell align="right">{row.transactionAmount}</StyledTableCell>
                        <StyledTableCell align="left">{row.transactionCurrency}</StyledTableCell>
                        {
                          !isEmpty(screenAccessDet)
                          && (screenAccessDet.levelName === ACCESS_LEVEL_READ || screenAccessDet.levelName === ACCESS_LEVEL_ALL)
                          && transType === OUT
                          && <StyledTableCell align='left'>{row.updatedBy || ''}</StyledTableCell>
                        }
                      </StyledTableRow>
                    )
                  })
                }
                {totalCount === 0 && (
                  <TableRow
                    sx={{
                      height: 53,
                    }}>
                    <StyledTableCell colSpan={transType === OUT ? 10 : 8}>
                      <Typography sx={{ display: 'flex', justifyContent: 'center' }}>
                        <FormattedMessage id="viewTransactions.noRecords" defaultMessage={defaultLocales['viewTransactions.noRecords']} />
                      </Typography>
                    </StyledTableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
            <TablePagination component={"div"} count={totalCount || 0}
              page={pageNumber}
              rowsPerPageOptions={RowsPerPageOptions}
              onPageChange={onHandlePageChange}
              rowsPerPage={rowsPerPage} onRowsPerPageChange={handleChangeRowsPerPage}
              showFirstButton showLastButton />
          </TableContainer>
        </Grid>
      </LoadingViewer>
      {
        openViewMXMTMsg
        && <ViewMessageDialogMain openDialog={openViewMXMTMsg}
          selectedTableRowData={selectedTableRow} enqType={enqType} transType={transType}
          onHandleClose={onHandleCloseViewMsgDialog} />
      }
      {
        openViewTxnAsDtl
        && <ViewSelectedTransactionDialogMain transType={transType} openViewRef={openViewTxnAsDtl} onHandleClose={onHandleCloseViewTxnAsDtl} />
      }
      <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesTrans.open}
        severity={snackBarPropertiesTrans.severity}
        message={snackBarPropertiesTrans.snackBarMessage} />
    </>
  )
})
export default ViewTransactionsMain
