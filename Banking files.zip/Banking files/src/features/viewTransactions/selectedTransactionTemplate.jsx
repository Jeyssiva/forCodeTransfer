// import { Container, Grid, Typography } from "@mui/material"
// import { useDispatch, useSelector } from "react-redux"
// import * as React from "react";
// import MbButton from "../common/mbButton";
// import { ACCESS_LEVEL_ALL, ACCESS_LEVEL_READ, ACCESS_LEVEL_WRITE, DATE_TIME_FORMAT, TRANS_TYPE, sessionItems } from "../../constants/constants";
// import { getConfirmNaviMsg, getSaveSelectedMxMT, getSelectedTxnDet, setConfirmNaviMsg } from "../showMxTemplateAsTreeView/showMxTempSlice";
// import {Link, useLocation, useNavigate } from 'react-router-dom';
// import { VIEW_TRANSACTIONS } from "../../constants/sliceConstants";
// import { CUSTPAYMENTMAINROUTE, HOME_PAGE, MODULENAME } from "../../constants/routesURL";
// import BreadCrumbs from "./breadcrumbs";
// import { FormattedMessage } from "react-intl";
// import MakerActivities from './makerActivities';
// import CheckerActivities from './checkerActivities';
// import { defaultLocales } from "../i18n";
// import { getSelectedMXDataByMsgId, saveTransactionDetailAction } from "./viewTransactionsAction";
// import ShowMxTemplateMain from "../showMxTemplateAsTreeView/showTemplateMain";
// import MbSnackbar from "../common/mbSnackbar";
// import { getDisableMkrChkrActivity, getTempLoadingDetails, setTemplateLoading, snackBarActionsTrans } from "./viewTransactionSlice";
// import { isEmpty } from "lodash";
// import { getScreenAccess, getSelectedMenuInfo } from "../dashboard/dashboardSlice";
// import { memo } from "react";
// import { PAYMENT_TABS } from "../../constants/transactionConstants";
// import { MSG_STATUS_DRAFT, MSG_STATUS_DRAFTRETURN, MSG_STATUS_PENDING_APPROVAL } from "../../constants/mxTempConstants";
// import { useEffect } from "react";
// import LoadingViewer from "../loadingViewer";
// import { initialState } from "../customerPaymentData/customerReducer";
// import ConfirmationDialog from "../customerPaymentData/confirmationDialog";
// import { convertDataXMLtoJSONWithDeclaration } from "../showMxTemplateAsTreeView/conversionHelpers";
// import moment from "moment";
// import { setSaaTreeMountedStatus } from "../showMxTemplateAsTreeView/saaHeaderSlice";
// import { getAllStaticTransDataPersist, getCountryListPersist } from "../showMxTemplateAsTreeView/persistedSlice";
// import { getAllStaticTransactionDataAction } from "../showMxTemplateAsTreeView/showTempAction";

//  const SelectedTemplate = memo (({transType}) => {
//     const actDispatch = useDispatch();
//     const [enqType, setEnqType] = React.useState('b2c');

//     const selectedMenuInfo = useSelector(getSelectedMenuInfo);
//     const snackBarPropertiesTrans = useSelector(state => state[VIEW_TRANSACTIONS].snackBarPropertiesTrans);
//     // const isTreeviewMounted = useSelector(state => state[SHOW_MX_TEMPLATE].isTreeviewMounted);
//     const tempTransLoadingDetails = useSelector(getTempLoadingDetails);
//     const selectedTxnDet = useSelector(getSelectedTxnDet);
//     const screenAccessDet = useSelector(getScreenAccess);
//     const confirmCustNaviMsg = useSelector(getConfirmNaviMsg);
//     const disableActivity = useSelector(getDisableMkrChkrActivity);
    
//     const countryListPersist = useSelector(getCountryListPersist);
    
//     const location = useLocation();
//     const navigation = useNavigate();
//     let {selTransaction: {messageId = "", messageLatestVersion, updatedBy,
//      msgStatus: msgStatusFromLocation, messageDefID} = {}, selectedTab = '' } = location.state || {};

//     const {enqTxn : [{msgStatus, mxMessage}] = [{msgStatus: msgStatusFromLocation}] } 
//     = selectedTxnDet || {};

//     // const loadTxnDet = (tType, enType, messageId, messageLatestVersion) => {
//     //   const requestBody = {
//     //     messageDefId: messageDefID,
//     //     msgId: messageId,
//     //     msgVerNo: messageLatestVersion,
//     //     msgTypeToView : "Mx"           
//     //   }
//     //   actDispatch(getSelectedMXDataByMsgId(requestBody, TRANS_TYPE[tType], enType.toUpperCase()))
//     // }

//     useEffect(() => {  
//       return () => {
//         actDispatch(snackBarActionsTrans({open:false}));
//         actDispatch(setTemplateLoading({status: false}));
//       }
//     }, [])

//     useEffect(() => {
//       if(!selectedMenuInfo || isEmpty(selectedMenuInfo)) return;     
//       const [ tType, enType ] = selectedMenuInfo.menuUrl.split('/');
//       // setTransType(tType);
//       setEnqType(enType);
//       // loadTxnDet(tType, enType, messageId, messageLatestVersion);
//       return () => {
//         actDispatch(setSaaTreeMountedStatus({status: false}));
//       }
//     }, [])

//     const onSnackBarClose = (event, reason) => {
//       if(reason === 'clickaway'){
//           return;
//       }
//       actDispatch(snackBarActionsTrans({open: false}));
//     }

//     const selectedPayment = PAYMENT_TABS.find(x => x.value === selectedTab);
//     const crumbs = React.useMemo(() => 
//       [{name:`viewTransactions.${transType}Title`, formattedName: true}, 
//       {name:`viewTransactions.${enqType}.title`, formattedName: true, color: 'inherit',
//       url : `/${MODULENAME}/${transType}/${enqType}/`},
//       selectedPayment 
//         ? {name: selectedPayment.label} 
//         : {name: 'viewTransactions.allPayment', formattedName: true},
//        {name : msgStatus},
//       {name: 'viewTransactions.paymentDetail', formattedName: true}
//     ]
//     , [msgStatus, enqType, transType])

//     const onHandleAction = (actionData, naviStatus = false, txnDetails) => {
//       const {verPkSeqNo} = txnDetails || {};
//       const requestBody = {...actionData, msgId: messageId, msgVerNo : messageLatestVersion, 
//           msgStatus, verPkSeqNo, messageDefId: messageDefID};
//       // MOMENT_CUR_TIMEZONE
//       const statusMessage = `Your request has been submitted at ${moment().format(DATE_TIME_FORMAT)}`;
//       actDispatch(setTemplateLoading({status: true}));
//       actDispatch(saveTransactionDetailAction(requestBody, TRANS_TYPE[transType], enqType, statusMessage, naviStatus));
//     }

//     const onHandleConfirmNaviCancel = () => {
//      actDispatch(setConfirmNaviMsg({status: false}));
//     }

//     const onHandleConfirmNaviOk = () => {
//       try {
//         const {selectedCustomer} = initialState;
//         const resultJson = convertDataXMLtoJSONWithDeclaration(mxMessage);
//         const fitName = enqType === 'b2b' ? 'FICdtTrf' : 'FIToFICstmrCdtTrf';
//         const getCreditTransfer = resultJson["DataPDU"]["Body"]["Document"][fitName]["CdtTrfTxInf"] || {};
//         const getDebt = enqType === 'b2c' 
//                   ? getCreditTransfer["Dbtr"] || {} 
//                   : (getCreditTransfer["Dbtr"] && getCreditTransfer["Dbtr"]["FinInstnId"]) || {};
//         const getDebtAcct = (getCreditTransfer && getCreditTransfer["DbtrAcct"]) || {};
//         const custBankAcNo = (getDebtAcct 
//                             && getDebtAcct["Id"]
//                             && getDebtAcct["Id"]["Othr"]
//                             && getDebtAcct["Id"]["Othr"]["Id"]
//                             && getDebtAcct["Id"]["Othr"]["Id"]._text) || '';
//         const custName = (getDebt && getDebt["Nm"] && getDebt["Nm"]._text) || '';
//         const getPostalAddress = (getDebt && getDebt["PstlAdr"]) || {};
//         const addressInfo = {
//             ...selectedCustomer.addressInfo,
//             dept: (getPostalAddress["Dept"] && getPostalAddress["Dept"]._text) || '',
//             subDept: (getPostalAddress["SubDept"] && getPostalAddress["SubDept"]._text) || '',
//             streetName: (getPostalAddress["StrtNm"] && getPostalAddress["StrtNm"]._text) || '',
//             buildingNo: (getPostalAddress["BldgNb"] && getPostalAddress["BldgNb"]._text) || '',
//             buildingName: (getPostalAddress["BldgNm"] && getPostalAddress["BldgNm"]._text) || '',
//             floor: (getPostalAddress["Flr"] && getPostalAddress["Flr"]._text) || '', 
//             postBox: (getPostalAddress["PstBx"] && getPostalAddress["PstBx"]._text) || '',
//             room: (getPostalAddress["Room"] && getPostalAddress["Room"]._text) || '',
//             postCode: (getPostalAddress["PstCd"] && getPostalAddress["PstCd"]._text) || '',
//             townName: (getPostalAddress["TwnNm"] && getPostalAddress["TwnNm"]._text) || '',
//             townLocName: (getPostalAddress["TwnLctnNm"] && getPostalAddress["TwnLctnNm"]._text) || '',
//             districtName: (getPostalAddress["DstrctNm"] && getPostalAddress["DstrctNm"]._text) || '',
//             countrySubDv: (getPostalAddress["CtrySubDvsn"] && getPostalAddress["CtrySubDvsn"]._text) || '',
//             country: (getPostalAddress["Ctry"] && getPostalAddress["Ctry"]._text) || '',
//         }
//         actDispatch(setConfirmNaviMsg({status: false}));
//         navigation(`${HOME_PAGE}${CUSTPAYMENTMAINROUTE}`, {state : {...selectedCustomer, custBankAcNo, custName, addressInfo}})
//       }
//       catch(err) {
//         actDispatch(snackBarActionsTrans({open: true, severity: 'error', snackBarMessage: `${err.message}`}));
//       }
//     }

//     // const renderActivitiesButtons = React.useCallback(() => {
//     //   if(isEmpty(screenAccessDet) || disableActivity) return null;
//     //   const getUsername = sessionStorage.getItem(sessionItems.Username);
//     //   // disableActivity - while approve/reject/return the transation detail, if timeout exists , disable the checker activities
//     //   if((screenAccessDet.levelName === ACCESS_LEVEL_WRITE || screenAccessDet.levelName === ACCESS_LEVEL_ALL)
//     //     && [MSG_STATUS_DRAFT, MSG_STATUS_DRAFTRETURN].includes(msgStatus.toLowerCase())
//     //     && updatedBy !== getUsername)
//     //     return <MakerActivities onHandleAction = {onHandleAction} />

//     //   // if the loggedin user has maker and checker role, no privilege to review the same payment data which one updated by same user.  
//     //   if((screenAccessDet.levelName === ACCESS_LEVEL_READ || screenAccessDet.levelName === ACCESS_LEVEL_ALL) 
//     //     && msgStatus.toLowerCase() === MSG_STATUS_PENDING_APPROVAL && updatedBy !== getUsername)
//     //     return <CheckerActivities onHandleAction = {onHandleAction} />
//     //   return null;
//     // }, [selectedMenuInfo, msgStatus, disableActivity]);

//     if(!transType) return null;

//     const {tempLoadingIndicator = false, tempLoadingMessage} = tempTransLoadingDetails || {};

//     return (
//       <LoadingViewer loading = {tempLoadingIndicator} message = {tempLoadingMessage}>
//         <Container maxWidth={false} disableGutters sx={{height: 'auto', width: 'auto', paddingTop: '10px', px: '5px'}}>
//           <BreadCrumbs crumbsList={crumbs} currentPage={enqType} transType={transType}/>
//           <Grid sx={{display: 'flex', flexDirection: 'row', height: '50px'}}>   
//               <Typography variant='h5' sx = {{fontWeight: 'bold', display: 'flex', alignItems: 'center', width: '50%', fontSize: '13px'}}>
//                   {messageId}
//               </Typography>
//               {/* <Grid item sx= {{display: 'flex', alignItems: 'center', justifyContent: 'flex-end', width:'50%'}}>
//                 {
//                   renderActivitiesButtons()
//                 }
//                 <Link to = {`/${MODULENAME}/${transType}/${enqType}/`}>
//                   <MbButton size="small" sxButtonStyle={{marginRight: '8px'}} buttonName={
//                     <FormattedMessage id = 'common.back' defaultMessage={defaultLocales['common.back']} />
//                   }/>
//                 </Link>     
//               </Grid> */}
//           </Grid>
//           {/* <ShowMxTemplateMain staticHeight = {270} /> */}
//           <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesTrans.open} 
//             severity={snackBarPropertiesTrans.severity} 
//             message={snackBarPropertiesTrans.snackBarMessage}/>
//               {
//                 confirmCustNaviMsg && <ConfirmationDialog openDialog={confirmCustNaviMsg} 
//                 dialogContent="Debtor information has been changed. Please proceed to complete the update at 'Customer Payment Data'."
//                 onHandleCancel={onHandleConfirmNaviCancel} onHandleOk={onHandleConfirmNaviOk} />
//               }
//         </Container>
//       </LoadingViewer>
//     )
//   })

//   export default SelectedTemplate;