import moment from "moment";
import { useSelector } from "react-redux";
import { FormattedMessage } from "react-intl";
import { CloseOutlined } from "@mui/icons-material";
import { Typography, CardMedia, Dialog, DialogContent, DialogContentText, DialogTitle, IconButton, List, ListItem, ListItemText } from "@mui/material";

import { defaultLocales } from "../i18n";
import human from '../../images/human.jpg';
import { getUserInfo } from "../login/loginSlice";
import { DATE_FORMAT } from "../../constants/constants";

export default function ProfileMain({ openDialog, onClose }) {
    const getUserDetail = useSelector(getUserInfo);
    if (!getUserDetail) return null;
    return (
        <Dialog
            open={openDialog}
            onClose={onClose}
        >
            <DialogTitle component={'span'} id="confirm-dialog-title" sx={{ textTransform: 'uppercase', justifyContent: 'left', display: 'flex', justifyContent: 'space-between' }}>
                <h2>
                    <FormattedMessage id='profilePage.title' defaultMessage={defaultLocales["profilePage.title"]} />
                </h2>
                <IconButton onClick={onClose}>
                    <CloseOutlined />
                </IconButton>
            </DialogTitle>
            <DialogContent dividers>
                <DialogContentText component={'span'} sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <CardMedia
                        component="img"
                        className="profile"
                        image={human}
                        alt="profile"
                    />
                    <List sx={{ border: 1, borderColor: '#c0c0c0', display: 'flex', flexDirection: 'column' }}>
                        <ListItem>
                            <ListItemText className="profile" primary="Name"></ListItemText>
                            <Typography component={'span'} variant='h5' className="profile-title">{getUserDetail.userTitle} {getUserDetail.userFirstName} {getUserDetail.userLastName}
                            </Typography>
                        </ListItem>
                        <ListItem>
                            <ListItemText className="profile" primary="D.O.B"></ListItemText>
                            <Typography component={'span'} variant='h5' className="profile-title">{`${getUserDetail.dob && moment(getUserDetail.dob).format(DATE_FORMAT)}`}</Typography>
                        </ListItem>
                        <ListItem>
                            <ListItemText className="profile" primary="PF Number"></ListItemText>
                            <Typography component={'span'} variant='h5' className="profile-title">{`${getUserDetail.pfNo}`}</Typography>
                        </ListItem>
                        <ListItem>
                            <ListItemText className="profile" primary="Role Name"></ListItemText>
                            <Typography component={'span'} variant='h5' className="profile-title">{`${getUserDetail && getUserDetail.userUserGroups
                                && getUserDetail.userUserGroups[0] && getUserDetail.userUserGroups[0].userGroupId}`}</Typography>
                        </ListItem>
                        <ListItem>
                            <ListItemText className="profile" primary={`Email `}></ListItemText>
                            <Typography component={'span'} variant='h5' className="profile-title">{`${getUserDetail.userContactDetailDTO.email}`}</Typography>
                        </ListItem>
                    </List>
                </DialogContentText>
            </DialogContent>
        </Dialog >
    )
}