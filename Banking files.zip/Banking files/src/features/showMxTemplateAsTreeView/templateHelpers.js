import { cloneDeep, has, isEmpty } from "lodash";
import { AddressPatternFields, ERRORCODES } from "../../constants/mxTempConstants";
import { PATTERN_DESCRIPTION } from "../../constants/constants";
import { checkLastItemIsNumber } from "./validationHelpers";

function restrictionData(data, type, parentDetails, purposeCodes) { 
    const findRestriction = data[type].elements.find(ele => ele.name === 'xs:restriction');
    if(findRestriction){
        const restrictObj = {};
       // restrictObj.base = findRestriction.attributes.base;
        const eType = findRestriction.attributes.base.split(':')[1];
        restrictObj.elementType = eType;
        // By Default, disableField and isMandatory should be false.
        restrictObj.disableField = false;
        restrictObj.ismandatoryfield = false
        const findEnumeration = findRestriction.elements 
                        && findRestriction.elements.filter(ele => ele.name === 'xs:enumeration');    
        if(findEnumeration && findEnumeration.length > 0){
            restrictObj.elementType = 'dropdown';
            const options = findEnumeration.map(enumItem => {
                const { attributes, elements } = enumItem;
                if(elements)           
                    return {
                        value: attributes.value,
                        label: `${attributes.value}(${elements[0].elements[0].elements[0].text})`,
                        desc: elements[0].elements[1].elements[0].text
                    }
                else
                {
                    // const lastParentName = parType.slice(-1)[0]
                    // const findTitleandDesc = appHeaderTitle.find(h => h.key === attributes.value && (h.parent === lastParentName || h.parent === null));
                    // if(findTitleandDesc) {
                    //     const {label, desc, key} = findTitleandDesc;
                    //     return {
                    //         value: key,
                    //         label,
                    //         desc
                    //     }
                    // } else {             
                        return {
                            value: attributes.value,
                            label: attributes.value,
                            desc: ""
                        }
                    // }
                }
                   
            })
            restrictObj.options = options;
        } else {
            let validations = {};   
            findRestriction.elements && findRestriction.elements.forEach(validItem => {
                const isNum = /^\d+$/.test(validItem.attributes.value);
                validations = {...validations, [validItem.name.split(":")[1]] : isNum 
                    ? Number(validItem.attributes.value) 
                    : validItem.attributes.value}
            })

            if(!isEmpty(validations)) {
                if(validations.pattern){
                    const {desc, example} = PATTERN_DESCRIPTION[validations.pattern]
                    restrictObj.restrictions = {...validations, patternDescription: desc, Example : example};
                } else {
                    restrictObj.restrictions = validations;
                }
                restrictObj.elementType = validations && validations.maxLength > 50 && eType === 'string' ? 'longString' : eType;
            }
            // Added the pattern validation manually for Debitor accountname and structured address.
            if(eType === 'string' || eType === 'longString') {
                let [parentName, fieldName] = parentDetails.slice(-2);
                // The manual pattern validation is apllicable for Debitor and Postal Address.
                if(parentName === 'Dbtr' || parentName === 'Cdtr' || parentName === 'PstlAdr') {
                    if(fieldName === 'Nm')
                        restrictObj.restrictions = {...restrictObj.restrictions || {}, pattern: '(?!.* {2})[a-zA-Z0-9,@\\/().& -]+',
                            patternDescription: 'Matches a string consisting of alphanumeric characters and allows some special characters like comma (,), at symbol (@), forward slash (/), period (.), hyphen (-), parentheses (()), ampersand (&), and single space ( )',
                            example: 'Example@123'}

                    else if(AddressPatternFields.includes(fieldName))
                        restrictObj.restrictions = {...restrictObj.restrictions || {}, pattern: '(?!.* {2})[a-zA-Z0-9,@\\/().#& -]+',
                            patternDescription: 'Matches a string consisting of alphanumeric characters and allows some special characters like comma (,), at symbol (@), forward slash (/) period (.), hyphen (-), Number sign(#), parentheses (()), ampersand (&), and single space ( )',
                            example: 'Number#123'}
                }
                // Set the Purpose code as dropdown, it is applicable for tansaction type Out-B2C
                else if(parentName === 'Purp' && fieldName === 'Cd' && type === 'ExternalPurpose1Code' && purposeCodes) {
                    restrictObj.elementType = 'dropdown';
                    const options = purposeCodes.map(purpItem => {             
                        return {
                            value: purpItem.code,
                            label: `(${purpItem.code})${purpItem.description}` ,
                            desc: purpItem.description
                        }
                    })
                    restrictObj.options = options
                }
            } 
        }
        return restrictObj;
    }
    return null;
}
function getRestrictions(restrictElements){
    let baseValidations = {}
    restrictElements.forEach(fItem => {
        const isNum = /^\d+$/.test(fItem.attributes.value);
        baseValidations = {...baseValidations, [fItem.name.split(":")[1]] : isNum 
            ? Number(fItem.attributes.value) 
            : fItem.attributes.value}
    }) 
    return baseValidations
}
function simpleContentData(data, type){
    const findSimpleContent = data[type].elements.find(ele => ele.name === 'xs:simpleContent');
    if(findSimpleContent){
        const contentObj = {}
        const sContent = findSimpleContent.elements[0]
        const {attributes, elements: sElements} = sContent
        contentObj.elementType = "autocomplete"
        contentObj.base = "autocomplete"
        // By Default, disableField and isMandatory should be false.
        contentObj.disableField = false;
        contentObj.ismandatoryfield = false
        contentObj.simpleContent  = {
            attributes : {...attributes, ...sElements[0].attributes},
            text: sElements[0].elements[0].elements[0].elements[0].text, 
            desc: sElements[0].elements[0].elements[1].elements[0].text  }
        const findBaseRestrictions = data[attributes.base]?.elements[0]?.elements
        if(findBaseRestrictions){
            let baseValidations = getRestrictions(findBaseRestrictions)
            if(!isEmpty(baseValidations)) {
                contentObj.restrictions = baseValidations
            }
        }
        const findCurrencyDesc = data[sElements[0].attributes.type]
        if(findCurrencyDesc) {
            let currencyCodeDesc = {}
            currencyCodeDesc.name = findCurrencyDesc.attributes.name
            currencyCodeDesc.desc = findCurrencyDesc.elements[0].elements[1].elements[0].text
            currencyCodeDesc.elementType = findCurrencyDesc.elements[1].attributes.base.split(':')[1]
            let validations = getRestrictions(findCurrencyDesc.elements[1].elements)
            if(!isEmpty(validations)){
                currencyCodeDesc.restrictions = validations 
            }
            contentObj.currencyCodeDetails = currencyCodeDesc
        }
        return contentObj;
    }
    return null;
}
function childSequenceData(data, type) {
    const findChildSequence = data[type].elements.find(ele => ele.name === 'xs:sequence');
    if(findChildSequence && findChildSequence.elements)
    {
        const findAny = findChildSequence.elements.find(ele => ele.name === 'xs:any');
        if(findAny){     
            return {elementType : 'string', restrictions : {...findAny.attributes}}
        }
    }

    return null;
}
function getTitleandDescriptionData(seqElements, data,type){
    if(seqElements.elements){
        let longTitle = seqElements.elements[0].elements[0].elements[0].text;
        let description = seqElements.elements[0].elements[1].elements[0].text; 
        return {longTitle, description};
    } else {
        const findAnnotation = data[type].elements.find(ele => ele.name === 'xs:annotation');
        if(findAnnotation && findAnnotation.elements){
            let longTitle = findAnnotation.elements[0].elements[0].text;
            let description = findAnnotation.elements[1].elements[0].text;
            return {longTitle, description};
        }
    } 
    return null;
}
function createEmptyItem(child, index, findRestriction, findSimpleContent, 
    findChildSequence, dataElement, childHierarchy, isSingleField = false, strNLevel, bodyDataCount) {
    const { disableField, ismandatoryfield, hierIndex } = child;
    const childEmptyItem = {}
    const name = `Item${index}`;
    childEmptyItem[name] = 
        {
            shortTitle: name, 
            longTitle: name, 
            selfHierarchy: true,
            isRemovableItem: bodyDataCount > 1 ? true : false,
            parentDetails : !isSingleField ? [...child.parentDetails, index] : [...child.parentDetails],
            nodeLevel: `${strNLevel}.${index}`,
            disableField,
            ismandatoryfield,
            hierIndex
        }
    if(findRestriction !== null){
        childEmptyItem[name] = {...childEmptyItem[name], ...findRestriction}
    }
    if(findSimpleContent !== null){
        childEmptyItem[name] = {...childEmptyItem[name], ...findSimpleContent}
    }
    if(findChildSequence !== null){
        childEmptyItem[name] = {...childEmptyItem[name], ...findChildSequence}
    } 
    const findChoice = dataElement.elements.find(ele => ele.name === 'xs:choice');
    if(findChoice){
        childEmptyItem[name].isChoicable = true
    }
    if(Object.keys(childHierarchy).length > 0){
        childEmptyItem[name].children = childHierarchy;
    }  

    return childEmptyItem;
}
export const hasTextFieldAvailable = (obj) => {
    if (typeof obj !== 'object' || obj === null) {
      return false;
    }
  
    if ('_text' in obj) {
      return true;
    }
  
    return Object.values(obj).some((value) => hasTextFieldAvailable(value));
};
function containsChoiceAndElement(childElements) {
    // Check if both 'xs:choice' and 'xs:element'
  const containsChoice = childElements.some(obj => obj.name === 'xs:choice');
  const containsElement = childElements.some(obj => obj.name === 'xs:element');
  
  // Return true if both conditions are met, otherwise false
  return containsChoice && containsElement;
}

function createRawDropdownForChoicableType(childInfo, isChoiceInsideSequence = false) {
    const childDetails = cloneDeep(childInfo);
    const newChoiceType = {
        longTitle : 'Type',
        shortTitle: 'ChoiceType',
        description: '',
        tagName: 'xs:dropdown',
        elementType: 'dropdown',
        parentDetails : [...childDetails.parentDetails, 'ChoiceType'],
        isManualProperty: true,
        disableField : false,
        ismandatoryfield: false,
        nodeLevel: childDetails.parentDetails.join('.').concat('.ChoiceType')
    }
    newChoiceType.options = [{label : 'None', value: 'NA'}, ...Object.keys(childDetails.children).map(key => {
        return {
            label: childDetails.children[key].longTitle,
            value: key,
            desc : ''
        }
    })]

    if(isChoiceInsideSequence){
        newChoiceType.isChoiceInsideSequence = isChoiceInsideSequence;
    }
    const childElements = {...childDetails.children}
    const resultChild = {}
    Object.keys(childElements).forEach(ele => {
        if(has(childElements[ele], 'isChoiceChildHidden')){
            if(!childElements[ele].isManualProperty){
                resultChild[ele] = {...childElements[ele], isChoiceChildHidden: true}
            }
        } else resultChild[ele] = childElements[ele]
    })
    childDetails.children = resultChild
    return { newChoiceType, childDetails }
}

// Function to generate hierarchical structure
export function generateRawSchemaHierarchy(data, childArrayElements, parentDet, purposeCodes, fieldPriorities) {
    let hierarchy = {};
    if(childArrayElements){
        childArrayElements.elements.forEach((childElement, index) => {
            const typeName = (childElement.attributes && childElement.attributes.name) ? childElement.attributes.name : childElement.name;
            const {isApplicable = true} = isFieldApplicableInSchema([...parentDet, typeName], fieldPriorities);
            if(isApplicable === false) return;
            if (childElement.type === 'element' && childElement.name === 'xs:element' 
                    && childElement.attributes && childElement.attributes.type) {
                const childType = childElement.attributes.type;
                const childName = childElement.attributes.name;
                if (data[childType]) {
                    if (!hierarchy[childName]) {
                        hierarchy[childName] = {};
                    }
                    const {name: shortTitle, type, ...rest} = childElement.attributes;
                    const parentDetails = [...parentDet, childName]
                    const strNodeLevel = parentDetails.join('.');           
                    let child = {
                        tagName: childArrayElements.name,
                        shortTitle,
                        type,
                        parentDetails,
                        longTitle: shortTitle,
                        nodeLevel: strNodeLevel,
                        hierIndex : index
                    };
                    if(childArrayElements.name === 'xs:choice') child.isChoiceChildHidden = true
                    if(Object.keys(rest).length > 0) {
                        let occObj = {};
                        Object.keys(rest).forEach(item => {
                            const isNum = /^\d+$/.test(rest[item]);
                            occObj[item] = isNum 
                            ? Number(rest[item]) 
                            : rest[item]
                        })
                        child.occuranceObj = {...occObj, count : 0, restrictOccurs : false, disabled : false}
                    }
                    if(child.occuranceObj){
                        // if minOccurs == 0, hide the children
                        if(child.occuranceObj.minOccurs === 0) child.hideChildForRequired = true

                        // if minOccurs >= 1, then set the count equal to minOccurs
                        // Ensure, respective children are available in schema definition, 
                        // For Ex, if minOccurs = 2, then children should be 2
                        if(child.occuranceObj.minOccurs >= 1) {
                            child.occuranceObj = {...child.occuranceObj, count : child.occuranceObj.minOccurs}
                        }

                        // Sometimes, max occurance is not available but if min occurs are appear then
                        // Set the max Occurs into 1 by default.
                        if(!child.occuranceObj.maxOccurs && child.occuranceObj.minOccurs === 0){
                            child.occuranceObj.maxOccurs = 1;
                        }
                        // avoid the min and max occurs appearance if maxOccurs = 1     
                        if(child.occuranceObj.maxOccurs === 1) {
                            const isValidMinOccur = child.occuranceObj.minOccurs === 0;
                            // const sectionFeatureMode = checkFeatureEnabledForParent(parentDetails, fieldAccessHierarchyList);
                            child.checkBoxProps = {isChoicable: true, isTicked: !isValidMinOccur, disabled : false}
                            child.hideChildForRequired = isValidMinOccur                                
                        }
                    } 
                    const findContext = getTitleandDescriptionData(childElement, data, type);
                    if(findContext !== null){
                        child = {...child, ...findContext}
                    }
                    const findRestriction = restrictionData(data, type, parentDetails, purposeCodes);
                    const findSimpleContent = simpleContentData(data, type);
                    const findChildSequence = childSequenceData(data, type); 

                    if(findRestriction !== null){
                        child = {...child, ...findRestriction}
                    }
                    if(findSimpleContent !== null){
                        child = {...child, ...findSimpleContent}
                    }
                    if(findChildSequence !== null){
                        child = {...child, ...findChildSequence}
                    }

                    // By Default, set the some of fields should be 
                    // avoid the checkbox props if have elementType, means check box is not applicable for field type
                    if(has(child,'elementType')) {  
                        // const propertyMode = setMandatoryFieldByDefault(parentDetails);
                        child.disableField = false;
                        child.ismandatoryfield = false;
                        // Avoid the checkbox properities if have elementType.
                        if(has(child, 'checkBoxProps')) delete child['checkBoxProps'];
                    }
                    const getSeqorChoiceChildElements = data[childType].elements.find(ele => ele.name === 'xs:sequence' || ele.name === 'xs:choice');
                    if(getSeqorChoiceChildElements && getSeqorChoiceChildElements.elements){
                        const findBothChoiceSeq = containsChoiceAndElement(getSeqorChoiceChildElements.elements);
                        if(findBothChoiceSeq){
                            child.isContainsChoiceInsideSequence = true;
                        }
                    }       
                    const rawChildHierarchy = 
                        generateRawSchemaHierarchy(data, getSeqorChoiceChildElements, parentDetails, purposeCodes, fieldPriorities);
                    if (Object.keys(rawChildHierarchy).length > 0) {
                        child.children = rawChildHierarchy;
                    }  else {
                        // Set the isFieldWithMultientry = true, if the element doesnot contain children and multiple entries.
                        // and maxOccurs > 1 or unbounded(no limitation),
                        if(child.occuranceObj && (child.occuranceObj.maxOccurs > 1 || child.occuranceObj.maxOccurs === 'unbounded')){
                            const childArray = createEmptyItem(child, 0, findRestriction, 
                                findSimpleContent, findChildSequence, data[type], rawChildHierarchy, true, strNodeLevel, 1)  
                            child.isFieldWithMultiEntry = true     
                            child.children = childArray
                        }
                    }
                    //if child object does not contains the isFieldWithMultiEntry and is ElementType, then remove the occuranceObj
                    if(has(child,'occuranceObj') && has(child,'elementType') && !has(child,'isFieldWithMultiEntry'))
                    {
                        delete child['occuranceObj'];
                    }
                    const findChoice = data[type].elements.find(ele => ele.name === 'xs:choice');
                    if(findChoice){
                        // If it is the choicable element, create one dropdown with children name manually
                        const {newChoiceType, childDetails} = createRawDropdownForChoicableType(child,false);
                        child.children = {ChoiceType: newChoiceType, ...childDetails.children}
                        child.isChoicableProperty = true;
                        // child.disableField = propertyMode.disableProp;
                        // child.ismandatoryfield = propertyMode.isMandatory;
                    }                      
                    hierarchy[childName] = child
                }
            } else if(childElement.name === 'xs:choice') { // handle if choicable elements inside sequence.         
                let pDet = [...parentDet, 'ChoiceType'];
                let child = {
                    tagName: 'xs:choice',
                    shortTitle : 'ChoiceType',
                    type : 'choicetype',
                    parentDetails : parentDet,
                    longTitle: 'Type',
                    nodeLevel: pDet.join('.')
                };
                const rawChildHierarchy = generateRawSchemaHierarchy(data, childElement, parentDet, purposeCodes, fieldPriorities);
                child.children = rawChildHierarchy;
                const {newChoiceType, childDetails} = createRawDropdownForChoicableType(child, true);
                hierarchy = {...hierarchy, ChoiceType : {...newChoiceType}, ...childDetails.children};
            }
        });
    }
    return hierarchy;
}

export const getPaymentActualData = (result, parentInfo) => {
    let currentData = result;
    for(let field of parentInfo){
        currentData = currentData[field] || ''
    }
    return currentData || {};
}

const isFieldApplicableInSchema = (parentDetails, accessConstants) => {
    let curParDetails = cloneDeep(accessConstants);
    for(let pInfo of parentDetails){
        curParDetails = curParDetails[pInfo] || {}
    }
    const { isApplicable, isMandatory, isDisabled } = curParDetails;
    return curParDetails && {isApplicable, isMandatory, isDisabled};
}

export const createNewArrayItem= (iIndex, parentDetails, sNLevel, disabled = false, hierIndex = 0) => {
    const newItem = {};
    const newName = `Item${iIndex}`;
    newItem.longTitle = newName;
    newItem.shortTitle = newName;
    newItem.parentDetails = [...parentDetails, iIndex]; 
    newItem.isRemovableItem= true;
    newItem.nodeLevel = `${sNLevel}.${iIndex}`;
    newItem.disableItem = disabled;
    newItem.disableField = disabled;
    newItem.hierIndex = hierIndex
    return newItem;
}

/**
 * The method used for update the parentdetails for all corresponding children
 * If body data is available for corresponding key, updated the checkboxprops, enable the children and activate the choicable property.
 * @param {json} SchamaJson - Hierarchy schema json for children 
 * @param {*} BodyDataJson -  Body data Json 
 * @param {*} index - index for add in the item
 * @param {*} removableIndex - remove the parent name from parent details based on the inde
 * @param {*} parentDHier - Parent details - used to get the length of the grant parent
 */
export function updateSchemaStructure(schema, data, index, removableIndex, parentDHier, parChoiceProperty) {
    for (const key in schema) {
        if (typeof schema[key] === 'object') {
            if (schema[key].parentDetails) {
                const updatedParentDetails = [...schema[key].parentDetails];
                if(index !== null){
                    updatedParentDetails.splice(parentDHier.length, removableIndex, index); 
                } else {
                    updatedParentDetails.splice(parentDHier.length, removableIndex); 
                }          
                schema[key].parentDetails = updatedParentDetails;
            }
            if(schema[key].nodeLevel) schema[key].nodeLevel = `${schema[key].nodeLevel}.${index || 0}` 
            if (key in data) {
                // Update properties based on objDataJson    
                if(schema[key].checkBoxProps) {
                schema[key].checkBoxProps = {...schema[key].checkBoxProps, isTicked: true}
                } 
                if(schema[key].hideChildForRequired) {
                schema[key].hideChildForRequired = false
                }
                if(schema[key].isChoicableProperty){
                const choicableChildren = cloneDeep(schema[key].children);
                const [firstItem] = Object.keys(data[key]);
                const resultChild = {}
                Object.keys(choicableChildren).forEach(ele => {
                    if(has(choicableChildren[ele], 'isChoiceChildHidden')){
                        if(firstItem === ele) {
                            resultChild[ele] = {...choicableChildren[ele], isChoiceChildHidden: false}
                        } else if(!choicableChildren[ele].isManualProperty){
                            resultChild[ele] = {...choicableChildren[ele], isChoiceChildHidden: true}
                        } 
                    } else resultChild[ele] = choicableChildren[ele]
                })
                schema[key].children = resultChild;
                data[key] = {...data[key], ChoiceType: {_text: firstItem}}
                }
                if(parChoiceProperty){
                const [firstItem] = Object.keys(data);
                if(firstItem === key) schema[key].isChoiceChildHidden = false
                data.ChoiceType = {_text: firstItem}
                }
            } else {
                // if key not in data, then add the validation if applicable
                const {restrictions, ismandatoryfield} = schema[key];
                let errorCode = {};
                if(restrictions && restrictions.minLength === 1 && ismandatoryfield)
                    errorCode = {_text: ERRORCODES['mandatory_min']}
                // else if(restrictions && restrictions.minLength === 1)
                //     errorCode = {_text: ERRORCODES['minLength']}
                else if(ismandatoryfield)
                    errorCode = {_text: ERRORCODES['mandatory']}
                if(!isEmpty(errorCode)){
                    data[key] = {...data[key], error : errorCode}
                }
            }
            if ((data[key] && typeof data[key] === 'object') || (schema[key] && typeof schema[key] === 'object')) {
                updateSchemaStructure(schema[key].children, data[key] || {}, index, removableIndex, parentDHier, parChoiceProperty);
            } 
        }
    }
}

function fetchCheckBoxStatus(shortTitle, bodyDataResult, transConfiguration, restrictToAccessTransaction) {
    // Check if the shortTitle exists and is not empty in bodyDataResult
    if (shortTitle in bodyDataResult && !isEmpty(bodyDataResult[shortTitle])) {
        return { isTicked: true, disabled: true, hideChildForRequired: false };
    }
    // Check if the shortTitle exists in transConfiguration
    const config = transConfiguration[shortTitle];
    if (config) {
        const { isSection, isEnabled, isMandatory } = config;
        // If it's a section, determine the checkbox status
        if (isSection) {
            if (!isEnabled && isMandatory) return { isTicked: true, disabled: true, hideChildForRequired: false }; //For PstlAdr
            if (isEnabled && !isMandatory) return { isTicked: false, disabled: restrictToAccessTransaction, hideChildForRequired: true };
        }
    }
    return { isTicked: false, disabled: true, hideChildForRequired: true };
}


export function updateRawHierarchywithResultData(rawHierarchy, bodyDataResult, expandedList = [], 
    restrictToAccessTransaction = undefined, transConfiguration = {}) {
    try {
        for(const shortTitle in rawHierarchy){    
            const {occuranceObj, checkBoxProps, hierIndex, 
                isFieldWithMultiEntry, nodeLevel, isChoicableProperty, isContainsChoiceInsideSequence, 
                restrictions} = rawHierarchy[shortTitle];     
            // const [gg,g, p, f] = parentDetails.slice(-4);
            // if(g === 'CdtTrfTxInf' && p === 'Cdtr' && f === 'PstlAdr'){
            //     console.log('come');
            // }
            // if(gg === 'CdtTrfTxInf' && g === 'Dbtr' && p === 'PstlAdr' && f === 'AdrLine'){
            //     console.log('come');
            // }
            // if(gg === 'CdtTrfTxInf' && g === 'UltmtCdtr' && p === 'Id' && f === 'ChoiceType'){
            //     console.log('come');
            // }
            // if(gg === 'CdtTrfTxInf' && g === 'InitgPty' && p === 'Id' && f === 'ChoiceType'){
            //     console.log('come');
            // }
            // if(gg === 'UltmtDbtr' && g === 'Id' && p === 'OrgId' && f === 'LEI'){
            //     console.log('come');
            // }
            // const [p1, f1] = parentDetails.slice(-2);
            // if(p1 === 'Id' && f1 === 'OrgId'){
            //     console.log('come')
            // }
            const isElementType = has(rawHierarchy[shortTitle], 'elementType');  
            // In this case, Disable all fields, checkbox, occurance and multiple entry field.
            if(isElementType) {
                rawHierarchy[shortTitle] = {...rawHierarchy[shortTitle], 
                    disableField: true, ismandatoryfield : false};
            } 
            if(occuranceObj || checkBoxProps){
                rawHierarchy[shortTitle].hideChildForRequired = true;
                if(occuranceObj)
                    rawHierarchy[shortTitle].occuranceObj = {...rawHierarchy[shortTitle].occuranceObj, 
                        disabled : true }
                if(checkBoxProps)
                    rawHierarchy[shortTitle].checkBoxProps = {...rawHierarchy[shortTitle].checkBoxProps, 
                        disabled : true, 
                        isTicked : false};
            }

            // if have data based on shortTitle
            if(shortTitle in bodyDataResult || shortTitle in transConfiguration){ 
                // update the expandedList for Treeview expansion.
                if(!isElementType || isFieldWithMultiEntry)        
                    expandedList.push(nodeLevel);
                
                // Scope - update bodydata if field either mandatory or mandatory_min.
                // 1. if element type
                // 2. only consider editable Msg Status(Draft, Draft Return)
                // 3. bodyData should be empty.
                // 4. Avoided the multiple entries here for validation.
                // 5. check whether the last character of shortTitle is number or not, if number so it specifies the singlefieldmultipleentries
                const {isNumber} = checkLastItemIsNumber(shortTitle);
                if(isElementType && !Array.isArray(bodyDataResult) && !isNumber && !restrictToAccessTransaction 
                       && (shortTitle in transConfiguration)) {
                        const {isMandatory, isEnabled } = transConfiguration[shortTitle] || {};
                        if(!has(bodyDataResult[shortTitle], '_text')) {      
                            if(restrictions && restrictions.minLength === 1 && isMandatory)
                                bodyDataResult[shortTitle] = {...bodyDataResult[shortTitle], error: {_text: ERRORCODES['mandatory_min']}};
                            else if(isMandatory)
                                bodyDataResult[shortTitle] = {...bodyDataResult[shortTitle], error: {_text: ERRORCODES['mandatory']}};
                        }
                    // if(shortTitle === 'ChoiceType' && choiceType) {
                    //     const {options} = rawHierarchy[shortTitle];
                    //     const filteredOption = options.filter(o => o.value === 'NA' || o.value === choiceType);
                    //     rawHierarchy[shortTitle] = {...rawHierarchy[shortTitle], options: filteredOption};
                    // }
                    rawHierarchy[shortTitle] = {...rawHierarchy[shortTitle], 
                        disableField : !isEnabled, ismandatoryfield: isMandatory };
                }
                if(occuranceObj){
                    if(occuranceObj.maxOccurs === 1) {
                        const {isTicked, disabled, hideChildForRequired} = 
                                fetchCheckBoxStatus(shortTitle, bodyDataResult, transConfiguration, restrictToAccessTransaction);
                        rawHierarchy[shortTitle].checkBoxProps = {...rawHierarchy[shortTitle].checkBoxProps, 
                                isTicked, disabled};
                        rawHierarchy[shortTitle].hideChildForRequired = hideChildForRequired;
                    } else rawHierarchy[shortTitle].hideChildForRequired = false;
                    
                    const count = (Array.isArray(bodyDataResult[shortTitle]) ? bodyDataResult[shortTitle].length : 1) || 1;
                    rawHierarchy[shortTitle].occuranceObj = {...rawHierarchy[shortTitle].occuranceObj, count,
                        showMinusForSingleItem : count === 1 && occuranceObj.minOccurs === 0 ? true : false,
                        restrictOccurs: occuranceObj.maxOccurs === 1 
                        ? true : (bodyDataResult[shortTitle] && bodyDataResult[shortTitle].length) === occuranceObj.maxOccurs 
                        ? true : false }
                }
                // If the section is Choicable element or combined with choice and sequence, display the specific element in the childen list.
                if(isChoicableProperty || isContainsChoiceInsideSequence){
                    const isTextFieldThere = hasTextFieldAvailable(bodyDataResult[shortTitle]);
                    if(isTextFieldThere) {
                        const [firstItem] = Object.keys(bodyDataResult[shortTitle]);
                        bodyDataResult[shortTitle].ChoiceType = {_text: firstItem};
                        const childElements = cloneDeep(rawHierarchy[shortTitle].children)
                        const resultChild = {}
                        Object.keys(childElements).forEach(ele => {
                            if(has(childElements[ele], 'isChoiceChildHidden')){
                                if(firstItem === ele) {
                                    resultChild[ele] = {...childElements[ele], isChoiceChildHidden: false}
                                } else if(!childElements[ele].isManualProperty){
                                    resultChild[ele] = {...childElements[ele], isChoiceChildHidden: true}
                                }
                            } else resultChild[ele] = childElements[ele]
                        })
                        rawHierarchy[shortTitle].children  = resultChild;
                    }
                }

                if(Array.isArray(bodyDataResult[shortTitle]) && bodyDataResult[shortTitle].length > 1){
                    const {parentDetails, nodeLevel, isFieldWithMultiEntry, children, isChoicableProperty} = rawHierarchy[shortTitle];
                    const childInfo = cloneDeep(children);
                    let addChildItems = {};
                    for(let i = 0; i < bodyDataResult[shortTitle].length; i++){
                        const newItemName = `Item${i}`
                        const newItem = createNewArrayItem(i, parentDetails, nodeLevel, true, hierIndex);
                        const cloneBodyData = cloneDeep(bodyDataResult[shortTitle][i])
                        if(childInfo && !isFieldWithMultiEntry){
                            const cloneChildInfo = cloneDeep(childInfo);
                            updateSchemaStructure(cloneChildInfo, cloneBodyData, i, 0, parentDetails, isChoicableProperty);
                            addChildItems[newItemName] = {...newItem, children: cloneChildInfo};
                            expandedList.push(newItem.nodeLevel);
                        } else {
                            const [singleItem] = Object.values(childInfo);
                            addChildItems[newItemName] = {...singleItem, ...newItem, disableItem: true, disableField: true};
                        }
                        bodyDataResult[shortTitle][i] = {...cloneBodyData, hierIndex}
                    }
                    rawHierarchy[shortTitle].children = addChildItems
                }

                //update hierIndex for which of the fields contains the data
                if(isEmpty(bodyDataResult[shortTitle])) bodyDataResult[shortTitle] = {}
                bodyDataResult[shortTitle].hierIndex = hierIndex;
            }
            if(rawHierarchy[shortTitle].children){
                updateRawHierarchywithResultData(rawHierarchy[shortTitle].children, 
                    bodyDataResult[shortTitle] || {}, expandedList, restrictToAccessTransaction, transConfiguration[shortTitle])
            } 
        }
    }
    catch(err){
        console.log(err)
    }
}
