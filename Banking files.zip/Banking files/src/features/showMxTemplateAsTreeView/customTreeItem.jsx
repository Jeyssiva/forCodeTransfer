import * as React from "react";
import { styled } from '@mui/material/styles';
import { TreeItem, treeItemClasses } from '@mui/x-tree-view/TreeItem';
import TemplateSubItems from "./templateSubItems";

const StyledTreeItemRoot = styled(TreeItem)(({ theme }) => ({
    color: theme.palette.text.secondary,
    [`& .${treeItemClasses.content}`]: {
      color: theme.palette.text.secondary,
      // borderTopRightRadius: theme.spacing(2),
      // borderBottomRightRadius: theme.spacing(2),
      paddingRight: theme.spacing(1),
      fontWeight: theme.typography.fontWeightMedium,
      '&.Mui-expanded': {
        fontWeight: theme.typography.fontWeightRegular,
      },
      '&:hover': {
        backgroundColor: theme.palette.action.hover,
      },
      '&.Mui-focused, &.Mui-selected, &.Mui-selected.Mui-focused': {
        // backgroundColor: `var(--tree-view-bg-color, ${theme.palette.action.selected})`,
        color: 'var(--tree-view-color)',
        fontWeight: 'bold'
      },
      [`& .${treeItemClasses.label}`]: {
        fontWeight: 'inherit',
        color: 'inherit',
      },
    }
  }));

const CustomTreeItemComponent = React.memo(
      function CustomTreeItem(props) {       
        return <StyledTreeItemRoot
                  suppressContentEditableWarning={true} ContentComponent = {TemplateSubItems}
                  ContentProps = {{contentProps: {...props}}} {...props}
              />;
    }
  )

  export default CustomTreeItemComponent;
  