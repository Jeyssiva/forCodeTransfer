
import _, { cloneDeep, isEmpty } from 'lodash';
import { PERSISTED_SLICE, SHOW_MX_TEMPLATE } from '../../constants/sliceConstants';
import { createSelector, createSlice } from '@reduxjs/toolkit'; //default is localStorage;
import { convertSchemaXMLtoJSON } from './conversionHelpers';
import { generateRawSchemaHierarchy } from './templateHelpers';

import { GET_SECTION_DETAIL_SCHEMA_NAMES, PACS008, STATIC_LIST_PERSIST_NAMES, 
  GET_PERSISTED_BODY_SCHEMA_NAMES } from '../../constants/createPaymentConstants';

import { generateHierarchyByArray } from './itemManipulateHelpers';
import { NAMES_TO_REMOVE, SRCOFTXN_CREATEPAYMENT, SRCOFTXN_MIDAS } from '../../constants/mxTempConstants';

export const persistInitialState = {
  bodySchemaB2CSTDPersist : {},
  bodySchemaB2BSTDPersist : {},
  bodySchemaB2BCoVPersist : {},
  saaHeaderSchemaPersist : {},
  appHeaderSchemaPersist : {},
  applicableFalseDataPersist : {},
  countryListPersist : [],
  currencyListPersist : [],
  purposeCodesPersist : [],
  msgConfigB2BPersist : [],
  msgConfigB2CPersist : [],
  msgConfigB2BCovPersist : [],
  // defaultValuesB2CSTDPersist : [],
  // defaultValuesB2BSTDPersist : [],
  // defaultValuesB2BCOVPersist : [],
  elementAttributes : {},
  requiredApiRequests : {saaHeader: false, appHeader: false, staticData : false, countryList: false, applicableFalse: false,
    msgConfigB2B: false, msgConfigB2C: {status: false, reqParams : {}}, 
    msgConfigB2BCov: false, bodyB2CSTD : false, bodyB2BSTD: false, bodyB2BCov: false,
    // defaultB2CSTD : false, defaultB2BCoV : false, defaultB2BSTD : false
}
}

const convertBodyGenerateRawHier = (xmlData, state) => {
  const bodySecDtlSchema = convertSchemaXMLtoJSON(xmlData);
  const purposeCodes = cloneDeep(state.purposeCodesPersist);   
  if(bodySecDtlSchema){
    const typeName = bodySecDtlSchema['Document'].attributes.name;
    const getSeqorChoiceChildElements = bodySecDtlSchema[typeName].elements.find(ele => ele.name === 'xs:sequence' || ele.name === 'xs:choice');
    const rawBodyHier = generateRawSchemaHierarchy(bodySecDtlSchema, getSeqorChoiceChildElements, [], purposeCodes, {});
    return rawBodyHier;
  }
}

// Slice to handle any state changes
const persistedSlice = createSlice({
    name: PERSISTED_SLICE,
    initialState: persistInitialState,
    reducers: {
      loadCustomerPaymentStaticData(state, action) {
        const { ddLists, ddListType } = action.payload.resData.responseBody;
        state[STATIC_LIST_PERSIST_NAMES[ddListType]] = ddLists[0][ddListType] ? 
        [
            ...ddLists[0][ddListType].map(dd => {
                return {
                    ...dd,
                    description : `${dd.description.trim()}`,
                    isoDisplayName : `${dd.code} - ${dd.description}`
                }
            })
        ]: [];
        state.requiredApiRequests = {...state.requiredApiRequests, countryList : ddLists[0]["GBR_COUNTRY_LIST"] ? true : false}
      },
      loadAllSchemaAsHier(state, action) {
        const { requiredApis, requests, msgConfigBody } = action.payload;
        let apis = cloneDeep(requiredApis);
        let msgConfigApplicableFalse = {};
        if(!requiredApis.applicableFalse && !isEmpty(requests['applicableFalseDataPersist'] 
        && requests['applicableFalseDataPersist'].data)) {
          const {responseBody: {enqTxn  = []} = {}} = JSON.parse(requests['applicableFalseDataPersist'].data);
          msgConfigApplicableFalse = enqTxn && enqTxn.length > 0
                      ? generateHierarchyByArray(enqTxn)  
                      : {};
          state.applicableFalseDataPersist = msgConfigApplicableFalse;
          apis = {...apis, applicableFalse: !isEmpty(requests['applicableFalseDataPersist'].data)};
        }
        if(!requiredApis.saaHeader && !isEmpty(requests['saaHeader'] && requests['saaHeader'].data)) {
          const saaHeaderSchema = convertSchemaXMLtoJSON(requests['saaHeader'].data);
            if(saaHeaderSchema){
              const saaIsApplicableFalse = {saaHeader: msgConfigApplicableFalse['DataPDU'] || {}};
              const typeName = saaHeaderSchema['DataPDU'].attributes.name;
              const getSeqorChoiceChildElements = saaHeaderSchema[typeName].elements
                          .find(ele => ele.name === 'xs:sequence' || ele.name === 'xs:choice');
              const rawSaaHeader = generateRawSchemaHierarchy(saaHeaderSchema, getSeqorChoiceChildElements, ['saaHeader'], null, saaIsApplicableFalse); 
              state.saaHeaderSchemaPersist = {saaHeader: 
                  {longTitle: 'SAA Header', nodeLevel: '1', type: 'saaHeader', parentDetails: [], children: rawSaaHeader}};
            }
          apis = {...apis, saaHeader: !isEmpty(requests['saaHeader'].data)};
        }
        if(!requiredApis.appHeader && !isEmpty(requests['appHeader'] && requests['appHeader'].data)) {
          const appHeaderSchema = convertSchemaXMLtoJSON(requests['appHeader'].data);
          if(appHeaderSchema){
              const typeName = appHeaderSchema['AppHdr'].attributes.type;
              const getSeqorChoiceChildElements = appHeaderSchema[typeName].elements.find(ele => ele.name === 'xs:sequence' || ele.name === 'xs:choice');
              const rawApp = generateRawSchemaHierarchy(appHeaderSchema, getSeqorChoiceChildElements, ['AppHdr'], null, {});
              state.appHeaderSchemaPersist = 
                  {AppHdr: {longTitle: 'Application Header', nodeLevel: '1', type: 'AppHdr', parentDetails: [], children: rawApp}};
          }
          apis = {...apis, appHeader: !isEmpty(requests['appHeader'].data)};
        }
        if(!isEmpty(requests['msgConfigB2CPersist'] && requests['msgConfigB2CPersist'].data)) {
          const {responseHeader : {statuscode, executionStatus},  responseBody: {enqTxn : sectionHierarchyB2C = []} = {}} 
          = JSON.parse(requests['msgConfigB2CPersist'].data);
          if(statuscode === "200" && executionStatus.toLowerCase() === "success") {
            //Remove "Document", "AppHdr", "DataPDU" from Original Array
            _.remove(sectionHierarchyB2C, e => NAMES_TO_REMOVE.includes(e.messagePath));

            const hierarchyResult = sectionHierarchyB2C && sectionHierarchyB2C.length > 0
            ? generateHierarchyByArray(sectionHierarchyB2C)  
            : {};
            state.msgConfigB2CPersist = hierarchyResult;
            apis = {...apis, msgConfigB2C: {status: !isEmpty(requests['msgConfigB2CPersist'].data), reqParams: msgConfigBody}};
          }
        }
        if(!isEmpty(requests['msgConfigB2BPersist'] && requests['msgConfigB2BPersist'].data)) {
          const {responseHeader : {statuscode, executionStatus},  responseBody: {enqTxn : sectionHierarchyB2B = []} = {}} 
          = JSON.parse(requests['msgConfigB2BPersist'].data);
          if(statuscode === "200" && executionStatus.toLowerCase() === "success") {
             //Remove "Document", "AppHdr", "DataPDU" from Original Array
             _.remove(sectionHierarchyB2B, e => NAMES_TO_REMOVE.includes(e.messagePath));

            const hierarchyResult = sectionHierarchyB2B && sectionHierarchyB2B.length > 0
                        ? generateHierarchyByArray(sectionHierarchyB2B)  
                        : {}; 
            state.msgConfigB2BPersist = hierarchyResult;
            apis = {...apis, msgConfigB2B: {status:!isEmpty(requests['msgConfigB2BPersist'].data), reqParams: msgConfigBody}};
          }
        }
        if(!isEmpty(requests['msgConfigB2BCovPersist'] && requests['msgConfigB2BCovPersist'].data)) {
          const {responseHeader : {statuscode, executionStatus},  responseBody: {enqTxn : sectionHierarchyB2BCov = []} = {}}  
          = JSON.parse(requests['msgConfigB2BCovPersist'].data);
          if(statuscode === "200" && executionStatus.toLowerCase() === "success") {
            //Remove "Document", "AppHdr", "DataPDU" from Original Array
            _.remove(sectionHierarchyB2BCov, e => NAMES_TO_REMOVE.includes(e.messagePath));

            const hierarchyResult = sectionHierarchyB2BCov && sectionHierarchyB2BCov.length > 0
                        ? generateHierarchyByArray(sectionHierarchyB2BCov)  
                        : {}; 
            state.msgConfigB2BCovPersist = hierarchyResult;
            apis = {...apis, msgConfigB2BCov: {status: !isEmpty(requests['msgConfigB2BCovPersist'].data), reqParams: msgConfigBody}};
          }
        }
        if(!requiredApis.staticData){
          const curIndex = requiredApis.countryList ? 0 : 1
          const purIndex = requiredApis.countryList? 1 : 2; 
          const {responseBody: {ddLists}} = JSON.parse(requests['staticData'].data);

          state.currencyListPersist = ddLists[curIndex]["GBR_CURRENCY_LIST"] ?
            [...ddLists[curIndex]["GBR_CURRENCY_LIST"].map(cur => {
                return {
                    ...cur,
                    description : `${cur.description.trim()}`,
                    isoDisplayName : `${cur.code} - ${cur.description}`
                }
            })] : [];
          state.purposeCodesPersist = ddLists[purIndex]["GBR_PURPOSE_ALL"] ?
            [...ddLists[purIndex]["GBR_PURPOSE_ALL"].map(cur => {
                return {
                    ...cur,
                    description : `${cur.description.trim()}`,
                    isoDisplayName : `${cur.code} - ${cur.description}`
                }
            })] : [];
          const status = ddLists[curIndex]["GBR_CURRENCY_LIST"].length > 0 && ddLists[purIndex]["GBR_PURPOSE_ALL"].length > 0;
          apis = {...apis, staticData: status};

          if(!requiredApis.countryList) {
            state.countryListPersist = ddLists[0]["GBR_COUNTRY_LIST"] ? 
            [
                ...ddLists[0]["GBR_COUNTRY_LIST"].map(coun => {
                    return {
                        ...coun,
                        isoDisplayName : `${coun.code} - ${coun.description}`
                    }
                })
            ]: [];
            apis = {...apis, countryList: ddLists[0]["GBR_COUNTRY_LIST"] ? true : false}
          }
        }
        if(!requiredApis.bodyB2CSTD && !isEmpty(requests['bodySchemaB2CSTDPersist'] && requests['bodySchemaB2CSTDPersist'].data)) {
          const convertionB2C = convertBodyGenerateRawHier(requests['bodySchemaB2CSTDPersist'].data, state)
          state.bodySchemaB2CSTDPersist = convertionB2C;
          apis = {...apis, bodyB2CSTD: !isEmpty(requests['bodySchemaB2CSTDPersist'].data)};
        }
        if(!requiredApis.bodyB2BSTD && !isEmpty(requests['bodySchemaB2BSTDPersist'] && requests['bodySchemaB2BSTDPersist'].data)) {
          const convertionB2B = convertBodyGenerateRawHier(requests['bodySchemaB2BSTDPersist'].data, state);
          state.bodySchemaB2BSTDPersist = convertionB2B;
          apis = {...apis, bodyB2BSTD: !isEmpty(requests['bodySchemaB2BSTDPersist'].data)};
        }
        if(!requiredApis.bodyB2BCov && !isEmpty(requests['bodySchemaB2BCoVPersist'] && requests['bodySchemaB2BCoVPersist'].data)) {
          const convertionB2BCOV = convertBodyGenerateRawHier(requests['bodySchemaB2BCoVPersist'].data, state);
          state.bodySchemaB2BCoVPersist = convertionB2BCOV;
          apis = {...apis, bodyB2BCov: !isEmpty(requests['bodySchemaB2BCoVPersist'].data)};
        }
        // if(!requiredApis.defaultB2CSTD && !isEmpty(requests['defaultValuesB2CSTDPersist'] && requests['defaultValuesB2CSTDPersist'].data)) {
        //   const {hierByArray = {}} = requests['defaultValuesB2CSTDPersist'].data;
        //   state.defaultValuesB2CSTDPersist = hierByArray;
        //   apis = {...apis, defaultB2CSTD : !isEmpty(requests['defaultValuesB2CSTDPersist'].data)}
        // }
        // if(!requiredApis.defaultB2BSTD && !isEmpty(requests['defaultValuesB2BSTDPersist'] && requests['defaultValuesB2BSTDPersist'].data)) {
        //   const {hierByArray = {}} = requests['defaultValuesB2BSTDPersist'].data;
        //   state.defaultValuesB2BSTDPersist = hierByArray;
        //   apis = {...apis, defaultB2BSTD : !isEmpty(requests['defaultValuesB2BSTDPersist'].data)}
        // }
        // if(!requiredApis.defaultB2BCoV && !isEmpty(requests['defaultValuesB2BCOVPersist'] && requests['defaultValuesB2BCOVPersist'].data)) {
        //   const {hierByArray = {}} = requests['defaultValuesB2BCOVPersist'].data;
        //   state.defaultValuesB2BCOVPersist = hierByArray;
        //   apis = {...apis, defaultB2BCoV : !isEmpty(requests['defaultValuesB2BCOVPersist'].data)}
        // }
        state.requiredApiRequests = {...apis};
      },
      loadElementAttributes(state, action) {
        const {msgDefId, elementAttributes} = action.payload;
        state.elementAttributes = {...state.elementAttributes, [msgDefId] : elementAttributes}
      }
    },
  });

// // Persisted reducer (with RTK Query API service included)
// export const persistedDataReducer = persistReducer(
//     persistConfig,
//     // combineReducers({
//     //   persistedData: persistedSlice.reducer
//     // })
//     persistedSlice.reducer
// );

const countries = state => state[PERSISTED_SLICE].countryListPersist;
const currencies = state => state[PERSISTED_SLICE].currencyListPersist;
const saaHeader = state => state[PERSISTED_SLICE].saaHeaderSchemaPersist;
const appHeader = state => state[PERSISTED_SLICE].appHeaderSchemaPersist;
const purposes = state => state[PERSISTED_SLICE].purposeCodesPersist;
const apiRequest = state => state[PERSISTED_SLICE].requiredApiRequests;
const eleAttributes = state => state[PERSISTED_SLICE].elementAttributes;

const saaHeaderSecDtlSchema = (state, args) => {
  const {activeMessageDefId = PACS008} = state[SHOW_MX_TEMPLATE];
  const {enqTxn = []} = args;
  const { sourceOfTxn = SRCOFTXN_MIDAS } = (enqTxn && enqTxn[0]) || {};
  if(sourceOfTxn === SRCOFTXN_MIDAS) {
    return {originalSaaHeader: state[PERSISTED_SLICE].saaHeaderSchemaPersist, transConfig : {}}
  } else {
    const transConfig = state[PERSISTED_SLICE][GET_SECTION_DETAIL_SCHEMA_NAMES[activeMessageDefId]];
    const dataPDU = transConfig['DataPDU'] || {};
    const header = dataPDU['Header'] || {};
    return {originalSaaHeader: state[PERSISTED_SLICE].saaHeaderSchemaPersist, transConfig : {Header : header}}
  }
}

const appHeaderSecDtlSchema = (state, args) => {
  const {activeMessageDefId = PACS008} = state[SHOW_MX_TEMPLATE];
  const {enqTxn = []} = args;
  const {sourceOfTxn = SRCOFTXN_MIDAS} = (enqTxn && enqTxn[0]) || {};
  if(sourceOfTxn === SRCOFTXN_MIDAS) return {originalAppHeader: state[PERSISTED_SLICE].appHeaderSchemaPersist, transConfig: {}}
  else {
    const transConfig = state[PERSISTED_SLICE][GET_SECTION_DETAIL_SCHEMA_NAMES[activeMessageDefId]];
    const dataPDU = transConfig['DataPDU'] || {};
    const pduBody = dataPDU['Body'] || {};
    const app = pduBody['AppHdr'] || {};
    return {originalAppHeader: state[PERSISTED_SLICE].appHeaderSchemaPersist, 
      transConfig : {AppHdr : app} }
  }
}

const bodySecDtlSchema = (state) => {
  const {activeMessageDefId = PACS008} = state[SHOW_MX_TEMPLATE];
  const transConfig = state[PERSISTED_SLICE][GET_SECTION_DETAIL_SCHEMA_NAMES[activeMessageDefId]];
  const dataPDU = transConfig['DataPDU'] || {};
  const pduBody = dataPDU['Body'] || {};
  const document = pduBody['Document'];
  return {originalBody: state[PERSISTED_SLICE][GET_PERSISTED_BODY_SCHEMA_NAMES[activeMessageDefId]], 
    transConfiguration : {...document}};
}

const bodySchema = state => {
  const {activeMessageDefId = PACS008, selectedTxnDet = {}} = state[SHOW_MX_TEMPLATE];
  const {enqTxn = []} = selectedTxnDet || {};
  const { sourceOfTxn = SRCOFTXN_CREATEPAYMENT } = (enqTxn && enqTxn[0]) || {};
  return {originalBody: state[PERSISTED_SLICE][GET_PERSISTED_BODY_SCHEMA_NAMES[activeMessageDefId]], sourceOfTxn} 
}

const bodyandPurposeCode = state => {
  const {activeMessageDefId = PACS008} = state[SHOW_MX_TEMPLATE];
  return {originalBody: state[PERSISTED_SLICE][GET_PERSISTED_BODY_SCHEMA_NAMES[activeMessageDefId]], 
    purposeCode : state[PERSISTED_SLICE].purposeCodesPersist};
}

const saaHeaderWithMsgConfigForNew = (state, args) => {
  const {msgDefId} = args;
  const defaultValues = state[PERSISTED_SLICE][GET_SECTION_DETAIL_SCHEMA_NAMES[msgDefId]];
  const dataPDU = defaultValues['DataPDU'] || {};
  const header = dataPDU['Header'] || {};
  return {originalSaaHeader: state[PERSISTED_SLICE].saaHeaderSchemaPersist, 
    defaultValuesList : {saaHeader : { Header : header}} }
}

const appHeaderWithMsgConfigForNew = (state, args) => {
  const {msgDefId} = args;
  const defaultValues = state[PERSISTED_SLICE][GET_SECTION_DETAIL_SCHEMA_NAMES[msgDefId]];
  const dataPDU = defaultValues['DataPDU'] || {};
  const pduBody = dataPDU['Body'] || {};
  const app = pduBody['AppHdr'] || {};
  return {originalAppHeader: state[PERSISTED_SLICE].appHeaderSchemaPersist, 
    defaultValuesList : {AppHdr : app} }
}

const bodySchemaWithMsgConfigForNew = (state, args) => {
  const { msgDefId } = args;
  const defaultValues = state[PERSISTED_SLICE][GET_SECTION_DETAIL_SCHEMA_NAMES[msgDefId]];
  const dataPDU = defaultValues['DataPDU'] || {};
  const pduBody = dataPDU['Body'] || {};
  const document = pduBody['Document'];
   return {originalBody: state[PERSISTED_SLICE][GET_PERSISTED_BODY_SCHEMA_NAMES[msgDefId]], 
      defaultValuesList : { ...document}
   }
}

export const getCountryListPersist = createSelector(countries, (coun) => coun);
export const getCurrencyListPersist = createSelector(currencies, (cur) => cur);
export const getSaaHeaderSchemaPersist = createSelector(saaHeader, s => s);
export const getAppHeaderSchemaPersist = createSelector(appHeader, a => a);
export const getPurposeCodesPersist = createSelector(purposes, p => p);
export const getRequiredApiRequest = createSelector(apiRequest, api => api);
export const getElementAttributes = createSelector(eleAttributes, e => e);

export const getSaaHeaderSecDtlSchemaPersist = createSelector(saaHeaderSecDtlSchema, saa => saa);
export const getAppHeaderSecDtlSchemaPersist = createSelector(appHeaderSecDtlSchema, app => app);
export const getBodySecDtlSchemaPersist = createSelector(bodySecDtlSchema, (body) => body);
export const getBodySchemaPersist = createSelector(bodySchema, (body) => body);
export const getBodyandPurposeCodePersist = createSelector(bodyandPurposeCode, (purp) => purp);

export const getSaaHeaderMsgConfigForCreatePayment = createSelector(saaHeaderWithMsgConfigForNew, (saa) => saa);
export const getAppHeaderMsgConfigForCreatePayment = createSelector(appHeaderWithMsgConfigForNew, app => app);
export const getBodySchemarMsgConfigForCreatePayment = createSelector(bodySchemaWithMsgConfigForNew, body => body);

export const {
  loadCustomerPaymentStaticData,
  loadAllSchemaAsHier,
  loadElementAttributes
} = persistedSlice.actions;

export default persistedSlice.reducer;