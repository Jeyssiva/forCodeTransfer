import { createSelector, createSlice } from "@reduxjs/toolkit";
import { BODY_SLICE } from "../../constants/sliceConstants";
import { updateRawHierarchywithResultData } from "./templateHelpers";
import { cloneDeep, isEmpty } from "lodash";
import { inputValidation, updateChoiceableChildVisibiltyBasedonType } from "./validationHelpers";
import { getNestedProperty, onAddNewItems, 
    onChildItemRequiredStatus, onRemoveCreatedItems, onRemoveSingleChildItem, 
    updateRawHierarchywithDefaultData} from "./itemManipulateHelpers";
import { SRCOFTXN_CREATEPAYMENT } from "../../constants/mxTempConstants";
import { updateRawHierarchywithSavedTemplates } from "../createPayment/savedTemplates/savedTemplateHelpers";
import { getBodySchemaPersist, getBodySchemarMsgConfigForCreatePayment, getBodySecDtlSchemaPersist } from "./persistedSlice";

export const bodyInitialState = {
    hierSchemaJsonBody : {},
    treeItemExpandedListBody : [],
    resultBodyDataJsonBody : {}
}

const getAllDatas = (tabName, state) => {
    return {cHierSchemaJson : cloneDeep(state.hierSchemaJsonBody), cResultBodyJson : cloneDeep(state.resultBodyDataJsonBody), 
        cTreeListArray : cloneDeep(state.treeItemExpandedListBody)};
}

const bodySlice = createSlice({
    name : BODY_SLICE,
    initialState : bodyInitialState,
    reducers: {
        resetJsonBody(state, action) {
            state.resultBodyDataJsonBody = {};
            state.hierSchemaJsonBody = {};
            state.treeItemExpandedListBody = {};
        },
        rewriteDataBody(state, action){
            const {originalBody = {}, transConfiguration, args} = action.payload;
            const { enqTxn, jsonData, restrictToAccessTransaction } = args;
            let bodySchema = originalBody;
            const dataJson = cloneDeep(jsonData["DataPDU"]["Body"]["Document"]);
            if(bodySchema){
                const hierBodyDataResult = (!isEmpty(dataJson) && dataJson) || {};
                const rawHierarchyWithData = cloneDeep(bodySchema);
                const bodyResultData = cloneDeep(hierBodyDataResult);
                const expandedResult = [];
                const {sourceOfTxn = undefined} = (enqTxn && enqTxn[0]) || {};
                if(!restrictToAccessTransaction && sourceOfTxn === SRCOFTXN_CREATEPAYMENT)
                    updateRawHierarchywithSavedTemplates(rawHierarchyWithData, bodyResultData, transConfiguration ,expandedResult);
                else 
                    updateRawHierarchywithResultData(rawHierarchyWithData, bodyResultData, expandedResult, restrictToAccessTransaction, transConfiguration);                
                state.hierSchemaJsonBody = rawHierarchyWithData;
                state.resultBodyDataJsonBody = bodyResultData;
                state.treeItemExpandedListBody = expandedResult;
            }
        },
        loadOriginalToBody(state, action) {
            const {originalBody = {}, defaultValuesList } = action.payload; 
            const rawBodyHier = cloneDeep(originalBody);
            const manBodyExpandList = [];
            const bodyDefaultData = cloneDeep(defaultValuesList);
            const bodyResult = {}
            updateRawHierarchywithDefaultData(rawBodyHier, bodyDefaultData,manBodyExpandList, bodyResult )
            state.resultBodyDataJsonBody = bodyResult;
            state.hierSchemaJsonBody = rawBodyHier;
            state.treeItemExpandedListBody = manBodyExpandList;
        },
        treeExpandedListBody(state, action) {
            const {expandedList} = action.payload;
            state.treeItemExpandedListBody = expandedList;
        },
        inputChangeBody(state, action) {
            try {
                const {originalBody, sourceOfTxn, args} = action.payload;
                const {inputValue, inputFormat, fieldForAddiValidation,
                    parentDetails, restrictions, isManualProperty, tabName, validationIssue,
                    elementHierName, ...others} = args;
                const {hierIndex} = others;
                const [lastItem] = parentDetails.slice(-1);
                let cResultBodyJson = cloneDeep(state.resultBodyDataJsonBody);
                let resultDataObj = cResultBodyJson;
                if(isManualProperty){
                    const schemaJson = cloneDeep(state.hierSchemaJsonBody);
                    const oriSchemaJson = cloneDeep(originalBody);
                    const {hierSchemaResult, hierDataResult} = 
                        updateChoiceableChildVisibiltyBasedonType(schemaJson, cResultBodyJson, oriSchemaJson, 
                            inputValue, parentDetails, sourceOfTxn);
                    resultDataObj = {...hierDataResult}
                    state.hierSchemaJsonBody = hierSchemaResult;
                }
                // let autoBindData = autoBindingData(tabName, parentDetails, resultDataObj, inputValue);
                let validPattern = inputValidation(inputValue, restrictions, inputFormat, validationIssue, elementHierName, 
                    fieldForAddiValidation, others);
                const resultBindData = getNestedProperty(parentDetails, resultDataObj); 
                resultBindData[inputFormat] = inputValue;
                resultBindData.error = validPattern;
                // Avoid the hierIndex if choicetype 
                if(lastItem !== 'ChoiceType') resultBindData.hierIndex = hierIndex;
                state.resultBodyDataJsonBody = cResultBodyJson;
            } catch (err) {
                throw err;
            }
        },
        newChildItemBody(state,action) {
            try {
                const {originalBody, args} = action.payload;
                const {parentDetails,shortTitle,nodeId, tabName} = args;
                const {cHierSchemaJson, cResultBodyJson, cTreeListArray} = getAllDatas(tabName, state); 
                const cOriginalHierSchemaJson = cloneDeep(originalBody);
                const {hierSchemaResult, hierDataResult} =  
                onAddNewItems(cHierSchemaJson, cResultBodyJson, cOriginalHierSchemaJson, parentDetails,shortTitle);
                const findNodeId = cTreeListArray.find(e => e === nodeId);
                if(!findNodeId){
                    state.treeItemExpandedListBody = [nodeId, ...cTreeListArray];
                }
                state.hierSchemaJsonBody = hierSchemaResult;
                state.resultBodyDataJsonBody = hierDataResult;
            } catch(err){
                throw err;
            }
        },
        removeExistingItemBody(state,action){
            try {
                const {parentDetails, shortTitle, tabName} = action.payload;
                const {cHierSchemaJson, cResultBodyJson} = getAllDatas(tabName, state);
                const {hierSchemaResult, hierDataResult} = onRemoveCreatedItems(cHierSchemaJson, 
                    cResultBodyJson, parentDetails, shortTitle) 
                state.hierSchemaJsonBody = hierSchemaResult;
                state.resultBodyDataJsonBody = hierDataResult;
            } catch (err){
                throw err;
            }
        },
        removeSingleItemBody(state,action){
            try {
                const {value, parentDetails, shortTitle, tabName} = action.payload;
                const {cHierSchemaJson, cResultBodyJson} = getAllDatas(tabName, state);
                const {rSchJson, rDataJson} = onRemoveSingleChildItem(cHierSchemaJson, 
                    cResultBodyJson, value, parentDetails,shortTitle);
                state.hierSchemaJsonBody = rSchJson;
                state.resultBodyDataJsonBody = rDataJson;
            } catch(err){
                throw err;
            }
        },
        itemRequiredBody(state,action){
            try {
                const {originalBody, sourceOfTxn, args} = action.payload;
                const {value, parentDetails, shortTitle, nodeId, tabName} = args;
                const {cHierSchemaJson, cResultBodyJson, cTreeListArray} = getAllDatas(tabName, state);
                const cOriginalHierSchemaJson = cloneDeep(originalBody);
                const {rSchJson, rDataJson} = onChildItemRequiredStatus(cHierSchemaJson, value,parentDetails,shortTitle, 
                    cResultBodyJson, cOriginalHierSchemaJson, sourceOfTxn);
                const findNodeId = cTreeListArray.find(e => e === nodeId);
                if(!findNodeId){
                    state.treeItemExpandedListBody = [nodeId, ...cTreeListArray];
                }
                state.hierSchemaJsonBody = rSchJson;
                state.resultBodyDataJsonBody = rDataJson;
            }
            catch(err) {
                throw err;
            }      
        },
        updateCrossValidationData(state,action) {
            const {resultData, resultHier, treeList} = action.payload;
            state.resultBodyDataJsonBody = resultData;
            state.treeItemExpandedListBody = [...state.treeItemExpandedListBody, ...treeList]
            state.hierSchemaJsonBody = resultHier;
        },
        loadBodyDataFromSavedTemplate(state, action) {
            try {
                const {originalBody = {}, defaultValuesList = {}, args} = action.payload;
                const { jsonData } = args;
                const bodyResultData = cloneDeep(jsonData["DataPDU"]["Body"]["Document"]);
                const expandedResult = [];
                const rawBodyHier = cloneDeep(originalBody); 
                updateRawHierarchywithSavedTemplates(rawBodyHier, bodyResultData, defaultValuesList ,expandedResult, true);
                state.hierSchemaJsonBody = rawBodyHier;
                state.resultBodyDataJsonBody = bodyResultData;
                state.treeItemExpandedListBody = expandedResult;
            } catch(err) {
                throw err;
            }
        }
    }
})

const hierBody = state => state[BODY_SLICE].hierSchemaJsonBody;
const resultBodyBody = state => state[BODY_SLICE].resultBodyDataJsonBody;
const treeExpandBody = state => state[BODY_SLICE].treeItemExpandedListBody;
// const originalJson = state => state[BODY_SLICE].originalHierSchemaBody;

export const getHierSchemaBody = createSelector(hierBody, App => App);
export const getTreeExpandBody = createSelector(treeExpandBody, tree => tree);
export const getResultBodyDataBody = createSelector(resultBodyBody, body => body);

//Thunk the data
export const getBodyOriFromPersistRewrite = (args) => (dispatch, getState) => {
    const {originalBody = {}, transConfiguration = {}} = getBodySecDtlSchemaPersist(getState());
    dispatch(rewriteDataBody({originalBody, transConfiguration, args}));
}

export const getBodyOriginalDataForCreateTemplate = (args) => (dispatch, getState) => {
    const {originalBody, defaultValuesList} = getBodySchemarMsgConfigForCreatePayment(getState(), args);
    dispatch(loadOriginalToBody({originalBody, defaultValuesList}));
}

export const getBodyOriFromPersistInputChange = (args) => (dispatch, getState) => {
    const {originalBody, sourceOfTxn = SRCOFTXN_CREATEPAYMENT} = getBodySchemaPersist(getState());
    dispatch(inputChangeBody({originalBody, sourceOfTxn, args}));
}

export const getBodyOriFromPersistNewChildItem = (args) => (dispatch, getState) => {
    const {originalBody, sourceOfTxn = SRCOFTXN_CREATEPAYMENT} = getBodySchemaPersist(getState());
    dispatch(newChildItemBody({originalBody, sourceOfTxn, args}));
}

export const getBodyOriFromPersistItemRequired = (args) => (dispatch, getState) => {
    const {originalBody, sourceOfTxn = SRCOFTXN_CREATEPAYMENT} = getBodySchemaPersist(getState());
    dispatch(itemRequiredBody({originalBody, sourceOfTxn, args})); 
}

export const getBodyOriFromPersistSavedTemplate = (args) => (dispatch, getState) => {
    const {originalBody, defaultValuesList} = getBodySchemarMsgConfigForCreatePayment(getState(), args);
    dispatch(loadBodyDataFromSavedTemplate({originalBody, defaultValuesList, args})); 
}

export const {
    rewriteDataBody,
    treeExpandedListBody,
    inputChangeBody,
    newChildItemBody,
    removeExistingItemBody,
    removeSingleItemBody,
    itemRequiredBody,
    resetJsonBody,
    // loadBodyTemplate,
    loadOriginalToBody,
    updateCrossValidationData,
    loadBodyDataFromSavedTemplate
} = bodySlice.actions

export default bodySlice.reducer;