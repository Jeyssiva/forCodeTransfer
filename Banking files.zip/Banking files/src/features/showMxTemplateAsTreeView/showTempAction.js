import { isEmpty } from 'lodash';
import { networkISO } from '../../connections/networkISO';
import { INQUIRY, TEMPLATE_CONFIGURATION, VIEW_TRANSACTION_DETAILS } from '../../constants/apiConstants';
import { TRANS_INQ_SUB_TYPE, TRANS_INQ_TYPE, TRANS_SECTION, TRANS_SECTION_SUBTYPE } from '../../constants/constants';
import { GET_PERSISTED_BODY_SCHEMA_NAMES, GET_SCHEMA_NAMES } from '../../constants/createPaymentConstants';
import XMLAPPHEADERSCHEMA from '../doc/appHead_xsd/head.001.001.02.xsd'
import XMLSAAHEADERSCHEMA from '../doc/saaHead_xsd/SAA_XML_v2_0.xsd'
import { getAppOriFromPersistRewrite } from './appHeaderSlice';
import { getBodyOriFromPersistRewrite } from './bodySlice';
import { convertDataXMLtoJSONWithDeclaration } from './conversionHelpers';
import { loadAllSchemaAsHier } from './persistedSlice';
import { getSaaOriFromPersistRewrite } from './saaHeaderSlice';
import { loadDataTemplates, snackBarActionsShowTemp } from './showMxTempSlice';
import { checkTransactionAccessDisibility } from './validationHelpers';
import { FETCH_ISO_SERVICE } from '../../apacheEnvConfig';

export const getAllStaticTransactionDataAction = (msgDefId, secDtlTransName, requiredApis, msgConfigBody, 
    inqReqBody, applicableFalseReq,
    {txnReqBody, transType, enquiryType}, loggedInUserDtl, screenAccessDet) => {
    const requests = {};
    return dispatch => {
        try {
            //Initialize an array to hold promises conditionally
            const apiPromises = [];
            if(!requiredApis.applicableFalse) {
                apiPromises.push(
                    networkISO.post(`${process.env.REACT_APP_MBB_ISO_SERVICE}/${TEMPLATE_CONFIGURATION}`, 
                        applicableFalseReq, TRANS_SECTION, TRANS_SECTION_SUBTYPE)
                )
                requests['applicableFalseDataPersist'] = {data: {}};
            }
            if(!requiredApis.saaHeader){
                apiPromises.push(fetch(XMLSAAHEADERSCHEMA, {
                    method: 'get',
                    headers: {
                        "Content-Type": "application/xml; charset=utf-8"
                    }
                }))
                requests['saaHeader'] = {data: {}};
            }
            if(!requiredApis.appHeader) {
                apiPromises.push(
                    fetch(XMLAPPHEADERSCHEMA, {
                        method: 'get',
                        headers: {
                            "Content-Type": "application/xml; charset=utf-8"
                        }
                    })
                )
                requests['appHeader'] = {data: {}};
            }
            if(!requiredApis.bodySchema){
                apiPromises.push(
                    fetch(`/schema_xsd/${GET_SCHEMA_NAMES[msgDefId]}.xsd`, {
                        method: 'get',
                        headers: {
                            "Content-Type": "application/xml; charset=utf-8"
                        }
                }))
                requests[GET_PERSISTED_BODY_SCHEMA_NAMES[msgDefId]] = {data: {}};
            }
            if(!requiredApis.msgConfigBySchema){
                apiPromises.push(
                    networkISO.post(`${process.env.REACT_APP_MBB_ISO_SERVICE}/${TEMPLATE_CONFIGURATION}`, 
                        msgConfigBody, TRANS_SECTION, TRANS_SECTION_SUBTYPE)
                )
                requests[secDtlTransName] = {data: {}};
            }
            if(!requiredApis.staticData){
                apiPromises.push(
                    networkISO.post(`${FETCH_ISO_SERVICE()}/${INQUIRY}`, 
                        inqReqBody, TRANS_INQ_TYPE, TRANS_INQ_SUB_TYPE)
                )
                requests['staticData'] = {data: {}}
            }
            apiPromises.push(networkISO.post(`${FETCH_ISO_SERVICE()}/${VIEW_TRANSACTION_DETAILS}`, 
            txnReqBody, transType, enquiryType));
            requests['txnDtl'] = {data: {}};
        Promise.allSettled(apiPromises)
            .then(resSchemas => {              
                // Get a JSON object from each of the responses
                const schemaPromises= resSchemas.map(result => {
                    if(result.status === 'fulfilled' && result.value.ok && result.value.status === 200)
                        return result.value.text();
                    else return Promise.reject(new Error(`Api issue : ${result.reason}`));
                });
                return Promise.allSettled(schemaPromises);
            })
            .then(resData => {
                Object.keys(requests).forEach((reqItem, index) => {
                    if(resData[index].status === 'fulfilled' && !resData[index].value.includes('<!DOCTYPE html>'))
                        requests[reqItem] = {data: resData[index].value}
                })
                dispatch(loadAllSchemaAsHier({msgDefId, requiredApis, requests, msgConfigBody}));
                if(requests['txnDtl'] && !isEmpty(requests['txnDtl'].data)){
                    const { responseBody = {} } = JSON.parse(requests['txnDtl'].data);
                    const {enqTxn} = responseBody;
                    const {mxMessage} = enqTxn && enqTxn[0] && enqTxn[0];
                    const dataJson = convertDataXMLtoJSONWithDeclaration(mxMessage);
                    dispatch(loadDataTemplates({responseBody, dataJson, msgDefId}));
                    const restrictToAccessTransaction = checkTransactionAccessDisibility(enqTxn, loggedInUserDtl, screenAccessDet)
                    dispatch(getSaaOriFromPersistRewrite({enqTxn, jsonData : dataJson, restrictToAccessTransaction}));
                    dispatch(getAppOriFromPersistRewrite({enqTxn, jsonData : dataJson, restrictToAccessTransaction}));
                    dispatch(getBodyOriFromPersistRewrite({enqTxn, jsonData : dataJson, msgDefId, restrictToAccessTransaction}));
                }
            })
            .catch(error => {
                dispatch(snackBarActionsShowTemp({open: true, severity: 'error', snackBarMessage: `${error.message}`}));
            })
        }
        catch(error) {
            dispatch(snackBarActionsShowTemp({open: true, severity: 'error', snackBarMessage: `${error.message}`}));
        }
    }
}
