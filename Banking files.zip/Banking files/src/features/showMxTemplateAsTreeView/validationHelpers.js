import { cloneDeep, has, isEmpty, isEqual } from "lodash"
import { findNumberwithIndex, reArrangeParentDetailsWithOriginalSchema } from "./itemManipulateHelpers"
import { ERRORCODES, ISODATETIME_TYPES, MSG_STATUS_DRAFT, MSG_STATUS_DRAFTRETURN, SRCOFTXN_CREATEPAYMENT, SRCOFTXN_MIDAS } from "../../constants/mxTempConstants"
import { COUNTRY_ADMIN_ROLE, IN, OUT } from "../../constants/transactionConstants";
import { INCOMING_PACS008, INCOMING_PACS009, INCOMING_PACS009COV, PACS008, PACS009, PACS009COV } from "../../constants/createPaymentConstants";
import { ACCESS_LEVEL_READ, NO_ACCESS_LEVEL, TRANS_TYPE } from "../../constants/constants";

export const inputValidation = (value, restrictions, inputFormat, validationIssue, elementHierName, fieldForAddiValidation, others) => {
    const {occuranceObj, isMandatoryField,valueData} = others;
    let additionalValidation = {};
    if(fieldForAddiValidation){
        // input value is currency format and additional validation - Amount.
        if(inputFormat === '_attributes' && fieldForAddiValidation === "_text" ){
            if((!isEmpty(value) && (!valueData["_text"] || !has(valueData, "_text")))){
                additionalValidation = {_text : ERRORCODES['mandatory']}
            } else if(isEmpty(value) && (valueData["_text"])){
                additionalValidation = {_attributes : ERRORCODES['mandatory']}
            } else if(isEmpty(value) && !valueData["text"] && ((occuranceObj && occuranceObj.minOccurs >= 1) || isMandatoryField)){
                additionalValidation = {_text : ERRORCODES['mandatory']}
            } else if(validationIssue){ //check whether have any invalid currrency or not 
                additionalValidation = {_attributes : ERRORCODES['attriInvalidCur']}
            }
        } //input value is amount and additional validation - currency format
         else if(inputFormat === '_text' && fieldForAddiValidation === "_attributes"){
            if(value && (!valueData["_attributes"] || !has(valueData, '_attributes') || isEmpty(valueData["_attributes"]))){
                additionalValidation = {_attributes : ERRORCODES['mandatory']}
            } else if(!value && (!isEmpty(valueData["_attributes"]))){ //amount(_text) is null and _attributes(currency) is available 
                additionalValidation = {_text : ERRORCODES['mandatory']}
            } else if(validationIssue){ //check whether have any invalid currrency or not while enter amount and have any value in ccy
                additionalValidation = {_attributes : ERRORCODES['attriInvalidCur']}
            }
        }
    }
    if(restrictions && inputFormat === '_text'){
        const { pattern, fractionDigits, totalDigits, minInclusive, maxInclusive, length } = restrictions;
        if(value !== "" && pattern) {
            const patternValue =  `^${pattern}?$`;
            try {
                const regexPattern = new RegExp(patternValue)
                if(!regexPattern.test(value)) return { _text: ERRORCODES['regexIssue'], ...additionalValidation }
            } catch (e) {
                return { _text: ERRORCODES['regexCatch'], ...additionalValidation  }
            }
        }
        if(totalDigits || fractionDigits){
            const totalCount = value.replace('.','').length
            const fractionalValue = value.split('.')[1]?.length
            if(totalCount > totalDigits) return {_text: ERRORCODES['totalDigits'], ...additionalValidation }
            else if(fractionalValue > fractionDigits) return {_text: ERRORCODES['fractionDights'], ...additionalValidation } 
        }
        if(minInclusive || maxInclusive){
            if(minInclusive && value < minInclusive)
                return {_text: ERRORCODES['minInclusive'], ...additionalValidation }
            else if(maxInclusive && value > maxInclusive)
                return {_text: ERRORCODES['maxInclusive'], ...additionalValidation }
        }
        if(value && length && value.length < length){
            return {_text: ERRORCODES['mustBe'], ...additionalValidation}
        }
        if(value === "" && ((occuranceObj && occuranceObj.minOccurs >= 1) || isMandatoryField)){
            return { _text: ERRORCODES['mandatory'], ...additionalValidation }
        }
        if(elementHierName === 'CountryCode' && validationIssue) return {_text: ERRORCODES['invalidCountry'], ...additionalValidation }
    } else if(ISODATETIME_TYPES.includes(elementHierName) && inputFormat === '_text') {
        if(value === 'Invalid date') return { _text: ERRORCODES['invalidDate'], ...additionalValidation }
    }
    return { _text: ERRORCODES['noErrors'], ...additionalValidation };
}

export const inputFocusValidation = (value , restrictions, focusIn) => {
    if(restrictions && value === '' && focusIn){
        if(restrictions.minLength){
            return {_text: ERRORCODES['minLength']}
        }
    }
    return { _text: ERRORCODES['noErrors'] };
}

export const updateChoiceableChildVisibiltyBasedonType = (schemaJson,hierDataJson, oriSchemaJson, 
    inputValue, parentDets, sourceOfTxn) => {
    try {
        let schemaObj = schemaJson;
        let dataObj = hierDataJson;
        let oriSchemaObj = oriSchemaJson;
    
        const pDets = parentDets.slice(0, -1);
        const [lastParentName] = pDets.slice(-1);
        pDets.forEach((field, index) => {
            const iName = typeof field === "number" ? `Item${field}` : field
            if(index === pDets.length - 1) {
                schemaObj = schemaObj[iName]
                if(typeof field !== "number") oriSchemaObj = oriSchemaObj[field]
            } else {
                schemaObj = schemaObj[iName].children 
                if(typeof field !== "number") oriSchemaObj = oriSchemaObj[field].children
                if(isEmpty(dataObj[field])) {
                    dataObj[field] = {}
                }
                dataObj = dataObj[field]
            } 
        })   
    
        // If the element has choice elements and sequence elements, then consider to remove the data from choice elements only.
        // Keep the data from sequence elements instead of remove all.
        if(schemaObj.isContainsChoiceInsideSequence){
            const fetchData = dataObj[lastParentName];
            const getChoicableProperities = Object.keys(dataObj[lastParentName])
            for(const item of getChoicableProperities){
                if(has(schemaObj.children[item], 'isChoiceChildHidden')){
                    delete fetchData[item]
                }
            }
            delete fetchData['ChoiceType'];
            dataObj[lastParentName] = fetchData;
        } else if (schemaObj.isChoicableProperty) delete dataObj[lastParentName];
        
        // update input validation like minLength, maxLength if choicable element have children
        if(inputValue !== 'NA' ){
            if(schemaObj.children[inputValue].children) {
                const dataObjValidation = {[inputValue] : {}};
                const processSchema = cloneDeep(schemaObj.children[inputValue]);
                let originalSchema = {};
                if(sourceOfTxn === SRCOFTXN_MIDAS){
                    originalSchema = cloneDeep(schemaObj.children[inputValue]);
                } else {
                    originalSchema = cloneDeep(oriSchemaObj.children[inputValue]);
                    const numbersList = findNumberwithIndex(processSchema.parentDetails);
                    reArrangeParentDetailsWithOriginalSchema(originalSchema.children, numbersList, null, null,
                        processSchema.parentDetails, dataObjValidation[inputValue]);                
                }
                const updatedParentElement = {...originalSchema, parentDetails: processSchema.parentDetails, children: {...originalSchema.children}}; 
                schemaObj.children[inputValue] = {...updatedParentElement};
                if(isEmpty(dataObj[lastParentName])) dataObj[lastParentName] = {};
                dataObj = dataObj[lastParentName];
                dataObj[inputValue] = dataObjValidation[inputValue];  // updateValidationInChoicableElement(schemaObj.children[inputValue].children, {})
            } else {
                const { restrictions, ismandatoryfield } = schemaObj.children[inputValue];
                let errorCode = {}
                if(restrictions && restrictions.minLength === 1 && ismandatoryfield)
                    errorCode = {error: { _text: ERRORCODES['mandatory_min'] }};
                // else if(restrictions && restrictions.minLength === 1)
                //     errorCode = {error: { _text: ERRORCODES['minLength'] }};
                else if(ismandatoryfield)
                    errorCode = {error: { _text: ERRORCODES['mandatory'] }};
                if(!isEmpty(errorCode)) {
                        if(schemaObj.isContainsChoiceInsideSequence) {
                        const dataObjEle = dataObj[lastParentName] || {};
                        dataObj[lastParentName] = {...dataObjEle, [inputValue] : errorCode}
                    } 
                    else dataObj[lastParentName] = {[inputValue] : {...errorCode}}
                }  else { 
                    // If not error just add hierIndex.
                    dataObj[lastParentName] = {hierIndex: schemaObj.hierIndex};
                } 
            }
        }
    
        const childElements = {...schemaObj.children}
        const resultChild = {}
        Object.keys(childElements).forEach(ele => {
            if(has(childElements[ele], 'isChoiceChildHidden')){
                if(inputValue === ele) {
                    resultChild[ele] = {...childElements[ele], isChoiceChildHidden: false}
                } else if(!childElements[ele].isManualProperty){
                    resultChild[ele] = {...childElements[ele], isChoiceChildHidden: true}
                }   
            } else resultChild[ele] = childElements[ele]
        })
        schemaObj.children = {...resultChild}
        return {hierSchemaResult: schemaJson, hierDataResult: hierDataJson}
    } catch (error) {
        throw error;
    }
}
  
export function attributesValidation(fieldForAddiValidation, dataObj, inputValue, validPattern){
    if(fieldForAddiValidation)
        if(inputValue && !dataObj[fieldForAddiValidation]){
            validPattern = {...validPattern, [fieldForAddiValidation]: ERRORCODES["mandatory"]}
        }
        else validPattern = {...validPattern}
    return validPattern
}
export function accountNameValidation(inputValue) {
    const regexPattern = /^(?!.* {2})[a-zA-Z0-9,@\/.\-()& ]+$/; // eslint-disable-line
    if (regexPattern.test(inputValue)) {
        return true;
    } else {
        return false;
    }
}

export function addressValidation(inputValue) {
    const regexPattern = /^(?!.* {2})[a-zA-Z0-9,@\/.\-()#& ]+$/; // eslint-disable-line
    if (regexPattern.test(inputValue)) {
        return true;
    } else {
        return false;
    }
}

//1. Get the Last Char from String
//2. Convert as integer
//3. Check is number or not
//Used in Multiple entry scenario For Ex : Item 0 and Item 1
export function checkLastItemIsNumber(strName) {
    const itemExceptLast = strName.slice(0, -1);
    const lastChar = strName.charAt(strName.length - 1);
    const lastCharN = parseInt(lastChar, 10)
    return {isNumber : !isNaN(lastCharN) && itemExceptLast === 'Item', lastCharN : lastCharN}; 
}

export const allotRows = maxLength => {
    switch(true) {
      case maxLength > 51 && maxLength <= 70: return 2;
      case maxLength > 71 && maxLength <= 150: return 3;
      case maxLength > 151 && maxLength <= 500: return 4;
      case maxLength > 501 && maxLength <= 1000: return 5;
      case maxLength > 1001: return 6; 
      default: return 1;
    }
  }

  // 1. Check whether msgaSatatus is Draft or DraftReturn 
  // 2. Same user access the who ever updated the enquiry latest
  /**
   * 
   * @param {Selected Transaction Information} enqTxn 
   * @param {Loggedin User Detail - used to ignore field disable condition for country admin } loggedInUserDtl 
   * @param {Avoid field enabled if screen Access Permission - 0} screenAccessDet 
   * @returns 
   */
export const checkTransactionAccessDisibility = (enqTxn = {}, loggedInUserDtl, screenAccessDet) => {
    const { levelName } = screenAccessDet || {};
    if(levelName === NO_ACCESS_LEVEL) return true;
    const {msgStatus = undefined, createdBy = ''} = (enqTxn && enqTxn[0]) || {};
    const getUsername = loggedInUserDtl?.userLogin;
    const userGroupIdbyLoggedInUser = loggedInUserDtl?.userUserGroups[0]?.userGroupId;
    const disabledModeStatus = msgStatus && ![MSG_STATUS_DRAFT, MSG_STATUS_DRAFTRETURN].includes(msgStatus.toLowerCase());
    return disabledModeStatus || (getUsername === createdBy && userGroupIdbyLoggedInUser !== COUNTRY_ADMIN_ROLE); 
}

export const findBodySchemaLoaded = (messageDefID, requiredApis) => {
    if((messageDefID === PACS008 || messageDefID === INCOMING_PACS008)
        && requiredApis.bodyB2CSTD) return true;
    else if ((messageDefID === PACS009 || messageDefID === INCOMING_PACS009)
        && requiredApis.bodyB2BSTD)
        return true;
    else if ((messageDefID === PACS009COV || messageDefID === INCOMING_PACS009COV)
        && requiredApis.bodyB2BCov)
        return true;
    return false;
}

export const findDefaultValuesLoaded = (messageDefID, requiredApis) => {
    if(messageDefID === PACS008 && requiredApis.defaultB2CSTD) return true;
    else if(messageDefID === PACS009 && requiredApis.defaultB2BSTD) return true;
    else if(messageDefID === PACS009COV && requiredApis.defaultB2BCoV) return true;
    return false;
}

export const findMsgConfigLoaded = (messageTxnType, sourceOfTxn, msgStatus, screenAccessDet, messageDefID, requiredApis, msgConfigParams) => {
    if(messageTxnType === TRANS_TYPE[IN] || screenAccessDet.levelName === ACCESS_LEVEL_READ
        || (messageTxnType === TRANS_TYPE[OUT] 
          && (sourceOfTxn === SRCOFTXN_MIDAS || sourceOfTxn === SRCOFTXN_CREATEPAYMENT) 
          && msgStatus.toLowerCase() !== MSG_STATUS_DRAFT && msgStatus.toLowerCase() !== MSG_STATUS_DRAFTRETURN))
    return true;

    if(messageDefID === PACS008 && (requiredApis.msgConfigB2C.status && isEqual(requiredApis.msgConfigB2C.reqParams, msgConfigParams )))
        return true;
    else if (messageDefID === PACS009 && (requiredApis.msgConfigB2B.status && isEqual(requiredApis.msgConfigB2B.reqParams, msgConfigParams )))
        return true;
    else if (messageDefID === PACS009COV && (requiredApis.msgConfigB2BCov.status && isEqual(requiredApis.msgConfigB2BCov.reqParams, msgConfigParams )))
        return true;
    return false;
}

export const getSectionDetailRequests = (messageTxnType, screenAccessDet, msgStatus, sourceOfTxn, messageDefId) => {
    if(messageTxnType === TRANS_TYPE[IN] || screenAccessDet.levelName === ACCESS_LEVEL_READ
          || (messageTxnType === TRANS_TYPE[OUT] 
            && (sourceOfTxn === SRCOFTXN_MIDAS || sourceOfTxn === SRCOFTXN_CREATEPAYMENT) 
            && msgStatus.toLowerCase() !== MSG_STATUS_DRAFT && msgStatus.toLowerCase() !== MSG_STATUS_DRAFTRETURN)
      )
        return {
          messageDefId: ['SAA_HEADER'],
          sourceOfTxn,
          isApplicable: 0
        }
     else if (messageTxnType === TRANS_TYPE[OUT] 
      && (sourceOfTxn === SRCOFTXN_MIDAS || sourceOfTxn === SRCOFTXN_CREATEPAYMENT) 
      && (msgStatus.toLowerCase() === MSG_STATUS_DRAFT || msgStatus.toLowerCase() === MSG_STATUS_DRAFTRETURN)) 
        return {
          messageDefId: ['SAA_HEADER', 'APP_HEADER', messageDefId],
          sourceOfTxn,
          isApplicable: 1
        }
      else
        return {
          messageDefId: ['SAA_HEADER'],
          sourceOfTxn,
          isApplicable: 0
        }
  }