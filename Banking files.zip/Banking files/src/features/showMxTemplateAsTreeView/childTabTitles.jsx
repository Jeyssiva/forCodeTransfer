import { memo, useCallback } from "react"
import { useSelector } from "react-redux";
import { SyncLoader } from "react-spinners";
import { Badge, Grid, IconButton, Tab, Tabs, Typography } from "@mui/material"

import { getTabMaintainance } from "./showMxTempSlice";
import { MXTabs } from "../../constants/mxTempConstants";

const ChildTabTitles = ({ handleTabChange, tabValue }) => {
  const tabMaintainance = useSelector(getTabMaintainance);

  const onBadgeClick = useCallback((e) => {
    e.stopPropagation()
  }, [tabValue])

  return (
    <Tabs
      value={tabValue}
      onChange={handleTabChange}
      indicatorColor="primary"
      variant="fullWidth"
      className='tab'
    >
      {
        MXTabs.map(tabItem => {
          const { errors = [], invisible = true, loaded = false } = tabMaintainance[tabItem.value] || {}
          return (
            <Tab
              value={tabItem.value}
              disabled={!loaded}
              key={`tab_${tabItem.label}`}
              label={
                <Grid sx={{ width: '100%', display: 'flex', justifyContent: 'center', flexDirection: 'row' }}>
                  <h5>
                    {tabItem.label}
                  </h5>
                  {
                    !loaded ? (
                      // <IconButton sx={{ width: '5%', marginLeft: '3px' }}>
                      <SyncLoader color={'#000000'}
                        loading={true}
                        size={3}
                        aria-label="Loading Spinner"
                        data-testid="loader" />
                      // </IconButton>
                    ) : (
                      // <IconButton onClick={onBadgeClick}>
                      <div onClick={onBadgeClick}>
                        <Badge sx={{ marginLeft: '10px' }} badgeContent={errors.length}
                          invisible={invisible} color="error" />
                      </div>
                      // </IconButton>
                    )
                  }
                </Grid>
              }
            />
          )
        })
      }
    </Tabs>
  )
}

export default memo(ChildTabTitles)