
import xmlJs from 'xml-js';

export const getDesc = (headerData, bodyResult) => {
    const bodySchemaOptions = {
        compact: false, spaces:0, ignoreDeclaration: true, ignoreComment: true, ignoreInstruction: true
    }
    const xmlSchemaJson = xmlJs.xml2json(headerData, bodySchemaOptions); 
    const namedHeadSchemaJson = JSON.parse(xmlSchemaJson)?.elements[0]?.elements || [];
    const finalResult = []
    namedHeadSchemaJson.forEach(eachItem => {
        const getDetailsFromBodyResult = bodyResult[eachItem.attributes.name];
        if(!getDetailsFromBodyResult) return null
        const findAnnotation = getDetailsFromBodyResult.elements.find( x => x.name === 'xs:annotation');
        const findRestrictions = getDetailsFromBodyResult.elements.find( x => x.name === 'xs:restriction');
        const findChoice = getDetailsFromBodyResult.elements.find( x => x.name === 'xs:choice');
        const findSequence = getDetailsFromBodyResult.elements.find( x => x.name === 'xs:sequence');

        if(findAnnotation) {
            const objAnnotation = { key: eachItem.attributes.name, 
                label: findAnnotation.elements[0].elements[0].text, parent: null, desc: findAnnotation.elements[1].elements[0].text }
            finalResult.push(objAnnotation)
        }
        if(findRestrictions) {
            const findEnumeration = findRestrictions.elements 
                        && findRestrictions.elements.filter(ele => ele.name === 'xs:enumeration');
            if(findEnumeration && findEnumeration.length > 0){
                findEnumeration.forEach(enumItem => {
                    const { attributes, elements } = enumItem;
                    finalResult.push({
                        key: attributes.value,
                        label: elements ? elements[0].elements[0].elements[0].text : attributes.value,
                        desc: elements ?  elements[0].elements[1].elements[0].text : '',
                        parent: eachItem.attributes.name
                    })
                })
             }
        }
        if(findChoice) {
            findChoice.elements.forEach(choiceItem => {
                finalResult.push({
                    key: choiceItem.attributes.name,
                    label: choiceItem.elements[0].elements[0].elements[0].text,
                    desc: choiceItem.elements[0].elements[1].elements[0].text,
                    parent: eachItem.attributes.name
                })
            })
        }
        if(findSequence) {
            findSequence.elements.forEach(choiceItem => {
                finalResult.push({
                    key: choiceItem.attributes.name,
                    label: choiceItem.elements[0].elements[0].elements[0].text,
                    desc: choiceItem.elements[0].elements[1].elements[0].text,
                    parent: eachItem.attributes.name
                })
            })
        }
    })   
}

export const convertSchemaXMLtoJSON = (schemaData) => {
    const bodySchemaOptions = {
        compact: false, spaces:0, ignoreDeclaration: true, ignoreComment: true, ignoreInstruction: true
    }
    const xmlSchemaJson = xmlJs.xml2json(schemaData, bodySchemaOptions); 
    const namedSchemaJson = JSON.parse(xmlSchemaJson)?.elements[0]?.elements || [];
    const properties = {};
    namedSchemaJson.forEach(eachItem => {
      const filterSameElements = namedSchemaJson.filter( n => n.attributes.name === eachItem.attributes.name);
      if(filterSameElements.length > 1) {
        const rootElements = filterSameElements.find(f => f.name !== 'xs:element')
        properties[eachItem.attributes.name] = rootElements;
      } else 
        properties[eachItem.attributes.name] = eachItem
    })
    const finalArray = {...properties};
    return finalArray;
}

export const convertDataXMLtoJSON = (bodyData) => {
    const bodyDataOptions = {
        compact: true, spaces:0, ignoreDeclaration: true, ignoreComment: true, ignoreInstruction: true
    }
    const xmlDataJson = xmlJs.xml2json(bodyData, bodyDataOptions);
    const namedDataJson = JSON.parse(xmlDataJson);
    return namedDataJson
}

export const convertDataJsontoXML = (datajson) => {
    const bodyDataOptions = {
        compact: true, spaces:0, ignoreDeclaration: false, ignoreComment: true, ignoreInstruction: false
    }
    const jsonToXML = xmlJs.json2xml(datajson, bodyDataOptions);
    return jsonToXML
}

export const convertDataXMLtoJSONWithDeclaration = (bodyData) => {
    const bodyDataOptions = {
        compact: true, spaces: 0, ignoreComment: true
    }
    const xmlDataJson = xmlJs.xml2json(bodyData, bodyDataOptions);
    const namedDataJson = JSON.parse(xmlDataJson);
    return namedDataJson;
}

export const converDateStringIntoExpectedFormat = (dateString) => {
    try {
        if(!dateString) return ''
        // Check if the date string contains the 'T' delimiter (ISO format)
        if (dateString.includes('T')) {
            // If 'T' is present, handle it as an ISO 8601 date string (e.g., '2024-11-14T06:12:56.512+00:00')
            const [datePart, timePart] = dateString.split('T');
            const [year, month, day] = datePart.split('-');
            const [hour, minute, secondWithMs] = timePart.split(':');
            const [second] = secondWithMs.split('.'); // Remove milliseconds
            return `${day}/${month}/${year} ${hour}:${minute}:${second}`;
        }

        // If the date string does not contain 'T', check for a hyphen (-) and colon (:)
        if (dateString.includes('-') && dateString.includes(':')) {
            // Assuming the format is something like '2024-11-14 06:12:56'
            const [datePart, timePart] = dateString.split(' '); // Split by space
            const [year, month, day] = datePart.split('-'); // Split the date part
            const [hour, minute, second] = timePart.split(':'); // Split the time part
            return `${day}/${month}/${year} ${hour}:${minute}:${second}`;
        }

        // If no common delimiters, assume it's a custom or invalid format and return as-is
        return dateString;
    }
   catch(err){
     throw err;
   }
}