import { createSelector, createSlice } from "@reduxjs/toolkit";
import { APP_HEADER_SLICE } from "../../constants/sliceConstants";
import { updateRawHierarchywithResultData } from "./templateHelpers";
import { cloneDeep, isEmpty } from "lodash";
import { inputValidation, updateChoiceableChildVisibiltyBasedonType } from "./validationHelpers";
import { getNestedProperty, onAddNewItems, 
    onChildItemRequiredStatus, onRemoveCreatedItems, onRemoveSingleChildItem, 
    updateRawHierarchywithDefaultData} from "./itemManipulateHelpers";
import { SRCOFTXN_CREATEPAYMENT } from "../../constants/mxTempConstants";
import { updateRawHierarchywithSavedTemplates } from "../createPayment/savedTemplates/savedTemplateHelpers";
import { getAppHeaderSchemaPersist, getAppHeaderMsgConfigForCreatePayment, getAppHeaderSecDtlSchemaPersist } from "./persistedSlice";

export const appInitialState = {
    hierSchemaJsonAppHeader : {},
    treeItemExpandedListAppHeader : [],
    resultBodyDataJsonAppHeader : {}
}

const getAllDatas = (tabName, state) => {
    return {cHierSchemaJson: cloneDeep(state.hierSchemaJsonAppHeader), 
        cResultBodyJson : cloneDeep(state.resultBodyDataJsonAppHeader), cTreeListArray : cloneDeep(state.treeItemExpandedListAppHeader)};
}

// const setAllNames = (tabName) => {
//     let obj = {hierName : '', bodyName : '', treeName : ''};
//     switch(tabName) {
//         case SAAHEADER_TAB : {
//             obj = {hierName : 'hierSchemaJsonSaaHeader',bodyName : 'resultBodyDataJsonSaaHeader', treeName: 'treeItemExpandedListSaaHeader' }
//             break;
//         }
//         case APPHEADER_TAB : {
//             obj = {hierName : 'hierSchemaJsonAppHeader',bodyName : 'resultBodyDataJsonAppHeader', treeName: 'treeItemExpandedListAppHeader' }
//             break;
//         }
//         case BODY_TAB : {
//             obj = {hierName : 'hierSchemaJsonBody',bodyName : 'resultBodyDataJsonBody', treeName: 'treeItemExpandedListBody' }
//             break;
//         }
//         default : {
//             return obj;
//         }
//     }
//     return obj;
// }

const appHeaderSlice = createSlice({
    name : APP_HEADER_SLICE,
    initialState : appInitialState,
    reducers: {
        resetJsonApp(state, action) {
            state.resultBodyDataJsonAppHeader = {};
            state.hierSchemaJsonAppHeader = {};
            state.treeItemExpandedListAppHeader = {};
        },
        rewriteDataAppHeader(state, action) {
            const {appHeaderDetails = {}, args} = action.payload;
            const {originalAppHeader, transConfig} = appHeaderDetails;
            const { enqTxn, jsonData, restrictToAccessTransaction } = args;
            const appHeaderSchema = originalAppHeader.AppHdr?.children;
            const dataJson = cloneDeep(jsonData["DataPDU"]["Body"]["AppHdr"]);
            if(appHeaderSchema){
                const appHeadDataResult = (!isEmpty(dataJson) && dataJson) || {};
                const rawAppHierWithData = cloneDeep(appHeaderSchema);
                const appHeadResultData = cloneDeep(appHeadDataResult);
                const appExpandedList= ["1"];
                const {sourceOfTxn = undefined} = (enqTxn && enqTxn[0]) || {};
                if(!restrictToAccessTransaction && sourceOfTxn === SRCOFTXN_CREATEPAYMENT)
                    updateRawHierarchywithSavedTemplates(rawAppHierWithData, appHeadResultData, transConfig, appExpandedList);
                else
                    updateRawHierarchywithResultData(rawAppHierWithData, appHeadResultData, appExpandedList, restrictToAccessTransaction, {});
                state.hierSchemaJsonAppHeader =
                    {AppHdr: {longTitle: 'Application Header', nodeLevel: '1', type: 'AppHdr', parentDetails: [], children: rawAppHierWithData}};
                state.resultBodyDataJsonAppHeader = {AppHdr: appHeadResultData};
                state.treeItemExpandedListAppHeader = appExpandedList;
            }
        },
        loadOriginalToHierAppHeader(state, action) {
            const {appHeaderDetails : {originalAppHeader = {}, defaultValuesList = {}}} = action.payload;
            const rawAppHeader = cloneDeep(originalAppHeader);
            const manAppExpendList = [];
            const bodyDefaultResultApp = cloneDeep(defaultValuesList);
            const appResult = {AppHdr: {}};
            updateRawHierarchywithDefaultData(rawAppHeader, bodyDefaultResultApp, manAppExpendList, appResult);
            state.hierSchemaJsonAppHeader = rawAppHeader;
            state.treeItemExpandedListAppHeader = manAppExpendList;
            state.resultBodyDataJsonAppHeader = appResult;
            // state.tabMaintainance = {SAAHEADER_TAB :{loaded: true}, APPHEADER_TAB: {loaded: true}};
        },
        treeExpandedListApp(state, action) {
            const {expandedList} = action.payload;
            state.treeItemExpandedListAppHeader = expandedList;
        },
        inputChangeApp(state, action) {
            const {originalAppHeader, args} = action.payload;
            const {inputValue, inputFormat, fieldForAddiValidation,
                parentDetails, restrictions, isManualProperty, tabName, validationIssue,
                elementHierName, ...others} = args;
            const {hierIndex} = others;
            const [lastItem] = parentDetails.slice(-1);
            let cResultBodyJson = cloneDeep(state.resultBodyDataJsonAppHeader);
            let resultDataObj = cResultBodyJson;
            if(isManualProperty){
                const schemaJson = cloneDeep(state.hierSchemaJsonAppHeader);
                const oriSchemaJson = cloneDeep(originalAppHeader);
                const {hierSchemaResult, hierDataResult} = 
                    updateChoiceableChildVisibiltyBasedonType(schemaJson,cResultBodyJson, oriSchemaJson, inputValue, parentDetails)
                resultDataObj = {...hierDataResult}
                state.hierSchemaJsonAppHeader = hierSchemaResult;
            }

            // let autoBindData = autoBindingData(tabName, parentDetails, resultDataObj, inputValue);
            let validPattern = inputValidation(inputValue, restrictions, inputFormat, validationIssue, elementHierName, 
                fieldForAddiValidation, others);
            const resultBindData = getNestedProperty(parentDetails, resultDataObj); 
            resultBindData[inputFormat] = inputValue;
            resultBindData.error = validPattern;
            // Avoid the hierIndex if choicetype 
            if(lastItem !== 'ChoiceType') resultBindData.hierIndex = hierIndex;
            state.resultBodyDataJsonAppHeader = cResultBodyJson;
        },
        newChildItemApp(state,action) {
            try {
                const {originalAppHeader, args} = action.payload;
                const {parentDetails,shortTitle,nodeId, tabName} = args;
                const {cHierSchemaJson, cResultBodyJson, cTreeListArray} = getAllDatas(tabName, state); 
                const cOriginalHierSchemaJson = cloneDeep(originalAppHeader);
                const {hierSchemaResult, hierDataResult} =  
                onAddNewItems(cHierSchemaJson, cResultBodyJson, cOriginalHierSchemaJson, parentDetails,shortTitle);
                const findNodeId = cTreeListArray.find(e => e === nodeId);
                if(!findNodeId){
                    state.treeItemExpandedListAppHeader = [nodeId, ...cTreeListArray];
                }
                state.hierSchemaJsonAppHeader = hierSchemaResult;
                state.resultBodyDataJsonAppHeader = hierDataResult;
            } catch (err){
                throw err;
            }
        },
        removeExistingItemApp(state,action){
            try {
                const {parentDetails, shortTitle, tabName} = action.payload;
                const {cHierSchemaJson, cResultBodyJson} = getAllDatas(tabName, state);
                const {hierSchemaResult, hierDataResult} = onRemoveCreatedItems(cHierSchemaJson, 
                    cResultBodyJson, parentDetails, shortTitle);
                state.hierSchemaJsonAppHeader = hierSchemaResult;
                state.resultBodyDataJsonAppHeader = hierDataResult;
            } catch(err) {
                throw err;
            }
        },
        removeSingleItemApp(state,action){
            try {
                const {value, parentDetails, shortTitle, tabName} = action.payload;
                const {cHierSchemaJson, cResultBodyJson} = getAllDatas(tabName, state);
                const {rSchJson, rDataJson} = onRemoveSingleChildItem(cHierSchemaJson, 
                    cResultBodyJson, value, parentDetails,shortTitle);
                state.hierSchemaJsonAppHeader = rSchJson;
                state.resultBodyDataJsonAppHeader = rDataJson;
            } catch(err){
                throw err;
            }           
        },
        itemRequiredApp(state,action){
            try {
                const {originalAppHeader, args} = action.payload;
                const {value, parentDetails, shortTitle, nodeId, tabName} = args;
                const {cHierSchemaJson, cResultBodyJson, cTreeListArray} = getAllDatas(tabName, state);
                const cOriginalHierSchemaJson = cloneDeep(originalAppHeader);
                const {rSchJson, rDataJson} = onChildItemRequiredStatus(cHierSchemaJson, value,parentDetails,shortTitle, cResultBodyJson, cOriginalHierSchemaJson)
                const findNodeId = cTreeListArray.find(e => e === nodeId);
                if(!findNodeId){
                    state.treeItemExpandedListAppHeader = [nodeId, ...cTreeListArray];
                }
                state.hierSchemaJsonAppHeader = rSchJson;
                state.resultBodyDataJsonAppHeader = rDataJson;
            } catch (err) {
                throw err;
            }
        },
        loadAppHeaderFromSavedTemplate(state, action){
            try {
                const { appHeaderDetails : { originalAppHeader = {}, defaultValuesList = {} }, args } = action.payload;
                const { jsonData } = args;
                const appHeaderSchema = originalAppHeader.AppHdr?.children;
                const dataJson = cloneDeep(jsonData["DataPDU"]["Body"]["AppHdr"]);
                if(appHeaderSchema){
                    const appHeadDataResult = (!isEmpty(dataJson) && dataJson) || {};
                    const rawAppHierWithData = cloneDeep(appHeaderSchema);
                    const appHeadResultData = cloneDeep(appHeadDataResult);
                    const appExpandedList= ["1"];
                    updateRawHierarchywithSavedTemplates(rawAppHierWithData, appHeadResultData, defaultValuesList['AppHdr'], 
                            appExpandedList)
                    state.hierSchemaJsonAppHeader =
                        {AppHdr: {longTitle: 'Application Header', nodeLevel: '1', type: 'AppHdr', parentDetails: [], 
                        children: rawAppHierWithData}};
                    state.resultBodyDataJsonAppHeader = {AppHdr: appHeadResultData};
                    state.treeItemExpandedListAppHeader = appExpandedList;
                }
            } catch (err) {
                throw err;
            }
        }
    }
})

const hierAppHeader = state => state[APP_HEADER_SLICE].hierSchemaJsonAppHeader;
const resultBodyAppHeader = state => state[APP_HEADER_SLICE].resultBodyDataJsonAppHeader;
const treeExpandAppHeader = state => state[APP_HEADER_SLICE].treeItemExpandedListAppHeader;

export const getHierSchemaAppHeader = createSelector(hierAppHeader, App => App);
export const getTreeExpandAppHeader = createSelector(treeExpandAppHeader, tree => tree);
export const getResultBodyDataAppHeader = createSelector(resultBodyAppHeader, body => body);

//Thunk the data
export const getAppOriFromPersistRewrite = (args) => (dispatch, getState) => {
    const appHeaderDetails = getAppHeaderSecDtlSchemaPersist(getState(), args);
    dispatch(rewriteDataAppHeader({appHeaderDetails, args}));
}

export const getAppOriginalDataForCreateTemplate = (args) => (dispatch, getState) => {
    const appHeaderDetails = getAppHeaderMsgConfigForCreatePayment(getState(), args);
    dispatch(loadOriginalToHierAppHeader({appHeaderDetails, args}));
}

export const getAppOriFromPersistInputChange = (args) => (dispatch, getState) => {
    const originalAppHeader = getAppHeaderSchemaPersist(getState());
    dispatch(inputChangeApp({originalAppHeader, args}));
}

export const getAppOriFromPersistNewChildItem = (args) => (dispatch, getState) => {
    const originalAppHeader = getAppHeaderSchemaPersist(getState());
    dispatch(newChildItemApp({originalAppHeader, args}));
}

export const getAppOriFromPersistItemRequired = (args) => (dispatch, getState) => {
    const originalAppHeader = getAppHeaderSchemaPersist(getState());
    dispatch(itemRequiredApp({originalAppHeader, args})); 
}

export const getAppOriFromPersistSavedTemplate = (args) => (dispatch, getState) => {
    const appHeaderDetails = getAppHeaderMsgConfigForCreatePayment(getState(), args);
    dispatch(loadAppHeaderFromSavedTemplate({appHeaderDetails, args})); 
}

export const {
    rewriteDataAppHeader,
    treeExpandedListApp,
    inputChangeApp,
    newChildItemApp,
    removeExistingItemApp,
    removeSingleItemApp,
    itemRequiredApp,   
    resetJsonApp,
    loadOriginalToHierAppHeader,
    loadAppHeaderFromSavedTemplate
} = appHeaderSlice.actions

export default appHeaderSlice.reducer;