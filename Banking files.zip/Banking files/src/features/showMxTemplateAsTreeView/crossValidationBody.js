import { cloneDeep, has, isEmpty } from "lodash";
import { PACS008, PACS009, PACS009COV } from "../../constants/createPaymentConstants";

export const crossSectionorFieldsValidation = (hierData, resultData, templateDetails) => {
    try {
        let bodyData = cloneDeep(resultData);
        let bodyHier = cloneDeep(hierData);
        let treeItemList = [];
        let expectRebinded = false;

        const validateFunctions = {
            [PACS009COV]: [bicFiorNameValidation, { fn: iBANorOtherReqByDebtAcctCdtrAcct, args: [bodyData, ['FICdtTrf', 'CdtTrfTxInf', 'UndrlygCstmrCdtTrf']] }],
            [PACS009]: [bicFiorNameValidation],
            [PACS008]: [instructedAmtRequiredWhileChargesInfo, { fn: iBANorOtherReqByDebtAcctCdtrAcct, args: [bodyData, ['FIToFICstmrCdtTrf', 'CdtTrfTxInf']] }],
        };

        const validators = validateFunctions[templateDetails.value] || [];

        for (const validate of validators) {
            let args;
            let isFunction = typeof validate === 'function';

            if (isFunction) {
                args = validate === instructedAmtRequiredWhileChargesInfo ? [bodyData] : [bodyHier, bodyData];
            } else {
                // Extract function and arguments
                const { args: funcArgs } = validate;
                args = funcArgs;
            }

            const { updatedData, updatedHier, treeList = [], expectRebind = false } = isFunction ? validate(...args) : validate.fn(...args);
            bodyData = updatedData || bodyData; // Fallback to original if undefined
            bodyHier = updatedHier || bodyHier; // Fallback to original if undefined
            treeItemList = [...treeItemList, ...treeList]; // Concatenate tree lists
            expectRebinded = expectRebinded || expectRebind; // Logical OR for expectRebind
        }

        return { updatedData: bodyData, updatedHier: bodyHier, treeList: treeItemList, expectRebind: expectRebinded };
    } catch (err) {
        return { err };
    }
};

const updateHierarchicalData = (hierSchema, newValues, pDetails, lastName) => {
    let schemaObj = hierSchema;
    pDetails.forEach((field, index) => {
        const iName = typeof field === "number" ? `Item${field}` : field
        schemaObj = schemaObj[iName].children
    })
    schemaObj[lastName] = {...newValues};
    return hierSchema;
};

// FICdtTrf.CdtTrfTxInf.Cdtr.FinInstnId.BICFI
// FICdtTrf.CdtTrfTxInf.Cdtr.FinInstnId.Nm
// FICdtTrf.CdtTrfTxInf.Cdtr.FinInstnId.PstlAdr
// Applicable for Pacs.009 & Pacs.009Cov
// Either BICFI or Name is required in Creditor, if Name required, Twnname and Country is required.
const bicFiorNameValidation = (hierData, resultData) => {
    try {
        let bicData = resultData['FICdtTrf']['CdtTrfTxInf'];
        let bicHier = hierData['FICdtTrf'].children['CdtTrfTxInf'].children;
        let treeList = [];

        if (!bicData) return { updatedData: resultData, updatedHier: hierData, treeList, expectRebind: false };
        const errorCode = { error: { _text: 'BICFI/Name is Required' } };
        const setErrorCodes = (keys, treeExpends) => {
            keys.forEach(key => {
                bicData['Cdtr']['FinInstnId'][key] = errorCode;   
            });
        };
        const setTreeList = (trees) => {
            trees.forEach(tree => {
                treeList.push(`FICdtTrf.CdtTrfTxInf.${tree}`)
            })
        };
        // if Cdtr is not available
        if (!has(bicData, 'Cdtr')) { 
            bicData['Cdtr'] = { 'FinInstnId': { 'BICFI': errorCode, 'Nm': errorCode } };
            setTreeList(['Cdtr', 'Cdtr.FinInstnId']);
            // treeList.push('FICdtTrf.CdtTrfTxInf.Cdtr', 'FICdtTrf.CdtTrfTxInf.Cdtr.FinInstnId');
            return { updatedData: resultData, updatedHier: hierData, treeList, expectRebind: true };
        } 
        // if FinInstnId is not available
        if (!has(bicData['Cdtr'], 'FinInstnId')) { 
            // bicData['Cdtr']['FinInstnId'] = { 'BICFI': errorCode, 'Nm': errorCode };
            setErrorCodes(['BICFI', 'Nm']);
            setTreeList(['Cdtr.FinInstnId']);
            // treeList.push('FICdtTrf.CdtTrfTxInf.Cdtr.FinInstnId');
            return { updatedData: resultData, updatedHier: hierData, treeList, expectRebind: true };
        }
        const finInstnId = bicData['Cdtr']['FinInstnId'] || {};
        const { BICFI = {}, Nm = {}, PstlAdr } = finInstnId;

        // BICFI and Name, both are not present
        if ((!BICFI || !BICFI._text) && (!Nm || !Nm._text)) { 
            setErrorCodes(['BICFI', 'Nm']);
            return { updatedData: resultData, updatedHier: hierData, treeList, expectRebind: true };
        } 

        const bicFiText = BICFI?._text;
        const nameText = Nm?._text;

        if(bicFiText && !nameText) {
            const twnNmCtryValid = {
                ...(PstlAdr || {}),
                ...(has(PstlAdr, 'TwnNm') && PstlAdr['TwnNm'].error 
                    ? { TwnNm: {...(PstlAdr['TwnNm'] || {}), error: { _text: 1 } } } 
                    : {}),
                ...(has(PstlAdr, 'Ctry') && PstlAdr['Ctry'].error 
                    ? { Ctry: {...(PstlAdr['Ctry'] || {}),  error: { _text: 1 } } } 
                    : {})
            };
            bicData['Cdtr']['FinInstnId']['PstlAdr'] = {
                ...PstlAdr,
                ...twnNmCtryValid
            };
        }

        // if BiCFI is empty and name is present
        if (!bicFiText && nameText) {
            const twnNmCtryValid = {
                ...(PstlAdr || {}),
                ...((!has(PstlAdr, 'TwnNm') || !has(PstlAdr['TwnNm'], '_text') || PstlAdr['TwnNm']._text === '' ) ? 
                    { TwnNm: { error: { _text: 'TownName is Required' } } } : {}),
                ...((!has(PstlAdr, 'Ctry') || !has(PstlAdr['Ctry'], '_text') || PstlAdr['Ctry']._text === '') ? 
                    { Ctry: { error: { _text: 'Country is Required' } } } : {})
            };

            const { error = {} } = BICFI; 
            BICFI.error = error._text !== errorCode.error._text ? { _text: error._text } : { _text: 1 }; 

            bicData['Cdtr']['FinInstnId']['PstlAdr'] = {
                ...PstlAdr,
                ...twnNmCtryValid
            };
            const pstlAdrProperties = cloneDeep(bicHier['Cdtr'].children['FinInstnId'].children['PstlAdr']);
            const pstlAdrUpdate = {
                ...pstlAdrProperties,
                hideChildForRequired: false,         
                checkBoxProps: { ...pstlAdrProperties.checkBoxProps, isTicked: true },
                // TODO : tick is not enabled in UI, so added the 'PostalAddress '. It is a temporary solution
                longTitle: 'PostalAddress '
                // occuranceObj : {...pstlAdrProperties.occuranceObj, count: 1, restrictOccurs: true }
            };
            const parentDetails = ['FICdtTrf', 'CdtTrfTxInf', 'Cdtr', 'FinInstnId'];

            // Update the hierarchical structure directly in hierData
            const deepHierData = cloneDeep(hierData);
            const updatedHier = updateHierarchicalData(deepHierData, pstlAdrUpdate, parentDetails, 'PstlAdr');
            // treeList.push('FICdtTrf.CdtTrfTxInf.Cdtr.FinInstnId.PstlAdr');
            setTreeList(['Cdtr.FinInstnId.PstlAdr']);
            return { updatedData: resultData, updatedHier, treeList, expectRebind: true };
        }

        // Handle regexIssue or invalid value for BICFI and Name
        const { error = {} } = BICFI; 
        BICFI.error = (error._text !== 1 && error._text !== undefined) ? { _text: error._text } : { _text: 1 }; 
        if (Nm) Nm.error = { _text: 1 };
        return { updatedData: resultData, updatedHier: hierData, treeList, expectRebind: true };
    } catch (err) {
        throw err;
    }
};

const instructedAmtRequiredWhileChargesInfo = (resultData) => {
    try {
        const { CdtTrfTxInf } = resultData['FIToFICstmrCdtTrf'];
        const chrgsData = CdtTrfTxInf['ChrgsInf'];
        const instructedAmount = CdtTrfTxInf['InstdAmt'];
        const errorCode = { error: { _text: 'Instructed Amount is Required if Charges Information applicable' } };
        const instrdExtErrText = instructedAmount?.error?._text;

        // Check if Charges Information exists
        if (chrgsData) {
            const instrdAmtNotExists = !instructedAmount?._text;
            const amtExists = Array.isArray(chrgsData) 
                ? chrgsData.some(obj => obj.Amt?._text) 
                : chrgsData.Amt?._text;

            if (amtExists && instrdAmtNotExists) {
                CdtTrfTxInf['InstdAmt'] = errorCode;
                return { updatedData: resultData, expectRebind: true };
            } else if (instrdExtErrText === errorCode.error._text) {
                CdtTrfTxInf['InstdAmt'] = { error: { _text: 1 } };
                return { updatedData: resultData, expectRebind: true };
            }
        } else if (instrdExtErrText === errorCode.error._text) {
            CdtTrfTxInf['InstdAmt'] = { error: { _text: 1 } };
            return { updatedData: resultData, expectRebind: true };
        }

        return { updatedData: resultData, expectRebind: false };
    } catch (err) {
        throw err;
    }
};

const iBANorOtherReqByDebtAcctCdtrAcct = (resultData, mainSectionPath) => {
    try {
        let debtCdtData = resultData;
        const getParentPath = () => {
            mainSectionPath.forEach(key => {
                debtCdtData = debtCdtData[key] || {};
            });
        };

        const errorCode = { error: { _text: 'IBAN/Other is Required' } };
        getParentPath();
        const {CdtrAcct = {}, DbtrAcct = {}} = debtCdtData;
        const {Id : {ChoiceType: choiceDbtr = {}, IBAN : debtIBAN, Othr : debtOther}} = DbtrAcct || {};
        let expectRebind = false;
        if(choiceDbtr._text === ''){
            debtCdtData['DbtrAcct']['Id']['ChoiceType'] = {...choiceDbtr, ...errorCode};
            expectRebind = true;
        }
         
        if(choiceDbtr._text === "IBAN" 
            && (!has(DbtrAcct.Id, "IBAN") || isEmpty(debtIBAN) || (has(DbtrAcct.Id, debtIBAN) && debtIBAN._text === ""))) {
            const errorCode = { error: { _text: 'IBAN is Required' } };
            debtCdtData['DbtrAcct']['Id']['IBAN'] = {...errorCode};
            expectRebind = true;
        } else if(choiceDbtr._text === "Othr"
         && (!has(DbtrAcct.Id, "Othr") || isEmpty(debtOther) || isEmpty(debtOther.Id) || debtOther.Id.text === "" )) {
            const errorCode = { error: { _text: 'Id is Required' } };
            debtCdtData['DbtrAcct']['Id']['Othr']["Id"] = {...errorCode};
            expectRebind = true;
        }    
        
        const {Id : {ChoiceType : choiceCdtrAcct = {}, IBAN: cdtrIBAN, Othr: cdtrOther}} = CdtrAcct || {};
        if(choiceCdtrAcct._text === ''){
            debtCdtData['CdtrAcct']['Id']['ChoiceType'] = {...choiceCdtrAcct, ...errorCode};
            expectRebind = true;
        }
        if(choiceCdtrAcct._text === 'IBAN'
        && (!has(CdtrAcct.Id, "IBAN") || isEmpty(cdtrIBAN) || (has(CdtrAcct.Id, cdtrIBAN) && cdtrIBAN._text === "")))  {
            const errorCode = { error: { _text: 'IBAN is Required' } };
            debtCdtData['CdtrAcct']['Id']['IBAN'] = {...errorCode};
            expectRebind = true;
        } else if(choiceCdtrAcct._text === "Othr"
         && (!has(CdtrAcct.Id, "Othr") || isEmpty(cdtrOther) || isEmpty(cdtrOther.Id) || cdtrOther.Id.text === "" )) {
            const errorCode = { error: { _text: 'Id is Required' } };
            debtCdtData['CdtrAcct']['Id']['Othr']['Id'] = {...errorCode};
            expectRebind = true;
        }
        return { updatedData: resultData, expectRebind };
    } catch(err){
        throw err;
    }
}