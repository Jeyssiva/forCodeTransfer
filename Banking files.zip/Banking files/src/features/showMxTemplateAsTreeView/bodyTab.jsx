import { memo, useEffect, useMemo, useRef } from "react"
import ChildTabs from "./childTabs";
import { useDispatch, useSelector, shallowEqual } from "react-redux";
import { setTabMaintainance, snackBarActionsShowTemp } from "./showMxTempSlice";
import { isEmpty } from "lodash";
import { BODY_TAB } from "../../constants/mxTempConstants";
import { getHierSchemaBody, getTreeExpandBody } from "./bodySlice";

const BodyTab = ({data, treeHeights, tabItem, tabValue, key, reMounted}) => {
    const hierSchemaJson = useSelector(getHierSchemaBody, shallowEqual);
    const treeItemExpandedList = useSelector(getTreeExpandBody, shallowEqual);
    // const [loadBody, setBody] = useState(false);
    const bodyWorkerRef = useRef(null);
    const dispatch = useDispatch();
   // const [bodyData, setBodyData] = useState(null);
   // const findLoadStatus= useSelector(getTabLoadStatus([BODY_TAB]));

    // useEffect(() => {
    //   // if(findLoadStatus) return;
    //   // const setBodyTimeout = setTimeout(() => {
    //   //   setBody(true);
    //   //   // Reason for hand code - loaded : true, Inside the timeout not able to get the latest value of tabMaintainance.
    //   //   // If try to add tabMaintainance in square bracket [], setTimeout initialized every time based on BODY_TIMER.
    //   //   dispatch(setTabMaintainance({tabMaintainance: {[SAAHEADER_TAB] : {loaded: true}, [APPHEADER_TAB]: {loaded: true}, [BODY_TAB] : {loaded: true}}}))
    //   // }, BODY_TIMER);
    //   // return () => {
    //   //    clearTimeout(setBodyTimeout)
    //   // }
    //   setBody(true);
    //   dispatch(setTabMaintainance({tabMaintainance: {[SAAHEADER_TAB] : {loaded: true}, [APPHEADER_TAB]: {loaded: true}, [BODY_TAB] : {loaded: true}}}))
    // }, [findLoadStatus])

    useEffect(() => {
      // cleanup previous worker instance if it exists
      if(bodyWorkerRef.current) {
        bodyWorkerRef.current.terminate();
        bodyWorkerRef.current = null;
      }
      // Create new worker instance
      const bodyWorker = new Worker(new URL ('tabWorker.js', import.meta.url));
      bodyWorkerRef.current = bodyWorker;
       // Post initial messae to the worker
      bodyWorker.postMessage({tabKey: BODY_TAB, payload: 'dataForBody'});
      // Handle worker's response
      bodyWorker.onmessage = e => {
        //Dispatch result to Redux store
        dispatch(setTabMaintainance({tabName: [BODY_TAB], data : {loaded: true}}));
      }
      bodyWorker.onerror = err => {
        dispatch(snackBarActionsShowTemp({open: true, severity: 'error', snackBarMessage: err.message}));
      }
      // Cleanup on component unmount or remount
      return () => {
          if(bodyWorkerRef.current) {
            bodyWorkerRef.current.terminate();
            bodyWorkerRef.current = null;
          }
      }
    }, [reMounted, dispatch])

    const MemoizeChildTab = useMemo(() => {
      return (
          <ChildTabs tabValue = {tabValue}
              tabItem = {tabItem}
              key = {key} treeHeights = {treeHeights}
              hierSchemaJson = {hierSchemaJson} treeItemExpandedList = {treeItemExpandedList}
          />
      )
    }, [treeHeights, hierSchemaJson, treeItemExpandedList, tabValue])
    // console.log(`bodydata: ${data}`);
    // if(!data) return <div>{'Loading....'}</div>
   
    if(isEmpty(hierSchemaJson)) return null;
    return (
        <div
            role="tabpanel"
            hidden={!(tabValue === tabItem.value)}
            id={`full-width-tabpanel-body`}
            aria-labelledby={`full-width-tab-body`}
        >
          {
            MemoizeChildTab
          }
        </div>
    )
} 
export default memo(BodyTab);