import { Box, IconButton } from "@mui/material"
import { FadeLoader } from "react-spinners";
import MbSnackbar from "../common/mbSnackbar";
import { useDispatch, useSelector } from "react-redux";
import { SHOW_MX_TEMPLATE } from "../../constants/sliceConstants";
import React, { useEffect, useState, memo, useCallback, lazy, Suspense } from "react";
import { snackBarActionsShowTemp } from "./showMxTempSlice";
import { getAppResolution } from "../dashboard/dashboardSlice";
// import LazySaaHeader from './saaHeaderTab';
// import LazyAppHeader from './AppHeaderTab';
// import LazyBody from './bodyTab';
import ChildTabTitles from "./childTabTitles";
import { getSaaTreeMountStatus } from "./saaHeaderSlice";
import { SAAHEADER_TAB } from "../../constants/mxTempConstants";

const LazySaaHeader = lazy(() => import('./saaHeaderTab'));
const LazyAppHeader = lazy(() => import('./AppHeaderTab'));
const LazyBody = lazy(() => import('./bodyTab'));
const STATIC_HEIGHT = 265;

const SuspenseLoader = memo((loadingStatus, reMounted) => {
  return (
    <IconButton sx={{ display: 'flex', textAlign: 'center', width: '100%', height: '100%' }}>
      <FadeLoader
        color={'#000000'}
        loading={true}
        size={100}
        aria-label="Loading Spinner"
        data-testid="loader" />
    </IconButton>
  )
});

const ShowMxTemplateMain = memo(({ reMounted = false, staticHeight = STATIC_HEIGHT }) => {
  const actDispatch = useDispatch();
  const [tabValue, setTabValue] = useState(SAAHEADER_TAB);
  const screenResolution = useSelector(getAppResolution);
  const [treeHeights, setTreeHeights] = useState({
    height: `calc(${screenResolution.outerHeight - staticHeight}px)`,
    min: `calc(${screenResolution.outerHeight - staticHeight}px)`, max: `calc(${screenResolution.outerHeight - staticHeight}px)`
  }); // Default height;
  const isTreeviewMounted = useSelector(getSaaTreeMountStatus);
  const snackBarPropertiesShowTemp = useSelector(state => state[SHOW_MX_TEMPLATE].snackBarPropertiesShowTemp);

  useEffect(() => {
    return () => {
      actDispatch(snackBarActionsShowTemp({ open: false }));
    }
  }, [])

  useEffect(() => {
    // Function to calculate and set height based on resolution
    // if(screenResolution.outerHeight <= 768) setTreeHeights({height: '71vh', max: '80vh'})
    // else setTreeHeights({height: '76vh', max: '80vh'})
    setTreeHeights({
      height: `calc(${screenResolution.outerHeight - staticHeight}px)`,
      min: `calc(${screenResolution.outerHeight - staticHeight}px)`, max: `calc(${screenResolution.outerHeight - staticHeight}px)`
    })
  }, [screenResolution]);

  useEffect(() => {
    setTabValue(SAAHEADER_TAB)
  }, [reMounted])

  const handleTabChange = useCallback((event, newValue) => {
    event.preventDefault();
    setTabValue(newValue);
  }, []);

  const onSnackBarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    actDispatch(snackBarActionsShowTemp({ open: false }));
  }

  return (
    <>
      <Box sx={{ bgcolor: 'background.paper', boxShadow: 1, borderRadius: 1, marginTop: 3 }}>
        <ChildTabTitles handleTabChange={handleTabChange} tabValue={tabValue} />
        <Suspense fallback={<SuspenseLoader loadingStatus={!isTreeviewMounted} reMounted={reMounted} />}>
          <LazySaaHeader reMounted={reMounted} treeHeights={treeHeights} tabValue={tabValue} tabItem={{ label: 'SAA Header', value: 'saaHeader' }} />
          <LazyAppHeader reMounted={reMounted} treeHeights={treeHeights} tabValue={tabValue} tabItem={{ label: 'Application Header', value: 'appHead' }} />
          <LazyBody reMounted={reMounted} treeHeights={treeHeights} tabValue={tabValue} tabItem={{ label: 'Body', value: 'body' }} />
        </Suspense>
        <MbSnackbar onClose={onSnackBarClose} open={snackBarPropertiesShowTemp.open}
          severity={snackBarPropertiesShowTemp.severity}
          message={snackBarPropertiesShowTemp.snackBarMessage} />
      </Box>
      {
        !isTreeviewMounted && <SuspenseLoader />
      }
    </>
  )
})
export default ShowMxTemplateMain