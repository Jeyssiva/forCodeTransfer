import { cloneDeep, has, isEmpty } from "lodash";
import { createNewArrayItem, hasTextFieldAvailable } from "./templateHelpers";
import { ERRORCODES, SRCOFTXN_CREATEPAYMENT, SRCOFTXN_MIDAS } from "../../constants/mxTempConstants";
import { checkLastItemIsNumber } from "./validationHelpers";
import moment from "moment";
import { DATE_FORMAT_PICKER, DATE_TIME_FORMAT_PICKER } from "../../constants/constants";

export function findNumberwithIndex(arrList) {
  let numbersWithIndex = arrList.reduce((result, value, index) => {
    if (typeof value === 'number') {
      result.push({ number: value, indexNum: index });
    }
    return result;
  }, []);

  return numbersWithIndex
}

/**
 * Used to add the missing numbers in original schema json
 * 1. Get the numbers and corresponding index using findNumberwithIndex method
 * 2. Check whether the any numbers are need to add in the parent details of original schema.
 * 3. If yes, add the numbers with help of corresponding index using splice method.
 * 4. after that, Add the item's number in same parent details using index and removableIndex.
 * 5. while iteration, validate the string(min length - 1). Doesnot consider the choicableProperty, checkbox parent and occurance parent
 * @param {json} schema 
 * @param {array} indexArray 
 * @param {integer} index 
 * @param {integer} removableIndex 
 * @param {array} parentDHier 
 * @param {object} dataValidation
 */
export function reArrangeParentDetailsWithOriginalSchema(schema, indexArray, index, removableIndex, parentDHier, dataValidation = {}) {
  let dataObjValidation = dataValidation
  for (const key in schema) {
    if (typeof schema[key] === 'object') {
      if (schema[key].parentDetails) {
          const updatedParentDetails = [...schema[key].parentDetails];   
          // Step - 3     
          indexArray.forEach(({number, indexNum}) => {
            updatedParentDetails.splice(indexNum, 0, number);
          })
          if(index !== null){
            updatedParentDetails.splice(parentDHier.length, removableIndex, index);
          } else if(removableIndex !== null){
            updatedParentDetails.splice(parentDHier.length, removableIndex);
          }
          schema[key].parentDetails = updatedParentDetails;
      }
      if(schema[key].nodeLevel) schema[key].nodeLevel = `${schema[key].nodeLevel}.${index || 0}`;
      if(schema[key].occuranceObj && schema[key].occuranceObj.minOccurs === 1) schema[key].occuranceObj.count = 1;
       
      if (schema[key] && schema[key].children && typeof schema[key] === 'object') {
        if(!schema[key].isChoicableProperty && !schema[key].checkBoxProps && !schema[key].occuranceObj) {
          dataObjValidation[key] = reArrangeParentDetailsWithOriginalSchema(schema[key].children, indexArray, index, removableIndex, parentDHier, dataObjValidation[key] || {});
        } else {
          reArrangeParentDetailsWithOriginalSchema(schema[key].children, indexArray, index, removableIndex, parentDHier, undefined)
        }    
      } else {
        if(typeof dataObjValidation === 'object' && index !== 0){
          const { defaultValue } = schema[key];
          if(defaultValue) {
            dataObjValidation[key] = {_text : defaultValue === 'new Date()' 
              ? moment().format(DATE_TIME_FORMAT_PICKER)
              : defaultValue};
            schema[key].disableField = true;
          } else {
            const {isNumber, lastCharN} = checkLastItemIsNumber(key);
            let errorCode = {}
            if(schema[key].restrictions
              && schema[key].restrictions.minLength === 1
              && schema[key].ismandatoryfield) errorCode = {error: { _text: ERRORCODES['mandatory_min'] }}
            // else if(schema[key].restrictions 
            //   && schema[key].restrictions.minLength === 1) errorCode = {error: { _text: ERRORCODES['minLength'] }}
            else if(schema[key].ismandatoryfield) errorCode =  {error: { _text: ERRORCODES['mandatory'] }}
            if(!isEmpty(errorCode)){
              if(isNumber) dataObjValidation[lastCharN] = errorCode;
              else dataObjValidation[key] = errorCode;
            }
          }
        }
      }
    }
  }
  return dataObjValidation
}

/**
 * Method is used to create one or more items.
 * 
 * @param {JSON} hierSchema 
 * @param {JSON} hierData 
 * @param {JSON} oriHierSchema 
 * @param {Array} parentDets 
 * @param {String} shortTitle 
 * @returns 
 */
export const onAddNewItems = (hierSchema, hierData, oriHierSchema, parentDets, shortTitle) => {
  try {
    let childSchemaObj = hierSchema
    let childDataObj = hierData
    let oriHierSchemaObj = oriHierSchema

    parentDets.slice(0, -1).forEach(item => {
      const iName = typeof item === "number" ? `Item${item}` : item
      childSchemaObj = childSchemaObj[iName].children
      if(typeof item !== "number") oriHierSchemaObj = oriHierSchemaObj[item].children
      if(!isEmpty(childDataObj[item])){
          childDataObj = childDataObj[item]
      } else {
        childDataObj[item] ={}
        childDataObj = childDataObj[item]
      }
    })

    const childDetailsFromOriginalSchema = cloneDeep(oriHierSchemaObj[shortTitle])
    const curDataItem  = childDataObj && childDataObj[shortTitle] ? {...childDataObj[shortTitle]} : null;
    let curParentItem = {...childSchemaObj[shortTitle]};
    const {hierIndex, occuranceObj, parentDetails, nodeLevel, ismandatoryfield, restrictions, isFieldWithMultiEntry } = curParentItem;
    const dataObjValidation = {[shortTitle] : {"hierIndex": hierIndex}};

    //If add the item as first time, revert the checkbox settings and choice properties
    if(occuranceObj.count === 0) {
     // dataObjValidation[shortTitle] = {}
      const originalSchema = cloneDeep(childDetailsFromOriginalSchema)
      const numbersList = findNumberwithIndex(parentDetails); 
      reArrangeParentDetailsWithOriginalSchema(originalSchema.children, numbersList, null, null, parentDetails, dataObjValidation[shortTitle]);
      if(originalSchema.isFieldWithMultiEntry){
        curParentItem.children = {'Item0': {...originalSchema.children['Item0'], isRemovableItem: false}}
      } else {
        curParentItem.children = originalSchema.children
      }
      
      // if(originalSchema.isFieldWithMultiEntry) childDataObj[shortTitle] = dataObjValidation[shortTitle][0]
      // else 
      childDataObj[shortTitle] = {...dataObjValidation[shortTitle]}
    } 
    
    curParentItem.hideChildForRequired = false;
    curParentItem.occuranceObj.count += 1;
    if(occuranceObj.count === 1) curParentItem.occuranceObj.showMinusForSingleItem = true
    else curParentItem.occuranceObj.showMinusForSingleItem = false
    
    if(occuranceObj.count === occuranceObj.maxOccurs){
      curParentItem.occuranceObj.restrictOccurs = true
    }
    
    if(occuranceObj.count >= 3){
      const iIndex = occuranceObj.count - 1
      const newName = `Item${iIndex}`
      //dataObjValidation[shortTitle] = {}
      // get the item0 as first item.
      const firstItemChild = cloneDeep(curParentItem.children['Item0'])
      const newItem = createNewArrayItem(iIndex, parentDetails, nodeLevel, false, hierIndex);
      if(firstItemChild.children){
        const originalSchema = cloneDeep(childDetailsFromOriginalSchema)
        const numbersList = findNumberwithIndex(parentDetails); 
        reArrangeParentDetailsWithOriginalSchema(originalSchema.children, numbersList, iIndex, 0, parentDetails, 
          dataObjValidation[shortTitle])
        curParentItem.children[newName] = {...newItem, children: originalSchema.children } 
      } else {
         curParentItem.children[newName] = {...firstItemChild, ...newItem}
      }

      // if restrictions.minLength === 1, then add the error type = 3
      let emptyObject = cloneDeep(dataObjValidation[shortTitle]);
      let errorCode = {}
      if(restrictions && curParentItem.restrictions.minLength === 1
        && ismandatoryfield) errorCode = {error: { _text: ERRORCODES['mandatory_min'] }}
      // else if(curParentItem.restrictions 
      //   && curParentItem.restrictions.minLength === 1) errorCode = {error: { _text: ERRORCODES['minLength'] }}
      else if(ismandatoryfield) errorCode =  {error: { _text: ERRORCODES['mandatory'] }}
      if(!isEmpty(errorCode)){
        emptyObject = errorCode;
      }
      // Add the empty object in data json based on the item addition
      childDataObj[shortTitle].push(emptyObject)
    } 
    // if the occurance count >= 2, then the child fields should be come inside items like Item0 and Item1
    else if(occuranceObj.count >= 2){
      let addChildItems = {};   
      const childInfo = cloneDeep(curParentItem.children);     
      for(let i = 0; i < 2; i++){
        const newItemName = `Item${i}`
        const newItem = createNewArrayItem(i, parentDetails, nodeLevel, false, hierIndex);
        //dataObjValidation[shortTitle] = {}
        if(childInfo && !isFieldWithMultiEntry){
          if(i === 0){   
            reArrangeParentDetailsWithOriginalSchema(childInfo, [], i, 0, parentDetails)
            addChildItems[newItemName] = {...newItem, isRemovableItem : !occuranceObj.isItemRequired, children: childInfo }
          } else {
            const originalSchema = cloneDeep(childDetailsFromOriginalSchema)
            const numbersList = findNumberwithIndex(parentDetails);
            reArrangeParentDetailsWithOriginalSchema(originalSchema.children, numbersList, i, 0, parentDetails, dataObjValidation[shortTitle])
            addChildItems[newItemName] = {...newItem, children: originalSchema.children }  
          }
        } else {
          const [singleItem] = Object.values(childInfo);
          addChildItems[newItemName] = {...singleItem, ...newItem}
        }
      }

      curParentItem.children = cloneDeep(addChildItems);
      // if restrictions.minLength === 1, then add the error type = 3
      let emptyObject = cloneDeep(dataObjValidation[shortTitle])
      let errorCode = {}
      if(restrictions && curParentItem.restrictions.minLength === 1
        && ismandatoryfield) errorCode = {error: { _text: ERRORCODES['mandatory_min'] }}
      // else if(curParentItem.restrictions 
      //   && curParentItem.restrictions.minLength === 1) errorCode = {error: { _text: ERRORCODES['minLength'] }}
      else if(ismandatoryfield) errorCode =  {error: { _text: ERRORCODES['mandatory'] }}
      if(!isEmpty(errorCode)){
        emptyObject = errorCode;
      }
      // If single data item available, then rearrange the item into array.
      // isFieldWithMultiEntry - It is single field but multipleentries, So is it true, rearrange the item0 into the array. 
      if(curDataItem){
      // childDataObj[shortTitle] = !childSchemaObj[shortTitle].isFieldWithMultiEntry ? [curDataItem] : [curDataItem[0]]
        childDataObj[shortTitle] = [curDataItem]
        childDataObj[shortTitle].push(emptyObject)
      } else {
        // If no data items are found, then create two empty array items.
        childDataObj[shortTitle] = []
        for(let i = 0; i < 2; i++){
          childDataObj[shortTitle].push(emptyObject)
        }
      }
    }
    childSchemaObj[shortTitle] = curParentItem;
    return {hierSchemaResult: hierSchema, hierDataResult: hierData}
  } catch (err){
    console.log(err);
    throw err;
  }
}

const elementValidation = (schemaObj, dataObj, parentKey) => {
  if (dataObj && typeof dataObj === 'object') {
    // let childObj = schemaObj;
    let dataObjResult = dataObj;
    for (const key in schemaObj) {
      if (schemaObj[key].children 
        && !schemaObj[key].isChoicableProperty 
        && !schemaObj[key].checkBoxProps 
        && !schemaObj[key].occuranceObj) {
        dataObjResult[key] = elementValidation(
          schemaObj[key].children,
          dataObjResult[key] || {},
          parentKey
        );
      } else {
        let errorCode = {}
        const {restrictions, ismandatoryfield, hierIndex} = schemaObj[key];
        if (restrictions &&restrictions.minLength === 1 && ismandatoryfield) 
          errorCode = { error: { _text: ERRORCODES['mandatory_min'] } };
        else if(ismandatoryfield)
          errorCode = { error: { _text: ERRORCODES['mandatory'] } };
        else if(parentKey === 'PstlAdr' && (key === 'TwnNm' || key === 'Ctry')){
          // It is applicable if parent is PstlAdr
          errorCode = { error: { _text: ERRORCODES['mandatory'] }, hierIndex };
        }
        if(!isEmpty(errorCode)) dataObjResult[key] = errorCode;
      }
    }
    return dataObjResult;
  }
  return dataObj;
};

function updateChildPropertiesCheckboxUnTick(schema) {
  for (const key in schema) {
    if (typeof schema[key] === 'object') {  
      if(schema[key].checkBoxProps) schema[key].checkBoxProps = {...schema[key].checkBoxProps, isTicked: false};
      if(has(schema[key],"hideChildForRequired")) schema[key].hideChildForRequired = true;
      if(has(schema[key] , "isChoiceChildHidden")) schema[key].isChoiceChildHidden = true;
      if (schema[key] && typeof schema[key] === 'object') updateChildPropertiesCheckboxUnTick(schema[key].children);
    }
  }
}

export const onChildItemRequiredStatus = 
    (hierSchema, chkBoxValue, parentDets, shortTitle, hierarchyData, 
      oriHierSchema, sourceOfTxn = SRCOFTXN_CREATEPAYMENT) => {
    try
    {
      let schemaObj = hierSchema;
      let dataObj = hierarchyData;
      let oriSchemaObj = oriHierSchema;

      parentDets.slice(0,-1).forEach(item => {
        const iName = typeof item === "number" ? `Item${item}` : item
        schemaObj = schemaObj[iName].children
        if(typeof item !== "number") oriSchemaObj = oriSchemaObj[iName].children       
        if(isEmpty(dataObj[item])){
          dataObj[item] = {}
        } 
        dataObj = dataObj[item]
      });
      schemaObj[shortTitle].hideChildForRequired = !chkBoxValue;
      schemaObj[shortTitle].checkBoxProps.isTicked = chkBoxValue;

      /* if checkbox is unticked, 
          1. remove the corresponding values from body data
          2. Set isRequired = false in all schema 
          3. Clear all multi items corresponding with parent
          4. Replace the current active item from original schema
      */
      if(chkBoxValue === false){
        let updatedSchema = {};
        if(sourceOfTxn === SRCOFTXN_MIDAS){
          updatedSchema = cloneDeep(schemaObj[shortTitle]);
          updateChildPropertiesCheckboxUnTick(updatedSchema.children);
          schemaObj[shortTitle] = {...schemaObj[shortTitle], children: updatedSchema.children}
        } else {
          updatedSchema = cloneDeep(oriSchemaObj[shortTitle]);
          const numbersList = findNumberwithIndex(parentDets); 
          reArrangeParentDetailsWithOriginalSchema(updatedSchema.children, numbersList, null, null,parentDets)
          schemaObj[shortTitle] = {...schemaObj[shortTitle], children: updatedSchema.children}
        }
        delete dataObj[shortTitle];
      } else {
        dataObj[shortTitle] = {hierIndex: schemaObj[shortTitle].hierIndex, ...elementValidation(schemaObj[shortTitle].children, {}, shortTitle)}
      }
      return {rSchJson: hierSchema, rDataJson: hierarchyData};
    } catch(err) {
      console.log(err)
      throw(err);
    }
}

export const onRemoveSingleChildItem = (hierSchema, hierData,value, parentDets, shortTitle) => {
  try{
    let schemaObj = hierSchema
    let dataObj = hierData
    parentDets.slice(0,-1).forEach(item => {
      const iName = typeof item === "number" ? `Item${item}` : item
      schemaObj = schemaObj[iName].children
      dataObj = !isEmpty(dataObj[item]) && dataObj[item]
    });
    delete dataObj[shortTitle]
    const singleItem = schemaObj[shortTitle];
    singleItem.hideChildForRequired = value;
    if(singleItem.checkBoxProps) singleItem.checkBoxProps.isTicked = value;
    singleItem.occuranceObj.showMinusForSingleItem = false;
    singleItem.occuranceObj.count -= 1
    if(singleItem.occuranceObj.count !== singleItem.occuranceObj.maxOccurs) singleItem.occuranceObj.restrictOccurs = false
    return {rSchJson: hierSchema, rDataJson: hierData}
  } catch(err){
    console.log(err)
    throw err;
  }   
}

export const updateParentDetailsInItemRemoval = (children, parentDHier, index, removableIndex) => {
  if (children && typeof children === 'object') {
      let finalObj = cloneDeep(children);
      if (finalObj.parentDetails) {
          const updatedParentDetails = [...finalObj.parentDetails];
          if(index !== null){
              updatedParentDetails.splice(parentDHier.length, removableIndex, index); 
          } else {
              updatedParentDetails.splice(parentDHier.length, removableIndex); 
          }          
          finalObj.parentDetails = updatedParentDetails;
      }
      if(finalObj.nodeLevel) finalObj.nodeLevel = `${finalObj.nodeLevel}.${index || 0}`
      for (const key in finalObj) {
          if (key === 'children') {
              const resultObj = updateParentDetailsInItemRemoval(finalObj[key], parentDHier, 
                  index, removableIndex);
              finalObj[key] = resultObj;
          } else if (typeof finalObj[key] === 'object') {
              finalObj[key] = updateParentDetailsInItemRemoval(finalObj[key], parentDHier, 
                  index, removableIndex);
          }
      }
      return finalObj;
  }
  return children;
};

export  const onRemoveCreatedItems = (hierSchema, hierData, parentDets, shortTitle) => {
  try {
    let schemaObj = hierSchema;
    let dataObj = hierData;
    const pDetails = parentDets.slice(0,-1);
    const pdDetails = parentDets.slice(0, -2)
    pDetails.forEach((item, index) => {
      const iName = typeof item === "number" ? `Item${item}` : item
      if(index === pDetails.length - 1) schemaObj = schemaObj[iName]
      else schemaObj = schemaObj[iName].children
    });
    pdDetails.forEach((pItem, ind) =>{
      dataObj = dataObj[pItem]
    })
    const deletedItemIndex = parentDets.slice(-1)[0]
    const lastParentName = pDetails.slice(-1)[0]
    const totalChildCount = schemaObj.occuranceObj.count - 1
    delete schemaObj.children[shortTitle]
    dataObj[lastParentName].splice(deletedItemIndex, 1)

    // If have a single item, remove the item0 parent and bind the children as direct instead of inside item0
    if(totalChildCount === 1){  
      const [singleItem] = Object.values(schemaObj.children);
      const {minOccurs, isItemRequired = false} = schemaObj.occuranceObj;
      schemaObj.occuranceObj.showMinusForSingleItem = (minOccurs === 0 && !isItemRequired) ? true : false;
      if(singleItem.children) {
        const resultForParentUpdateIndex = {...updateParentDetailsInItemRemoval(singleItem.children, schemaObj.parentDetails, null, 1)}
        schemaObj.children = {...resultForParentUpdateIndex}
      } else {
        const updateSingleItem = {}
        const itemName = `Item${0}`
        const parentDetails = [...singleItem.parentDetails.slice(0, -1)]
        //parentDetails[parentDetails.length - 1] = 0
        updateSingleItem[itemName] = { ...singleItem,longTitle : itemName, shortTitle : itemName, parentDetails, isRemovableItem: false}
        schemaObj.children = {...updateSingleItem}
      }
      // If it is the single item, convert array into object and reassign the array[0] in to the object.
      if(Array.isArray(dataObj[lastParentName])){
        dataObj[lastParentName] = {...dataObj[lastParentName][0]}
      }
    } else if( deletedItemIndex < totalChildCount ){ 
      // if try to delete the middle of items(For ex: total items - 5, deleted item - 3), rearrange the remaining items with ascending order(4 & 5 into 3,4)
      const updatedItems = {}; 
      for(let i = 0; i < totalChildCount; i++){
        if(i >= deletedItemIndex){
          const itemName = `Item${i}`;
          updatedItems[itemName] = cloneDeep(schemaObj.children[`Item${i + 1}`])
          updatedItems[itemName].longTitle = itemName
          updatedItems[itemName].shortTitle = itemName
          const parentDetails = [...updatedItems[itemName].parentDetails]
          parentDetails[parentDetails.length - 1] = i
          updatedItems[itemName].parentDetails = [...parentDetails]
          updatedItems[itemName].nodeLevel = `${updatedItems[itemName].nodeLevel.slice(0, -1)}${i}`
          if(updatedItems[itemName].children){
            const resultforParentIndexChange = {...updateParentDetailsInItemRemoval(updatedItems[itemName].children, 
              schemaObj.parentDetails, i, 1)}
            updatedItems[itemName].children = {...resultforParentIndexChange}
          }
        } else {
          updatedItems[`Item${i}`] = schemaObj.children[`Item${i}`]
        }      
      }
      schemaObj.children = {...updatedItems}
    }

    schemaObj.occuranceObj.count -= 1
    if(schemaObj.occuranceObj.count !== schemaObj.occuranceObj.maxOccurs){
      schemaObj.occuranceObj.restrictOccurs = false
    }
    return {hierSchemaResult: hierSchema, hierDataResult: hierData}
  } catch(err){
    console.log(err)
    throw err;
  }
}

export function getNestedProperty(parentDetails, autoBindData) {
    return parentDetails.reduce((acc, dataItem) => {
      if (!acc[dataItem]) {
          if (typeof dataItem === 'number') {
              if (Array.isArray(acc)) {
                  acc.push({});
              }
          }
          acc[dataItem] = {};
      }
      return acc[dataItem];
  }, autoBindData);
}

export function generateHierarchyByArray(arrayData) {
  if(Array.isArray(arrayData) && arrayData.length > 0)
  {
     const activeDefaultValues = arrayData
                 .filter(arr => arr.isActive)
                 .map(item => {
                   return {
                      ...item
                   }
                 })
     return buildHierarchy(activeDefaultValues)
  }
 return {}
}

 function buildHierarchy(array) {
  const result = {};

  array.forEach(item => {
    const pathParts = item.messagePath.split('/');
    let currentLevel = result;

    // Navigate through the path, creating nested objects if necessary
    for (let i = 0; i < pathParts.length; i++) {
      const part = pathParts[i];
      //  if (!currentLevel[part]) {
        currentLevel[part] = (i === pathParts.length - 1) 
          ? { ...currentLevel[part], ...item } 
          : {...currentLevel[part]};
      // }
      currentLevel = currentLevel[part];
    }
  });

  return result;
}

export function updateRawHierarchywithDefaultData(rawHierarchy, bodyDataResult, expandedList = [], dataResult = {}) {
  try {
      for(const shortTitle in rawHierarchy){
          const {occuranceObj, hierIndex = 0, isFieldWithMultiEntry, nodeLevel, isChoicableProperty, 
            isContainsChoiceInsideSequence, elementType, parentDetails} = rawHierarchy[shortTitle];
          // Create Payment accepts structured address only, so disable the AdrLine Field for all sections.

        //  const [g, p, f] = parentDetails.slice(-3);
        //   if(g === 'CdtTrfTxInf' && p === 'PmtTpInf' && f === 'SvcLvl'){
        //     console.log('come');
        //   }

          // by default disabled multiple items option of AdrLine and CdtTrfTxInf
          if(shortTitle === 'AdrLine' || shortTitle === 'CdtTrfTxInf') 
            rawHierarchy[shortTitle].occuranceObj = {...rawHierarchy[shortTitle].occuranceObj, disabled: true};
           
          // if have data based on shortTitle
          if(shortTitle in bodyDataResult){
              //update hierIndex for which of the fields contains the data
              if(isEmpty(dataResult[shortTitle])) dataResult[shortTitle] ={hierIndex}
              else dataResult[shortTitle].hierIndex = hierIndex;
             
              if(elementType) {
                const {isMandatory = false,
                   defaultValue = null, choiceType = null} = bodyDataResult[shortTitle] || {};     
                if(defaultValue) {
                  dataResult[shortTitle] = {_text : bodyDataResult[shortTitle].defaultValue === 'new DateTime()' 
                      ? moment().local().format() // Consider the local desktop timezone only rather than from settings 
                      : bodyDataResult[shortTitle].defaultValue === 'new Date()' 
                          ? moment().format(DATE_FORMAT_PICKER) : bodyDataResult[shortTitle].defaultValue };
                  rawHierarchy[shortTitle].disableField = true;
                } else if(choiceType) {
                  dataResult[shortTitle] = {_text: choiceType};
                  rawHierarchy[shortTitle].disableField =  true;
                } else if(isMandatory)
                  dataResult[shortTitle] = {error : {_text : ERRORCODES['mandatory']}};
              }
              // update the expandedList for Treeview expansion.
              if(!has(rawHierarchy[shortTitle], 'elementType') || isFieldWithMultiEntry)        
                  expandedList.push(nodeLevel)
             
              // update the occuranceObj information
              if(occuranceObj){
                const { isMandatory = false} = bodyDataResult[shortTitle];
                rawHierarchy[shortTitle].hideChildForRequired = false;
                if(occuranceObj.maxOccurs === 1) 
                  rawHierarchy[shortTitle].checkBoxProps = {...rawHierarchy[shortTitle].checkBoxProps, isTicked: true, disabled: true};
                        
                const count = (Array.isArray(bodyDataResult[shortTitle]) ? bodyDataResult[shortTitle].length : 1) || 1;
                rawHierarchy[shortTitle].occuranceObj = {...rawHierarchy[shortTitle].occuranceObj, count,
                    showMinusForSingleItem : (count === 1 && occuranceObj.minOccurs === 0 && !isMandatory) ? true : false,
                    restrictOccurs: occuranceObj.maxOccurs === 1 
                    ? true : bodyDataResult[shortTitle].length === occuranceObj.maxOccurs 
                    ? true : false, isItemRequired : isMandatory }
              }
              // If the section is Choicable element or combined with choice and sequence, display the specific element in the childen list.
              if(isChoicableProperty || isContainsChoiceInsideSequence){
                  const isTextFieldThere = hasTextFieldAvailable(bodyDataResult[shortTitle]);
                  let firstItem = ''
                  if(isTextFieldThere) {
                    firstItem = Object.keys(bodyDataResult[shortTitle])[0];
                    dataResult[shortTitle].ChoiceType = {_text: firstItem?.choiceType || ''};            
                  } else {
                    firstItem = bodyDataResult[shortTitle].ChoiceType?.choiceType || '';
                    dataResult[shortTitle] = {...dataResult[shortTitle], "ChoiceType" : {_text: firstItem}};
                  }
                  const childElements = cloneDeep(rawHierarchy[shortTitle].children)
                  let resultChild = {}
                  Object.keys(childElements).forEach(ele => {
                      if(has(childElements[ele], 'isChoiceChildHidden')){
                          if(firstItem === ele) {
                              resultChild[ele] = {...childElements[ele], isChoiceChildHidden: false}
                          } else if(!childElements[ele].isManualProperty){
                              resultChild[ele] = {...childElements[ele], isChoiceChildHidden: true}
                          }
                      } else resultChild[ele] = childElements[ele]
                  })
                  //If the array contains "ChoiceType", update disabled = true. 
                  // if(resultChild.ChoiceType){
                  //   resultChild = {...resultChild,ChoiceType : {...resultChild.ChoiceType, disableField: true}}
                  // }
                  rawHierarchy[shortTitle].children = resultChild;
              }
          }
          if(rawHierarchy[shortTitle].children){
              updateRawHierarchywithDefaultData(rawHierarchy[shortTitle].children, bodyDataResult[shortTitle] || {}, 
                expandedList, dataResult[shortTitle] || {})
          } 
      }
  }
  catch(err){
      console.log(err)
  }
}