import { SAAHEADER_TAB } from "../../constants/mxTempConstants";
import { getNestedProperty } from "./itemManipulateHelpers";


function ignoreSpecialChars(inputValue) {
    return inputValue.replace(/[^a-zA-Z0-9]/g, '');
  }

// Auto binding the X1 value into corresponding DN field.
export function autoBindingData(tabName, parentDetails, resultData, inputValue) {
    if (tabName === SAAHEADER_TAB && parentDetails.slice(-1)[0] === 'X1') {
      // Extract grandParent keys from parentDetails
      const grandParents = parentDetails.slice(0, 4);
      // Use getNestedProperty to safely access the nested DN property
      const dnPath = [...grandParents, 'DN'];
      const dnObject = getNestedProperty(dnPath, resultData);
      if (dnObject && dnObject._text) {
        const sanitizedValue = ignoreSpecialChars(inputValue).substring(0,8).toLowerCase();
        // Regular expression to match the first occurrence of 'o='
        const updatedDnValue = dnObject._text.replace(/(o=)([^,]*)/, `o=${sanitizedValue}`);
        // Update the resultData with the new DN value
        dnObject._text = updatedDnValue;
      }
    }
  
    return resultData;
  }