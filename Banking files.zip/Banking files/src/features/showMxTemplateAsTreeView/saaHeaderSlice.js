import { createSelector, createSlice } from "@reduxjs/toolkit";
import { SAA_HEADER_SLICE } from "../../constants/sliceConstants";
import { updateRawHierarchywithResultData } from "./templateHelpers";
import { cloneDeep, isEmpty } from "lodash";
import { inputValidation, updateChoiceableChildVisibiltyBasedonType } from "./validationHelpers";
import {
    getNestedProperty, onAddNewItems,
    onChildItemRequiredStatus, onRemoveCreatedItems, onRemoveSingleChildItem,
    updateRawHierarchywithDefaultData
} from "./itemManipulateHelpers";
import { SAAHEADER_TAB, SRCOFTXN_CREATEPAYMENT } from "../../constants/mxTempConstants";
import { autoBindingData } from "./crossValidationHelpers";
import { updateRawHierarchywithSavedTemplates } from "../createPayment/savedTemplates/savedTemplateHelpers";
import { getSaaHeaderSchemaPersist, getSaaHeaderMsgConfigForCreatePayment, getSaaHeaderSecDtlSchemaPersist } from "./persistedSlice";

export const saaInitialState = {
    // originalHierSchemaSaaHeader : {},
    hierSchemaJsonSaaHeader: {},
    treeItemExpandedListSaaHeader: [],
    resultBodyDataJsonSaaHeader: {},
    saaTreeMounted: false
}

const getAllDatas = (tabName, state) => {
    return {
        cHierSchemaJson: cloneDeep(state.hierSchemaJsonSaaHeader),
        cResultBodyJson: cloneDeep(state.resultBodyDataJsonSaaHeader), cTreeListArray: cloneDeep(state.treeItemExpandedListSaaHeader)
    };
}

const saaHeaderSlice = createSlice({
    name: SAA_HEADER_SLICE,
    initialState: saaInitialState,
    reducers: {
        resetSaa(state, action) {
            state.resultBodyDataJsonSaaHeader = {};
            state.hierSchemaJsonSaaHeader = {};
            state.treeItemExpandedListSaaHeader = {};
        },
        setSaaTreeMountedStatus(state, action) {
            state.saaTreeMounted = action.payload.status;
        },
        rewriteDataSaaHeader(state, action) {
            const { saaHeaderDetails, args } = action.payload;
            const {originalSaaHeader = {}, transConfig} = saaHeaderDetails;
            const { enqTxn, jsonData, restrictToAccessTransaction } = args;
            // const msgStatus = enqTxn && enqTxn[0] && enqTxn[0].msgStatus;       
            const saaHeaderSchema = originalSaaHeader.saaHeader?.children;
            // const fieldHierarchyList = cloneDeep(state.fieldHierListForAccess);
            const dataJson = cloneDeep(jsonData["DataPDU"]["Header"]);
            const msgConfigSaa = cloneDeep(transConfig);
            if (saaHeaderSchema) {
                const saaHeaderDataResult = (!isEmpty(dataJson) && dataJson) || {};
                const rawHierarchyWithData = cloneDeep(saaHeaderSchema);
                const saaResultData = cloneDeep({ Header: saaHeaderDataResult });
                const expandedResult = ["1"];
                const { sourceOfTxn = undefined } = (enqTxn && enqTxn[0]) || {};
                // const restrictToAccessTransaction = checkTransactionAccessDisibility(enqTxn);
                if (!restrictToAccessTransaction && sourceOfTxn === SRCOFTXN_CREATEPAYMENT)
                    updateRawHierarchywithSavedTemplates(rawHierarchyWithData, saaResultData, msgConfigSaa, expandedResult)
                else
                    updateRawHierarchywithResultData(rawHierarchyWithData, saaResultData, expandedResult, restrictToAccessTransaction, {});
                state.hierSchemaJsonSaaHeader = {
                    saaHeader:
                        { longTitle: 'SAA Header', nodeLevel: '1', type: 'saaHeader', parentDetails: [], children: rawHierarchyWithData }
                };
                state.resultBodyDataJsonSaaHeader = { saaHeader: saaResultData };
                state.treeItemExpandedListSaaHeader = expandedResult;
            }
            state.saaTreeMounted = true;
            state.tabMaintainance = { 'saaHeader': { loaded: true } };
        },
        loadOriginalToHierSaaHeader(state, action) {
            const { saaHeaderDetails : { originalSaaHeader = {}, defaultValuesList = {} } } = action.payload;
            const rawSaaHeader = cloneDeep(originalSaaHeader);
            const manSaaExpendList = [];
            const saaDefaultResult = cloneDeep(defaultValuesList);
            const saaResult = {saaHeader: { Header : {} }}
            updateRawHierarchywithDefaultData(rawSaaHeader, saaDefaultResult, manSaaExpendList, saaResult);
            state.hierSchemaJsonSaaHeader = rawSaaHeader;
            state.treeItemExpandedListSaaHeader = manSaaExpendList;
            state.resultBodyDataJsonSaaHeader = saaResult;
            state.tabMaintainance = { [SAAHEADER_TAB]: { loaded: true } };
            state.saaTreeMounted = true;
        },
        treeExpandedListSaa(state, action) {
            const { expandedList } = action.payload;
            state.treeItemExpandedListSaaHeader = expandedList;
        },
        inputChangeSaaHeader(state, action) {
            const { originalSaaHeader, args } = action.payload;
            const { inputValue, inputFormat, fieldForAddiValidation,
                parentDetails, restrictions, isManualProperty, tabName, validationIssue,
                elementHierName, ...others } = args;
            const { hierIndex } = others;
            const [lastItem] = parentDetails.slice(-1);
            let cResultBodyJson = cloneDeep(state.resultBodyDataJsonSaaHeader);
            let resultDataObj = cResultBodyJson;
            if (isManualProperty) {
                const schemaJson = cloneDeep(state.hierSchemaJsonSaaHeader);
                const oriSchemaJson = cloneDeep(originalSaaHeader)
                const { hierSchemaResult, hierDataResult } =
                    updateChoiceableChildVisibiltyBasedonType(schemaJson, cResultBodyJson, oriSchemaJson, inputValue, parentDetails)
                resultDataObj = { ...hierDataResult }
                state.hierSchemaJsonSaaHeader = hierSchemaResult;
            }

            let autoBindData = autoBindingData(tabName, parentDetails, resultDataObj, inputValue);
            let validPattern = inputValidation(inputValue, restrictions, inputFormat, validationIssue, elementHierName,
                fieldForAddiValidation, others);
            const resultBindData = getNestedProperty(parentDetails, autoBindData);
            resultBindData[inputFormat] = inputValue;
            resultBindData.error = validPattern;
            // Avoid the hierIndex if choicetype 
            if (lastItem !== 'ChoiceType') resultBindData.hierIndex = hierIndex;
            state.resultBodyDataJsonSaaHeader = cResultBodyJson;
        },
        newChildItemSaa(state, action) {
            try {
                const { originalSaaHeader, args } = action.payload;
                const { parentDetails, shortTitle, nodeId, tabName } = args;
                const { cHierSchemaJson, cResultBodyJson, cTreeListArray } = getAllDatas(tabName, state);
                const cOriginalHierSchemaJson = cloneDeep(originalSaaHeader);
                const { hierSchemaResult, hierDataResult } =
                    onAddNewItems(cHierSchemaJson, cResultBodyJson, cOriginalHierSchemaJson, parentDetails, shortTitle);
                const findNodeId = cTreeListArray.find(e => e === nodeId);
                if (!findNodeId) {
                    state.treeItemExpandedListSaaHeader = [nodeId, ...cTreeListArray];
                }
                state.hierSchemaJsonSaaHeader = hierSchemaResult;
                state.resultBodyDataJsonSaaHeader = hierDataResult;
            } catch (err) {
                throw err;
            }
        },
        removeExistingItemSaa(state, action) {
            try {
                const { parentDetails, shortTitle, tabName } = action.payload;
                const { cHierSchemaJson, cResultBodyJson } = getAllDatas(tabName, state);
                const { hierSchemaResult, hierDataResult } = onRemoveCreatedItems(cHierSchemaJson,
                    cResultBodyJson, parentDetails, shortTitle)
                state.hierSchemaJsonSaaHeader = hierSchemaResult;
                state.resultBodyDataJsonSaaHeader = hierDataResult;
            } catch (err) {
                throw err;
            }
        },
        removeSingleItemSaa(state, action) {
            try {
                const { value, parentDetails, shortTitle, tabName } = action.payload;
                const { cHierSchemaJson, cResultBodyJson } = getAllDatas(tabName, state);
                const { rSchJson, rDataJson } = onRemoveSingleChildItem(cHierSchemaJson, cResultBodyJson, value, parentDetails, shortTitle);
                state.hierSchemaJsonSaaHeader = rSchJson;
                state.resultBodyDataJsonSaaHeader = rDataJson;
            } catch (err) {
                throw err;
            }
        },
        itemRequiredSaa(state, action) {
            try {
                const { originalSaaHeader, args } = action.payload;
                const { value, parentDetails, shortTitle, nodeId, tabName } = args;
                const { cHierSchemaJson, cResultBodyJson, cTreeListArray } = getAllDatas(tabName, state);
                const cOriginalHierSchemaJson = cloneDeep(originalSaaHeader);
                const { rSchJson, rDataJson } = onChildItemRequiredStatus(cHierSchemaJson, value, parentDetails, shortTitle, cResultBodyJson, cOriginalHierSchemaJson)
                const findNodeId = cTreeListArray.find(e => e === nodeId);
                if (!findNodeId) {
                    state.treeItemExpandedListSaaHeader = [nodeId, ...cTreeListArray];
                }
                state.hierSchemaJsonSaaHeader = rSchJson;
                state.resultBodyDataJsonSaaHeader = rDataJson;
            }
            catch (err) {
                throw err;
            }
        },
        loadSaaHierFromSavedTemplate(state, action) {
            try {
                const { saaHeaderDetails : { originalSaaHeader = {}, defaultValuesList = {} }, args } = action.payload;
                const { jsonData } = args;
                const saaHeaderSchema = originalSaaHeader.saaHeader?.children;
                const dataJson = cloneDeep(jsonData["DataPDU"]["Header"]);
                const msgConfigSaa = cloneDeep(defaultValuesList["saaHeader"])
                if (saaHeaderSchema) {
                    const saaHeaderDataResult = (!isEmpty(dataJson) && dataJson) || {};
                    const rawHierarchyWithData = cloneDeep(saaHeaderSchema);
                    const saaResultData = cloneDeep({ Header: saaHeaderDataResult });
                    const expandedResult = ["1"];
                    updateRawHierarchywithSavedTemplates(rawHierarchyWithData, saaResultData, msgConfigSaa,expandedResult)
                    state.hierSchemaJsonSaaHeader = {
                        saaHeader:
                            { longTitle: 'SAA Header', nodeLevel: '1', type: 'saaHeader', parentDetails: [], children: rawHierarchyWithData }
                    };
                    state.resultBodyDataJsonSaaHeader = { saaHeader: saaResultData };
                    state.treeItemExpandedListSaaHeader = expandedResult;
                }
                state.saaTreeMounted = true;
                state.tabMaintainance = { 'saaHeader': { loaded: true } };
            } catch (err) {
                throw err;
            }
        }
    }
})

const hierSaaHeader = state => state[SAA_HEADER_SLICE].hierSchemaJsonSaaHeader;
const resultBodySaaHeader = state => state[SAA_HEADER_SLICE].resultBodyDataJsonSaaHeader;
const treeExpandSaaHeader = state => state[SAA_HEADER_SLICE].treeItemExpandedListSaaHeader;
//const originalJson = state => state[SAA_HEADER_SLICE].originalHierSchemaSaaHeader;
const mountStatus = state => state[SAA_HEADER_SLICE].saaTreeMounted;

export const getHierSchemaSaaHeader = createSelector(hierSaaHeader, saa => saa);
export const getTreeExpandSaaHeader = createSelector(treeExpandSaaHeader, tree => tree);
export const getResultBodyDataSaaHeader = createSelector(resultBodySaaHeader, body => body);
//export const getOriginalHierSchemaSaaHeader = createSelector(originalJson, ori => ori);
export const getSaaTreeMountStatus = createSelector(mountStatus, mount => mount);

//Thunk the data
export const getSaaOriFromPersistRewrite = (args) => (dispatch, getState) => {
    const saaHeaderDetails = getSaaHeaderSecDtlSchemaPersist(getState(), args);
    dispatch(rewriteDataSaaHeader({ saaHeaderDetails, args }));
}

export const getSaaOriginalDataForCreateTemplate = (args) => (dispatch, getState) => {
    const saaHeaderDetails = getSaaHeaderMsgConfigForCreatePayment(getState(), args);
    dispatch(loadOriginalToHierSaaHeader({ saaHeaderDetails, args }));
}

export const getSaaOriFromPersistInputChange = (args) => (dispatch, getState) => {
    const originalSaaHeader = getSaaHeaderSchemaPersist(getState());
    dispatch(inputChangeSaaHeader({ originalSaaHeader, args }));
}

export const getSaaOriFromPersistNewChildItem = (args) => (dispatch, getState) => {
    const originalSaaHeader = getSaaHeaderSchemaPersist(getState());
    dispatch(newChildItemSaa({ originalSaaHeader, args }));
}

export const getSaaOriFromPersistItemRequired = (args) => (dispatch, getState) => {
    const originalSaaHeader = getSaaHeaderSchemaPersist(getState());
    dispatch(itemRequiredSaa({ originalSaaHeader, args }));
}

export const getSaaOriFromPersistSavedTemplate = (args) => (dispatch, getState) => {
    const saaHeaderDetails = getSaaHeaderMsgConfigForCreatePayment(getState(), args);
    dispatch(loadSaaHierFromSavedTemplate({ saaHeaderDetails, args }));
}

export const {
    rewriteDataSaaHeader,
    treeExpandedListSaa,
    inputChangeSaaHeader,
    newChildItemSaa,
    removeExistingItemSaa,
    removeSingleItemSaa,
    itemRequiredSaa,
    resetSaa,
    // loadSaaSchema,
    loadOriginalToHierSaaHeader,
    setSaaTreeMountedStatus,
    loadSaaHierFromSavedTemplate
} = saaHeaderSlice.actions

export default saaHeaderSlice.reducer;