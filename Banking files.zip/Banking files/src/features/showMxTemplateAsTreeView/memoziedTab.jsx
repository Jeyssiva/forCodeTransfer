import React from 'react';
import Tab from '@mui/material/Tab';

const MemoizedTab = ({ label, value, key }) => {
  return (
    <Tab
      key={key}
      label={label}
      value={value}
      sx={{ fontWeight: 'bold', textTransform: 'none' }}
      id = {`full-width-tab-${value}`}
      aria-controls={`full-width-tabpanel-${value}`}
    />
  );
};

export default MemoizedTab;