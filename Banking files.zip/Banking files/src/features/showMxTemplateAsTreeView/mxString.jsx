import { memo, useCallback } from "react"
import MbAutocomplete from "../common/mbAutocomplete";
import { Grid, IconButton, Typography } from "@mui/material";
import MbTextField from "../common/mbTextField";
import { useSelector } from "react-redux";
import { Add } from "@mui/icons-material";
import { v4 as uuidv4 } from 'uuid';
import { getCountryListPersist } from "./persistedSlice";

const MxString = ({ restrictions, onTreeItemFieldChange, uploadFieldChanges, labelInfo, labelText, disabled, inputStyle, 
    noErrorStatus, inputRoot, elementHierName, tabName }) => {
      const countryList = useSelector(getCountryListPersist);
      const { maxLength, length } = restrictions || {};
      const mLength = maxLength || length;

      const onAutoCompleteInputChange = useCallback((inputValue) => {
        if(disabled || inputValue === 0) return;
        let validationIssue = false;
        let iValue = inputValue;
        if(inputValue) {
          const findCoun = countryList.find(c => c.description === inputValue);
          if(!findCoun) validationIssue = true;
          else iValue = findCoun.code;
        }
        uploadFieldChanges(iValue, '_text', undefined , validationIssue)
      }, [tabName]);

      const onAutocompleteSelectionChange = useCallback((e, obj) => {
        onAutoCompleteInputChange(((obj && obj.description) || ''))
      }, [tabName])

      const onHandleGenerateUUID = useCallback (() => {
        const uuid = uuidv4();
        uploadFieldChanges(uuid)
      }, [tabName]);

      if(elementHierName === 'CountryCode'){
          let findCountry = countryList.find(c => c.code === labelInfo) || {};  
          return (
              <MbAutocomplete options = {countryList} optionLabel="description" optionValue="code" 
                sxInputRootStyles={inputRoot}
                labelText = { findCountry && findCountry.code}
                size="small" fullWidth = {false} 
                onAutocompleteSelectionChange={onAutocompleteSelectionChange}
                onAutoCompleteInputChange={onAutoCompleteInputChange}
                value={findCountry} inputValue={(findCountry && findCountry.description) || labelInfo}
                sx={{width: '100%', marginTop: '5px'}}
                error = {noErrorStatus} 
                // helperText={getStringHelperText(labelText, error)}
                readOnly = {disabled} inputStyle= {inputStyle}/>
              )
        } else {
          if(restrictions && mLength) {        
            return (
              <Grid sx={{display: 'flex', width: '100%', flexDirection: 'column'}}>
                <Typography variant='body' sx={{display: 'flex', fontSize: '5px', fontWeight: 'bold', direction: 'rtl'}}>
                  {`${labelInfo ? labelInfo.length : 0}/${mLength}`}
                </Typography>
                <MbTextField sx={{width: '100%', flexGrow : 1}} className = {inputRoot} label = {labelText} value = {labelInfo} 
                  onTextFieldChange={onTreeItemFieldChange}
                  error = {noErrorStatus} maxLength={restrictions && (mLength)}
                  readOnly = {disabled} size = {'small'}
                  // helperText = {getStringHelperText(labelText, error, restrictions)} 
                  isLabelShrinkNotReq = {true} inputStyle={inputStyle}
                  // onTextFieldFocus = {e => onTextFocus(e)}
                  // onTextBlur={e => onTextBlur(e)}
                  />
              </Grid>
            )
          } else {
            return (
              <Grid sx={{display: 'flex', flexDirection: 'row', width: '100%'}}>
                  <MbTextField sx={{width: elementHierName === "UUIDv4Identifier" ? '94%' : '100%'}} label = {labelText} 
                    value = {labelInfo} className = {inputRoot} onTextFieldChange={onTreeItemFieldChange}
                    error = {noErrorStatus} maxLength={restrictions && mLength}
                    readOnly = {elementHierName === "UUIDv4Identifier" ? true : disabled} size = {'small'} inputStyle={inputStyle}
                    // helperText = {getStringHelperText(labelText, error, restrictions)} 
                    isLabelShrinkNotReq = {true}/>
                      {
                      elementHierName === "UUIDv4Identifier" && 
                        <IconButton disabled = {disabled} size="small"
                            sx={{width: '6%', display: 'flex', padding: 0}} onClick={onHandleGenerateUUID}>
                            <Add/>
                        </IconButton>
                      }   
              </Grid>
                        
            )
          }
      }
}
export default memo(MxString)