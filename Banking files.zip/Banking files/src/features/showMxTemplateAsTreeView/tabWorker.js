onmessage = (e) => {
    const { tabKey, data } = e.data;

    const processData = () => {
        // for(let i = 0; i< 1e9; i++) {}
        return {result: `Processed data for ${tabKey}`}
    };

    const result = processData();
    postMessage({tabKey, result});
}