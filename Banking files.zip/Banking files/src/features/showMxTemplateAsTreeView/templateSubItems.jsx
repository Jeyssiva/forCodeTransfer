import { Suspense, lazy, memo, useCallback, useState } from "react"
import { FormControlLabel, Grid, Typography, Checkbox, IconButton, Tooltip, Skeleton } from "@mui/material";
import { useTreeItem } from '@mui/x-tree-view/TreeItem';
import { isMobileOnly } from "react-device-detect";
import { Add, Delete, Description, Remove } from "@mui/icons-material";
import { makeStyles } from '@mui/styles';
import clsx from 'clsx';
import { useDispatch } from "react-redux";
import DescriptionPopover from "./descriptionPopover";
// import MxFieldComponents from "./mxFieldComponents";
import { FormattedMessage } from "react-intl";
import ChildErrorPage from "../errorPage/childErrorPage";
import { FONT_SIZE, HEADER_FONT_SIZE } from "../../constants/constants";
import { APPHEADER_TAB, BODY_TAB, SAAHEADER_TAB } from "../../constants/mxTempConstants";
import { getSaaOriFromPersistItemRequired, getSaaOriFromPersistNewChildItem, removeExistingItemSaa, removeSingleItemSaa } from "./saaHeaderSlice";
import { getAppOriFromPersistItemRequired, getAppOriFromPersistNewChildItem, removeExistingItemApp, removeSingleItemApp } from "./appHeaderSlice";
import { getBodyOriFromPersistItemRequired, getBodyOriFromPersistNewChildItem, removeExistingItemBody, removeSingleItemBody } from "./bodySlice";
import { snackBarActionsShowTemp } from "./showMxTempSlice";

export const MxFieldComponents = lazy(() => import("./mxFieldComponents"));
const useStyles = makeStyles(() => ({
  boldTitle: {
    fontWeight: 'inherit',
    fontSize: 'inherit'
  },
  occuranceStyle: {
    marginRight: '5px',
    fontWeight: 'inherit',
    fontSize: 'inherit'
  },
  iconButtonStyle: {
    padding: '1px'
  },
  occuranceDisabled: {
    pointerEvents: 'none'
  },
  occuranceEnabled: {
  }
}));

 export const RenderLabelText = memo(({labeltext, occuranceObj, ismandatoryfield, disableField, hasChildren}) => {
    return (
      <Tooltip title={labeltext}>
        <Typography variant="body2"
            sx={{ fontStyle: !hasChildren ? 'oblique': 'normal', alignSelf: 'center',
            color: disableField === false ? 'red' : 'inherit', fontSize: hasChildren ? HEADER_FONT_SIZE : FONT_SIZE, 
                fontWeight: hasChildren ? '900' : '600'}} >
              {
                labeltext.length > 10
                    && isMobileOnly && occuranceObj && occuranceObj.maxOccurs !== 1
                        ? `${labeltext.substr(0,10)}...` 
                        : labeltext
              } 
              {
                ismandatoryfield && <span style={{color:"red"}}>{' *'}</span>
              }    
        </Typography>
      </Tooltip> 
    )
  });

export const RenderWithChild = memo(({ occuranceObj, checkBoxProps, onHandleAddChildItem, onHandleRemoveSingleChildItem }) => {
  const styleClasses = useStyles();
  return (
    <Grid sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
      {
        occuranceObj && (occuranceObj.maxOccurs > 1 || !checkBoxProps) &&
        <Grid
          sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', fontSize: '11px' }}>
          <Typography className={styleClasses.boldTitle}>{isMobileOnly ? "C:" : "Count:"}</Typography>
          <Typography className={styleClasses.boldTitle}>{occuranceObj.count}</Typography>
          <IconButton className={styleClasses.iconButtonStyle} disabled={occuranceObj.restrictOccurs || occuranceObj.disabled}
            onClick={onHandleAddChildItem}>
            <Add />
          </IconButton>
          {
            occuranceObj.showMinusForSingleItem &&
            <IconButton className={styleClasses.iconButtonStyle}
              onClick={onHandleRemoveSingleChildItem}
              disabled={occuranceObj.disabled}>
              <Remove />
            </IconButton>
          }
          <Typography className={styleClasses.occuranceStyle}>
            {isMobileOnly ? "min:" : <FormattedMessage id="mxTemplates.minOccurs" />}</Typography>
          <Typography className={styleClasses.occuranceStyle}>{occuranceObj.minOccurs}</Typography>
          <Typography className={styleClasses.occuranceStyle}>
            {isMobileOnly ? "max:" : <FormattedMessage id="mxTemplates.maxOccurs" />}
          </Typography>
          <Typography className={styleClasses.occuranceStyle}>
            {occuranceObj.maxOccurs === 'unbounded' ? "-" : occuranceObj.maxOccurs}
          </Typography>
        </Grid>
      }
    </Grid>
  )
});

const TemplateSubItems = memo(
  function TemplateSubItems(props) {
    const {
      className,
      classes,
      contentProps,
      icon: iconProp,
      nodeId,
      expansionIcon,
      displayIcon,
    } = props;

    const {
      hasChildren,
      elementHierName,
      shortTitle,
      labeltext,
      tabName,
      ...itemOthers
    } = contentProps;
    const { elementType, restrictions, options, parentDetails, checkBoxProps, occuranceObj,
      simpleContent, isRemovableItem, isManualProperty, description,
      currencyCodeDetails, disableField, disableItem, ismandatoryfield, hierIndex } = itemOthers;
    const checkBoxLabel = { inputProps: { 'aria-label': 'Checkbox demo' } }
    const dispatch = useDispatch();
    const {
      disabled,
      expanded,
      selected,
      focused,
      handleExpansion,
      // handleSelection,
      preventSelection,
    } = useTreeItem(nodeId);
    const icon = iconProp || expansionIcon || displayIcon;
    const [descPop, setDescPop] = useState(null);
    const openDescriptionPopover = Boolean(descPop);

    const handleMouseDown = (event => {
      preventSelection(event);
    });

    const handleExpansionClick = (event => {
      handleExpansion(event);
    });

    const onHandleAddChildItem = useCallback(() => {
      try {
        switch (tabName) {
          case SAAHEADER_TAB: {
            dispatch(getSaaOriFromPersistNewChildItem({ parentDetails, shortTitle, nodeId, tabName }));
            return;
          }
          case APPHEADER_TAB: {
            dispatch(getAppOriFromPersistNewChildItem({ parentDetails, shortTitle, nodeId, tabName }));
            return;
          }
          case BODY_TAB: {
            dispatch(getBodyOriFromPersistNewChildItem({ parentDetails, shortTitle, nodeId, tabName }))
            return;
          }
          default: return;
        }
      }
      catch (err) {
        dispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: 'Item Addition Failed' }));
      }
    }, [tabName, parentDetails, shortTitle, nodeId, dispatch]);

    const onHandleDescriptionPopoverStatus = useCallback(status => {
      setDescPop(status);
    }, []);

    const onHandleDescriptionPopoverLeave = useCallback(() => {
      setDescPop(null);
    }, []);

    const onHandleChildItemRequired = useCallback((e) => {
      try {
        switch (tabName) {
          case SAAHEADER_TAB:
            {
              dispatch(getSaaOriFromPersistItemRequired({ value: e.target.checked, parentDetails, shortTitle, nodeId, tabName }))
              return;
            }
          case APPHEADER_TAB: {
            dispatch(getAppOriFromPersistItemRequired({ value: e.target.checked, parentDetails, shortTitle, nodeId, tabName }))
            return;
          }
          case BODY_TAB: {
            dispatch(getBodyOriFromPersistItemRequired({ value: e.target.checked, parentDetails, shortTitle, nodeId, tabName }))
            return;
          }
          default: return;
        }
      }
      catch (err) {
        dispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: 'CheckBox Item Selection Failed' }));
      }
    }, [tabName, parentDetails, shortTitle, nodeId, dispatch])

    const onHandleRemoveCreatedtems = useCallback(() => {
      try {
        switch (tabName) {
          case SAAHEADER_TAB: {
            dispatch(removeExistingItemSaa({ parentDetails, shortTitle, tabName }));
            return;
          }
          case APPHEADER_TAB: {
            dispatch(removeExistingItemApp({ parentDetails, shortTitle, tabName }));
            return;
          }
          case BODY_TAB: {
            dispatch(removeExistingItemBody({ parentDetails, shortTitle, tabName }));
            return;
          }
          default: return;
        }
      } catch (err) {
        dispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: 'Item Removal Failed' }));
      }
    }, [tabName, parentDetails, shortTitle, dispatch])

    const onHandleRemoveSingleChildItem = useCallback(() => {
      try {
        switch (tabName) {
          case SAAHEADER_TAB: {
            dispatch(removeSingleItemSaa({ value: true, parentDetails, shortTitle, tabName }));
            return;
          }
          case APPHEADER_TAB: {
            dispatch(removeSingleItemApp({ value: true, parentDetails, shortTitle, tabName }));
            return;
          }
          case BODY_TAB: {
            dispatch(removeSingleItemBody({ value: true, parentDetails, shortTitle, tabName }));
            return;
          }
          default: return;
        }
      }
      catch (err) {
        dispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: 'Item Removal Failed' }));
      }
    }, [tabName, shortTitle, parentDetails, dispatch])

    const renderDescription = useCallback(() => {
      return (
        (!isManualProperty && !isRemovableItem) &&
        <>
          <IconButton sx={{ padding: 0, ml: isMobileOnly ? '1px' : 1 }}
            aria-haspopup="true" size="small"
            aria-owns={openDescriptionPopover ? `mouseOverDescPopOver_${nodeId}` : undefined}
            onMouseEnter={onHandleDescriptionPopoverStatus}
            onMouseLeave={onHandleDescriptionPopoverLeave}>
            <Description sx={{ width: '16px' }} />
          </IconButton>
          {
            openDescriptionPopover &&
            <DescriptionPopover id={`mouseOverDescPopOver_${nodeId}`} key={`mouseOverDescPopOverKey_${nodeId}`}
              handleDescriptionPopoverClose={onHandleDescriptionPopoverLeave} title={labeltext}
              openPopover={openDescriptionPopover} popOverEle={descPop} description={description}
              restrictions={restrictions} parentDets={parentDetails} elementType={elementType} isManualProperty={isManualProperty}
            />
          }
        </>
      )
    }, [openDescriptionPopover]);

    const renderCheckbox = useCallback(() => {
      return (
        checkBoxProps && !elementType &&
        <FormControlLabel sx={{ mr: 0 }}
          disabled={checkBoxProps.disabled}
          value={checkBoxProps.isTicked}
          control={
            <Checkbox {...checkBoxLabel} sx={{ ml: '3px', padding: '4px' }} disabled={checkBoxProps.disabled} size="small"
              defaultChecked={checkBoxProps.isTicked} onChange={onHandleChildItemRequired} />
          } />
      )
    }, [checkBoxProps, elementType, tabName])

    const fieldProps = {
      elementType, labelText: labeltext,
      restrictions, tabName, parentDetails, hasChildren, isManualProperty, elementHierName,
      options, simpleContent, currencyCodeDetails, nodeId, disabled: disableField,
      isMandatoryField: ismandatoryfield, occuranceObj,
      hierIndex
    }

    try {
      return (
        <>
          <Grid
            sx={{
              display: 'flex',
              alignItems: 'center',
              flexDirection: 'row',
              pr: 0,
              maxWidth: 'auto',
              bgcolor: hasChildren ? '#c4dcf4' : null
            }}
            className={clsx(className, classes.root, {
              [classes.expanded]: expanded,
              [classes.selected]: selected,
              [classes.focused]: focused,
              [classes.disabled]: disabled,
            })}
            onMouseDown={handleMouseDown}
            key={`Field_${labeltext}`}
          >
            <IconButton sx={{ mr: '2px' }} onClick={handleExpansionClick} className={classes.iconContainer}>
              {icon}
            </IconButton>
            {
              renderCheckbox()
            }
            {
              isRemovableItem && <IconButton disabled={disableItem}
                onClick={onHandleRemoveCreatedtems}>
                <Delete />
              </IconButton>
            }
            {
              !isMobileOnly || (isMobileOnly && hasChildren) ?
                <Grid item sx={{ maxWidth: '55%', width: '25%', alignItems: 'flex-start', display: 'flex' }}>
                  <RenderLabelText labeltext={labeltext} ismandatoryfield={ismandatoryfield} occuranceObj={occuranceObj}
                    disableField={disableField} hasChildren={hasChildren} />
                  {/* {renderLabelText()} */}
                  {renderDescription()}
                </Grid>
                : renderDescription()
            }
            {
              !hasChildren
                ? <Suspense fallback={<Skeleton variant="rounded" width={210} height={40} sx={{ mb: '2px' }} />}>
                  <MxFieldComponents fieldProps={fieldProps} />
                </Suspense>
                : <Suspense variant="rounded" width={210} height={20} sx={{ mb: '2px' }}>
                  <RenderWithChild occuranceObj={occuranceObj} checkBoxProps={checkBoxProps}
                    onHandleAddChildItem={onHandleAddChildItem}
                    onHandleRemoveSingleChildItem={onHandleRemoveSingleChildItem} />
                </Suspense>
            }
          </Grid>
        </>
      );
    }
    catch (err) {
      console.error(err);
      return <ChildErrorPage subTitle={"common.wentWrong"} />
    }
  }
);

export default TemplateSubItems
