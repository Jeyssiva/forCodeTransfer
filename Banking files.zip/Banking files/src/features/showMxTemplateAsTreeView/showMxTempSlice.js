import { createSelector, createSlice } from "@reduxjs/toolkit";
import { APP_HEADER_SLICE, BODY_SLICE, SAA_HEADER_SLICE, SHOW_MX_TEMPLATE } from "../../constants/sliceConstants";
import { cloneDeep } from "lodash";
import { APPHEADER_TAB, BODY_TAB, MXTabs, SAAHEADER_TAB } from "../../constants/mxTempConstants";

export const showMxInitialState = {
    resultOriginalDataJson: {},
    snackBarPropertiesShowTemp: {},
    bodySchema: '',
    ISOCurrencyList : [],
    originalHierSchemaJson : {},
    mx_mt_OverlayMessage: {},
    selectedTxnDet : {},
    custNaviConfirmationMessage: false,
    tabMaintainance : {},
    activeMessageDefId : ''
}

const showMxTemplateSlice = createSlice({
    name : SHOW_MX_TEMPLATE,
    initialState : showMxInitialState,
    reducers: {
        resetJson(state, action) {
            state.resultOriginalDataJson = {};
            state.selectedTxnDet = {};
            state.custNaviConfirmationMessage = false;
            state.tabMaintainance = {};
            state.activeMessageDefId = '';
        },
        loadDataTemplates(state, action) {
            const { responseBody, dataJson, msgDefId } = action.payload;
            state.resultOriginalDataJson = dataJson;
            state.selectedTxnDet = responseBody;
            state.activeMessageDefId = msgDefId;
        },
        snackBarActionsShowTemp(state,action) {
            state.snackBarPropertiesShowTemp = {...action.payload}
        },
        loadBodySchemaTemplates(state, action) {
            // TODO: This slice method is not required.
            state.bodySchema = action.payload.data
        },
        setSaveSelectedMxMTResult(state, action){
            const {responseBody, confirmStatus} = action.payload;
            const {verPkSeqNo, msgVerNo, mxMessage, msgStatus } = responseBody;
            const {enqTxn = []} = cloneDeep(state.selectedTxnDet) || {};
            state.selectedTxnDet = {...state.selectedTxnDet, verPkSeqNo, msgVerNo, enqTxn: [{...enqTxn[0], mxMessage, msgStatus}]};
            state.custNaviConfirmationMessage = confirmStatus;
        },
        setConfirmNaviMsg(state, action){
            state.custNaviConfirmationMessage = action.status;
        },
        setTabMaintainance(state, action){
            const {tabName, data} = action.payload;
            const mainTainance = cloneDeep(state.tabMaintainance);
            if(!mainTainance[tabName]) mainTainance[tabName] = {};
            mainTainance[tabName] = {...data};
            state.tabMaintainance = {...mainTainance};
        },
        setErrorsInTabMaintainance(state, action) {
            state.tabMaintainance = action.payload.tabMaintainance;
        },
        setMountedStatus(state, action) {
            state.isTreeviewMounted = action.payload.status;
        },
        setActiveMsgDefId(state, action) {
            state.activeMessageDefId = action.payload.msgDefId
        }
    }
})

const originalJson = state => state[SHOW_MX_TEMPLATE].resultOriginalDataJson;
const txnDet = state => state[SHOW_MX_TEMPLATE].selectedTxnDet;
const conStatus = state => state[SHOW_MX_TEMPLATE].custNaviConfirmationMessage;
const tabMain = state => state[SHOW_MX_TEMPLATE].tabMaintainance;

const bodyJson = tabName => state =>  {
    switch(tabName){
        case SAAHEADER_TAB : return state[SAA_HEADER_SLICE].resultBodyDataJsonSaaHeader
        case APPHEADER_TAB : return state[APP_HEADER_SLICE].resultBodyDataJsonAppHeader
        case BODY_TAB : return state[BODY_SLICE].resultBodyDataJsonBody
        default: return {}
    }
}
export const getBodyJson = createSelector(bodyJson, body => body);
export const getOriginalJson = createSelector(originalJson, ori => ori);
export const getSelectedTxnDet = createSelector(txnDet, det => det);
export const getConfirmNaviMsg = createSelector(conStatus, stat => stat);
export const getTabMaintainance = createSelector(tabMain, cnt => cnt);

const findAllTabsLoaded = state => {
    const tabArray = MXTabs;
    const filter = tabArray.filter(f => state[SHOW_MX_TEMPLATE].tabMaintainance[f.value] && state[SHOW_MX_TEMPLATE].tabMaintainance[f.value].loaded) || [];
    return tabArray && filter && tabArray.length === filter.length;
}
export const getAllTabLoadedStatus = createSelector(findAllTabsLoaded, all => all);

const tabLoadStatus = tabName => state => {
    return !state[SHOW_MX_TEMPLATE].tabMaintainance[tabName] ? false : state[SHOW_MX_TEMPLATE].tabMaintainance[tabName].loaded;
}

export const getTabLoadStatus = createSelector(tabLoadStatus, all => all)

export const {
    setMountedStatus,
    loadDataTemplates,
    snackBarActionsShowTemp,
    loadBodySchemaTemplates,
    resetJson,
    setSaveSelectedMxMTResult,
    setConfirmNaviMsg,
    setTabMaintainance,
    setErrorsInTabMaintainance,
    setActiveMsgDefId
} = showMxTemplateSlice.actions

export default showMxTemplateSlice.reducer;