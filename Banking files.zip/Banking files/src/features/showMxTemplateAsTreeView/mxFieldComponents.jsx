import * as React from 'react';
import MbTextField from '../common/mbTextField';
import MbDateMuiField from '../common/mbDateMuiPicker';
import MbRadio from '../common/mbRadio';
import MbDropdown from '../common/mbDropdown';
import { FormHelperText, Grid} from '@mui/material';
import { isEmpty } from 'lodash';
import MbTimePickerMuiField from '../common/mbTimeMuiPicker';
import moment from 'moment';
import dayjs from 'dayjs';
import { DATE_FORMAT, DATE_FORMAT_PICKER, DATE_TIME_FORMAT, 
  FONT_SIZE, TIME_FORMAT, trueFalseIndicator, yornIndicaterWithTrueFalse, yornIndicator } from '../../constants/constants';
import { useDispatch, useSelector } from 'react-redux';
import { getPaymentActualData } from './templateHelpers';
import { getBodyJson, snackBarActionsShowTemp } from './showMxTempSlice';
import MbDateTimeMuiField from '../common/mbDateTimeMuiPicker';
import { isMobileOnly } from 'react-device-detect';
import ChildErrorPage from '../errorPage/childErrorPage';
import { APPHEADER_TAB, BODY_TAB, ERRORCODES, SAAHEADER_TAB } from '../../constants/mxTempConstants';
import { useState, useCallback, useMemo } from 'react';
import { makeStyles } from '@mui/styles';
import MxLongString from './mxLongString';
import MxString from './mxString';
import MxAutoComplete from './mxAutoComplete';
import { getSaaOriFromPersistInputChange, inputChangeSaaHeader } from './saaHeaderSlice';
import { getAppOriFromPersistInputChange, inputChangeApp } from './appHeaderSlice';
import { getBodyOriFromPersistInputChange, inputChangeBody } from './bodySlice';

const useStyles = makeStyles(() => ({
  inputRoot : {
    '& .MuiInputBase-root': {
      height: '20px', // Adjust the height as needed
    },
  },
  dateFieldRoot : {
    '& .MuiInputBase-root': {
      height: '20px', // Adjust the height as needed
    },
    width: '100%'
  },
  dropdownRoot: {
    // height: '25px', // Adjust the max height as needed,
    height: '31px', // Adjust the max height as needed,
    textAlign: 'left'
  },
  autoCompleteRoot: {
    height: '20px',
    padding: '0px',
    display: 'flex'
  },
  radioRoot: {
    height: '20px',
    display: 'flex',
    alignContent: 'center',
  },
  inputStyle : {
    fontSize : FONT_SIZE
  }
}));

const MxFieldComponents = React.memo(({fieldProps}) => {
    const {elementType, labelText, 
      restrictions,tabName,parentDetails, hasChildren, isManualProperty,
      elementHierName, options, simpleContent,
      currencyCodeDetails, nodeId, disabled = false, ...others} = fieldProps;
    const resultBodyDataJson = useSelector(getBodyJson(tabName));
    const dispatch = useDispatch();
    const classes = useStyles();

    const valueData = !hasChildren ? getPaymentActualData(resultBodyDataJson, parentDetails) : '';
    const {_text: labelInfo = '', _attributes: attributeData = '', error = {}} = valueData || '';

    const getHelperText = useCallback ((labelText, error, restrictions, isShortNote = false) => {
       const { Example, minLength, length } = restrictions || {};
        switch(error._text) {
          case ERRORCODES['regexIssue'] : return `${labelText} is not matched with valid pattern. ${Example ? `Ex: ${Example}` : ''}`
          case ERRORCODES['regexCatch'] : return 'Pattern is not valid format' 
          case ERRORCODES['minLength'] : return  `Minimum length should be ${minLength}`
          case ERRORCODES['mandatory'] : return  `${labelText} is Required`
          case ERRORCODES['mandatory_min'] : return 'Mandatory & Minimum length should be 1'
          case ERRORCODES['accNameValid'] : return 'Support Alphanumeric and @, Single Space, '
          case ERRORCODES['invalidCountry']: return 'Invalid Country'
          case ERRORCODES['totalDigits']: return `${labelText} does not meet the total digits limitation`
          case ERRORCODES['fractionDights']: return `${labelText} does not meet the fraction limitation`
          case ERRORCODES['minInclusive']: return `${labelText} should be greater then minimum inclusive`
          case ERRORCODES['maxInclusive']: return `${labelText} should be less then maximum inclusive`
          case ERRORCODES['invalidDate'] : return `${labelText} - Invalid Date Format`
          case ERRORCODES['mustBe'] : return `${labelText} length must be ${length}`
          default: return error._text;
        }
    }, [])

    const getCurrencyHelperText = useCallback((error) => {
      switch(error._attributes) {
        case ERRORCODES['mandatory'] : return  `Amount/Currency is Required`
        case ERRORCODES['attriCurFormat']: return 'Currency Format is required'
        case ERRORCODES['attriInvalidCur']: return 'Invalid Currency'
        default: return error._attributes;
      }
    }, []);

    const uploadFieldChanges = useCallback((inputValue, inputFormat = '_text', 
        fieldForAddiValidation = undefined, validationIssue = false, valueDataFrom = {}) => {
      if(disabled) return;
      try {
        switch(tabName){
          case SAAHEADER_TAB : {
            dispatch(getSaaOriFromPersistInputChange({inputValue, inputFormat, fieldForAddiValidation, 
            parentDetails, restrictions, isManualProperty,tabName, validationIssue, elementHierName, valueData: valueDataFrom ,...others}));
            return;
          }
          case APPHEADER_TAB : {
            dispatch(getAppOriFromPersistInputChange({inputValue, inputFormat, fieldForAddiValidation, 
            parentDetails, restrictions, isManualProperty,tabName, validationIssue, elementHierName, valueData: valueDataFrom ,...others}));
            return;
          }
          case BODY_TAB : {
            dispatch(getBodyOriFromPersistInputChange({inputValue, inputFormat, fieldForAddiValidation, 
            parentDetails, restrictions, isManualProperty,tabName, validationIssue, elementHierName, valueData: valueDataFrom ,...others}));
            return;
          }
          default: return;
        }
      }
      catch (err) {
        dispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: 'Input Change/Choice Selection Failed' }));
      }
    }, [tabName])

    const onTreeItemFieldChange = useCallback((e) => {
      uploadFieldChanges(e.target.value)
    }, [tabName]);

    const onDateFieldChange = useCallback(dateValue => {
      let dValue = '';
      if(dateValue) dValue = moment(dayjs(dateValue).toDate()).format(DATE_FORMAT_PICKER)
      uploadFieldChanges(dValue)
    }, [tabName]);

    const onDateTimeChange = useCallback(dateTimeValue => {
      // const dtValue = moment(dayjs(dateTimeValue).toDate()).format(DATE_TIME_FORMAT_PICKER); //This format is necessary for dayjs's conversion
      let dtValue = '';
      if(dateTimeValue) {
        const zoneValue = moment(dayjs(dateTimeValue).toDate()).local(); // moment.utc(dayjs(dateTimeValue).toDate()).tz(getZone);
        dtValue = zoneValue.format();
      }
      uploadFieldChanges(dtValue);
    }, [tabName]);

    const onTimeChange = useCallback(timeValue => {
      let tValue = '';
      if(timeValue) tValue = moment(dayjs(timeValue).toDate()).format(TIME_FORMAT)
      uploadFieldChanges(tValue)
    }, [tabName])

    const onYearChange = useCallback(yearValue => {
        let yValue = '';
        if(yearValue) yValue = moment(dayjs(yearValue).toDate()).format('YYYY')
        uploadFieldChanges(yValue)   
    }, [tabName]);
  
    const noErrorStatus = useMemo(() => {
      return !isEmpty(error) && error._text !== ERRORCODES['noErrors'];
    }, [error]);

    const attributeErrorStatus = useMemo(() => {
      return !isEmpty(error) && error._attributes && error._attributes !== 1;
    }, [error]);

    const radioList = useMemo(() => {
      switch(elementHierName){
        case 'TrueFalseIndicator' : return trueFalseIndicator;
        case 'SwBoolean' : return yornIndicaterWithTrueFalse;
        default : return yornIndicator
      }
    }, [elementHierName])
    
    const renderFields = useCallback(() => {
      try {
        switch(elementType) {
          case 'longString':
            return (
              <MxLongString restrictions={restrictions} onTreeItemFieldChange = {onTreeItemFieldChange} disabled = {disabled}
              labelInfo={labelInfo} labelText={labelText} inputStyle={classes.inputStyle} noErrorStatus={noErrorStatus}/>
            )   
          case 'string':
            return (
              <MxString restrictions={restrictions} onTreeItemFieldChange = {onTreeItemFieldChange} disabled = {disabled}
              labelInfo={labelInfo} labelText={labelText} inputStyle={classes.inputStyle} noErrorStatus={noErrorStatus} 
              inputRoot={classes.inputRoot} elementHierName = {elementHierName} uploadFieldChanges={uploadFieldChanges} tabName={tabName}/>
            )
          case 'date':
            return (
              <MbDateMuiField onDateChange = {onDateFieldChange} clsDateStyles  = {classes.inputRoot}
              labelInfo= {labelInfo} labelText = {labelText} views={['year', 'month', 'day']} format = {DATE_FORMAT}
              readOnly= {disabled} size = {'small'} isLabelShrinkNotReq = {true} inputStyle = {classes.inputStyle}
              error = {noErrorStatus}
              />
            )
          case 'dateTime':
            return (
              <MbDateTimeMuiField onDateChange = {onDateTimeChange} clsDateTimeStyle = {classes.inputRoot}
              labelInfo= {labelInfo} labelText = {labelText} format = {DATE_TIME_FORMAT} readOnly = {disabled} 
              size= {'small'} isLabelShrinkNotReq = {true} inputStyle = {classes.inputStyle}
              view = {['year', 'month', 'day', 'hours', 'minutes', 'seconds']}
              error = {noErrorStatus}/>
            )
          case 'decimal':
            return (
              <MbTextField sx={{width: '100%'}} type="number" label = {labelText} value = {labelInfo} 
                onTextFieldChange={onTreeItemFieldChange} className = {classes.inputRoot}
                error = {noErrorStatus}
                // helperText = {getDecimalHelperText(labelText, error, restrictions, false)}
                readOnly = {disabled} isLabelShrinkNotReq = {true} size = {'small'} inputStyle={classes.inputStyle}
              />
            )
          case 'int': 
            return (
              <MbTextField sx = {{width: '100%'}} type="number" label={labelText} value= {labelInfo}
                onTextFieldChange={onTreeItemFieldChange} className = {classes.inputRoot}
                error = {noErrorStatus}  readOnly = {disabled} isLabelShrinkNotReq = {true}
                size = {'small'} inputStyle={classes.inputStyle}/>
            )
          case 'boolean':
            return (
              <MbRadio radioList={radioList} 
                radioGrpStyles={classes.radioRoot}
                label = { isMobileOnly && labelText } readOnly= {disabled} radioValue = {labelInfo}
                onRadioChange={onTreeItemFieldChange} size={"small"} inputStyle = {classes.inputStyle} />
            )
          case 'dropdown':
            return (
              <MbDropdown labelName={labelText} labelValue={labelInfo} dropdownList={options || []} fullWidth={true} 
                onDropdownChange={onTreeItemFieldChange} error = {noErrorStatus} variant = {'outlined'}
                readOnly = {disabled}  size = {'small'} isLabelShrinkNotReq = {true} sxSelectStyles={classes.dropdownRoot}
                />
            )
          case 'autocomplete':
            return (
              <MxAutoComplete simpleContent={simpleContent}
              currencyCodeDetails= {currencyCodeDetails} labelInfo= {labelInfo} inputRoot = {classes.inputRoot} inputStyle = {classes.inputStyle}
              disabled = {disabled} attributeData ={attributeData} tabName = {tabName} noErrorStatus={noErrorStatus}
              attributeErrorStatus = {attributeErrorStatus} nodeId = {nodeId} parentDetails = {parentDetails} uploadFieldChanges={uploadFieldChanges}
              valueData = {valueData} isLabelShrinkNotReq = {true}
              />
            )
          case 'time':
            return (
              <MbTimePickerMuiField onTimeChange = {onTimeChange} 
              labelText={labelText} labelInfo= {labelInfo} format = {TIME_FORMAT} 
              readOnly={disabled} size= {'small'} isLabelShrinkNotReq = {true} inputStyle= {classes.inputStyle}
              error = {noErrorStatus} />
            )
          case 'gYear':
            return (
              <MbDateMuiField onDateChange = {onYearChange} clsDateStyles = {classes.dateFieldRoot}
              labelText={labelText} labelInfo = {labelInfo} views={['year']} format = {"YYYY"} 
              readOnly = {disabled} isLabelShrinkNotReq = {true} inputStyle= {classes.inputStyle}
              error = {noErrorStatus} />
            )
          default:
            return null;
        }
      }
      catch(err) {
        console.error(err);
        return <ChildErrorPage subTitle = {"common.wentWrong"}/>
      }
    }, [elementType,tabName, valueData]);

    return (
      <Grid item sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-start',
        width: isMobileOnly ? '100%' : '60%',
        maxWidth: '100%',
        my: '1px',
      }}>
        <Grid sx={{width: '100%', flexDirection: 'row', display: 'flex'}}>
          <Grid sx = {{width: '50%', display: 'flex'}}>
            {renderFields()}
          </Grid>
          {
            noErrorStatus && 
              <FormHelperText sx= {{marginLeft: '10px', color: 'red', fontSize: '10px', alignContent: 'center'}}>
                {getHelperText(labelText, error, restrictions)}
              </FormHelperText>
          }
          {
            attributeErrorStatus && 
            <FormHelperText sx= {{marginLeft: '10px', color: 'red', fontSize: '10px', alignContent: 'center'}}>
              {getCurrencyHelperText(error)}
            </FormHelperText>
          }
        </Grid>
      </Grid>
    )
})

export default MxFieldComponents;