import React, {memo} from 'react'
import MbTextField from '../common/mbTextField';
import { Grid, Typography } from '@mui/material';
import { allotRows } from './validationHelpers';

const MxLongString = ({ restrictions, onTreeItemFieldChange, labelInfo, labelText, disabled, inputStyle, noErrorStatus }) => { 
    const { maxLength, length } = restrictions || {};
    const mLength = maxLength || length;  
    if(restrictions && mLength){
        return (
          <Grid sx={{display: 'flex', width: '100%', flexDirection: 'column'}}>
            <Typography component={"span"} variant='h5' sx={{display: 'flex', fontSize: '5px', fontWeight: 'bold', direction: 'rtl'}}>
              {`${labelInfo ? labelInfo.length : 0}/${mLength}`}
            </Typography>
            <MbTextField multiline = {true} rows = {allotRows(mLength)} sx = {{width: '100%'}} 
              label = {`${labelText}`} value= {labelInfo} inputStyle = {inputStyle}
              maxLength={mLength} error = {noErrorStatus}
              // helperText = {getStringHelperText(labelText, error, restrictions)}   
              onTextFieldChange={onTreeItemFieldChange} readOnly = {disabled}
              isLabelShrinkNotReq = {true}
              // onTextFieldFocus = {e => onTextFocus(e)}
              // onTextBlur={e => onTextBlur(e)}
              />
          </Grid>
        )
      } else {
        return (
          <MbTextField multiline = {true} rows = {allotRows(mLength)} sx = {{width: '100%'}} 
            label = {`${labelText}: Max - ${mLength} Chars`} value= {labelInfo} 
            maxLength={mLength} error = {noErrorStatus}
            // helperText = {getStringHelperText(labelText, error, restrictions)}
            onTextFieldChange={onTreeItemFieldChange} readOnly = {disabled}
            isLabelShrinkNotReq = {true} inputStyle = {inputStyle}/>                
        ) 
      }
};

export default memo(MxLongString);