import { memo, useEffect, useMemo, useRef } from "react"
import ChildTabs from "./childTabs";
import { isEmpty } from "lodash";
import { shallowEqual, useDispatch, useSelector } from "react-redux";
import { getHierSchemaSaaHeader, getTreeExpandSaaHeader } from "./saaHeaderSlice";
import { SAAHEADER_TAB } from "../../constants/mxTempConstants";
import { setTabMaintainance, snackBarActionsShowTemp } from "./showMxTempSlice";

const SAAHeaderTab = ({ treeHeights, tabItem, tabValue, key, reMounted }) => {
    const hierSchemaJson = useSelector(getHierSchemaSaaHeader, shallowEqual);
    const treeItemExpandedList = useSelector(getTreeExpandSaaHeader, shallowEqual);
    const dispatch = useDispatch();
    const saaWorkerRef = useRef(null);

    useEffect(() => {
        // cleanup previous worker instance if it exists
        if (saaWorkerRef.current) {
            saaWorkerRef.current.terminate();
            saaWorkerRef.current = null;
        }
        // Create new worker instance
        const saaWorker = new Worker(new URL('tabWorker.js', import.meta.url));
        saaWorkerRef.current = saaWorker;
        // Post initial messae to the worker
        saaWorker.postMessage({ tabKey: SAAHEADER_TAB, payload: 'dataForSaaHeader' });
        // Handle worker's response
        saaWorker.onmessage = e => {
            //Dispatch result to Redux store
            dispatch(setTabMaintainance({ tabName: [SAAHEADER_TAB], data: { loaded: true } }));
        }

        saaWorker.onerror = err => {
            dispatch(snackBarActionsShowTemp({ open: true, severity: 'error', snackBarMessage: err.message }));
        }
        // Cleanup on component unmount or remount
        return () => {
            if (saaWorkerRef.current) {
                saaWorkerRef.current.terminate();
                saaWorkerRef.current = null;
            }
        }
    }, [reMounted, dispatch])

    const MemoizeChildTab = useMemo(() => {
        return (
            <ChildTabs tabValue={tabValue}
                tabItem={tabItem}
                key={key} treeHeights={treeHeights}
                hierSchemaJson={hierSchemaJson} treeItemExpandedList={treeItemExpandedList}
            />
        )
    }, [treeHeights, hierSchemaJson, treeItemExpandedList, tabValue]);

    if (isEmpty(hierSchemaJson)) return <></>;
    return (
        <div
            role="tabpanel"
            hidden={!(tabValue === tabItem.value)}
            id={`full-width-tabpanel-saa`}
            aria-labelledby={`full-width-tab-saa`}
        >
            {
                MemoizeChildTab
            }
        </div>
    )
}
export default memo(SAAHeaderTab);