import React, { memo } from "react";
import { FormattedMessage } from "react-intl";
import { isMobileOnly } from "react-device-detect";
import { Divider, Grid, Popover, Typography } from "@mui/material";

const DescriptionPopover = ({ id, popOverEle,
    handleDescriptionPopoverClose, title, description, restrictions, openPopover, parentDets, elementType }) => {

    return (
        <Popover
            id={id}
            key={`key_${id}`}
            sx={{
                pointerEvents: 'none',
                width: isMobileOnly ? '100%' : '50%',
                // overflow: 'auto'
            }}
            open={openPopover}
            anchorEl={popOverEle || null}
            anchorOrigin={{
                vertical: 'center',
                horizontal: 'center',
            }}
            transformOrigin={{
                vertical: 'center',
                horizontal: 'right',
            }}
            onClose={handleDescriptionPopoverClose}
            disableRestoreFocus>
            <Grid item sx={{ padding: 1, border: '0.5px solid #000000', fontWeight: 'bold' }}>
                <Typography variant="h6">{title}</Typography>
                <Divider />
                {
                    elementType && (
                        <Typography variant="subtitle1" sx={{ mb: '0.5px' }}>
                            <span style={{ fontWeight: 'bold' }}>
                                <FormattedMessage id="mxTemplates.fieldType" />
                            </span>
                            <span>:</span>
                            <span style={{ textTransform: "capitalize" }}>{elementType}</span>
                        </Typography>
                    )
                }
                {
                    description && (
                        <>
                            <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: '0.5px' }}>
                                <FormattedMessage id="mxTemplates.description" />
                            </Typography>
                            <Typography variant="body2" sx={{ mb: '0.5px' }}>{description}</Typography>
                        </>
                    )
                }
                {
                    restrictions && (
                        <>
                            <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: '0.5px' }}>
                                <FormattedMessage id="mxTemplates.restrictions" />
                            </Typography>
                            {
                                Object.keys(restrictions).map((resItem, key) => {
                                    return (
                                        <React.Fragment key={key}>
                                            <Typography variant="body2"><span>{resItem}</span> <span>:</span> <span>{restrictions[resItem] || ''}</span></Typography>
                                            {/* {
                                                resItem === 'pattern' 
                                                && <Typography variant="body2">
                                                    <span>{resItem.patternDescription || ''}</span>
                                                   </Typography>
                                            } */}
                                        </React.Fragment>
                                    )
                                })
                            }
                        </>
                    )
                }
                {
                    parentDets && parentDets.length > 0 &&
                    <>
                        <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: '0.5px' }}>
                            <FormattedMessage id="mxTemplates.xpath" />
                        </Typography>
                        <Typography variant="body2" sx={{ mb: '0.5px' }}>
                            {parentDets.join('->')}
                        </Typography>
                    </>
                }
            </Grid>
        </Popover>
    )
}
export default memo(DescriptionPopover)