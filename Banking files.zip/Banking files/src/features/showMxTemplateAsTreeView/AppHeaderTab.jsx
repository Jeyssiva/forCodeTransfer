import { memo, useEffect, useMemo, useRef } from "react"
import ChildTabs from "./childTabs";
import { useDispatch, useSelector, shallowEqual } from "react-redux";
import { setTabMaintainance, snackBarActionsShowTemp } from "./showMxTempSlice";
import { isEmpty } from "lodash";
import { APPHEADER_TAB } from "../../constants/mxTempConstants";
import { getHierSchemaAppHeader, getTreeExpandAppHeader } from "./appHeaderSlice";

const AppHeaderTab = ({treeHeights, tabItem, tabValue, key, reMounted}) => {
    const hierSchemaJson = useSelector(getHierSchemaAppHeader, shallowEqual);
    const treeItemExpandedList = useSelector(getTreeExpandAppHeader, shallowEqual);
    const dispatch = useDispatch();
    const appWorkerRef = useRef(null);

    useEffect(() => {
        // cleanup previous worker instance if it exists
        if(appWorkerRef.current) {
            appWorkerRef.current.terminate();
            appWorkerRef.current = null;
        }
        // Create new worker instance
        const appWorker = new Worker(new URL ('tabWorker.js', import.meta.url));
        appWorkerRef.current = appWorker;
        // Post initial messae to the worker
        appWorker.postMessage({tabKey: APPHEADER_TAB, payload: 'dataForApp'});
        // Handle worker's response
        appWorker.onmessage = e => {
            //Dispatch result to Redux store
            dispatch(setTabMaintainance({tabName: [APPHEADER_TAB], data : {loaded: true}}));
        }
        appWorker.onerror = err => {
            dispatch(snackBarActionsShowTemp({open: true, severity: 'error', snackBarMessage: err.message}));
        }
        // Cleanup on component unmount or remount
        return () => {
            if(appWorkerRef.current) {
                appWorkerRef.current.terminate();
                appWorkerRef.current = null;
            }
        }
      }, [reMounted, dispatch]);

    const MemoizeChildTab = useMemo(() => {
        return (
            <ChildTabs tabValue = {tabValue}
                tabItem = {tabItem}
                key = {key} treeHeights = {treeHeights}
                hierSchemaJson = {hierSchemaJson} treeItemExpandedList = {treeItemExpandedList}
            />
        )
    }, [treeHeights, hierSchemaJson, treeItemExpandedList, tabValue])
    // if(!data) return <div>{'Loading....'}</div>
    // if(isEmpty(hierSchemaJson) || !loadAppHeader) return null;

    if(isEmpty(hierSchemaJson)) return null;
    return (
        <div
            role="tabpanel"
            hidden={!(tabValue === tabItem.value)}
            id={`full-width-tabpanel-appHead`}
            aria-labelledby={`full-width-tab-$appHead`}
        >
        {
            MemoizeChildTab
        }
        </div>
    )
}
export default memo(AppHeaderTab);