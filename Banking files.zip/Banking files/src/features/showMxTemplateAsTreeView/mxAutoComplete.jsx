import { memo, useCallback, useState } from "react"
import MbTextField from "../common/mbTextField";
import { Grid, IconButton } from "@mui/material";
import DescriptionPopover from "./descriptionPopover";
import MbAutocomplete from "../common/mbAutocomplete";
import { FormattedMessage } from "react-intl";
import { Description } from "@mui/icons-material";
import { useSelector } from "react-redux";
import { isMobileOnly } from "react-device-detect";
import { getCurrencyListPersist } from "./persistedSlice";

const MxAutoComplete = ({simpleContent, currencyCodeDetails, labelInfo, inputRoot,  inputStyle, disabled, 
        attributeData, noErrorStatus, attributeErrorStatus, nodeId, parentDetails, uploadFieldChanges, isLabelShrinkNotReq,
        valueData, tabName
        }) => {
    const ISOCurrencyList = useSelector(getCurrencyListPersist);
    const [curDescPop, setCurDescPop] = useState(null);
    const openCurDescPop = Boolean(curDescPop);
    let name = (simpleContent && simpleContent.attributes.name) || 'content';

    const onHandleCurDesPopStatus = useCallback((status) => {
        setCurDescPop(status);
    },[]);

    const onHandleCurPopLeave = useCallback(() => {
      setCurDescPop(null);
    }, [])

    const onAutocompleteSelectionChange = useCallback((e, obj) => {
      if(disabled) return
      onAutoCompleteValidation(((obj && obj !== null) || e.target.value)
      && {[name]: (obj && obj !== null && obj.description) || e.target.value})
    },[tabName, valueData])

    const onAutoCompleteInputChange = useCallback((eValue) => {
      if(disabled || eValue === 0) return;
      onAutoCompleteValidation(eValue && {[name]: eValue});
    }, [tabName, valueData]);

    const onAutoCompleteValidation = useCallback((inputValue) => {
      let validationIssue = false;
      let iValue = {...inputValue};
      if(inputValue){
          const findCur = ISOCurrencyList.find(c => c.description === inputValue[name]);
          if(!findCur) validationIssue = true;
          else iValue = {[name] : findCur.code};
      }
      uploadFieldChanges(iValue, '_attributes', "_text" , validationIssue, valueData)
    },[tabName, valueData])

    const onTextFieldAutoChange = useCallback(e => {
      let validationIssue = false;
      // Check whether currency is valid or not while enter amount 
      if(valueData && valueData._attributes && valueData._attributes[name]){
        validationIssue = !ISOCurrencyList.some(c => 
          c.code === valueData._attributes[name] || 
          c.description === valueData._attributes[name]);
      }
      uploadFieldChanges(e.target.value, "_text", "_attributes" , validationIssue, valueData)
    }, [tabName, valueData]);

    if(!simpleContent || simpleContent.text !== 'Currency') return null;
    let findCurrency = ""
    if(attributeData) {
      findCurrency = ISOCurrencyList.find(c => c.code ===  attributeData[name]) || {};
    }
    const {name: curCodeName, desc: curDesc, elementType: curElementType, restrictions : curRestrictions } = currencyCodeDetails

    return (
      <Grid sx={{display: 'flex', flexDirection : 'row', width: '100%'}}>
        <MbTextField sx={{width: '35%', marginRight: '1px', marginTop: '5px'}} className = {inputRoot}  value = {labelInfo} 
          onTextFieldChange={onTextFieldAutoChange}
          type = "number" error = {noErrorStatus} 
          label = {<FormattedMessage id="mxTemplates.amount"/>}
          readOnly = {disabled} size = {'small'} isLabelShrinkNotReq = {true} inputStyle={inputStyle}
          // helperText = {getDecimalHelperText(labelText, error, restrictions, true)}
        />
        <IconButton sx={{padding: 0, ml: isMobileOnly ? '1px' : 1, marginLeft: '0px'}}
          aria-haspopup="true" aria-owns={openCurDescPop ? `mouseOverCurrencyDescPopOver_${nodeId}`: undefined}
          onMouseEnter={onHandleCurDesPopStatus} onMouseLeave={onHandleCurPopLeave} size="small">
            <Description sx={{ width: '16px' }}/>
        </IconButton>
        {
          openCurDescPop &&
            <DescriptionPopover id = {`mouseOverCurrencyDescPopOver_${nodeId}`}
              handleDescriptionPopoverClose={onHandleCurPopLeave} title = {curCodeName}
              openPopover={openCurDescPop} popOverEle={curDescPop} description={curDesc}
              restrictions={curRestrictions} parentDets = {parentDetails} elementType={curElementType}/>
        }
        <MbAutocomplete options = {ISOCurrencyList} optionLabel="description" optionValue="code" 
          labelText = { findCurrency && findCurrency.code }
          // <FormattedMessage id = "mxTemplates.currencyformat" defaultMessage={defaultLocales["mxTemplates.currencyformat"]} />
          size="small" fullWidth = {false} 
          onAutocompleteSelectionChange={onAutocompleteSelectionChange}
          onAutoCompleteInputChange={onAutoCompleteInputChange}
          sxInputRootStyles={inputRoot}
          value={findCurrency} inputValue={(findCurrency && findCurrency.description) || (attributeData && attributeData[name])}
          sx={{width: '65%', marginTop: '5px'}}
          error = {attributeErrorStatus} 
          // helperText={getCurrencyHelperText(labelText, error)}
          readOnly = {disabled} inputStyle= {inputStyle} isLabelShrinkNotReq={isLabelShrinkNotReq}/>
      </Grid>        
    )

}

export default memo(MxAutoComplete)