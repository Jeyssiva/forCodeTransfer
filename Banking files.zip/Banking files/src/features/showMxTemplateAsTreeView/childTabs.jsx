import React, { memo } from "react";
import { Box } from "@mui/material";
import { useDispatch } from "react-redux";
import { TreeView } from "@mui/x-tree-view";

import CustomTreeItem from "./customTreeItem";
import { treeExpandedListBody } from "./bodySlice";
import { treeExpandedListSaa } from "./saaHeaderSlice";
import { treeExpandedListApp } from "./appHeaderSlice";
import ChildErrorPage from "../errorPage/childErrorPage";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { APPHEADER_TAB, BODY_TAB, SAAHEADER_TAB } from "../../constants/mxTempConstants";

const ChildTabs = (props) => {
  const { tabValue, tabItem, treeItemExpandedList, hierSchemaJson } = props;
  const dispatch = useDispatch();

  const renderTreeItem = (processingData, nodeName) => {
    const childArray = processingData[nodeName];
    const { shortTitle, children, longTitle, nodeLevel,
      type: elementHierName, ...childOthers } = childArray;
    const { isChoiceChildHidden } = childOthers;
    const hasChildren = children ? true : false;

    if (isChoiceChildHidden) return null;

    return (
      <Box
        sx={hasChildren ? {
          // boxShadow: 1,
          borderRadius: 0.5,
          px: 0.5, // Box Padding
          py: 0.2,
          border : '#e3e3e3 solid 2px'
        } : {}}
        key={`TreeBox_${shortTitle}`}
      >
        <CustomTreeItem
          key={shortTitle}
          nodeId={nodeLevel}
          labeltext={longTitle}
          hasChildren={hasChildren}
          elementHierName={elementHierName}
          shortTitle={shortTitle}
          tabName={tabValue}
          {...childOthers}
        >
          {
            (childOthers.hideChildForRequired !== true)
            && hasChildren
            && Object.keys(children).map((key, index) => {
              return renderTreeItem(children, key)
            })
          }
        </CustomTreeItem>
      </Box>
    )
  };
  
  const onHandleNodeExpand = (e, nodes) => {
    switch(tabValue){
      case SAAHEADER_TAB : {
        dispatch(treeExpandedListSaa({expandedList: nodes, tabName: tabValue}));
        return;
      }
      case APPHEADER_TAB : {
        dispatch(treeExpandedListApp({expandedList: nodes, tabName: tabValue}));
        return;
      }
      case BODY_TAB : {
        dispatch(treeExpandedListBody({expandedList: nodes, tabName: tabValue}));
        return;
      }
      default: return {}
    }
  };
  try {
    return (
      <div
        role="tabpanel"
        hidden={!(tabValue === tabItem.value)}
        id={`full-width-tabpanel-${0}`}
        aria-labelledby={`full-width-tab-${0}`}
      >
        <TreeView
          aria-label="summary"
          defaultCollapseIcon={<ExpandMoreIcon />}
          defaultExpandIcon={<ChevronRightIcon />}
          defaultEndIcon={<div style={{ width: 24 }} />}
          sx={{ px: 0.5, py: 0.5, flexGrow: 1, maxWidth: '100%'}}
          onNodeToggle={onHandleNodeExpand}
          expanded={(treeItemExpandedList && treeItemExpandedList) || []}
        >
          {
            renderTreeItem(hierSchemaJson, Object.keys(hierSchemaJson)[0])
          }
        </TreeView>
      </div>
    )
  }
  catch (err) {
    console.error(err);
    return <ChildErrorPage subTitle={"common.wentWrong"} />
  }
}
export default memo(ChildTabs);