import { flatten } from 'flat';

export const localizations = {
    'en-US': require('./lang/en-US.json'),
    'ms-MS': require('./lang/ms-MS.json')
}

export const defaultLocale = 'en-US';
export const defaultLocales = flatten(localizations[defaultLocale]);

export const locales = [
    {label: 'English', value: 'en-US', sLabel: 'E'},
    {label: 'Melayu', value:'ms-MS', sLabel: 'M'}
]

export function getLocalizedText(locale, key) {
    return flatten(localizations[locale])[key] || key;
}