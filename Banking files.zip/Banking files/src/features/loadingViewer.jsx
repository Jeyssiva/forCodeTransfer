import * as React from 'react';
import { Grid, IconButton, Typography } from "@mui/material";
import { makeStyles } from '@mui/styles';
import { FadeLoader } from "react-spinners";
import { isEmpty } from 'lodash';

export const useStyles = makeStyles(() => ({
  container: {
    position: 'relative',
    width: '100%',
    height: '100%'
  },
  spinnerContainer: {
    position: 'absolute',
    // top: 0,
    // left: 0,
    width: '100%',
    height: '100%',
    zIndex: 9999
  },
  spinnerOverlay: {
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      backgroundColor: 'rgba(0, 0, 0, 0.3)', /* semi-transparent black */
      zIndex: 9998
  },
  spinnerDialog: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      zIndex: 9999
  }
}))

const LoadingViewer = ({loading, message, sxContainerStyle = {}, sxSpinOverlay = {}, children, loadColor, spinnerDialog = {}}) => {
  const classes = useStyles();
  return (
    <Grid sx= {{...sxContainerStyle}} className={classes.container}>
      <LoadingIndicator loading = {loading} sxSpinOverlay = {sxSpinOverlay} loadColor={loadColor} 
          message={message} spinnerDialog = {spinnerDialog}/>
      {children}
    </Grid>
  )
}

const LoadingIndicator = React.memo(function LoadingIndicator({loading, loadColor = '#000000',
       message = 'Loading...', sxSpinOverlay, spinnerDialog}) {
    const classes = useStyles();
    return (
        <Grid className={classes.spinnerContainer} sx={{ display: loading ? 'block' : 'none' }}>
        <Grid  sx = {{...sxSpinOverlay}} className={classes.spinnerOverlay} />
        <Grid className={!isEmpty(spinnerDialog) ? spinnerDialog : classes.spinnerDialog}>
            <Grid sx={{display: 'flex', flexDirection: 'column'}}>
              <IconButton>
                <FadeLoader
                  color={loadColor}
                  loading={loading}
                  aria-label="Loading Spinner"
                  data-testid="loader"/> 
                </IconButton>
              <Typography variant='body'>{message}</Typography>
            </Grid>           
        </Grid>
      </Grid>
    )
})
export default LoadingViewer;
