import { Container, Typography } from "@mui/material";
import { defaultLocales } from "./features/i18n";
import { FormattedMessage } from "react-intl";

export default function FallbackPage(){

    return (
        <Container sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            minHeight: '100vh'
          }}>
            <Typography sx={{fontWeight: 'bold'}}>
                <FormattedMessage id = 'common.pageLoading' defaultMessage={defaultLocales["common.pageLoading"]}/>
            </Typography>
        </Container>
    )
};