import App from './App';
import store from './store';
import { Provider } from 'react-redux'
import ReactDOM from 'react-dom/client';
// import { persistStore } from 'redux-persist';
// import { PersistGate } from 'redux-persist/integration/react';

const root = ReactDOM.createRoot(document.getElementById('root'));

// const persistor = persistStore(store);

root.render(
    <Provider store={store}>
        {/* <PersistGate persistor={persistor}> */}
            <App />
        {/* </PersistGate> */}
    </Provider>
);

if(!window.location.hostname.includes('mpop'))
// to display the global store in console 
    window.store = store