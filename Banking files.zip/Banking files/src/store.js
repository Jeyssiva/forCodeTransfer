// import storage from 'redux-persist/lib/storage';
import loginReducer from './features/login/loginSlice';
import bankReducer from './features/banklist/bankSlice';
import { configureStore } from '@reduxjs/toolkit';
import mxTemplateReducer from './features/mxTemplates/mxTemplatesSlice';
import dashboardReducer, { dashInitialState } from './features/dashboard/dashboardSlice';
import { FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER } from 'redux-persist';
import createpaymentReducer, { paymentInitialState } from './features/createPayment/paymentSlice';
import customerReducer, { customerInitialState } from './features/customerPaymentData/customerDataSlice';
import showMxTempReducer, { showMxInitialState } from './features/showMxTemplateAsTreeView/showMxTempSlice';
import viewTransactionReducer, { viewTransInitialState } from './features/viewTransactions/viewTransactionSlice';
import saaHeaderReducer, { saaInitialState } from './features/showMxTemplateAsTreeView/saaHeaderSlice';
import appHeaderReducer, { appInitialState } from './features/showMxTemplateAsTreeView/appHeaderSlice';
import bodyReduer, { bodyInitialState } from './features/showMxTemplateAsTreeView/bodySlice';
import savedTemplatesReducer, { templatesInitialState } from './features/createPayment/savedTemplates/templatesSlice';
import persistedDataReducer, { persistInitialState } from './features/showMxTemplateAsTreeView/persistedSlice';
// import createIndexedDBStorage from 'redux-persist-indexeddb-storage';

// // Expiration logic for user data
// const expireTransformer = {
//   in: (inboundState, key) => {
//     const stateWithTimestamp = inboundState;

//     // Check if the fetchedTimestamp is older than 24 hours (1 day)
//     if (stateWithTimestamp?.lastFetchedTimestamp) {
//       const lastFetched = stateWithTimestamp.lastFetchedTimestamp;
//       if (Date.now() - lastFetched > 2 * 60 * 1000) { // 24 * 60 * 60 * 1000
//         // If older than 1 day, clear the state (return undefined)
//         return undefined;
//       }
//     }

//     return stateWithTimestamp;
//   },
//   out: (outboundState, key) => outboundState,
// };

// Create IndexedDB storage
// const indexedDBStorage = createIndexedDBStorage('mpopDB') // 'mpopDB' is the IndexedDB database name

// const persistConfig = {
//   key: 'root',
//   whitelist : []
//   // storage: indexedDBStorage,
//   // whitelist: ['persistedData']
//   // transforms : [expireTransformer]
// };

const rootReducer = (state, action) => {
  if (action.type === 'auth/logout') {
    return {
      login: state.login,
      dashboard: dashInitialState,
      bankmaintainance: undefined,
      mxtemplates: undefined,
      viewtransactions: viewTransInitialState,
      showMxTemplate: showMxInitialState,
      createcustomer: customerInitialState,
      createpayment: paymentInitialState,
      saaheader: saaInitialState,
      appheader: appInitialState,
      bodytab: bodyInitialState,
      savedtemplates: templatesInitialState,
      persistedData : persistInitialState
    }
  }
  // Return the original state if not handling logout
  return {
    login: loginReducer(state?.login, action),
    dashboard: dashboardReducer(state?.dashboard, action),
    bankmaintainance: bankReducer(state?.bankmaintainance, action),
    mxtemplates: mxTemplateReducer(state?.mxtemplates, action),
    viewtransactions: viewTransactionReducer(state?.viewtransactions, action),
    showMxTemplate: showMxTempReducer(state?.showMxTemplate, action),
    createcustomer: customerReducer(state?.createcustomer, action),
    createpayment: createpaymentReducer(state?.createpayment, action),
    saaheader: saaHeaderReducer(state?.saaheader, action),
    appheader: appHeaderReducer(state?.appheader, action),
    bodytab: bodyReduer(state?.bodytab, action),
    savedtemplates: savedTemplatesReducer(state?.savedtemplates, action),
    persistedData: persistedDataReducer(state?.persistedData, action)
  }
}

// const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    immutableCheck: { warnAfter: 150 },
    serializableCheck: {
      warnAfter: 150,
      ignoreActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER]
    }
  })
});

export default store;