import moment from "moment";
import { sessionItems } from "../constants/constants";
import ApacheEnvConfig from "../apacheEnvConfig";
// import { sessionClear } from "../features/dashboard/helpers";
// import { navigation } from "../navigationContext";
// // import { history } from "../features/history";
// const navigate = navigation()

const SERVER_ISO_URL = (window.location.hostname.includes('localhost')) 
                        ? `${process.env.REACT_APP_ISO_URL}` 
                        : `${window.location.protocol}//${window.location.host}`

const { apiTimeout, authAPITimeout } = ApacheEnvConfig.getApacheConfig();
let TIMEOUT = apiTimeout ;
let AUTH_TIMEOUT = authAPITimeout;

// Rewrite the env settings from apache configuration
export const rewriteEnvSettings = (headerObj) => {
    const { apiTimeout, authAPITimeout } = headerObj;
    TIMEOUT = apiTimeout;
    AUTH_TIMEOUT = authAPITimeout;
}

// const getLocalIPAddress = () => {
//     const peer = new RTCPeerConnection({ iceServers: [] });
//     peer.createDataChannel('');
//     peer.createOffer().then(offer => peer.setLocalDescription(offer));
//     peer.onicecandidate = (event) => {
//         if (event.candidate) {
//             const ip = event.candidate.candidate.split(' ')[4];
//             peer.close();
//             return ip;
//         }
//     };
//     return '';
// }

// const ipv4Address = getLocalIPAddress();
// console.log(ipv4Address);

// MOMENT_CUR_TIMEZONE
const RequestHeaders = {
    transactionRefNo: moment().format('YYYYMMDDHHmmss'),
    sourceChannel: "ISOADM",
    sourceId: "MAINT",
    sourceCountry: sessionStorage.getItem(sessionItems.CountryCode),
    destinationCountry: "",
    transactionDate: moment().format('YYYYMMDD'),
    transactionTime: moment().format('HHmmss'),
    transactionType: "",
    transactionSubType: "",
    requestedHost: "ADMIN",
    requestor: sessionStorage.getItem(sessionItems.Username)
}

// const auth = async (url, data) => {
//     const controller = new AbortController();
//     const authSignal = controller.signal;
//     const authTimeout = setTimeout(() => {
//         controller.abort();
//         clearTimeout(authTimeout);
//     }, TIMEOUT);
//     const responseAuth = 
//     await fetch(`${SERVER_ISO_URL}${url}`, {
//         method: "POST",
//         body : JSON.stringify(data),
//         headers: {
//             "Content-Type": "application/json",
//             "Access-Control-Allow-Headers": "Content-Type",
//             "Access-Control-Allow-Origin": "*"
//         },
//         signal: authSignal // Pass the signal to the fetch options for call outside catch block
//     })
//     clearTimeout(authTimeout);
//     return responseAuth;
//     // const {status} = responseAuth;
//     // // If not authenticated, then back to login page.
//     // if(status === 401 || status === 502) {
//     //     window.location.href = `/${ERROR_NAME}/${status}`;
//     // } else { 
//     //     return responseAuth;
//     // }
// }

const auth = async (url, data) => {
    try {
        const controller = new AbortController();
        const authSignal = controller.signal;
        const timeoutPromise = new Promise((_, reject) => {
            const authPost = setTimeout(() => {
                controller.abort();
                clearTimeout(authPost);
                reject(new Error('API response timeout'));
            }, AUTH_TIMEOUT)
        });
        const responseAuth = await Promise.race([
            fetch(`${SERVER_ISO_URL}${url}`, {
                method: "POST",
                body : JSON.stringify(data),
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Origin": "*"
                },
                signal: authSignal // Pass the signal to the fetch options for call outside catch block
            }),
            timeoutPromise
        ]);
        return responseAuth;
    }
    catch(err) {
        // console.log('Error', err);
        throw err;
    }
}
const loggedinUserProcess = async (url, data) => {
    try {
        const uamToken = sessionStorage.getItem(sessionItems.UAMToken) === 'undefined' 
            ? undefined 
            : sessionStorage.getItem(sessionItems.UAMToken);
        const isoToken = `Bearer ${sessionStorage.getItem(sessionItems.ISOToken)}`;
        const controller = new AbortController();
        const logSignal = controller.signal;
        const timeoutPromise = new Promise((_, reject) => {
            const authPost = setTimeout(() => {
                controller.abort();
                clearTimeout(authPost);
                reject(new Error('API response timeout'));
            }, TIMEOUT)
        });

        const resposeLoggedin = await Promise.race([
            fetch(`${SERVER_ISO_URL}${url}`, {
                method: 'POST',
                body: JSON.stringify({
                    ...data,
                    ...(!data.lcAuth && {uamToken})}),
                headers: {
                    "Authorization" : isoToken,
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Origin": "*"
                },
                signal: logSignal // Pass the signal to the fetch options for call outside catch block
            }),
            timeoutPromise
        ])
        return resposeLoggedin;
    }
    catch (err) {
        throw err;
    } 
}

const getISOToken = async (url ,data) => {
    try {
        const controller = new AbortController();
        const signal = controller.signal;
        const timeoutPromise = new Promise((_, reject) => {
            const authPost = setTimeout(() => {
                controller.abort();
                clearTimeout(authPost);
                reject(new Error('API response timeout'));
            }, TIMEOUT)
        });
        const responseToken = await 
            Promise.race([
                fetch(`${SERVER_ISO_URL}${url}`, {
                        method: "POST",
                        body : JSON.stringify(data),
                        headers: {
                            "Content-Type": "application/json",
                            "Access-Control-Allow-Headers": "Content-Type",
                            "Access-Control-Allow-Origin": "*"
                        },
                        signal // Pass the signal to the fetch options for call outside catch block
                    }),
                    timeoutPromise
            ])
        return responseToken;
    }
    catch(err) {
        // console.log('Error', err);
        throw err;
    }
}
// const loggedinUserProcess = async (url, data) => {
//     const uamToken = sessionStorage.getItem(sessionItems.UAMToken) === 'undefined' 
//                     ? undefined 
//                     : sessionStorage.getItem(sessionItems.UAMToken);
//     const isoToken = `Bearer ${sessionStorage.getItem(sessionItems.ISOToken)}`;
//     const controller = new AbortController();
//     const logSignal = controller.signal;
//     const authloggedinTO = setTimeout(() => {
//         controller.abort();
//         clearTimeout(authloggedinTO);
//     }, TIMEOUT);
//     const resposeLoggedin = await fetch(`${SERVER_ISO_URL}${url}`, {
//         method: 'POST',
//         body: JSON.stringify({
//             ...data,
//             uamToken}),
//         headers: {
//             "Authorization" : isoToken,
//             "Content-Type": "application/json",
//             "Access-Control-Allow-Headers": "Content-Type",
//             "Access-Control-Allow-Origin": "*"
//         },
//         signal: logSignal // Pass the signal to the fetch options for call outside catch block
//     });
//     clearTimeout(authloggedinTO);
//     // const {status} = resposeLoggedin;
//     // If not authenticated, then back to login page.
//     // if(status === 401 || status === 502) {
//     //     window.location.href = `/${ERROR_NAME}/${status}`;
//     // } else { 
//     //     return resposeLoggedin;
//     // }
//     return resposeLoggedin;
// }



// const getISOToken = async (url ,data) => {
//     const controller = new AbortController();
//     const signal = controller.signal;
//     const timeoutToken = setTimeout(() => {
//         controller.abort();
//         clearTimeout(timeoutToken);
//         // dispatch(callbackFunction({status: 'fail', messages: ['API Response failed due to timeout'], data}))
//         // throw new Error('API Response failed due to timeout');
//     }, TIMEOUT);
//     const responseToken = await fetch(`${SERVER_ISO_URL}${url}`, {
//         method: "POST",
//         body : JSON.stringify(data),
//         headers: {
//             "Content-Type": "application/json",
//             "Access-Control-Allow-Headers": "Content-Type",
//             "Access-Control-Allow-Origin": "*"
//         },
//         signal // Pass the signal to the fetch options for call outside catch block
//     }); 
//     clearTimeout(timeoutToken); // Clearing the timeout since the request has completed
//     // const {status} = responseToken;
//     // If not authenticated, then back to login page.
//     // if(status === 401 || status === 502) {
//     //     window.location.href = `/${ERROR_NAME}/${status}`;
//     // } else { 
//     //     return responseToken;
//     // }
//     return responseToken;
// }

// const post = async (url, data, transactionType, transactionSubType) => {
//     try {  
//         const isoToken = `Bearer ${sessionStorage.getItem(sessionItems.ISOToken)}`; 
//         const dataBody = {
//             requestHeader : {
//                 ...RequestHeaders,
//                 transactionType,
//                 transactionSubType,
//                 sourceCountry: sessionStorage.getItem(sessionItems.CountryCode),
//                 requestor: sessionStorage.getItem(sessionItems.Username)
//             },
//             requestBody: data
//         } 
//         const controller = new AbortController();
//         const postSignal = controller.signal;
//         const authPost = setTimeout(() => {
//             controller.abort();
//             clearTimeout(authPost);
//         }, TIMEOUT);
//         const responsePost = await fetch(`${SERVER_ISO_URL}${url}`, {
//             method: 'POST',
//             body: JSON.stringify(dataBody),
//             headers : {
//                 "Authorization" : isoToken,
//                 "Content-Type": "application/json",
//                 "Access-Control-Allow-Headers": "Content-Type",
//                 "Access-Control-Allow-Origin": "*"
//             },
//             signal: postSignal // Pass the signal to the fetch options for call outside catch block
//         });
//         clearTimeout(authPost);
//         return responsePost;
//         // const {status} = responsePost;
//         // // If not authenticated, then back to login page.
//         // if(status === 401 || status === 502) {
//         //     sessionClear();

//         //    // history.push(`/${ERROR_NAME}/${status}`);
//         //    //  window.location.href = `/${ERROR_NAME}/${status}`;
//         // } else { 
//         //     return responsePost;
//         // }
//     } catch(err) {
//         console.log('Error', err);
//     }
// }

const post = async (url, data, transactionType, transactionSubType, timeout = TIMEOUT) => {
    try {  
        const isoToken = `Bearer ${sessionStorage.getItem(sessionItems.ISOToken)}`; 
        const dataBody = {
            requestHeader : {
                ...RequestHeaders,
                transactionType,
                transactionSubType,
                sourceCountry: sessionStorage.getItem(sessionItems.CountryCode),
                requestor: sessionStorage.getItem(sessionItems.Username)
            },
            requestBody: data
        } 
        const controller = new AbortController();
        const postSignal = controller.signal;

        // timeout promise for reject after certain time.
        const timoutPromise = new Promise((_, reject) => {
            const authPost = setTimeout(() => {
                controller.abort();
                clearTimeout(authPost);
                reject(new Error('API response timeout'));
            }, timeout)
        });

        // Race between the fetch call and the timeout promise
        const responsePost = await Promise.race([
            fetch(`${SERVER_ISO_URL}${url}`, {
                method: 'POST',
                body: JSON.stringify(dataBody),
                headers : {
                    "Authorization" : isoToken,
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Origin": "*"
                },
                signal: postSignal // Pass the signal to the fetch options for call outside catch block
             }),
             timoutPromise
        ]);
        return responsePost;
    } catch(err) {
       // console.log('Error', err);
       throw err;
    }
}


const get = (url, data, transactionType, transactionSubType) => {
    const isoToken = `Bearer ${sessionStorage.getItem(sessionItems.ISOToken)}`; 
    const dataBody = {
        requestHeader : {
            ...RequestHeaders,
            transactionType,
            transactionSubType,
            sourceCountry: sessionStorage.getItem(sessionItems.CountryCode),
            requestor: sessionStorage.getItem(sessionItems.Username)
        },
        requestBody: data
    }
    return fetch(`${SERVER_ISO_URL}${url}`, {
        method: 'GET',
        body: JSON.stringify(dataBody),
        headers : {
            "Authorization" : isoToken,
            "Content-Type": "application/json",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "*"
        }
    })
}

const head = () => {
    return fetch(`${SERVER_ISO_URL}`, {
        method: "HEAD"
    })
}

export const networkISO = {auth, loggedinUserProcess, post, getISOToken, get, head};