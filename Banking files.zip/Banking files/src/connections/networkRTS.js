import moment from "moment/moment"
import { sessionItems } from "../constants/constants"

const SERVER_RTS_URL = undefined //`${process.env.REACT_APP_RTS_URL}`
// const RTS_SERVICE_URL =  `${SERVER_RTS_URL}/${process.env.REACT_APP_MBB_RTS_SERVICE}`
const RequestHeaders = {
    transactionRefNo: moment(new Date()).format('YYYYMMDDHHmmss'),
    sourceChannel: "ADMIN",
    sourceId: "MAINT",
    sourceCountry: "MY",
    destinationCountry: "MY",
    transactionDate: moment(new Date()).format('YYYYMMDD'),
    transactionTime: moment(new Date()).format('HHmmss'),
    transactionType: "BANLISINQ",
    transactionSubType: "BANLISMY",
    requestedHost: "ADMIN",
    requestor: sessionStorage.getItem(sessionItems.pfNo)
}

const post = (url, transactionType, transactionSubType, data) => {
    const dataBody = {
        requestHeader : {
            ...RequestHeaders,
            transactionType,
            transactionSubType
        },
        requestBody: data
    }
    return fetch(`${SERVER_RTS_URL}${url}`, {
        method: 'POST',
        body: JSON.stringify(dataBody),
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "*",  
        }
    })
}

export const networkRTS = { post }