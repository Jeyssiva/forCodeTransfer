import { flatten } from 'flat';
import { IntlProvider } from 'react-intl';
import { useSelector } from 'react-redux';
import React, { lazy, Suspense } from 'react';
import { useTheme, createTheme, ThemeProvider } from '@mui/material/styles';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';

import './App.css';
import './index.css';
import FallbackPage from './fallbackPage';
import ErrorBoundary from './errorBoundary';
import { localizations } from './features/i18n';
import { FONT_FAMILY } from './constants/constants';
import ErrorPage from './features/errorPage/errorPage';
import ChildErrorPage from './features/errorPage/childErrorPage';
import { CustomerProvider } from './features/customerPaymentData/customerReducer';
import { LOGIN, DASHBOARD, SWIFT, VIEWINTRANSACTIONROUTE, VIEWOUTTRANSACTIONROUTE, CUSTROUTE, BENEROUTE, 
  EXITPAGE, INVALIDSESSION, PENDINGACTIONS, CUSTOMERPAYMENTDATA, BANK_LIST, CREATEPAYMENT, 
  SAVEDTEMPLATES, SUMMARY, ACTIVITYLOG } from './constants/routesURL';

const Home = lazy(() => import("./features/home"));
const Login = lazy(() => import("./features/login/login"));
const Summary = lazy(() => import("./features/inward/summaryMain"));
const ExitScreen = lazy(() => import("./features/logout/exitPage"));
const BankList = lazy(() => import("./features/banklist/bankListMain"));
const AuditLogMain = lazy(() => import("./features/auditLog/auditLogMain"));
const DashboardMain = lazy(() => import("./features/dashboard/dashboardMain"));
const InvalidSession = lazy(() => import("./features/errorPage/invalidSession"));
const CreatePayment = lazy(() => import("./features/createPayment/paymentMain"));
const IncomingMain = lazy(() => import("./features/incomingTransaction/incomingMain"));
const OutgoingMain = lazy(() => import("./features/outgoingTransaction/outgoingMain"));
const CustBeneHome = lazy(() => import("./features/customerPaymentData/custBeneHome"));
const CustomerPaymentMain = lazy(() => import("./features/customerPaymentData/customerDataMain"));
const BeneficiaryPaymentMain = lazy(() => import("./features/customerPaymentData/beneficiaryDataMain"));
const SavedTemplates = lazy(() => import("./features/createPayment/savedTemplates/savedTemplatesMain"));
// const ShowTransTemplate = lazy(() => import("./features/viewTransactions/selectedTransactionTemplate"));
// const PendingActionsHome = lazy(() => import("./features/customerPaymentData/pendingActions/pendingActionsHome"));
const PendingActionsCustomerPayment = lazy(() => import("./features/customerPaymentData/pendingActions/pendingActionsCustomerPayment"));

const LoginPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <Login />
  </Suspense>
)

const HomePage = () => (
  <Suspense fallback={<FallbackPage />}>
    <CustomerProvider>
      <Home />
    </CustomerProvider>
  </Suspense>
)

const DashboardPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <DashboardMain />
  </Suspense>
)

const SummaryPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <Summary />
  </Suspense>
)

const BankListPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <BankList />
  </Suspense>
)

const CreatePaymentPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <CreatePayment />
  </Suspense>
)

const ViewIncomingMainPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <IncomingMain />
  </Suspense>
)

const ViewOutgoingMainPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <OutgoingMain />
  </Suspense>
)

const CustomerPaymentPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <CustomerPaymentMain />
  </Suspense>
)

const AuditLogPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <AuditLogMain />
  </Suspense>
)

const SavedTemplatesMainRoutePage = () => (
  <Suspense fallback={<FallbackPage />}>
    <SavedTemplates />
  </Suspense>
)

const CustBeneHomePage = () => (
  <Suspense fallback={<FallbackPage />}>
    <CustBeneHome />
  </Suspense>
)

const BeneficiaryPaymentPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <BeneficiaryPaymentMain />
  </Suspense>
)

const InvalidSessionPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <InvalidSession />
  </Suspense>
)

const ExitPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <ExitScreen />
  </Suspense>
)

const PendingActionsCustomerPaymentPage = () => (
  <Suspense fallback={<FallbackPage />}>
    <PendingActionsCustomerPayment />
  </Suspense>
)

// const ViewIncomingTransactionRoutes = () => {
//   const routes = useRoutes([
//     {
//       path: "/",
//       element: <IncomingMain />
//     },
//     {
//       path: SHOW_MXTEMPLATE,
//       element: <ShowTransTemplatePage transType={'in'} />
//     }
//   ]);
//   return routes;
// }

// const ViewOutgoingTransactionRoutes = () => {
//   const routes = useRoutes([
//     {
//       path: "/",
//       element: <OutgoingMain />
//     },
//     {
//       path: SHOW_MXTEMPLATE,
//       element: <ShowTransTemplatePage transType={'out'} />
//     }
//   ]);
//   return routes;
// }

const routes = createBrowserRouter([
  {
    path: LOGIN,
    element: <LoginPage />,
    errorElement: <ErrorPage />
  },
  {
    path: '/',
    element: <HomePage />,
    errorElement: <ErrorPage />,
    children: [
      {
        path: DASHBOARD,
        element: <DashboardPage />,
      },
    ]
  },
  {
    path: SWIFT,
    element: <HomePage />,
    errorElement: <ErrorPage />,
    children: [
      {
        path: SUMMARY,
        element: <SummaryPage />
      },
      {
        path: BANK_LIST,
        element: <BankListPage />
      },
      {
        path: VIEWINTRANSACTIONROUTE,
        element: <CustomerProvider><ViewIncomingMainPage /></CustomerProvider>
      },
      {
        path: VIEWOUTTRANSACTIONROUTE,
        element: <CustomerProvider><ViewOutgoingMainPage /></CustomerProvider>,
      },
      {
        path: CREATEPAYMENT,
        element: <CreatePaymentPage />
      },
      {
        path: SAVEDTEMPLATES,
        element: <SavedTemplatesMainRoutePage />
      },
      {
        path: CUSTOMERPAYMENTDATA,
        element: <CustomerProvider><CustBeneHomePage /></CustomerProvider>,
        children:
          [
            {
              path: CUSTROUTE,
              element: <CustomerPaymentPage />
            },
            {
              path: BENEROUTE,
              element: <BeneficiaryPaymentPage />
            },
            {
              path: PENDINGACTIONS,
              element: <PendingActionsCustomerPaymentPage />
            }
          ]
      },
      // {
      //   path: REJECTEDTRANSACTIONS,
      //   element: <RejectedTransactionPage />
      // },
      {
        path: "*",
        element: <ChildErrorPage />
      }
    ]
  },
  {
    path: ACTIVITYLOG,
    element: <HomePage />,
    errorElement: <ErrorPage />,
    children: [
      {
        path: '',
        element: <AuditLogPage />
      },
    ]
  },
  {
    path: INVALIDSESSION,
    element: <InvalidSessionPage />,
    errorElement: <ErrorPage />
  },
  {
    path: EXITPAGE,
    element: <ExitPage />,
    errorElement: <ErrorPage />
  }
])

function App() {
  const theme = useTheme();
  // const navigate = useNavigate();
  const locale = useSelector(state => state.dashboard.locale);
  const customTheme = React.useMemo(
    () => createTheme({
      ...theme,
      typography: {
        allVariants: {
          fontFamily: FONT_FAMILY
        }
      }
    }), [theme]
  );

  // React.useEffect(() => {
  //   const loginStatus = sessionStorage.getItem(sessionItems.LoginStatus);
  //   if (!loginStatus || loginStatus === 'false') {
  //     navigate('/')
  //   }
  // }, [navigate])

  return (
    <ThemeProvider theme={customTheme}>
      <IntlProvider locale={locale} messages={flatten(localizations[locale])}>
        <ErrorBoundary>
          <RouterProvider router={routes} />
        </ErrorBoundary>
      </IntlProvider>
    </ThemeProvider>
  );
}

export default App;
